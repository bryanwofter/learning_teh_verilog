from PyQt5 import QtCore, QtGui, QtWidgets
from qgis.gui import QgisInterface
from typing import Callable, List, Optional

class TRCPackages:

    actions: List[QtWidgets.QWidget]
    iface: QgisInterface

    def __init__(self, iface: QgisInterface) -> None:
        self.iface = iface
        self.actions = []

    def tr(self, message: str) -> str:
        return QtCore.QCoreApplication.translate('TRCPackages', message)

    def initGui(self) -> None:
        """
        Gonna ignore this.
        """

    def unload(self) -> None:
        """
        Gonna ignore this.
        """

    def run(self) -> None:
        """
        Gonna ignore this.
        """

