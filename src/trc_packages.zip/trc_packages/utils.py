
from qgis.core import *
from PyQt5.QtCore import QVariant
from PyQt5.QtWidgets import QMessageBox


def save_and_close(dlg):
    dlg.save()
    close(dlg)


def close(dlg):
    dlg.close()
    dlg.parent().close()


def check_checkbox_choices(box_checked, checkboxes):
    for checkbox in checkboxes:
        if checkbox.isChecked() and checkbox != box_checked:
            box_checked.setChecked(False)
            QMessageBox.information(None, "Invalid Selection", "Cannot select both " + box_checked.text() + " and " + checkbox.text())



def add_audit_options(audit_widget, feature):
    audit_options = ["", "Needs Collected", "Review", "Collected"]
    [audit_widget.addItem(audit_option, audit_option) for audit_option in audit_options]
    if type(feature['AUDIT_STATUS']) != QVariant:
        audit_widget.setCurrentText(feature['AUDIT_STATUS'])


def wait_for_dialog_result(dlg):
    '''
    Helper for new_ui function. Sets dialog to modal and starts.
    :param dlg:
    :return: True if ok was pressed. False if not.
    '''
    dlg.setModal(True)
    return dlg.exec_()


def nullSafeKey(key, dict):
    if key in dict.keys():
        return dict[key]
    else:
        return ''

def null_safe_keys(keys, dict):
    values = []
    for key in keys:
        values.append(nullSafeKey(key, dict))
    return values


def nullSafe(items):
    item_list = []
    for item in items:
        if type(item) == QVariant:
            item_list.append('')
        else:
            item_list.append(item)
    return item_list


def is_null(value):
    if value is None or isinstance(value, QVariant):
        return True
    else:
        return False
        
def check_field_exists(layer, field_name, field_type=QVariant.String):
    '''
    Checks a field exists in a table and adds the field if it doesn't. Used when updating a db.
    :param layer: The QGSVectorLayer to check
    :param field_name: Field to check
    :param field_type: Type of field to add
    '''
    fields = layer.fields()
    field_names = [field.name() for field in fields]
    if field_name not in field_names:
        in_edit = not bool(layer.startEditing())
        pr = layer.dataProvider()
        pr.addAttributes([QgsField(field_name, field_type)])
        layer.updateFields()
        layer.commitChanges()
        if in_edit:
            layer.startEditing()
