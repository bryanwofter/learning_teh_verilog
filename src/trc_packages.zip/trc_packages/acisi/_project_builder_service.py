from PyQt5 import QtCore
from qgis.core import QgsApplication, QgsProject  # type: ignore
from trc_packages.acisi import _configuration, _project_service, constants
from trc_packages.acisi.utils import _sync_usage_frequency as suf
from trc_packages.asynclib import step, total_steps, TrcService
from trc_packages.core.data import ForeignMapping, ForeignReference, ColumnReference
from trc_packages.core.features import BasicVectorObject
from trc_packages.debugging import printtodebugger
from trc_packages.symbology import PointSymbolType, SymbolGeneratorService
from typing import Any, Dict, List, NamedTuple, Optional, Tuple
import os
import shutil
import sqlite3


class ProjectBuilderService(_project_service.ProjectService[bool]):
    """Generates a new project file for the ACISI application."""

    project_generating: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='projectGenerating')
    project_generated: QtCore.pyqtSignal = QtCore.pyqtSignal([str], name='projectGenerated', arguments=['project_file'])  # type: ignore

    validation_messages: List[str] = None
    template_project_path: str = None
    auxiliary_layer_sql_files: Dict[str, str] = None
    mapping: ForeignMapping = None
    id_column_mapping: Dict[str, Tuple[List[str], ...]] = None
    project_generation: bool = False

    @property
    def template_project_file(self) -> str:
        return os.path.join(self.template_project_path, 'ACISI_v2_1.qgz')

    @printtodebugger
    def __init__(self, db_path: str, output_project_path: str, auxiliary_layer_sql_files: Dict[str, str], mapping: ForeignMapping,
                 id_column_mapping: Dict[str, Tuple[List[str], ...]], parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)
        self.db_path = db_path
        self.validation_messages = []
        self.output_project_path = output_project_path
        self.total_steps = total_steps(type(self))
        self.step_size = 1 / self.total_steps
        self.auxiliary_layer_sql_files = auxiliary_layer_sql_files
        self.mapping = mapping
        self.id_column_mapping = id_column_mapping

    @printtodebugger
    def _run(self) -> bool:
        """Generates the project file for ACISI."""
        self.project_generation = False
        self._progress = 0.0
        self.validation_messages.clear()

        if not os.path.isfile(self.output_project_file):
            if self.project_guid is None:
                self.validation_messages.append('Project GUID is required.')
            if self.project_name is None:
                self.validation_messages.append('Project name is required.')
            if self.project_id is None:
                self.validation_messages.append('Project ID is required.')
            if self.company_name is None:
                self.validation_messages.append('Company name is required.')
        if self.user_name is None:
            self.validation_messages.append('User name is required.')
        if self.db_path is None:
            self.validation_messages.append('DB path is required.')
        elif not os.path.isdir(self.db_path):
            self.validation_messages.append('DB path does not exist.')
        elif not os.path.isfile(self.db_file):
            self.validation_messages.append('DB does not exist.')
        if self.output_project_path is None:
            self.validation_messages.append('Output project path is required.')

        if any(self.validation_messages):
            return False

        if self.__correct_datetime_column_format():
            self._progress += self.step_size
        else:
            return False

        if self.__synchronize_usage_frequency():
            self._progress += self.step_size
        else:
            return False

        if self.__ensure_output_project_path_exists():
            self._progress += self.step_size
        else:
            return False

        if self.__create_project():
            self._progress += self.step_size
        else:
            return False

        if self.project_generation:
            self.project_generating.emit()

            if self.__create_db_indexes():
                self._progress += self.step_size
            else:
                return False

            if self.__create_db_triggers():
                self._progress += self.step_size
            else:
                return False

            if not self.__create_id_column_triggers():
                return False

            if not self.__create_auxiliary_views():
                return False

        self.project_generated[str].emit(self.output_project_file)  # type: ignore

        return not any(self.validation_messages)

    @step
    @printtodebugger
    def __correct_datetime_column_format(self) -> bool:
        """Converts the datetime columns of the history tables into the correct (hopefully) format."""
        with sqlite3.connect(self.db_file) as sqlite:  # type: sqlite3.Connection
            cursor: sqlite3.Cursor = sqlite.cursor()

            cursor.executescript(constants.CORRECT_DATETIME_COLUMNS)

        return not any(self.validation_messages)

    @step
    @printtodebugger
    def __synchronize_usage_frequency(self) -> bool:
        """Synchronizes the usage frequency of all project types within this project."""
        if not suf.sync_usage_frequency(db_file=self.db_file, project_guid=self.project_guid):
            self.validation_messages.append('Could not populate project usage frequencies.')

        return not any(self.validation_messages)

    @step
    @printtodebugger
    def __ensure_output_project_path_exists(self) -> bool:
        """Creates the output project path if one doesn't already exist."""
        if not os.path.isdir(self.output_project_path):
            try:
                os.mkdir(self.output_project_path)
                if not os.path.isdir(self.output_project_path):
                    self.validation_messages.append('Project output path could not be created.')
            except FileExistsError:
                if not os.path.isdir(self.output_project_path):
                    self.validation_messages.append('A file exists and prevented the creation of the output project path.')
            except BaseException as e:
                self.validation_messages.append(f"{e}")

        return not any(self.validation_messages)

    @step
    @printtodebugger
    def __create_project(self) -> bool:
        """Copies the template project to the new project directory."""
        project: QgsProject
        if not os.path.isfile(self.output_project_file):
            try:
                sqlite: sqlite3.Connection
                with sqlite3.connect(self.history_db_file) as sqlite:
                    sqlite.executescript(constants.CREATE_HISTORY_TABLE).close()
                    sqlite.executescript(constants.CREATE_SYNC_HISTORY_VIEW).close()
                project = QgsProject.instance()
                project.setFileName(self.output_project_file)
                project.write()
                self.project_generation = True
            except FileExistsError:
                pass
            except BaseException as e:
                self.validation_messages.append(f"{e}")
        if self.project_generation:
            if os.path.isfile(self.output_project_file):
                project = QgsProject.instance()
                project.setFileName(self.output_project_file)
                project.read()
                self.config.db_file = self.db_file
                self.config.company_name = self.company_name
                self.config.project_file = self.output_project_file
                self.config.project_name = self.project_name
                self.config.project_id = self.project_id
                self.config.project_guid = self.project_guid
                self.config.user_name = self.user_name
                self.config.logging_db_file = f"{os.path.splitext(self.db_file)[0]}_history.sqlite"
                project.write()
            else:
                self.validation_messages.append(f"Could not create a project at {self.output_project_file}.")

        return not any(self.validation_messages)

    @step
    @printtodebugger
    def __create_db_indexes(self) -> bool:
        """Generates the database indexes for the new project."""
        with sqlite3.connect(self.db_file) as sqlite:  # type: sqlite3.Connection
            cursor: sqlite3.Cursor = sqlite.cursor()

            try:
                cursor.executescript(self.mapping.index_stmts())
            except sqlite3.OperationalError as e:
                pass
            except BaseException as e:
                self.validation_messages.append(f"{e}")

            try:
                cursor.executescript("CREATE UNIQUE INDEX IF NOT EXISTS geometry_columns_f_table_name ON geometry_columns(f_table_name);")
            except sqlite3.OperationalError:
                pass
            except BaseException as e:
                self.validation_messages.append(f"{e}")

        return not any(self.validation_messages)

    @step
    @printtodebugger
    def __create_db_triggers(self) -> bool:
        """Generates the database triggers for the new project."""
        with sqlite3.connect(self.db_file) as sqlite:  # type: sqlite3.Connection
            cursor: sqlite3.Cursor = sqlite.cursor()

            try:
                cursor.executescript(self.mapping.trigger_stmts())
            except sqlite3.OperationalError as e:
                pass
            except BaseException as e:
                self.validation_messages.append(f"{e}")

        return not any(self.validation_messages)

    @step
    @printtodebugger
    def __create_id_column_triggers(self) -> bool:
        """Generates the database triggers for the ID columns of the new project."""
        step_size: float = self.step_size / len(self.id_column_mapping.items())

        with sqlite3.connect(self.db_file) as sqlite:  # type: sqlite3.Connection
            cursor: sqlite3.Cursor = sqlite.cursor()

            for table, properties in self.id_column_mapping.items():
                if self.__create_id_trigger(cursor, table, properties[0][1], properties[0][0], properties[1]):
                    self._progress += step_size
                else:
                    break

        return not any(self.validation_messages)

    @step
    @printtodebugger
    def __create_auxiliary_views(self) -> bool:
        """Creates all auxiliary layer views and layers."""
        step_size: float = self.step_size / len(self.auxiliary_layer_sql_files)

        with sqlite3.connect(self.db_file) as sqlite:  # type: sqlite3.Connection
            cursor: sqlite3.Cursor = sqlite.cursor()

            for layer, file in self.auxiliary_layer_sql_files.items():  # type: Tuple[str, str]
                view_name: str = os.path.splitext(os.path.basename(file))[0]

                try:
                    with open(file) as f:
                        cursor.executescript(f.read())
                        self._progress += step_size
                except sqlite3.OperationalError as e:
                    pass
                except BaseException as e:
                    self.validation_messages.append(f"{e}")
                    break

        return not any(self.validation_messages)

    @printtodebugger
    def __create_id_trigger(self, cursor: sqlite3.Cursor, table_name: str, guid_column: str, project_guid_column: str, id_columns: List[str]) -> bool:
        try:
            cursor.execute(self.__create_id_update_trigger(table_name, guid_column, project_guid_column, id_columns))
        except sqlite3.OperationalError as e:
            pass
        except BaseException as e:
            self.validation_messages.append(f"{e}")
            return False
        try:
            cursor.execute(self.__create_id_insert_trigger(table_name, guid_column, project_guid_column, id_columns))
        except sqlite3.OperationalError as e:
            pass
        except BaseException as e:
            self.validation_messages.append(f"{e}")
            return False
        return True

    @printtodebugger
    def __create_id_concat_stmt(self, column: str, guid_column: str, project_guid_column: str) -> str:
        return f"{column} = {project_guid_column} || ':' || {guid_column}"

    @printtodebugger
    def __create_id_concat_stmts(self, guid_column: str, project_guid_column: str, id_columns: List[str]) -> str:
        return ",\n\t\t".join(self.__create_id_concat_stmt(c, guid_column, project_guid_column) for c in id_columns)

    @printtodebugger
    def __create_id_update_stmt(self, table: str, guid_column: str, project_guid_column: str, id_columns: List[str]) -> str:
        return f'''
    UPDATE {table}
    SET {self.__create_id_concat_stmts(guid_column, project_guid_column, id_columns)}
    WHERE {table}.{guid_column} = new.{guid_column} AND
        {table}.{project_guid_column} = new.{project_guid_column};
'''

    @printtodebugger
    def __create_id_update_trigger(self, table: str, guid_column: str, project_guid_column: str, id_columns: List[str]) -> str:
        return f'''
CREATE TRIGGER IF NOT EXISTS {table}_after_update_of_{guid_column}_or_{project_guid_column}
AFTER UPDATE OF {guid_column}, {project_guid_column}
ON {table}
FOR EACH ROW BEGIN
{self.__create_id_update_stmt(table, guid_column, project_guid_column, id_columns)}
END;
'''

    @printtodebugger
    def __create_id_insert_trigger(self, table: str, guid_column: str, project_guid_column: str, id_columns: List[str]) -> str:
        return f'''
CREATE TRIGGER IF NOT EXISTS {table}_after_insert_on_ids
AFTER INSERT
ON {table}
FOR EACH ROW BEGIN
{self.__create_id_update_stmt(table, guid_column, project_guid_column, id_columns)}
END;
'''

