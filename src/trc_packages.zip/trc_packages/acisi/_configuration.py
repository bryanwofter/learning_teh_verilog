from trc_packages.core.json_handlers import TrcJSONEncoder, TrcJSONDecoder
from trc_packages.core.settings import setting, dict_setting, list_setting, ProjectSettings
from typing import Dict, Optional
import json


class Configuration(ProjectSettings):
    """Stores the settings of the project in a singleton."""
    plugin_name = "acisi"
    db_file = setting[str]('db_file')
    logging_db_file = setting[str]('logging_db_file')
    company_name = setting[str]('company_name')
    project_file = setting[str]('project_file')
    project_name = setting[str]('project_name')
    project_id = setting[str]('project_id')
    project_guid = setting[str]('project_guid')
    user_name = setting[str]('user_name')
    previous_pole = setting[str]('previous_pole')

    # These properties aren't stored. Instead, they're loaded whenever the plugin is loaded with initial data.
    base_type: str = None
    base_url: str = None
    mrisa_user: str = None
    mrisa_pass: str = None
    db_path: str = None
    temp_file_name: str = None
    xml_path: str = None
