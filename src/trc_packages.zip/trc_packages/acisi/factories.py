from PyQt5 import QtCore
from trc_packages.acisi import datamodels, viewmodels, vectors
from trc_packages.core.features import make_guid
from trc_packages.debugging import printtodebugger
from typing import Callable, Optional, Union
AttacheeUnion = Union[viewmodels.AttacheeView, datamodels.AttacheeFeature, datamodels.EntityFeature]
PropertyChangedSlot = Callable[[str, Optional[object], Optional[object]], None]


@printtodebugger
def _resolve_entity(attachee: AttacheeUnion) -> datamodels.EntityFeature:
    """
    Resolves the given AttacheeUnion back to its EntityFeature.
    :param attachee: The attachee to resolve the EntityFeature of.
    """
    if not isinstance(attachee, datamodels.EntityFeature):
        attachee = vectors.EntityVector().by_guid(attachee.entity_guid)  # type: ignore

    return attachee


@printtodebugger
def create_attachment_view(pole: datamodels.PoleFeature, attachee: AttacheeUnion, *,
                           attachment: Optional[viewmodels.AttachmentView]=None,
                           on_property_changed: Optional[PropertyChangedSlot]=None,
                           parent: Optional[QtCore.QObject]=None) -> viewmodels.AttachmentView:
    """
    Creates an AttachmentView if attachment is None and attaches the provided on_property_changed listener.
    :param pole: The pole that the AttachmentView will be associated to.
    :param attachee: The attachee that the AttachmentView will be associated to.
    :param attachment: The existing AttachmentView if one is available.
    :param on_property_changed: The slot to attach to the propertyChanged signal of the AttachmentView.
    :param parent: The optional parent of the AttachmentView.
    """
    attachee_guid: str = attachee.guid  # type: ignore
    attachee = _resolve_entity(attachee)

    if attachment is None:
        attachment = viewmodels.AttachmentView(parent=parent,
                                               attachee_guid=attachee_guid,
                                               attachee_display_name=attachee.display_name,
                                               attachee_name=attachee.name,
                                               project_guid=pole.project_guid,
                                               pole_guid=pole.guid,
                                               guid=make_guid())
    elif attachment.parent() is None:
        attachment.setParent(parent)

    if on_property_changed is not None:
        attachment.property_changed.connect(on_property_changed)

    return attachment


@printtodebugger
def create_transfer_step_view(pole: datamodels.PoleFeature, attachee: AttacheeUnion, *,
                              transfer_step: Optional[viewmodels.TransferStepView]=None,
                              on_property_changed: Optional[PropertyChangedSlot]=None,
                              parent: Optional[QtCore.QObject]=None) -> viewmodels.TransferStepView:
    """
    Creates a TransferStepView if transfer_step is None and attaches the provided on_property_changed listener.
    :param pole: The pole that the TransferStepView will be associated to.
    :param attachee: The attachee that the TransferStepView will be associated to.
    :param transfer_step: The existing TransferStepView if one is available.
    :param on_property_changed: The slot to attach to the propertyChanged signal of the TransferStepView.
    :param parent: The optional parent of the TransferStepView.
    """
    attachee = _resolve_entity(attachee)

    if transfer_step is None:
        transfer_step = viewmodels.TransferStepView(parent=parent,
                                                    attachee_entity_company_name=attachee.company_name,
                                                    attachee_entity_display_name=attachee.display_name,
                                                    attachee_entity_name=attachee.name,
                                                    project_guid=pole.project_guid,
                                                    pole_guid=pole.guid,
                                                    guid=make_guid())
    elif transfer_step.parent() is None:
        transfer_step.setParent(parent)

    if on_property_changed is not None:
        transfer_step.property_changed.connect(on_property_changed)

    return transfer_step


@printtodebugger
def create_violation_view(pole: datamodels.PoleFeature, attachee: AttacheeUnion, *,
                          violation: Optional[viewmodels.ViolationView]=None,
                          on_property_changed: Optional[PropertyChangedSlot]=None,
                          parent: Optional[QtCore.QObject]=None) -> viewmodels.ViolationView:
    """
    Creates a ViolationView if violation is None and attaches the provided on_property_changed listener.
    :param pole: The pole that the ViolationView will be associated to.
    :param attachee: The attachee that the ViolationView will be associated to.
    :param violation: The existing ViolationView if one is available.
    :param on_property_changed: The slot to attach to the propertyChanged signal of the ViolationView.
    :param parent: The optional parent of the ViolationView.
    """
    attachee_guid: str = attachee.guid  # type: ignore
    attachee = _resolve_entity(attachee)

    if violation is None:
        violation = viewmodels.ViolationView(parent=parent,
                                             attachee_guid=attachee_guid,
                                             attachee_display_name=attachee.display_name,
                                             attachee_name=attachee.name,
                                             project_guid=pole.project_guid,
                                             pole_guid=pole.guid,
                                             guid=make_guid())
    elif violation.parent() is None:
        violation.setParent(parent)

    if on_property_changed is not None:
        violation.property_changed.connect(on_property_changed)

    return violation

