DELETE_FROM_LOCAL: str = """
DELETE FROM "local"."{local}";
"""


INSERT_INTO_LOCAL: str = """
INSERT INTO "local"."{local}" ({local_columns})
SELECT {remote_columns}
FROM "remote"."{remote}";
"""


UPSERT_INTO_LOCAL: str = """
INSERT INTO "local"."{local}" ({local_columns})
SELECT {remote_columns}
FROM "remote"."{remote}"
WHERE true  --  Required to prevent a syntax error due to the ON CONFLICT clause
ON CONFLICT ("local"."{local}".[guid])
DO UPDATE
SET ({local_columns}) = ({local_columns});
"""


ATTACH_DATABASES: str = """
ATTACH {} AS "local";
ATTACH {} AS "remote";
"""


CORRECT_DATETIME_COLUMNS: str = '''
UPDATE "acisiuserhistory"
SET "date" = datetime("date");
UPDATE "acisiqc"
SET "qcdate" = datetime("qcdate");
UPDATE "acisigpshistory"
SET "date" = datetime("date");
UPDATE "acisiexternaldata"
SET "date" = datetime("date");
'''


CREATE_USER_HISTORY_VIEWS: str = '''
CREATE TEMPORARY VIEW IF NOT EXISTS "local_user_history"
AS SELECT "poleguid", "date" FROM "local"."acisiuserhistory"
GROUP BY "poleguid"
HAVING MAX(datetime("date"));

CREATE TEMPORARY VIEW IF NOT EXISTS "remote_user_history"
AS SELECT "poleguid", "date" FROM "remote"."acisiuserhistory"
GROUP BY "poleguid"
HAVING MAX(datetime("date"));
'''

CREATE_HISTORY_TABLE: str = '''
CREATE TABLE IF NOT EXISTS "acisihistory" (
    "id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    "type" VARCHAR(255) NOT NULL,
    "action" VARCHAR(20) CHECK("action" IN ('insert', 'update', 'delete', 'sync')),
    "date" VARCHAR(25) CHECK(datetime("date") IS NOT NULL),
    "project_guid" VARCHAR(36) NOT NULL,
    "object_guid" VARCHAR(36) NOT NULL,
    "json_blob" JSON NOT NULL,
    "synced" BOOLEAN DEFAULT(0) CHECK("synced" in (0, 1))
);

CREATE UNIQUE INDEX IF NOT EXISTS "acisihistory_project_guid_date_type_object_guid" ON "acisihistory" ("project_guid", datetime("date"), "type", "object_guid");
'''

CREATE_SYNC_HISTORY_VIEW: str = '''
CREATE VIEW IF NOT EXISTS "sync_history"
AS SELECT "project_guid", "type", "object_guid", (SELECT "action"
                                                  FROM "acisihistory" AS "subhistory"
                                                  WHERE "subhistory"."project_guid" = "history"."project_guid" AND
                                                        "subhistory"."type" = "history"."type" AND
                                                        "subhistory"."object_guid" = "history"."object_guid" AND
                                                        "subhistory"."synced" = 0
                                                  ORDER BY CASE WHEN "subhistory"."action" IN ('delete', 'insert') THEN 0
                                                                ELSE 1
                                                           END,
                                                           datetime("date") DESC
                                                  LIMIT 1) AS "action"
FROM "acisihistory" AS "history"
WHERE "synced" = 0
GROUP BY "project_guid", "type", "object_guid";
'''

SELECT_USER_HISTORY_CHANGES: str = """
SELECT "poleguid",
       "date",
       (SELECT "date" FROM "{other_name}" AS "o" WHERE "o"."poleguid" = "t"."poleguid" LIMIT 1) AS "compared_date",
       '{target}' AS "type",
       CASE
       WHEN EXISTS (SELECT * FROM "{other_name}" AS "o" WHERE "o"."poleguid" = "t"."poleguid" AND datetime("o"."date") > datetime("t"."date"))
       THEN CASE
            WHEN EXISTS (SELECT * FROM "{other}"."acisipole" AS "p" WHERE "p"."poleguid" = "t"."poleguid")
            THEN 'OTHER_MODIFIED'
            ELSE 'OTHER_REMOVED' END
       WHEN EXISTS (SELECT * FROM "{other_name}" AS "o" WHERE "o"."poleguid" = "t"."poleguid" AND datetime("o"."date") < datetime("t"."date"))
       THEN CASE
            WHEN EXISTS (SELECT * FROM "{target}"."acisipole" AS "p" WHERE "p"."poleguid" = "t"."poleguid")
            THEN 'MODIFIED'
            ELSE 'REMOVED' END
       WHEN NOT EXISTS (SELECT * FROM "{other_name}" AS "o" WHERE "o"."poleguid" = "t"."poleguid")
       THEN 'NEW'
       ELSE 'UNCHANGED' END AS "action"
FROM "{target_name}" AS "t"
WHERE NOT EXISTS (SELECT * FROM "{other_name}" AS "o" WHERE "o"."poleguid" = "t"."poleguid" AND datetime("o"."date") = datetime("t"."date"));
"""

