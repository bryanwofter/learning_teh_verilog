from typing import Any, Optional
from trc_packages.acisi import _pole_status as ps
from trc_packages.core.features import (BasicFeatureObject, FeatureItemProvider, BoolFeatureItem, FloatFeatureItem,
                                        IntFeatureItem, StrFeatureItem, DateTimeFeatureItem, EnumFeatureItem)
from trc_packages.core.features.factories import (property_item, bool_item, datetime_item, enum_item, float_item,
                                                  int_item, str_item)
from trc_packages.decorators import deprecated
from trc_packages.debugging import printtodebugger
from xml.etree import ElementTree as etree
import base64
import binascii


class ACISIObjectGuidFeature(FeatureItemProvider):
    object_guid: StrFeatureItem = str_item('id')


class ACISIGmlFeature(FeatureItemProvider):
    gml_guid: StrFeatureItem = str_item('gml_id')


class ACISIPositionFeature(FeatureItemProvider):
    latitude: FloatFeatureItem = float_item('lat')
    longitude: FloatFeatureItem = float_item('long')


class ACISIPoleFeature(FeatureItemProvider):
    pole_project_guid: StrFeatureItem = str_item('pole')
    pole_guid: StrFeatureItem = str_item('poleguid')


class ACISIProjectFeature(FeatureItemProvider):
    project_guid: StrFeatureItem = str_item('projectguid')


class ACISINamedFeature(FeatureItemProvider):
    name: StrFeatureItem = str_item()
    display_name: StrFeatureItem = str_item('displayname')


class ACISIDescribedFeature(FeatureItemProvider):
    description: StrFeatureItem = str_item()


class ACISIFrequencyFeature(FeatureItemProvider):
    frequency: IntFeatureItem = int_item()


class ACISIEntityFeature(FeatureItemProvider):
    entity_guid: StrFeatureItem = str_item('entityguid')


class ACISIProjectSettingFeature(ACISIGmlFeature, ACISIProjectFeature, ACISIFrequencyFeature):
    @printtodebugger
    def __lt__(self, other: object):
        if isinstance(other, type(self)):
            return (self.frequency, self.qgs_id) < (other.frequency, other.qgs_id)  # type: ignore
        else:
            return NotImplemented

    @printtodebugger
    def __lte__(self, other: object):
        if isinstance(other, type(self)):
            return (self.frequency, self.qgs_id) <= (other.frequency, other.qgs_id)  # type: ignore
        else:
            return NotImplemented

    @printtodebugger
    def __gt__(self, other: object):
        if isinstance(other, type(self)):
            return (self.frequency, self.qgs_id) > (other.frequency, other.qgs_id)  # type: ignore
        else:
            return NotImplemented

    @printtodebugger
    def __gte__(self, other: object):
        if isinstance(other, type(self)):
            return (self.frequency, self.qgs_id) >= (other.frequency, other.qgs_id)  # type: ignore
        else:
            return NotImplemented


class ACISITypeFeature(ACISIGmlFeature, ACISIDescribedFeature, ACISINamedFeature):
    pass


class AddressFeature(ACISIGmlFeature, ACISIObjectGuidFeature, ACISIPositionFeature, ACISIProjectFeature, ACISIPoleFeature, BasicFeatureObject):
    hash_field: str = 'addressguid'

    guid: StrFeatureItem = str_item('addressguid')
    house_no: StrFeatureItem = str_item('housenum')
    street: StrFeatureItem = str_item()
    notes: StrFeatureItem = str_item()
    place: StrFeatureItem = str_item()
    county: StrFeatureItem = str_item()
    state: StrFeatureItem = str_item()


class AttacheeFeature(ACISIGmlFeature, ACISIObjectGuidFeature, ACISIPositionFeature, ACISIPoleFeature, ACISIProjectFeature, BasicFeatureObject):
    hash_field: str = 'attacheeguid'

    display_name: StrFeatureItem = str_item('attacheedisplayname')
    entity_guid: StrFeatureItem = str_item('attacheeentityguid')
    guid: StrFeatureItem = str_item('attacheeguid')
    name: StrFeatureItem = str_item('attacheename')
    height_location: FloatFeatureItem = float_item('heightlocation')
    height_order: IntFeatureItem = int_item('heightorder')


class AttachmentFeature(ACISIGmlFeature, ACISIObjectGuidFeature, ACISIPositionFeature, ACISIPoleFeature, ACISIProjectFeature, BasicFeatureObject):
    hash_field: str = 'attachmentguid'

    attachee: StrFeatureItem = str_item('attachee')
    attachee_guid: StrFeatureItem = str_item('attacheeguid')
    attachee_display_name: StrFeatureItem = str_item('attacheedisplayname')
    attachee_entity_guid: StrFeatureItem = str_item('attacheeentityguid')
    attachee_name: StrFeatureItem = str_item('attacheename')
    guid: StrFeatureItem = str_item('attachmentguid')
    height_location: FloatFeatureItem = float_item('attachmentheightlocation')
    height_order: IntFeatureItem = int_item('attachmentheightorder')
    type_guid: StrFeatureItem = str_item('attachmenttypeguid')
    type_display_name: StrFeatureItem = str_item('typedisplayname')
    type_name: StrFeatureItem = str_item('typename')


class AttachmentTypeFeature(ACISITypeFeature, BasicFeatureObject):
    hash_field: str = 'attachmenttypeguid'

    guid: StrFeatureItem = str_item('attachmenttypeguid')


class DescriptorFeature(ACISIGmlFeature, ACISIProjectFeature, ACISIObjectGuidFeature, ACISIPositionFeature, ACISINamedFeature, BasicFeatureObject):
    hash_field: str = 'descriptorguid'

    pole_category_name: StrFeatureItem = str_item('categoryname')
    guid: StrFeatureItem = str_item('descriptorguid')
    pole_project_guid: StrFeatureItem = str_item('pole')
    pole_guid: StrFeatureItem = str_item('parentguid')
    pole_category_guid: StrFeatureItem = str_item('polecategoryguid')
    quantity: IntFeatureItem = int_item('qty')
    type_guid: StrFeatureItem = str_item('typeguid')
    value: StrFeatureItem = str_item()


class DescriptorTypeFeature(ACISITypeFeature, BasicFeatureObject):
    hash_field: str = 'descriptorguid'

    pole_category_name: StrFeatureItem = str_item('categoryname')
    guid: StrFeatureItem = str_item('descriptorguid')
    pole_category_guid: StrFeatureItem = str_item('polecategoryguid')


class EntityFeature(ACISIGmlFeature, ACISIDescribedFeature, ACISINamedFeature, BasicFeatureObject):
    hash_field: str = 'entityguid'

    category_display_name: StrFeatureItem = str_item('categorydisplayname')
    category_display_order: IntFeatureItem = int_item('categorydisplayorder')
    category_guid: StrFeatureItem = str_item('categoryguid')
    category_name: StrFeatureItem = str_item('categoryname')
    company_name: StrFeatureItem = str_item('companyname')
    guid: StrFeatureItem = str_item('entityguid')
    treatment_category_display_name: StrFeatureItem = str_item('treatcategorydisplayname')
    treatment_category_display_order: IntFeatureItem = int_item('treatcategorydisplayorder')
    treatment_category_guid: StrFeatureItem = str_item('treatcategoryguid')
    treatment_category_name: StrFeatureItem = str_item('treatcategoryname')


class EntityCategoryFeature(ACISITypeFeature, BasicFeatureObject):
    hash_field: str = 'entitycategoryguid'

    display_order: IntFeatureItem = int_item('displayorder')
    guid: StrFeatureItem = str_item('entitycategoryguid')


class ExternalDataFeature(ACISIGmlFeature, ACISIEntityFeature, BasicFeatureObject):
    hash_field: str = 'dataguid'

    guid: StrFeatureItem = str_item('dataguid')
    date: DateTimeFeatureItem = datetime_item()
    descriptor_display_name: StrFeatureItem = str_item('descriptordisplayname')
    descriptor_name: StrFeatureItem = str_item('descriptorname')
    descriptor_type_guid: StrFeatureItem = str_item('descriptortypeguid')
    entity_display_name: StrFeatureItem = str_item('entitydisplayname')
    entity_name: StrFeatureItem = str_item('entityname')
    parent_guid: StrFeatureItem = str_item('parentguid')
    value: StrFeatureItem = str_item()


class GpsHistoryFeature(ACISIGmlFeature, ACISIObjectGuidFeature, ACISIPositionFeature, ACISIProjectFeature, BasicFeatureObject):
    hash_field: str = 'historyguid'

    gps_satellite: StrFeatureItem = str_item('gpssat')
    gps_time: StrFeatureItem = str_item('gpstime')
    hdop: FloatFeatureItem = float_item()
    pdop: FloatFeatureItem = float_item()
    vdop: FloatFeatureItem = float_item()
    altitude: FloatFeatureItem = float_item()
    date: DateTimeFeatureItem = datetime_item()
    fix_quality: IntFeatureItem = int_item('fixquality')
    ground_speed: FloatFeatureItem = float_item('groundspeed')
    guid: StrFeatureItem = str_item('historyguid')
    htabvgeoid: FloatFeatureItem = float_item()
    satellite_no: IntFeatureItem = int_item('numsatellites')
    pole_guid: StrFeatureItem = str_item('poleguid')
    track_made_good: FloatFeatureItem = float_item('trackmadegood')
    user_history_guid: StrFeatureItem = str_item('userhistoryguid')


class PoleFeature(ACISIGmlFeature, ACISIPositionFeature, ACISIProjectFeature, ACISIObjectGuidFeature, BasicFeatureObject):
    hash_field: str = 'poleguid'

    client_id: IntFeatureItem = int_item('clientpoleid')
    in_client_db: BoolFeatureItem = bool_item('inclientdb')
    owner_guid: StrFeatureItem = str_item('owner')
    owner_company_name: StrFeatureItem = str_item('ownercompanyname')
    owner_display_name: StrFeatureItem = str_item('ownerdisplayname')
    guid: StrFeatureItem = str_item('poleguid')
    status: EnumFeatureItem[ps.PoleStatus, str] = enum_item('status', ps.PoleStatus)
    x: FloatFeatureItem = float_item()
    y: FloatFeatureItem = float_item()
    notes: StrFeatureItem = str_item()


class PoleCategoryFeature(ACISIGmlFeature, ACISIDescribedFeature, BasicFeatureObject):
    hash_field: str = 'polecategoryguid'

    name: StrFeatureItem = str_item()
    guid: StrFeatureItem = str_item('polecategoryguid')


class ProjectFeature(ACISIGmlFeature, ACISIDescribedFeature, BasicFeatureObject):
    hash_field: str = 'projectguid'

    client_company_name: StrFeatureItem = str_item('clientcompanyname')
    client_display_name: StrFeatureItem = str_item('clientdisplayname')
    client_guid: StrFeatureItem = str_item('clientguid')
    client_name: StrFeatureItem = str_item('clientname')
    name: StrFeatureItem = str_item('projectname')
    type: StrFeatureItem = str_item('projecttype')
    type_guid: StrFeatureItem = str_item('projecttypeguid')
    guid: StrFeatureItem = str_item('projectguid')


class ProjectAttacheeFeature(ACISIProjectSettingFeature, ACISIEntityFeature, BasicFeatureObject):
    hash_field: str = 'projectattacheeguid'

    guid: StrFeatureItem = str_item('projectattacheeguid')


class ProjectAttachmentTypeFeature(ACISIProjectSettingFeature, BasicFeatureObject):
    hash_field: str = 'projattachtypeguid'

    attachment_type_guid: StrFeatureItem = str_item('attachmenttypeguid')
    guid: StrFeatureItem = str_item('projattachtypeguid')


class ProjectClientOwnerFeature(BasicFeatureObject):
    hah_field: str = 'EntityGUID'

    project_guid: StrFeatureItem = str_item('projectguid')
    client_owner: StrFeatureItem = str_item('clientowner')
    entity_guid: StrFeatureItem = str_item('entityguid')


class ProjectDescriptorTypeFeature(ACISIProjectSettingFeature, BasicFeatureObject):
    hash_field: str = 'projectdescriptorguid'

    collect_additional_data: BoolFeatureItem = bool_item('collectadditional')
    descriptor_guid: StrFeatureItem = str_item('descriptorguid')
    guid: StrFeatureItem = str_item('projectdescriptorguid')


class ProjectPoleOwnerFeature(ACISIProjectSettingFeature, ACISIEntityFeature, BasicFeatureObject):
    hash_field: str = 'projectpoleownerguid'

    guid: StrFeatureItem = str_item('projectpoleownerguid')


class ProjectTransferTypeFeature(ACISIProjectSettingFeature, BasicFeatureObject):
    hash_field: str = 'projecttransfertypeguid'

    guid: StrFeatureItem = str_item('projecttransfertypeguid')
    transfer_type_guid: StrFeatureItem = str_item('transfertypeguid')


class ProjectViolationTypeFeature(ACISIProjectSettingFeature, BasicFeatureObject):
    hash_field: str = 'projectviolationtypeguid'

    guid: StrFeatureItem = str_item('projectviolationtypeguid')
    violation_type_guid: StrFeatureItem = str_item('violationtypeguid')


class QcFeature(ACISIGmlFeature, ACISIPoleFeature, ACISIProjectFeature, ACISIPositionFeature, BasicFeatureObject):
    hash_field: str = 'qcguid'

    date: DateTimeFeatureItem = datetime_item('qcdate')
    guid: StrFeatureItem = str_item('qcguid')
    user_guid: StrFeatureItem = str_item('userguid')
    notes: StrFeatureItem = str_item()


class QcSelectionFeature(ACISIGmlFeature, ACISIPoleFeature, ACISIProjectFeature, ACISIPositionFeature, BasicFeatureObject):
    hash_field: str = 'qcselectionguid'

    guid: StrFeatureItem = str_item('qcselectionguid')
    date: DateTimeFeatureItem = datetime_item()
    history_guid: StrFeatureItem = str_item('historyguid')


@deprecated
class TransferStepFeature(ACISIGmlFeature, ACISIPoleFeature, ACISIProjectFeature, ACISIPositionFeature, ACISIObjectGuidFeature, BasicFeatureObject):
    hash_field: str = 'stepguid'

    attachee_entity_guid: StrFeatureItem = str_item('attacheeentityguid')
    attachee_entity_company_name: StrFeatureItem = str_item('attacheeentitycompanyname')
    attachee_entity_display_name: StrFeatureItem = str_item('attacheeentitydisplayname')
    attachee_entity_name: StrFeatureItem = str_item('attacheeentityname')
    job_type_display_name: StrFeatureItem = str_item('jobtypedisplayname')
    job_type_guid: StrFeatureItem = str_item('jobtypeguid')
    job_type_name: StrFeatureItem = str_item('jobtypename')
    guid: StrFeatureItem = str_item('stepguid')
    step_order: IntFeatureItem = int_item('steporder')
    transfer_guid: StrFeatureItem = str_item('transferguid')
    notes: StrFeatureItem = str_item()


class TransferTypeFeature(ACISITypeFeature, BasicFeatureObject):
    hash_field: str = 'transfertypeguid'

    guid: StrFeatureItem = str_item('transfertypeguid')


class UserHistoryFeature(ACISIGmlFeature, ACISIProjectFeature, ACISIObjectGuidFeature, BasicFeatureObject):
    hash_field: str = 'historyguid'

    date: DateTimeFeatureItem = datetime_item()
    guid: StrFeatureItem = str_item('historyguid')
    pole_guid: StrFeatureItem = str_item('poleguid')
    pole_status: EnumFeatureItem[ps.PoleStatus, str] = enum_item('polestatus', ps.PoleStatus)
    user_guid: StrFeatureItem = str_item('userguid')

    # region Pole XML
    _pole_xml: Optional[etree.Element] = None

    @printtodebugger
    def pole_xml_getter(self) -> Optional[etree.Element]:
        return self._pole_xml

    @printtodebugger
    def pole_xml_setter(self, pole_xml: Optional[etree.Element]) -> None:
        self._pole_xml = pole_xml

    @printtodebugger
    def pole_xml_deleter(self) -> None:
        self.pole_xml = None

    @printtodebugger
    def pole_xml_out(value: Any) -> Optional[etree.Element]:
        if isinstance(value, str) or isinstance(value, bytes):
            try:
                return etree.fromstring(base64.b64decode(value, validate=True))
            except binascii.Error:
                pass
        return None

    @printtodebugger
    def pole_xml_in(value: Any) -> Optional[str]:
        return base64.b64encode(etree.tostring(value)).decode('utf-8') if isinstance(value, etree.Element) else None

    pole_xml = property_item(name='polexml', fin=pole_xml_in, fout=pole_xml_out, fdel=pole_xml_deleter, fset=pole_xml_setter)(pole_xml_getter)
    """
    To prevent mypy from getting a bit confused, we need to declare pole_xml as an actual property.
    """

    raw_pole_xml = str_item('polexml')
    """
    This is used by the XML mappings for WFS.
    """
    # endregion


class ViolationFeature(ACISIGmlFeature, ACISIObjectGuidFeature, ACISIEntityFeature, ACISIPositionFeature, ACISIPoleFeature, ACISIProjectFeature, BasicFeatureObject):
    hash_field: str = 'violationguid'

    assessment_display_name: StrFeatureItem = str_item('assessmentdisplayname')
    assessment_guid: StrFeatureItem = str_item('assessmentguid')
    assessment_name: StrFeatureItem = str_item('assessmentname')
    attachee_display_name: StrFeatureItem = str_item('attacheedisplayname')
    attachee_guid: StrFeatureItem = str_item('attacheeguid')
    attachee_name: StrFeatureItem = str_item('attacheename')
    entity_guid: StrFeatureItem = str_item('entityguid')
    type_display_name: StrFeatureItem = str_item('typedisplayname')
    type_guid: StrFeatureItem = str_item('typeguid')
    type_name: StrFeatureItem = str_item('typename')
    guid: StrFeatureItem = str_item('violationguid')
    notes: StrFeatureItem = str_item()


class ViolationAssessmentTypeFeature(ACISITypeFeature, BasicFeatureObject):
    hash_field: str = 'violationassessmentguid'

    guid: StrFeatureItem = str_item('violationassessmentguid')


class ViolationTypeFeature(ACISITypeFeature, BasicFeatureObject):
    hash_field: str = 'violationtypeguid'

    guid: StrFeatureItem = str_item('violationtypeguid')


class AttacheeTransferFeature(ACISIGmlFeature, ACISIObjectGuidFeature, ACISIPositionFeature, ACISIPoleFeature, ACISIProjectFeature, BasicFeatureObject):
    hash_field: str = 'transferguid'

    guid: StrFeatureItem = str_item('transferguid')
    job_type_guid: StrFeatureItem = str_item('jobtypeguid')


class AttacheeTransferStepFeature(ACISIGmlFeature, ACISIObjectGuidFeature, ACISIPositionFeature, ACISIPoleFeature, ACISIProjectFeature, BasicFeatureObject):
    hash_field: str = 'stepguid'

    guid: StrFeatureItem = str_item('stepguid')
    attachee_project_guid: StrFeatureItem = str_item('attachee')
    attachee_entity_guid: StrFeatureItem = str_item('attacheeentityguid')
    attachee_guid: StrFeatureItem = str_item('parentguid')
    transfer_project_guid: StrFeatureItem = str_item('transfer')
    transfer_guid: StrFeatureItem = str_item('transferguid')
    step_order: IntFeatureItem = int_item('steporder')
    notes: StrFeatureItem = str_item()

