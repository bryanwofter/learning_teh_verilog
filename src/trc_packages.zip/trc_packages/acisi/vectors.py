from uuid import UUID
from trc_packages.acisi import datamodels, _configuration as conf, _external_data_type as edt
from trc_packages.core.features import BasicVectorObject, BasicFeatureObject, protocols, TFeature, GuidUnion, GuidUnionList, FeatureUnion, FeatureUnionList, DateTime
from trc_packages.debugging import printtodebugger
from typing import Any, Dict, Optional, Type, List, TypeVar, Optional, overload, Iterable, Union
from trc_packages.decorators import deprecated
import os


class ACISIVectorObject(BasicVectorObject[TFeature]):

    @property
    def path(self) -> Optional[str]:
        return self._path or os.path.dirname(conf.Configuration().db_file)

    @path.setter
    def path(self, path: Optional[str]) -> None:
        self._path = path

    @path.deleter
    def path(self) -> None:
        del self._path

    @property
    def current_project(self) -> str:
        return self._current_project or conf.Configuration().project_name

    @current_project.setter
    def current_project(self, current_project: str) -> None:
        self._current_project = current_project

    @current_project.deleter
    def current_project(self) -> None:
        del self._current_project

    @property
    def current_circuit(self) -> str:
        return self._current_circuit or conf.Configuration().project_id

    @current_circuit.setter
    def current_circuit(self, current_circuit: str) -> None:
        self._current_circuit = current_circuit

    @current_circuit.deleter
    def current_circuit(self) -> None:
        del self._current_circuit

    @printtodebugger
    def by_guid(self, guid: GuidUnion, **kwargs: Any) -> Optional[TFeature]:
        return self.find_any("[guid] = {}", guid, **kwargs)

    @printtodebugger
    def by_guids(self, guids: GuidUnionList, **kwargs: Any) -> Iterable[TFeature]:
        return self.find("[guid] IN ({})", guids, **kwargs)

    @printtodebugger
    def by_project_and_guid(self, project: FeatureUnion[datamodels.ProjectFeature], guid: GuidUnion, **kwargs: Any) -> Optional[TFeature]:
        return self.find_any("[project_guid] = {} AND [guid] = {}", project, guid, **kwargs)


class AddressVector(ACISIVectorObject[datamodels.AddressFeature]):
    layer_name: str = 'acisiaddress'
    feature_object_type: Type[datamodels.AddressFeature] = datamodels.AddressFeature

    @printtodebugger
    def by_pole(self, pole: FeatureUnion[datamodels.PoleFeature], **kwargs: Any) -> Iterable[datamodels.AddressFeature]:
        return self.find("[pole_guid] = {}", pole, **kwargs)

    @printtodebugger
    def by_pole_and_project(self, pole: FeatureUnion[datamodels.PoleFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Optional[datamodels.AddressFeature]:
        return self.find_any("[pole_guid] = {} AND [project_guid] = {}", pole, project, **kwargs)


class AttacheeVector(ACISIVectorObject[datamodels.AttacheeFeature]):
    layer_name: str = 'acisiattachee'
    feature_object_type: Type[datamodels.AttacheeFeature] = datamodels.AttacheeFeature

    @printtodebugger
    def by_entity(self, entity: FeatureUnion[datamodels.EntityFeature], **kwargs: Any) -> Iterable[datamodels.AttacheeFeature]:
        return self.find("[entity_guid] = {}", entity, **kwargs)

    @printtodebugger
    def by_entity_and_project(self, entity: FeatureUnion[datamodels.EntityFeature], project: FeatureUnion[datamodels.EntityFeature], **kwargs: Any) -> Iterable[datamodels.AttacheeFeature]:
        return self.find("[entity_guid] = {} AND [project_guid] = {}", entity, project, **kwargs)

    @printtodebugger
    def by_pole(self, pole: FeatureUnion[datamodels.PoleFeature], **kwargs: Any) -> Iterable[datamodels.AttacheeFeature]:
        return self.find("[pole_guid] = {}", pole, **kwargs)

    @printtodebugger
    def by_pole_and_project(self, pole: FeatureUnion[datamodels.PoleFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.AttacheeFeature]:
        return self.find("[pole_guid] = {} AND [project_guid] = {}", pole, project, **kwargs)

    @printtodebugger
    def by_transfer(self, transfer: FeatureUnion[datamodels.AttacheeTransferFeature], **kwargs: Any) -> Iterable[datamodels.AttacheeFeature]:
        transfer_steps: Iterable[datamodels.AttacheeTransferStepFeature] = AttacheeTransferStepVector().by_transfer(transfer)

        return self.find("[guid] IN ({})", [t.attachee_guid for t in transfer_steps], **kwargs)

    @printtodebugger
    def by_transfer_and_project(self, transfer: FeatureUnion[datamodels.AttacheeTransferFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.AttacheeFeature]:
        transfer_steps: Iterable[datamodels.AttacheeTransferStepFeature] = AttacheeTransferStepVector().by_transfer_and_project(transfer, project)

        return self.find("[project_guid] = {} AND [guid] IN ({})", project, [t.attachee_guid for t in transfer_steps], **kwargs)

    @printtodebugger
    def by_transfer_step(self, transfer_step: FeatureUnion[datamodels.AttacheeTransferStepFeature], **kwargs: Any) -> Iterable[datamodels.AttacheeFeature]:
        return self.find("[guid] = {}", transfer_step.attachee_guid if isinstance(transfer_step, datamodels.AttacheeTransferStepFeature) else transfer_step, **kwargs)

    @printtodebugger
    def by_transfer_step_and_project(self, transfer_step: FeatureUnion[datamodels.AttacheeTransferStepFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Optional[datamodels.AttacheeFeature]:
        return self.find_any("[project_guid] = {} AND [guid] = {}", project, transfer_step.attachee_guid if isinstance(transfer_step, datamodels.AttacheeTransferStepFeature) else transfer_step, **kwargs)


class AttachmentVector(ACISIVectorObject[datamodels.AttachmentFeature]):
    layer_name: str = 'acisiattachment'
    feature_object_type: Type[datamodels.AttachmentFeature] = datamodels.AttachmentFeature

    @printtodebugger
    def by_attachee(self, attachee: FeatureUnion[datamodels.AttacheeFeature], **kwargs: Any) -> Iterable[datamodels.AttachmentFeature]:
        return self.find("[attachee_guid] = {}", attachee, **kwargs)

    @printtodebugger
    def by_attachee_and_project(self, attachee: FeatureUnion[datamodels.AttacheeFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.AttachmentFeature]:
        return self.find("[attachee_guid] = {} AND [project_guid] = {}", attachee, project, **kwargs)

    @printtodebugger
    def by_attachee_entity(self, attachee_entity: FeatureUnion[datamodels.EntityFeature], **kwargs: Any) -> Iterable[datamodels.AttachmentFeature]:
        return self.find("[attachee_entity_guid] = {}", attachee_entity, **kwargs)

    @printtodebugger
    def by_attachee_entity_and_project(self, attachee_entity: FeatureUnion[datamodels.EntityFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.AttachmentFeature]:
        return self.find("[attachee_entity_guid] = {} AND [project_guid] = {}", attachee_entity, project, **kwargs)

    @printtodebugger
    def by_pole(self, pole: FeatureUnion[datamodels.PoleFeature], **kwargs: Any) -> Iterable[datamodels.AttachmentFeature]:
        return self.find("[pole_guid] = {}", pole, **kwargs)

    @printtodebugger
    def by_pole_and_project(self, pole: FeatureUnion[datamodels.PoleFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.AttachmentFeature]:
        return self.find("[pole_guid] = {} AND [project_guid] = {}", pole, project, **kwargs)

    @printtodebugger
    def by_pole_and_attachee(self, pole: FeatureUnion[datamodels.PoleFeature], attachee: FeatureUnion[datamodels.AttacheeFeature], **kwargs: Any) -> Iterable[datamodels.AttachmentFeature]:
        return self.find("[pole_guid] = {} AND [attachee_guid] = {}", pole, attachee, **kwargs)

    @printtodebugger
    def by_pole_attachee_and_project(
        self, pole: FeatureUnion[datamodels.PoleFeature], attachee: FeatureUnion[datamodels.AttacheeFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any
    ) -> Iterable[datamodels.AttachmentFeature]:
        return self.find("[pole_guid] = {} AND [attachee_guid] = {} AND [project_guid] = {}", pole, attachee, project, **kwargs)

    @printtodebugger
    def by_pole_and_attachee_entity(self, pole: FeatureUnion[datamodels.PoleFeature], attachee_entity: FeatureUnion[datamodels.EntityFeature], **kwargs: Any) -> Iterable[datamodels.AttachmentFeature]:
        return self.find("[pole_guid] = {} AND [attachee_entity_guid] = {}", pole, attachee_entity, **kwargs)

    @printtodebugger
    def b_pole_attachee_entity_and_project(
        self, pole: FeatureUnion[datamodels.PoleFeature], attachee_entity: FeatureUnion[datamodels.EntityFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any
    ) -> Iterable[datamodels.AttachmentFeature]:
        return self.find("[pole_guid] = {} AND [attachee_entity_guid] = {} AND [project_guid] = {}", pole, attachee_entity, project, **kwargs)


class AttachmentTypeVector(ACISIVectorObject[datamodels.AttachmentTypeFeature]):
    layer_name: str = 'acisiattachmenttype'
    feature_object_type: Type[datamodels.AttachmentTypeFeature] = datamodels.AttachmentTypeFeature

    @printtodebugger
    def by_project(self, project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.AttachmentTypeFeature]:
        project_attachment_types: Dict[str, datamodels.ProjectAttachmentTypeFeature] = {a.attachment_type_guid: a for a in ProjectAttachmentTypeVector().by_project(project)}

        return sorted(self.by_guids(list(project_attachment_types.keys()), **kwargs), key=lambda a: project_attachment_types[a.guid], reverse=True)


class DescriptorVector(ACISIVectorObject[datamodels.DescriptorFeature]):
    layer_name: str = 'acisidescriptor'
    feature_object_type: Type[datamodels.DescriptorFeature] = datamodels.DescriptorFeature

    @printtodebugger
    def by_parent(self, parent: GuidUnion, **kwargs: Any) -> Iterable[datamodels.DescriptorFeature]:
        return self.find("[parent_guid] = {}", parent, **kwargs)

    @printtodebugger
    def by_parent_and_project(self, parent: GuidUnion, project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.DescriptorFeature]:
        return self.find("[parent_guid] = {} AND [project_guid] = {}", parent, project, **kwargs)

    @printtodebugger
    def by_pole(self, pole: FeatureUnion[datamodels.PoleFeature], **kwargs: Any) -> Iterable[datamodels.DescriptorFeature]:
        return self.find("[pole_guid] = {}", pole, **kwargs)

    @printtodebugger
    def by_pole_and_project(self, pole: FeatureUnion[datamodels.PoleFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.DescriptorFeature]:
        return self.find("[pole_guid] = {} AND [project_guid] = {}", pole, project, **kwargs)

    @printtodebugger
    def by_pole_and_parent(self, pole: FeatureUnion[datamodels.PoleFeature], parent: GuidUnion, **kwargs: Any) -> Iterable[datamodels.DescriptorFeature]:
        return self.find("[pole_guid] = {} AND [parent_guid] = {}", pole, parent, **kwargs)

    @printtodebugger
    def by_pole_parent_and_project(self, pole: FeatureUnion[datamodels.PoleFeature], parent: GuidUnion, project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.DescriptorFeature]:
        return self.find("[pole_guid] = {} AND [parent_guid] = {} AND [project_guid] = {}", pole, parent, project, **kwargs)


class DescriptorTypeVector(ACISIVectorObject[datamodels.DescriptorTypeFeature]):
    layer_name: str = 'acisidescriptorlookup'
    feature_object_type: Type[datamodels.DescriptorTypeFeature] = datamodels.DescriptorTypeFeature

    @printtodebugger
    def by_project(self, project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.DescriptorTypeFeature]:
        project_descriptor_types: Dict[str, datamodels.ProjectDescriptorTypeFeature] = {d.descriptor_guid: d for d in ProjectDescriptorTypeVector().by_project(project)}

        return sorted(self.by_guids(list(project_descriptor_types.keys()), **kwargs), key=lambda d: project_descriptor_types[d.guid], reverse=True)


class EntityVector(ACISIVectorObject[datamodels.EntityFeature]):
    layer_name: str = 'acisientity'
    feature_object_type: Type[datamodels.EntityFeature] = datamodels.EntityFeature

    @printtodebugger
    def attachees_by_project(self, project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.EntityFeature]:
        project_attachees: Dict[str, datamodels.ProjectAttacheeFeature] = {a.entity_guid: a for a in ProjectAttacheeVector().by_project(project)}
        entity_categories: Dict[str, datamodels.EntityCategoryFeature] = {c.guid: c for c in EntityCategoryVector()}

        return sorted(self.by_guids(list(project_attachees.keys()), **kwargs), key=lambda a: (-entity_categories[a.category_guid].display_order, project_attachees[a.guid]), reverse=True)

    @printtodebugger
    def pole_owners_by_project(self, project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.EntityFeature]:
        project_pole_owners: Dict[str, datamodels.ProjectPoleOwnerFeature] = {a.entity_guid: a for a in ProjectPoleOwnerVector().by_project(project)}
        entity_categories: Dict[str, datamodels.EntityCategoryFeature] = {c.guid: c for c in EntityCategoryVector()}

        return sorted(self.by_guids(list(project_pole_owners.keys()), **kwargs), key=lambda a: (-entity_categories[a.category_guid].display_order, project_pole_owners[a.guid]), reverse=True)

    @printtodebugger
    def by_display_name_company_name_and_name(self, display_name: str, company_name: str, name: str, **kwargs: Any) -> Optional[datamodels.EntityFeature]:
        return self.find_any("[display_name] = {} AND [name] = {} AND [company_name] = {}", display_name, name, company_name, **kwargs)


class EntityCategoryVector(ACISIVectorObject[datamodels.EntityCategoryFeature]):
    layer_name: str = 'acisientitycategory'
    feature_object_type: Type[datamodels.EntityCategoryFeature] = datamodels.EntityCategoryFeature


class ExternalDataVector(ACISIVectorObject[datamodels.ExternalDataFeature]):
    layer_name: str = 'acisiexternaldata'
    feature_object_type: Type[datamodels.ExternalDataFeature] = datamodels.ExternalDataFeature

    @printtodebugger
    def by_entity(self, entity: FeatureUnion[datamodels.EntityFeature], **kwargs: Any) -> Iterable[datamodels.ExternalDataFeature]:
        return self.find("[entity_guid] = {}", entity, **kwargs)

    @printtodebugger
    def by_pole(self, pole: FeatureUnion[datamodels.PoleFeature], **kwargs: Any) -> Iterable[datamodels.ExternalDataFeature]:
        return self.find("[parent_guid] = {}", pole, **kwargs)

    @printtodebugger
    def by_type_and_pole(self, type: Union[GuidUnion, edt.ExternalDataType], pole: FeatureUnion[datamodels.PoleFeature], **kwargs: Any) -> Optional[datamodels.ExternalDataFeature]:
        return self.find_any("[descriptor_type] = {} AND [parent_guid] = {}", type, pole, **kwargs)


class GpsHistoryVector(ACISIVectorObject[datamodels.GpsHistoryFeature]):
    layer_name: str = 'acisigpshistory'
    feature_object_type: Type[datamodels.GpsHistoryFeature] = datamodels.GpsHistoryFeature


class PoleVector(ACISIVectorObject[datamodels.PoleFeature]):
    layer_name: str = 'acisipole'
    base_name: str = 'Poles'
    feature_object_type: Type[datamodels.PoleFeature] = datamodels.PoleFeature
    field_aliases: Dict[str, str] = {'OwnerID': 'owner'}

    @printtodebugger
    def by_project(self, project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.PoleFeature]:
        return self.find("[project_guid] = {}", project, **kwargs)

    @printtodebugger
    def by_guid_and_project(self, guid: GuidUnion, project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Optional[datamodels.PoleFeature]:
        return self.find_any("[guid] = {} AND [project_guid] = {}", guid, project, **kwargs)

    @printtodebugger
    def by_owner(self, owner: FeatureUnion[datamodels.EntityFeature], **kwargs: Any) -> Iterable[datamodels.PoleFeature]:
        return self.find("[owner_guid] = {}", owner, **kwargs)

    @printtodebugger
    def by_owner_and_project(self, owner: FeatureUnion[datamodels.EntityFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.PoleFeature]:
        return self.find("[owner_guid] = {} AND [project_guid] = {}", owner, project, **kwargs)


class PoleCategoryVector(ACISIVectorObject[datamodels.PoleCategoryFeature]):
    layer_name: str = 'acisipolecategory'
    feature_object_type: Type[datamodels.PoleCategoryFeature] = datamodels.PoleCategoryFeature


class ProjectVector(ACISIVectorObject[datamodels.ProjectFeature]):
    layer_name: str = 'acisiproject'
    feature_object_type: Type[datamodels.ProjectFeature] = datamodels.ProjectFeature


class ACISIProjectSettingVectorObject(ACISIVectorObject[TFeature]):

    @printtodebugger
    def by_project(self, project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[TFeature]:
        return self.find("[project_guid] = {}", project, **kwargs)


class ProjectAttacheeVector(ACISIProjectSettingVectorObject[datamodels.ProjectAttacheeFeature]):
    layer_name: str = 'acisiprojectattachees'
    feature_object_type: Type[datamodels.ProjectAttacheeFeature] = datamodels.ProjectAttacheeFeature


class ProjectAttachmentTypeVector(ACISIProjectSettingVectorObject[datamodels.ProjectAttachmentTypeFeature]):
    layer_name: str = 'acisiprojectattachmenttypes'
    feature_object_type: Type[datamodels.ProjectAttachmentTypeFeature] = datamodels.ProjectAttachmentTypeFeature


class ProjectClientOwnerVector(ACISIProjectSettingVectorObject[datamodels.ProjectClientOwnerFeature]):
    layer_name: str = 'acisiprojectclientowner'
    feature_object_type: Type[datamodels.ProjectClientOwnerFeature] = datamodels.ProjectClientOwnerFeature


class ProjectDescriptorTypeVector(ACISIProjectSettingVectorObject[datamodels.ProjectDescriptorTypeFeature]):
    layer_name: str = 'acisiprojectdescriptors'
    feature_object_type: Type[datamodels.ProjectDescriptorTypeFeature] = datamodels.ProjectDescriptorTypeFeature


class ProjectPoleOwnerVector(ACISIProjectSettingVectorObject[datamodels.ProjectPoleOwnerFeature]):
    layer_name: str = 'acisiprojectpoleowners'
    feature_object_type: Type[datamodels.ProjectPoleOwnerFeature] = datamodels.ProjectPoleOwnerFeature


class ProjectTransferTypeVector(ACISIProjectSettingVectorObject[datamodels.ProjectTransferTypeFeature]):
    layer_name: str = 'acisiprojecttransfertypes'
    feature_object_type: Type[datamodels.ProjectTransferTypeFeature] = datamodels.ProjectTransferTypeFeature


class ProjectViolationTypeVector(ACISIProjectSettingVectorObject[datamodels.ProjectViolationTypeFeature]):
    layer_name: str = 'acisiprojectviolationtypes'
    feature_object_type: Type[datamodels.ProjectViolationTypeFeature] = datamodels.ProjectViolationTypeFeature


class QcVector(ACISIVectorObject[datamodels.QcFeature]):
    layer_name: str = 'acisiqc'
    feature_object_type: Type[datamodels.QcFeature] = datamodels.QcFeature


class QcSelectionVector(ACISIVectorObject[datamodels.QcSelectionFeature]):
    layer_name: str = 'acisiqcselection'
    feature_object_type: Type[datamodels.QcSelectionFeature] = datamodels.QcSelectionFeature


@deprecated
class TransferStepVector(ACISIVectorObject[datamodels.TransferStepFeature]):
    layer_name: str = 'acisitransferstep'
    feature_object_type: Type[datamodels.TransferStepFeature] = datamodels.TransferStepFeature

    @printtodebugger
    def by_pole_and_project(self, pole: FeatureUnion[datamodels.PoleFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.TransferStepFeature]:
        return self.find("[pole_guid] = {} AND [project_guid] = {}", pole, project, **kwargs)

    @printtodebugger
    def by_pole_attachee_and_project(
        self, pole: FeatureUnion[datamodels.PoleFeature], attachee: FeatureUnion[datamodels.AttacheeFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any
    ) -> Optional[datamodels.TransferStepFeature]:
        attachee = attachee if isinstance(attachee, datamodels.AttacheeFeature) else AttacheeVector().by_guid(attachee)
        return self.by_pole_attachee_entity_and_project(pole, attachee.entity_guid, project, **kwargs)

    @printtodebugger
    def by_pole_attachee_entity_and_project(
        self, pole: FeatureUnion[datamodels.PoleFeature], attachee_entity: FeatureUnion[datamodels.EntityFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any
    ) -> Optional[datamodels.TransferStepFeature]:
        attachee_entity = attachee_entity if isinstance(attachee_entity, datamodels.EntityFeature) else EntityVector().by_guid(attachee_entity)
        return self.find_any("[pole_guid] = {} AND [attachee_entity_name] = {} AND [project_guid] = {}", pole, attachee_entity.name, project, **kwargs)


class TransferTypeVector(ACISIVectorObject[datamodels.TransferTypeFeature]):
    layer_name: str = 'acisitransfertype'
    feature_object_type: Type[datamodels.TransferTypeFeature] = datamodels.TransferTypeFeature

    @printtodebugger
    def by_project(self, project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.TransferTypeFeature]:
        project_transfer_types: Dict[str, datamodels.ProjectTransferTypeFeature] = {t.transfer_type_guid: t for t in ProjectTransferTypeVector().by_project(project)}

        return sorted(self.by_guids(list(project_transfer_types.keys()), **kwargs), key=lambda t: project_transfer_types[t.guid], reverse=True)


class UserHistoryVector(ACISIVectorObject[datamodels.UserHistoryFeature]):
    layer_name: str = 'acisiuserhistory'
    feature_object_type: Type[datamodels.UserHistoryFeature] = datamodels.UserHistoryFeature

    @printtodebugger
    def by_pole_project_and_date(self, pole: FeatureUnion[datamodels.PoleFeature], project: FeatureUnion[datamodels.ProjectFeature], date: DateTime, **kwargs: Any) -> Iterable[datamodels.UserHistoryFeature]:
        return self.find("[pole_guid] = {} AND [project_guid] = {} AND [date] = {}", pole, project, date, **kwargs)

    @printtodebugger
    def by_pole_project_and_date_range(self, pole: FeatureUnion[datamodels.PoleFeature], project: FeatureUnion[datamodels.ProjectFeature], min_date: DateTime, max_date: DateTime, **kwargs: Any) -> Iterable[datamodels.UserHistoryFeature]:
        return self.find("[pole_guid] = {} AND [project_guid] = {} AND [date] >= {} AND [date] <= {}", pole, project, min_date, max_date, **kwargs)


class ViolationVector(ACISIVectorObject[datamodels.ViolationFeature]):
    layer_name: str = 'acisiviolation'
    feature_object_type: Type[datamodels.ViolationFeature] = datamodels.ViolationFeature

    @printtodebugger
    def by_attachee(self, attachee: FeatureUnion[datamodels.AttacheeFeature], **kwargs: Any) -> Iterable[datamodels.ViolationFeature]:
        return self.find("[attachee_guid] = {}", attachee, **kwargs)

    @printtodebugger
    def by_attachee_and_project(self, attachee: FeatureUnion[datamodels.AttacheeFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.ViolationFeature]:
        return self.find("[attachee_guid] = {} AND [project_guid] = {}", attachee, project, **kwargs)

    @printtodebugger
    def by_attachee_entity(self, attachee_entity: FeatureUnion[datamodels.EntityFeature], **kwargs: Any) -> Iterable[datamodels.ViolationFeature]:
        return self.find("[entity_guid] = {}", attachee_entity, **kwargs)

    @printtodebugger
    def by_attachee_entity_and_project(self, attachee_entity: FeatureUnion[datamodels.EntityFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.ViolationFeature]:
        return self.find("[entity_guid] = {} AND [project_guid] = {}", attachee_entity, project, **kwargs)

    @printtodebugger
    def by_pole(self, pole: FeatureUnion[datamodels.PoleFeature], **kwargs: Any) -> Iterable[datamodels.ViolationFeature]:
        return self.find("[pole_guid] = {}", pole, **kwargs)

    @printtodebugger
    def by_pole_and_project(self, pole: FeatureUnion[datamodels.PoleFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.ViolationFeature]:
        return self.find("[pole_guid] = {} AND [project_guid] = {}", pole, project, **kwargs)

    @printtodebugger
    def by_pole_and_attachee(self, pole: FeatureUnion[datamodels.PoleFeature], attachee: FeatureUnion[datamodels.AttacheeFeature], **kwargs: Any) -> Iterable[datamodels.ViolationFeature]:
        return self.find("[pole_guid] = {} AND [attachee_guid] = {}", pole, attachee, **kwargs)

    @printtodebugger
    def by_pole_and_attachee_entity(self, pole: FeatureUnion[datamodels.PoleFeature], attachee_entity: FeatureUnion[datamodels.EntityFeature], **kwargs: Any) -> Iterable[datamodels.ViolationFeature]:
        return self.find("[pole_guid] = {} AND [entity_guid] = {}", pole, attachee_entity, **kwargs)

    @printtodebugger
    def by_pole_attachee_and_project(
        self, pole: FeatureUnion[datamodels.PoleFeature], attachee: FeatureUnion[datamodels.AttacheeFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any
    ) -> Iterable[datamodels.ViolationFeature]:
        return self.find("[pole_guid] = {} AND [attachee_guid] = {} AND [project_guid] = {}", pole, attachee, project, **kwargs)

    @printtodebugger
    def by_pole_attachee_entity_and_project(
        self, pole: FeatureUnion[datamodels.PoleFeature], attachee_entity: FeatureUnion[datamodels.EntityFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any
    ) -> Iterable[datamodels.ViolationFeature]:
        return self.find("[pole_guid] = {} AND [entity_guid] = {} AND [project_guid] = {}", pole, attachee_entity, project, **kwargs)


class ViolationAssessmentTypeVector(ACISIVectorObject[datamodels.ViolationAssessmentTypeFeature]):
    layer_name: str = 'acisiviolationassessmenttype'
    feature_object_type: Type[datamodels.ViolationAssessmentTypeFeature] = datamodels.ViolationAssessmentTypeFeature


class ViolationTypeVector(ACISIVectorObject[datamodels.ViolationTypeFeature]):
    layer_name: str = 'acisiviolationtype'
    feature_object_type: Type[datamodels.ViolationTypeFeature] = datamodels.ViolationTypeFeature

    @printtodebugger
    def by_project(self, project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.ViolationTypeFeature]:
        project_violation_types: Dict[str, datamodels.ProjectViolationTypeFeature] = {v.violation_type_guid: v for v in ProjectViolationTypeVector().by_project(project)}

        return sorted(self.by_guids(list(project_violation_types.keys()), **kwargs), key=lambda v: project_violation_types[v.guid], reverse=True)


class AttacheeTransferVector(ACISIVectorObject[datamodels.AttacheeTransferFeature]):
    layer_name: str = 'acisiattacheetransfer'
    feature_object_type: Type[datamodels.AttacheeTransferFeature] = datamodels.AttacheeTransferFeature

    @printtodebugger
    def by_pole(self, pole: FeatureUnion[datamodels.PoleFeature], **kwargs: Any) -> Iterable[datamodels.AttacheeTransferFeature]:
        return self.find("[pole_guid] = {}", pole, **kwargs)

    @printtodebugger
    def by_pole_and_project(self, pole: FeatureUnion[datamodels.PoleFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Optional[datamodels.AttacheeTransferFeature]:
        return self.find_any("[project_guid] = {} AND [pole_guid] = {}", project, pole, **kwargs)


class AttacheeTransferStepVector(ACISIVectorObject[datamodels.AttacheeTransferStepFeature]):
    layer_name: str = 'acisiattacheetransferstep'
    feature_object_type: Type[datamodels.AttacheeTransferStepFeature] = datamodels.AttacheeTransferStepFeature

    @printtodebugger
    def by_pole(self, pole: FeatureUnion[datamodels.PoleFeature], **kwargs: Any) -> Iterable[datamodels.AttacheeTransferStepFeature]:
        return self.find("[pole_guid] = {}", pole, **kwargs)

    @printtodebugger
    def by_pole_and_project(self, pole: FeatureUnion[datamodels.PoleFeature], project: FeatureUnion[datamodels.PoleFeature], **kwargs: Any) -> Iterable[datamodels.AttacheeTransferStepFeature]:
        return self.find("[project_guid] = {} AND [pole_guid] = {}", project, pole, **kwargs)

    @printtodebugger
    def by_transfer(self, transfer: FeatureUnion[datamodels.AttacheeTransferFeature], **kwargs: Any) -> Iterable[datamodels.AttacheeTransferFeature]:
        return self.find("[transfer_guid] = {}", transfer, **kwargs)

    @printtodebugger
    def by_transfer_and_project(self, transfer: FeatureUnion[datamodels.AttacheeTransferFeature], project: FeatureUnion[datamodels.ProjectFeature], **kwargs: Any) -> Iterable[datamodels.AttacheeTransferStepFeature]:
        return self.find("[project_guid] = {} AND [transfer_guid] = {}", project, transfer, **kwargs)


vector_classes: Dict[str, Type[ACISIVectorObject]] = {
    PoleVector.layer_name: PoleVector,
    AddressVector.layer_name: AddressVector,
    AttacheeVector.layer_name: AttacheeVector,
    AttacheeTransferVector.layer_name: AttacheeTransferVector,
    AttacheeTransferStepVector.layer_name: AttacheeTransferStepVector,
    AttachmentVector.layer_name: AttachmentVector,
    DescriptorVector.layer_name: DescriptorVector,
    ViolationVector.layer_name: ViolationVector
}

