from trc_packages.acisi import datamodels, viewmodels, vectors, _pole_status as ps
from trc_packages.core import is_none_or_whitespace
from trc_packages.debugging import printtodebugger
from trc_packages.core.features import FeatureUnion
from typing import Iterable, Union
AttacheesUnion = Union[Iterable[datamodels.AttacheeFeature],
                       Iterable[viewmodels.AttacheeView],
                       Iterable[Union[datamodels.AttacheeFeature,
                                      viewmodels.AttacheeView]]]
DescriptorsUnion = Union[Iterable[datamodels.DescriptorFeature],
                         Iterable[viewmodels.DescriptorView],
                         Iterable[Union[datamodels.DescriptorFeature,
                                        viewmodels.DescriptorView]]]


@printtodebugger
def determine_pole_status(project: datamodels.ProjectFeature, pole: datamodels.PoleFeature, descriptors: DescriptorsUnion, attachees: AttacheesUnion) -> 'ps.PoleStatus':
    """
    Determines the new pole status of the pole based off of the pole and its attachees.
    :param project: The project to check against.
    :param pole: The pole to check.
    :param descriptors: The descriptors to check.
    :param attachees: The attachees to check.
    """
    status: ps.PoleStatus = ps.PoleStatus.POWER_ONLY

    power: bool = has_power(attachees)
    cable: bool = has_cable(attachees)
    phone: bool = has_phone(attachees)

    if cable and phone:
        status = ps.PoleStatus.TELCO_CATV
    elif cable:
        status = ps.PoleStatus.CATV_ONLY
    elif phone:
        status = ps.PoleStatus.TELCO_ONLY

    if has_light_pole(descriptors):
        status = ps.PoleStatus.LIGHT_POLE

    if has_not_applicable(descriptors):
        status = ps.PoleStatus.NOT_APPLICABLE
    elif has_not_in_field(descriptors):
        status = ps.PoleStatus.NOT_IN_FIELD
    elif has_not_accessible(descriptors):
        status = ps.PoleStatus.NOT_ACCESSIBLE

    if is_foreign(project, pole):
        status = ps.PoleStatus.FOREIGN_DONE

    return status


@printtodebugger
def has_not_applicable(descriptors: DescriptorsUnion) -> bool:
    """
    Determines if there are any NAP descriptors in the descriptors list.
    :param descriptors: The descriptors to search through.
    """
    return has_descriptor_type('NAP', descriptors)


@printtodebugger
def has_not_accessible(descriptors: DescriptorsUnion) -> bool:
    """
    Determines if there are any NA descriptors in the descriptors list.
    :param descriptors: The descriptors to search through.
    """
    return has_descriptor_type('NA', descriptors)


@printtodebugger
def has_not_in_field(descriptors: DescriptorsUnion) -> bool:
    """
    Determines if there are any NIF descriptors in the descriptors list.
    :param descriptors: The descriptors to search through.
    """
    return has_descriptor_type('NIF', descriptors)


@printtodebugger
def has_light_pole(descriptors: DescriptorsUnion) -> bool:
    """
    Determines if there are any LightPole descriptors in the descriptors list.
    :param descriptors: The descriptors to search through.
    """
    return has_descriptor_type('LightPole', descriptors)


@printtodebugger
def is_foreign(project: datamodels.ProjectFeature, pole: datamodels.PoleFeature) -> bool:
    """
    Determines if the pole has an owner other than the owner of the project.
    :param project: The project to check against.
    :param pole: The pole to check.
    """
    return (is_none_or_whitespace(pole.owner_guid) or
            is_none_or_whitespace(project.client_guid) or
            pole.owner_guid.upper() != project.client_guid.upper())


@printtodebugger
def has_cable(attachees: AttacheesUnion) -> bool:
    """
    Determines if an attachee of type CATV exists within the list of attachees.
    :param attachees: The attachees to search through.
    """
    return has_attachee_type('CATV', attachees)


@printtodebugger
def has_power(attachees: AttacheesUnion) -> bool:
    """
    Determines if an attachee of type Power exists within the list of attachees.
    :param attachees: The attachees to search through.
    """
    return has_attachee_type('Power', attachees)


@printtodebugger
def has_phone(attachees: AttacheesUnion) -> bool:
    """
    Determines if an attachee of type TelCo exists within the list of attachees.
    :param attachees: The attachees to search through.
    """
    return has_attachee_type('TelCo', attachees)


@printtodebugger
def has_attachee_type(type_: FeatureUnion[datamodels.EntityCategoryFeature], attachees: AttacheesUnion) -> bool:
    """
    Determines if an attachee of the given type exists within the list of attachees.
    :param type_: The type of attachee to search for. This may be a GUID, EntityCategoryFeature, or display name.
    :param attachees: The attachees to search through.
    """
    if not isinstance(type_, datamodels.EntityCategoryFeature):
        type_ = vectors.EntityCategoryVector().find_any("[guid] = {} OR [display_name] = {}", type_, type_)

    return (isinstance(type_, datamodels.EntityCategoryFeature) and
            vectors.EntityVector().exists("[category_guid] = {} AND [guid] IN ({})", type_, [a.entity_guid for a in attachees]))  # type: ignore


@printtodebugger
def has_descriptor_type(type_: FeatureUnion[datamodels.DescriptorTypeFeature], descriptors: DescriptorsUnion) -> bool:
    """
    Determines if a descriptor of the given type exists within the list of descriptors.
    :param type: The type of descriptor to search for. This may be a GUID, DescriptorTypeFeature, or display name.
    :param descriptors: The descriptors to search through.
    """
    if not isinstance(type_, datamodels.DescriptorTypeFeature):
        type_ = vectors.DescriptorTypeVector().find_any("[guid] = {} OR [display_name] = {}", type_, type_)

    return isinstance(type_, datamodels.DescriptorTypeFeature) and any(d for d in descriptors if d.type_guid == type_.guid)  # type: ignore

