from datetime import datetime
from trc_packages.acisi import vectors, structures
from trc_packages.core.features import protocols, VectorProvider
from trc_packages.debugging import Debug
from trc_packages.wfs.transaction_builder import Operation
from typing import Any, List, Set, Type, Union
_VECTOR_TYPES: Set[Type[vectors.ACISIVectorObject]] = set([vectors.PoleVector, vectors.AddressVector, vectors.AttacheeVector,
                                                           vectors.AttachmentVector, vectors.DescriptorVector, vectors.ViolationVector,
                                                           vectors.AttacheeTransferVector, vectors.AttacheeTransferStepVector])
from xml.etree import ElementTree as etree
import base64


class FeatureAction:
    """
    Provides a structure for an individual feature's action.
    """

    operation: Operation = None
    feature: 'protocols.Feature' = None

    def __init__(self, operation: Operation, feature: 'protocols.Feature') -> None:
        self.operation = operation
        self.feature = feature

    def __hash__(self) -> int:
        return hash(self.feature)

    def __eq__(self, other) -> bool:
        if isinstance(other, FeatureAction):
            return self.feature == other.feature
        elif isinstance(other, type(self.feature)):
            return self.feature == other
        else:
            return NotImplemented

    def __str__(self) -> str:
        return f"(operation: {self.operation}, feature: {self.feature})"


class PoleComparison:
    """
    Provides a structure for features that have been removed, added, or otherwise changed.
    """

    histories: List['datamodels.UserHistoryFeature'] = None
    features: Set[Union[FeatureAction, 'protocols.Feature']] = None

    def __init__(self, histories: List['datamodels.UserHistoryFeature']) -> None:
        self.histories = histories
        self.features = set()

    def __str__(self) -> str:
        return str([str(f) for f in self.features])

    def __repr__(self) -> str:
        return str(self)


class PoleComparator:
    """
    Allows for comparing the poles of a local and remote vector provider.
    """

    local: VectorProvider['vectors.ACISIVectorObject'] = None
    remote: VectorProvider['vectors.ACISIVectorObject'] = None

    def __init__(self, local: VectorProvider['vectors.ACISIVectorObject'], remote: VectorProvider['vectors.ACISIVectorObject']) -> None:
        self.local = local
        self.remote = remote

    def compare(self, project_guid: str, pole_guid: str, start_at: datetime, end_at: datetime) -> Any:
        """
        Performs a comparison of the given pole within the given project between the local and remote vectors, returning all features and their direction of change.
        :param project_guid: The GUID of the project the pole belongs to.
        :param pole_guid: The GUID of the pole.
        :param start_at: The starting date of the history.
        :parm end_at: The ending date of the history.
        """
        local_exists: bool = self.local[vectors.PoleVector].by_guid_and_project(pole_guid, project_guid) is not None
        remote_exists: bool = self.remote[vectors.PoleVector].by_guid_and_project(pole_guid, project_guid) is not None

        comparison: PoleComparison = PoleComparison(list(self.local[vectors.UserHistoryVector].by_pole_project_and_date_range(pole_guid, project_guid, start_at, end_at)))

        if local_exists and remote_exists:
            self.__compare_updated(project_guid, pole_guid, comparison)
        elif local_exists:
            self.__compare_added(project_guid, pole_guid, comparison)
        elif remote_exists:
            self.__compare_removed(project_guid, pole_guid, comparison)

        comparison.features.add(FeatureAction(Operation.UPDATE, self.local[vectors.PoleVector].by_guid_and_project(pole_guid, project_guid)))
        comparison.features.update(FeatureAction(Operation.INSERT, h) for h in self.local[vectors.UserHistoryVector].find("[pole_guid] = {} AND [project_guid] = {} AND [date] > {}", pole_guid, project_guid, start_at))

        return comparison

    def __compare_added(self, project_guid: str, pole_guid: str, comparison: PoleComparison) -> None:
        """Handles the comparison of an added pole."""
        for vector_type in _VECTOR_TYPES:  # type: Type[vectors.ACISIVectorObject]
            for feature in self.local[vector_type].find("[project_guid] = {} AND [pole_guid] = {}", project_guid, pole_guid):  # type: protocols.Feature
                if not self.remote[vector_type].exists("[project_guid] = {} AND [pole_guid] = {} AND [guid] = {}", project_guid, pole_guid, feature['guid']):
                    if feature in comparison.features:
                        comparison.features.remove(feature)

                    comparison.features.add(FeatureAction(Operation.INSERT, feature))

    def __compare_updated(self, project_guid: str, pole_guid: str, comparison: PoleComparison) -> None:
        """Handles the comparison of an updated pole."""
        # Call the common functionality for removals and additions
        self.__compare_removed(project_guid, pole_guid, comparison)
        self.__compare_added(project_guid, pole_guid, comparison)

        for vector_type in _VECTOR_TYPES:  # type: Type[vectors.ACISIVectorObject]
            for feature in self.local[vector_type].find("[project_guid] = {} AND [pole_guid] = {}", project_guid, pole_guid):  # type: protocols.Feature
                if self.remote[vector_type].exists("[project_guid] = {} AND [pole_guid] = {} AND [guid] = {}", project_guid, pole_guid, feature['guid']):
                    if feature in comparison.features:
                        comparison.features.remove(feature)

                    comparison.features.add(FeatureAction(Operation.UPDATE, feature))

    def __compare_removed(self, project_guid: str, pole_guid: str, comparison: PoleComparison) -> None:
        """Handles the comparison of a removed pole."""
        for structure in (structures.PoleStructure.from_xml(etree.fromstring(base64.b64decode(h.pole_xml)), self.local) for h in comparison.histories):  # type: structures.PoleStructure
            for feature in (f for f in structure.features() if f not in comparison.features):  # type: protocols.Feature
                vector_type: Type[vectors.ACISIVectorObject] = type(feature.vector_object)

                if self.remote[vector_type].exists("[project_guid] = {} AND [pole_guid] = {} AND [guid] = {}", project_guid, pole_guid, feature['guid']):
                    comparison.features.add(FeatureAction(Operation.DELETE, feature))

