from trc_packages.acisi import _configuration as conf
from trc_packages.acisi.utils import constants
from trc_packages.core.features import escape_filter_args
from trc_packages.debugging import printtodebugger
from typing import Dict, overload
import sqlite3
import warnings


@overload
def sync_usage_frequency(*, db_file: str, project_guid: str) -> bool:
    ...
@overload
def sync_usage_frequency() -> bool:
    ...


@printtodebugger
def sync_usage_frequency(*, db_file: str=None, project_guid: str=None) -> bool:
    """
    Syncs the usage frequency of all project tables with their corresponding tables for the current project.
    :param db_file: The optional database file to update.
    :param project_guid: The optional project GUID to use.
    """
    config: conf.Configuration = conf.Configuration()

    if db_file is None:
        db_file = config.db_file
    if project_guid is None:
        project_guid = config.project_guid

    has_error: bool = False
    if db_file is None:
        warnings.warn('Attempting to sync usage frequency without a project loaded.', UserWarning)
        has_error = True

    if project_guid is None:
        warnings.warn('Attempting to sync usage frequency of potentially corrupt project.', UserWarning)
        has_error = True

    if has_error:
        return False

    project_guid = escape_filter_args(project_guid)[0]

    with sqlite3.connect(db_file) as sqlite:  # type: sqlite3.Connection
        cursor: sqlite3.Cursor = sqlite.cursor()

        for details in constants.UPDATE_FREQUENCIES_TABLES:  # type: Dict[str, str]
            _sync_table_frequency(project_guid, cursor, **details)

    return True


@printtodebugger
def _sync_table_frequency(project_guid: str, cursor: sqlite3.Cursor, *, type_table: str, type_project_guid_column: str, type_guid_column: str, type_frequency_column: str, record_table: str, record_project_guid_column: str,
                          record_type_guid_column: str) -> None:
    """
    Syncs the specified type_table with the specified record_table.
    :param type_table: The table containing the frequency column.
    :param type_project_guid_column: The project GUID column of the type_table.
    :param type_guid_column: The ID column of the type_table.
    :param type_frequency_column: The column containing the usage frequency of the type_table.
    :param record_table: The table containing the records associated to the type_table.
    :param record_project_guid_column: The project GUID column of the record_table.
    :param record_type_guid_column: The type ID column of the record_table.
    """
    cursor.executescript(constants.UPDATE_FREQUENCIES.format(type_table=type_table, type_project_guid_column=type_project_guid_column, type_guid_column=type_guid_column, type_frequency_column=type_frequency_column,
                                                             record_table=record_table, record_project_guid_column=record_project_guid_column, record_type_guid_column=record_type_guid_column, project_guid=project_guid))

