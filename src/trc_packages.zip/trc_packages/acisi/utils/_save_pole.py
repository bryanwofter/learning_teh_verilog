from base64 import b64encode
from datetime import datetime
from xml.etree import ElementTree as etree
from trc_packages.acisi import datamodels, vectors, viewmodels, structures, determine_pole_status, Configuration
from trc_packages.core import is_none_or_whitespace, json_handlers
from trc_packages.core.features import protocols, VectorProvider, FeatureView, make_guid
from trc_packages.debugging import Debug, printtodebugger
from typing import Any, Dict, Iterable, overload, Optional, Type, TypeVar, Union
import json
import sqlite3
import contextlib
import functools
F = TypeVar('F', bound='protocols.Feature')


class SavedRecord:
    saved: bool = False


@contextlib.contextmanager
@printtodebugger
def _prepare_history_records(config: Configuration,
                             vector_provider: VectorProvider['vectors.ACISIVectorObject'],
                             project: 'datamodels.ProjectFeature',
                             pole: 'datamodels.PoleFeature',
                             address: 'datamodels.AddressFeature',
                             attachees: Iterable['datamodels.AttacheeFeature'],
                             transfer: Optional['datamodels.AttacheeTransferFeature'],
                             transfer_steps: Iterable['datamodels.AttacheeTransferStepFeature'],
                             attachments: Iterable['datamodels.AttachmentFeature'],
                             violations: Iterable['datamodels.ViolationFeature'],
                             descriptors: Iterable['datamodels.DescriptorFeature'],
                             removed_attachees: Iterable[str],
                             removed_transfer_steps: Iterable[str],
                             removed_attachments: Iterable[str],
                             removed_violations: Iterable[str],
                             removed_descriptors: Iterable[str]) -> SavedRecord:
    """
    Prepares a transaction for the given datamodels.
    """
    cursor: Optional[sqlite3.Cursor] = None
    sqlite: sqlite3.Connection = sqlite3.connect(config.logging_db_file)
    date: datetime = datetime.now()
    # This vector provider is used to make sure we get the original values from the database.
    o_vector_provider: VectorProvider['vectors.ACISIVectorObject'] = VectorProvider()
    saved_record: SavedRecord = SavedRecord()

    try:
        cursor = sqlite.execute('BEGIN TRANSACTION;')
        log_record: functools.partial = functools.partial(_log_record, cursor, config, date, project.guid)
        get_action: functools.partial = functools.partial(_get_action, project.guid)

        log_record(pole.guid, get_action(pole.guid, vector_provider[vectors.PoleVector]), o_vector_provider[vectors.PoleVector])

        log_record(address.guid, get_action(address.guid, vector_provider[vectors.AddressVector]), o_vector_provider[vectors.AddressVector])

        attachee: str
        for attachee in (a.guid for a in attachees):
            log_record(attachee, get_action(attachee, vector_provider[vectors.AttacheeVector]), o_vector_provider[vectors.AttacheeVector])

        for attachee in removed_attachees:
            log_record(attachee, 'delete', o_vector_provider[vectors.AttacheeVector])

        if transfer is not None:
            action: str = 'delete' if transfer.job_type_guid is None else get_action(transfer.guid, vector_provider[vectors.AttacheeTransferVector])
            is_delete: bool = 'delete' == action

            log_record(transfer.guid, action, o_vector_provider[vectors.AttacheeTransferVector])

            transfer_step: str
            for transfer_step in (t.guid for t in transfer_steps):
                log_record(transfer_step, 'delete' if is_delete else get_action(transfer_step, vector_provider[vectors.AttacheeTransferStepVector]), o_vector_provider[vectors.AttacheeTransferStepVector])

            for transfer_step in removed_transfer_steps:
                log_record(transfer_step, 'delete', o_vector_provider[vectors.AttacheeTransferStepVector])

        attachment: str
        for attachment in (a.guid for a in attachments):
            log_record(attachment, get_action(attachment, vector_provider[vectors.AttachmentVector]), o_vector_provider[vectors.AttachmentVector])

        for attachment in removed_attachments:
            log_record(attachment, 'delete', o_vector_provider[vectors.AttachmentVector])

        violation: str
        for violation in (v.guid for v in violations):
            log_record(violation, get_action(violation, vector_provider[vectors.ViolationVector]), o_vector_provider[vectors.ViolationVector])

        for violation in removed_violations:
            log_record(violation, 'delete', o_vector_provider[vectors.ViolationVector])

        descriptor: str
        for descriptor in (d.guid for d in descriptors):
            log_record(descriptor, get_action(descriptor, vector_provider[vectors.DescriptorVector]), o_vector_provider[vectors.DescriptorVector])

        for descriptor in removed_descriptors:
            log_record(descriptor, 'delete', o_vector_provider[vectors.DescriptorVector])

        yield saved_record

        if saved_record.saved:
            cursor.execute('COMMIT TRANSACTION;')
        else:
            cursor.execute('ROLLBACK TRANSACTION;')
    except Exception as e:
        if cursor is not None:
            cursor.execute('ROLLBACK TRANSACTION;')
        raise e

    finally:
        if cursor is not None:
            cursor.close()
        sqlite.close()


@overload
def save_pole(previous_pole_structure: 'structures.PoleStructure',
              pole: 'datamodels.PoleFeature',
              address: 'viewmodels.AddressView',
              attachees: Iterable['viewmodels.AttacheeView'],
              transfer: Optional['viewmodels.AttacheeTransferView'],
              transfer_steps: Iterable['viewmodels.AttacheeTransferStepView'],
              attachments: Iterable['viewmodels.AttachmentView'],
              violations: Iterable['viewmodels.ViolationView'],
              descriptors: Iterable['viewmodels.DescriptorView'],
              removed_attachees: Iterable[str],
              removed_transfer_steps: Iterable[str],
              removed_attachments: Iterable[str],
              removed_violations: Iterable[str],
              removed_descriptors: Iterable[str],
              qc_comment: Any,
              *,
              validators: Dict[Type['vectors.ACISIVectorObject'], Iterable['protocols.Validator']]) -> bool:
    ...


@overload
def save_pole(previous_pole_structure: 'structures.PoleStructure',
              pole: 'datamodels.PoleFeature',
              address: 'datamodels.AddressFeature',
              attachees: Iterable['datamodels.AttacheeFeature'],
              transfer: Optional['datamodels.AttacheeTransferFeature'],
              transfer_steps: Iterable['datamodels.AttacheeTransferStepFeature'],
              attachments: Iterable['datamodels.AttachmentFeature'],
              violations: Iterable['datamodels.ViolationFeature'],
              descriptors: Iterable['datamodels.DescriptorFeature'],
              removed_attachees: Iterable[str],
              removed_transfer_steps: Iterable[str],
              removed_attachments: Iterable[str],
              removed_violations: Iterable[str],
              removed_descriptors: Iterable[str],
              qc_comment: Any,
              *,
              validators: Dict[Type['vectors.ACISIVectorObject'], Iterable['protocols.Validator']]) -> bool:
    ...


@printtodebugger
def save_pole(previous_pole_structure: 'structures.PoleStructure',
              pole: 'datamodels.PoleFeature',
              address,
              attachees: Iterable,
              transfer: Optional,
              transfer_steps: Iterable,
              attachments: Iterable,
              violations: Iterable,
              descriptors: Iterable,
              removed_attachees: Iterable[str],
              removed_transfer_steps: Iterable[str],
              removed_attachments: Iterable[str],
              removed_violations: Iterable[str],
              removed_descriptors: Iterable[str],
              qc_comment: Any,
              *,
              validators: Dict[Type['vectors.ACISIVectorObject'], Iterable['protocols.Validator']]) -> bool:
    """
    Saves the supplied pole back to the database, including its associated features.
    :param previous_pole_structure: The previous data of the pole.
    :param pole: The pole feature that has been changed.
    :param address: The address feature or its view of the pole feature.
    :param attachees: The attachee features, or view of the attachee features, that belong to the pole.
    :param transfer_steps: The transfer step features, or view of the transfer step features, that belong to the pole.
    :param attachments: The attachment features, or view of the attachment features, that belong to the pole.
    :param violations: The violation features, or view of the violation features, that belong to the pole.
    :param descriptors: The descriptor features, or view of the descriptor features, that belong to the pole.
    :param removed_attachees: The GUIDs of all attachees removed from the pole.
    :param removed_transfer_steps: The GUIDs of all transfer steps removed from the pole.
    :param removed_attachments: The GUIDs of all attachments removed from the pole.
    :param removed_violations: The GUIDs of all violations removed from the pole.
    :param removed_descriptors: The GUIDs of all descriptors removed from the pole.
    :param qc_comment: The control that handles QC comment logic, if any is needed.
    :param validators: The validators to apply to the vectors prior to saving.
    """
    config: Configuration = Configuration()

    acisi_vectors: VectorProvider[vectors.ACISIVectorObject] = VectorProvider()

    projects_v: vectors.ProjectVector = acisi_vectors[vectors.ProjectVector]
    poles_v: vectors.PoleVector
    addresses_v: vectors.AddressVector
    transfers_v: vectors.AttacheeTransferVector
    transfer_steps_v: vectors.AttacheeTransferStepVector
    attachments_v: vectors.AttachmentVector
    violations_v: vectors.ViolationVector
    descriptors_v: vectors.DescriptorVector
    user_history_v: vectors.UserHistoryVector
    (poles_v, addresses_v, attachees_v, transfers_v, transfer_steps_v, attachments_v, violations_v, descriptors_v, user_history_v) = acisi_vectors[
        vectors.PoleVector, vectors.AddressVector, vectors.AttacheeVector, vectors.AttacheeTransferVector, vectors.AttacheeTransferStepVector,
        vectors.AttachmentVector, vectors.ViolationVector, vectors.DescriptorVector, vectors.UserHistoryVector
    ]

    if poles_v.editable:
        project: datamodels.ProjectFeature = projects_v.by_guid(config.project_guid)

        removed_attachees = list(removed_attachees)
        removed_transfer_steps = list(removed_transfer_steps)
        removed_attachments = list(removed_attachments)
        removed_violations = list(removed_violations)
        removed_descriptors = list(removed_descriptors)

        poles_v.validators.extend(validators.get(type(poles_v), []))
        addresses_v.validators.extend(validators.get(type(addresses_v), []))
        attachments_v.validators.extend(validators.get(type(attachments_v), []))

        address = _juggle_to_feature(address,  addresses_v)
        attachees = [_juggle_to_feature(a, attachees_v) for a in attachees]
        transfer = None if transfer is None else _juggle_to_feature(transfer, transfers_v)
        transfer_steps = [] if transfer is None else [_juggle_to_feature(t, transfer_steps_v) for t in transfer_steps]
        attachments = [_juggle_to_feature(a, attachments_v) for a in attachments]
        violations = [_juggle_to_feature(v, violations_v) for v in violations]
        descriptors = [_juggle_to_feature(d, descriptors_v) for d in descriptors]

        pole.status = determine_pole_status(project, pole, descriptors, attachees)

        saved: bool = False

        try:
            saved_record: SavedRecord
            with _prepare_history_records(config, acisi_vectors, project, pole, address, attachees, transfer, transfer_steps, attachments,
                                          violations, descriptors, removed_attachees, removed_transfer_steps, removed_attachments,
                                          removed_violations, removed_descriptors) as saved_record:
                # This is to correct for a bug in the master DB that thinks value must not be NULL even though its never set.
                for descriptor in descriptors:  # type: datamodels.DescriptorFeature
                    descriptor.value = ' '
                with acisi_vectors.start_transaction(
                    vectors.PoleVector, vectors.AddressVector, vectors.AttacheeVector, vectors.AttacheeTransferVector,
                    vectors.AttacheeTransferStepVector, vectors.AttachmentVector, vectors.ViolationVector, vectors.DescriptorVector,
                    vectors.UserHistoryVector
                ) as trans:  # type: protocols.transactionmanager
                    trans.success = False

                    user_history: datamodels.UserHistoryFeature = user_history_v.new_feature(guid=make_guid(),
                                                                                             project_guid=project.guid,
                                                                                             date=datetime.now(),
                                                                                             pole_guid=pole.guid,
                                                                                             pole_status=pole.status,
                                                                                             user_guid=make_guid(),  # TODO: Implement a real user GUID, maybe the user's min ID?
                                                                                             pole_xml=previous_pole_structure.to_xml())

                    saved = (poles_v.add_or_update(pole) and
                             addresses_v.add_or_update(address) and
                             attachees_v.add_or_update_all(attachees) and
                             attachees_v.delete_all(attachees_v.by_guids(removed_attachees)) and
                             (transfer is None or (transfers_v.delete(transfer)
                                                   if is_none_or_whitespace(transfer.job_type_guid)
                                                   else transfers_v.add_or_update(transfer))) and
                             transfer_steps_v.add_or_update_all(transfer_steps) and
                             transfer_steps_v.delete_all(transfer_steps_v.by_guids(removed_transfer_steps)) and
                             attachments_v.add_or_update_all(attachments) and
                             attachments_v.delete_all(attachments_v.by_guids(removed_attachments)) and
                             violations_v.add_or_update_all(violations) and
                             violations_v.delete_all(violations_v.by_guids(removed_violations)) and
                             descriptors_v.add_or_update_all(descriptors) and
                             descriptors_v.delete_all(descriptors_v.by_guids(removed_descriptors)) and
                             user_history_v.add_or_update(user_history))

                    saved_record.saved = saved
                    if saved and qc_comment is not None:
                        saved = qc_comment.save()

                    trans.success = saved

        finally:
            poles_v.start_editing()

        if saved:
            pole_s: structures.PoleStructure = structures.PoleStructure()
            pole_s.pole = pole
            pole_s.address = structures.AddressStructure()
            pole_s.address.address = address

            for descriptor in descriptors:  # type: datamodels.DescriptorFeature
                pole_s.descriptors[descriptor.type_guid].descriptor = descriptor

            if transfer is not None:
                pole_s.transfers = structures.AttacheeTransferStructure()
                pole_s.transfers.transfer = transfer

                for transfer_step in transfer_steps:  # type: datamodels.AttacheeTransferStepFeature
                    pole_s.transfers.transfer_steps[transfer_step.guid].transfer_step = transfer_step

            for attachee in attachees:  # type: datamodels.AttacheeFeature
                attachee_s: structures.AttacheeStructure = pole_s.attachees[attachee.entity_guid]
                attachee_s.attachee = attachee

                for attachment in (a for a in attachments if a.attachee_guid == attachee.guid):  # type: datamodels.AttachmentFeature
                    attachee_s.attachments[attachment.guid].attachment = attachment

                for violation in (v for v in violations if v.attachee_guid == attachee.guid):  # type: datamodels.ViolationFeature
                    attachee_s.violations[violation.type_guid].violation = violation

            config.previous_pole = b64encode(etree.tostring(pole_s.to_xml())).decode('utf-8')

        return saved
    return False


@printtodebugger
def _get_action(project_guid: str, object_guid: str, vector: vectors.ACISIVectorObject) -> str:
    return 'update' if vector.by_project_and_guid(project_guid, object_guid) is not None else 'insert'


@printtodebugger
def _log_record(sqlite: sqlite3.Cursor,
                config: Configuration,
                date: datetime,
                project_guid: str,
                object_guid: str,
                action: str,
                vector: vectors.ACISIVectorObject) -> None:
    """
    Takes the given project_guid and object_guid, resolves its feature, and stores a jsonified version of the data in the logging database.
    :param sqlite: The database connection of the running transaction.
    :param config: The configuration of the current project.
    :param date: The date of the transaction.
    :param project_guid: The project the feature belongs to.
    :param object_guid: The ID of the feature.
    :param action: The action being performed.
    :param vector: The vector of the feature.
    """

    if project_guid is not None and object_guid is not None:
        feature: protocols.Feature = vector.by_project_and_guid(project_guid, object_guid)
        sqlite.execute('INSERT INTO "acisihistory" ("type", "action", "date", "project_guid", "object_guid", "json_blob") VALUES (?, ?, ?, ?, ?, ?);',
                       [type(vector).layer_name, action, date, project_guid, object_guid, '{}' if feature is None else json.dumps(dict(feature.items()), cls=json_handlers.TrcJSONEncoder)])


@printtodebugger
def _juggle_to_feature(feature: Union[F, FeatureView[F]], vector: 'protocols.Vector[F]') -> F:
    """
    Juggles the type of feature to the appropriate feature type.
    :param feature: The feature to juggle the type of.
    :param vector: The vector that supplies the feature type and conversion functionality.
    """
    return feature.to_feature(vector) if isinstance(feature, FeatureView) else feature

