from typing import List, Dict


UPDATE_FREQUENCIES_TABLES: List[Dict[str, str]] = [
    {'type_table': 'acisiprojectattachees', 'type_project_guid_column': 'projectguid', 'type_guid_column': 'entityguid', 'type_frequency_column': 'frequency',
     'record_table': 'acisiattachee', 'record_project_guid_column': 'projectguid', 'record_type_guid_column': 'attacheeentityguid'},
    
    {'type_table': 'acisiprojectattachmenttypes', 'type_project_guid_column': 'projectguid', 'type_guid_column': 'attachmenttypeguid', 'type_frequency_column': 'frequency',
     'record_table': 'acisiattachment', 'record_project_guid_column': 'projectguid', 'record_type_guid_column': 'attachmenttypeguid'},

    {'type_table': 'acisiprojectdescriptors', 'type_project_guid_column': 'projectguid', 'type_guid_column': 'descriptorguid', 'type_frequency_column': 'frequency',
     'record_table': 'acisidescriptor', 'record_project_guid_column': 'projectguid', 'record_type_guid_column': 'typeguid'},

    {'type_table': 'acisiprojectpoleowners', 'type_project_guid_column': 'projectguid', 'type_guid_column': 'entityguid', 'type_frequency_column': 'frequency',
     'record_table': 'acisipole', 'record_project_guid_column': 'projectguid', 'record_type_guid_column': 'owner'},

    {'type_table': 'acisiprojecttransfertypes', 'type_project_guid_column': 'projectguid', 'type_guid_column': 'transfertypeguid', 'type_frequency_column': 'frequency',
     'record_table': 'acisitransferstep', 'record_project_guid_column': 'projectguid', 'record_type_guid_column': 'jobtypeguid'},

    {'type_table': 'acisiprojectviolationtypes', 'type_project_guid_column': 'projectguid', 'type_guid_column': 'violationtypeguid', 'type_frequency_column': 'frequency',
     'record_table': 'acisiviolation', 'record_project_guid_column': 'projectguid', 'record_type_guid_column': 'typeguid'}
]


UPDATE_FREQUENCIES: str = """
UPDATE "{type_table}"
SET "{type_frequency_column}" = (SELECT COUNT(*)
                                 FROM "{record_table}"
                                 WHERE "{record_table}"."{record_type_guid_column}" = "{type_table}"."{type_guid_column}" AND
                                       "{record_table}"."{record_project_guid_column}" = {project_guid})
WHERE "{type_project_guid_column}" = {project_guid};
"""
