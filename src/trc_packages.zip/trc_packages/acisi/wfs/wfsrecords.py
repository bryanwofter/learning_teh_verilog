from typing import ClassVar
from trc_packages.acisi import datamodels
from trc_packages.decorators import deprecated
from trc_packages.debugging import printtodebugger
from trc_packages.wfs.mappings import BasicWfsRecord, WfsStringItem, WfsFloatItem, WfsDateItem, WfsIntItem, WfsBoolItem


class AddressRecord(BasicWfsRecord[datamodels.AddressFeature]):
    WFS_TABLE_NAME: ClassVar[str] = 'ACISIAddress'
    WFS_PRIMARY_KEY: ClassVar[str] = 'id'

    project_guid: WfsStringItem = WfsStringItem('projectGUID')
    pole_project_guid: WfsStringItem = WfsStringItem('pole')
    pole_guid: WfsStringItem = WfsStringItem('poleGUID')
    latitude: WfsFloatItem = WfsFloatItem('lat')
    longitude: WfsFloatItem = WfsFloatItem('long')
    object_guid: WfsStringItem = WfsStringItem('id')
    guid: WfsStringItem = WfsStringItem('addressGUID')
    house_no: WfsStringItem = WfsStringItem('houseNum')
    street: WfsStringItem = WfsStringItem()
    notes: WfsStringItem = WfsStringItem()
    place: WfsStringItem = WfsStringItem()
    county: WfsStringItem = WfsStringItem()
    state: WfsStringItem = WfsStringItem()


class AttacheeRecord(BasicWfsRecord[datamodels.AttacheeFeature]):
    WFS_TABLE_NAME: ClassVar[str] = 'ACISIAttachee'
    WFS_PRIMARY_KEY: ClassVar[str] = 'id'

    project_guid: WfsStringItem = WfsStringItem('projectGUID')
    pole_project_guid: WfsStringItem = WfsStringItem('pole')
    pole_guid: WfsStringItem = WfsStringItem('poleGUID')
    latitude: WfsFloatItem = WfsFloatItem('lat')
    longitude: WfsFloatItem = WfsFloatItem('long')
    object_guid: WfsStringItem = WfsStringItem('id')
    display_name: WfsStringItem = WfsStringItem('attacheeDisplayName')
    entity_guid: WfsStringItem = WfsStringItem('attacheeEntityGUID')
    guid: WfsStringItem = WfsStringItem('attacheeGUID')
    name: WfsStringItem = WfsStringItem('attacheeName')
    height_location: WfsFloatItem = WfsFloatItem('heightLocation')
    height_order: WfsIntItem = WfsIntItem('heightOrder')


class AttachmentRecord(BasicWfsRecord[datamodels.AttachmentFeature]):
    WFS_TABLE_NAME: ClassVar[str] = 'ACISIAttachment'
    WFS_PRIMARY_KEY: ClassVar[str] = 'id'

    project_guid: WfsStringItem = WfsStringItem('projectGUID')
    pole_project_guid: WfsStringItem = WfsStringItem('pole')
    pole_guid: WfsStringItem = WfsStringItem('poleGUID')
    latitude: WfsFloatItem = WfsFloatItem('lat')
    longitude: WfsFloatItem = WfsFloatItem('long')
    object_guid: WfsStringItem = WfsStringItem('id')
    attachee_guid: WfsStringItem = WfsStringItem('attacheeGUID')
    attachee_display_name: WfsStringItem = WfsStringItem('attacheeDisplayName')
    attachee_entity_guid: WfsStringItem = WfsStringItem('attacheeEntityGUID')
    attachee_name: WfsStringItem = WfsStringItem('attacheeName')
    guid: WfsStringItem = WfsStringItem('attachmentGUID')
    height_location: WfsFloatItem = WfsFloatItem('attachmentHeightLocation')
    height_order: WfsIntItem = WfsIntItem('attachmentHeightOrder')
    type_guid: WfsStringItem = WfsStringItem('attachmentTypeGUID')
    type_display_name: WfsStringItem = WfsStringItem('typeDisplayName')
    type_name: WfsStringItem = WfsStringItem('typeName')


class DescriptorRecord(BasicWfsRecord[datamodels.DescriptorFeature]):
    WFS_TABLE_NAME: ClassVar[str] = 'ACISIDescriptor'
    WFS_PRIMARY_KEY: ClassVar[str] = 'id'

    name: WfsStringItem = WfsStringItem()
    display_name: WfsStringItem = WfsStringItem('displayName')
    project_guid: WfsStringItem = WfsStringItem('projectGUID')
    latitude: WfsFloatItem = WfsFloatItem('lat')
    longitude: WfsFloatItem = WfsFloatItem('long')
    object_guid: WfsStringItem = WfsStringItem('id')
    pole_category_name: WfsStringItem = WfsStringItem('categoryName')
    guid: WfsStringItem = WfsStringItem('descriptorGUID')
    pole_project_guid: WfsStringItem = WfsStringItem('pole')
    pole_guid: WfsStringItem = WfsStringItem('parentGUID')
    pole_category_guid: WfsStringItem = WfsStringItem('poleCategoryGUID')
    quantity: WfsIntItem = WfsIntItem('qty')
    type_guid: WfsStringItem = WfsStringItem('typeGUID')
    value: WfsStringItem = WfsStringItem()


class GpsHistoryRecord(BasicWfsRecord[datamodels.GpsHistoryFeature]):
    WFS_TABLE_NAME: ClassVar[str] = 'ACISIGPSHistory'
    WFS_PRIMARY_KEY: ClassVar[str] = 'id'

    project_guid: WfsStringItem = WfsStringItem('projectGUID')
    latitude: WfsFloatItem = WfsFloatItem('lat')
    longitude: WfsFloatItem = WfsFloatItem('long')
    object_guid: WfsStringItem = WfsStringItem('id')
    gps_satellite: WfsStringItem = WfsStringItem('GPSSat')
    gps_time: WfsStringItem = WfsStringItem('GPSTime')
    hdop: WfsFloatItem = WfsFloatItem('HDOP')
    pdop: WfsFloatItem = WfsFloatItem('PDOP')
    vdop: WfsFloatItem = WfsFloatItem('VDOP')
    altitude: WfsFloatItem = WfsFloatItem()
    date: WfsDateItem = WfsDateItem()
    fix_quality: WfsIntItem = WfsIntItem('fixQuality')
    ground_speed: WfsFloatItem = WfsFloatItem('groundSpeed')
    guid: WfsStringItem = WfsStringItem('historyGUID')
    htabvgeoid: WfsFloatItem = WfsFloatItem('htAbvGeoID')
    satellite_no: WfsIntItem = WfsIntItem('numSatellites')
    pole_guid: WfsStringItem = WfsStringItem('poleGUID')
    track_made_good: WfsFloatItem = WfsFloatItem('trackMadeGood')
    user_history_guid: WfsStringItem = WfsStringItem('userHistoryGUID')


class PoleRecord(BasicWfsRecord[datamodels.PoleFeature]):
    WFS_TABLE_NAME: ClassVar[str] = 'ACISIPole'
    WFS_PRIMARY_KEY: ClassVar[str] = 'id'

    project_guid: WfsStringItem = WfsStringItem('projectGUID')
    latitude: WfsFloatItem = WfsFloatItem('lat')
    longitude: WfsFloatItem = WfsFloatItem('long')
    object_guid: WfsStringItem = WfsStringItem('id')
    client_id: WfsIntItem = WfsIntItem('clientPoleID')
    in_client_db: WfsBoolItem = WfsBoolItem('inClientDB')
    owner_guid: WfsStringItem = WfsStringItem('owner')
    owner_company_name: WfsStringItem = WfsStringItem('ownerCompanyName')
    owner_display_name: WfsStringItem = WfsStringItem('ownerDisplayName')
    guid: WfsStringItem = WfsStringItem('poleGUID')
    status: WfsStringItem = WfsStringItem()
    x: WfsFloatItem = WfsFloatItem()
    y: WfsFloatItem = WfsFloatItem()
    notes: WfsStringItem = WfsStringItem()


class QcRecord(BasicWfsRecord[datamodels.QcFeature]):
    WFS_TABLE_NAME: ClassVar[str] = 'ACISIQC'
    WFS_PRIMARY_KEY: ClassVar[str] = 'QCGUID'

    project_guid: WfsStringItem = WfsStringItem('projectGUID')
    pole_project_guid: WfsStringItem = WfsStringItem('pole')
    pole_guid: WfsStringItem = WfsStringItem('poleGUID')
    latitude: WfsFloatItem = WfsFloatItem('lat')
    longitude: WfsFloatItem = WfsFloatItem('long')
    date: WfsDateItem = WfsDateItem('QCDate')
    guid: WfsStringItem = WfsStringItem('QCGUID')
    user_guid: WfsStringItem = WfsStringItem('userGUID')
    notes: WfsStringItem = WfsStringItem()
    description: WfsStringItem = WfsStringItem()
    record_guid: WfsStringItem = WfsStringItem('recordGUID')


class QcSelectionRecord(BasicWfsRecord[datamodels.QcSelectionFeature]):
    WFS_TABLE_NAME: ClassVar[str] = 'ACISIQCSelection'
    WFS_PRIMARY_KEY: ClassVar[str] = 'QCSelectionGUID'

    project_guid: WfsStringItem = WfsStringItem('projectGUID')
    pole_project_guid: WfsStringItem = WfsStringItem('pole')
    pole_guid: WfsStringItem = WfsStringItem('poleGUID')
    latitude: WfsFloatItem = WfsFloatItem('lat')
    longitude: WfsFloatItem = WfsFloatItem('long')
    guid: WfsStringItem = WfsStringItem('QCSelectionGUID')
    date: WfsDateItem = WfsDateItem()
    history_guid: WfsStringItem = WfsStringItem('historyGUID')


@deprecated
class TransferStepRecord(BasicWfsRecord[datamodels.TransferStepFeature]):
    WFS_TABLE_NAME: ClassVar[str] = 'ACISITransferStep'
    WFS_PRIMARY_KEY: ClassVar[str] = 'id'

    project_guid: WfsStringItem = WfsStringItem('projectGUID')
    pole_project_guid: WfsStringItem = WfsStringItem('pole')
    pole_guid: WfsStringItem = WfsStringItem('poleGUID')
    latitude: WfsFloatItem = WfsFloatItem('lat')
    longitude: WfsFloatItem = WfsFloatItem('long')
    object_guid: WfsStringItem = WfsStringItem('id')
    attachee_entity_guid: WfsStringItem = WfsStringItem('attacheeEntityGUID')
    attachee_entity_company_name: WfsStringItem = WfsStringItem('attacheeEntityCompanyName')
    attachee_entity_display_name: WfsStringItem = WfsStringItem('attacheeEntityDisplayName')
    attachee_entity_name: WfsStringItem = WfsStringItem('attacheeEntityName')
    job_type_display_name: WfsStringItem = WfsStringItem('jobtypedisplayname')
    job_type_guid: WfsStringItem = WfsStringItem('jobTypeGUID')
    job_type_name: WfsStringItem = WfsStringItem('jobTypeName')
    guid: WfsStringItem = WfsStringItem('stepGUID')
    step_order: WfsIntItem = WfsIntItem('stepOrder')
    transfer_guid: WfsStringItem = WfsStringItem('transferGUID')
    notes: WfsStringItem = WfsStringItem()


class UserHistoryRecord(BasicWfsRecord[datamodels.UserHistoryFeature]):
    WFS_TABLE_NAME: ClassVar[str] = 'ACISIUserHistory'
    WFS_PRIMARY_KEY: ClassVar[str] = 'id'

    project_guid: WfsStringItem = WfsStringItem('projectGUID')
    object_guid: WfsStringItem = WfsStringItem('id')
    date: WfsDateItem = WfsDateItem()
    guid: WfsStringItem = WfsStringItem('historyGUID')
    pole_guid: WfsStringItem = WfsStringItem('poleGUID')
    pole_status: WfsStringItem = WfsStringItem('poleStatus')
    user_guid: WfsStringItem = WfsStringItem('userGUID')
    pole_xml: WfsStringItem = WfsStringItem('poleXML', 'raw_pole_xml')


class ViolationRecord(BasicWfsRecord[datamodels.ViolationFeature]):
    WFS_TABLE_NAME: ClassVar[str] = 'ACISIViolation'
    WFS_PRIMARY_KEY: ClassVar[str] = 'id'

    project_guid: WfsStringItem = WfsStringItem('projectGUID')
    pole_project_guid: WfsStringItem = WfsStringItem('pole')
    pole_guid: WfsStringItem = WfsStringItem('poleGUID')
    latitude: WfsFloatItem = WfsFloatItem('lat')
    longitude: WfsFloatItem = WfsFloatItem('long')
    object_guid: WfsStringItem = WfsStringItem('id')
    assessment_display_name: WfsStringItem = WfsStringItem('assessmentDisplayName')
    assessment_guid: WfsStringItem = WfsStringItem('assessmentGUID')
    assessment_name: WfsStringItem = WfsStringItem('assessmentName')
    attachee_display_name: WfsStringItem = WfsStringItem('attacheeDisplayName')
    attachee_guid: WfsStringItem = WfsStringItem('attacheeGUID')
    attachee_name: WfsStringItem = WfsStringItem('attacheeName')
    entity_guid: WfsStringItem = WfsStringItem('entityGUID')
    type_display_name: WfsStringItem = WfsStringItem('typeDisplayName')
    type_guid: WfsStringItem = WfsStringItem('typeGUID')
    type_name: WfsStringItem = WfsStringItem('typeName')
    guid: WfsStringItem = WfsStringItem('violationGUID')
    notes: WfsStringItem = WfsStringItem()


class AttacheeTransferRecord(BasicWfsRecord[datamodels.AttacheeTransferFeature]):
    WFS_TABLE_NAME: ClassVar[str] = 'ACISIAttacheeTransfer'
    WFS_PRIMARY_KEY: ClassVar[str] = 'id'

    job_type_guid: WfsStringItem = WfsStringItem('jobTypeGUID')
    latitude: WfsFloatItem = WfsFloatItem('lat')
    longitude: WfsFloatItem = WfsFloatItem('long')
    object_guid: WfsStringItem = WfsStringItem('id')
    pole_project_guid: WfsStringItem = WfsStringItem('pole')
    pole_guid: WfsStringItem = WfsStringItem('poleGUID')
    project_guid: WfsStringItem = WfsStringItem('projectGUID')
    guid: WfsStringItem = WfsStringItem('transferGUID')


class AttacheeTransferStepRecord(BasicWfsRecord[datamodels.AttacheeTransferStepFeature]):
    WFS_TABLE_NAME: ClassVar[str] = 'ACISIAttacheeTransferStep'
    WFS_PRIMARY_KEY: ClassVar[str] = 'id'

    attachee_project_guid: WfsStringItem = WfsStringItem('attachee')
    attachee_entity_guid: WfsStringItem = WfsStringItem('attacheeEntityGUID')
    attachee_guid: WfsStringItem = WfsStringItem('parentGUID')
    object_guid: WfsStringItem = WfsStringItem('id')
    latitude: WfsFloatItem = WfsFloatItem('lat')
    longitude: WfsFloatItem = WfsFloatItem('long')
    notes: WfsStringItem = WfsStringItem()
    pole_project_guid: WfsStringItem = WfsStringItem('pole')
    pole_guid: WfsStringItem = WfsStringItem('poleGUID')
    project_guid: WfsStringItem = WfsStringItem('projectGUID')
    guid: WfsStringItem = WfsStringItem('stepGUID')
    step_order: WfsIntItem = WfsIntItem('stepOrder')
    transfer_project_guid: WfsStringItem = WfsStringItem('transfer')
    transfer_guid: WfsStringItem = WfsStringItem('transferGUID')

