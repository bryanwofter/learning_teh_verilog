from requests.auth import HTTPBasicAuth
from typing import ClassVar, List, Optional, Type, TypeVar
from trc_packages.debugging import printtodebugger
from trc_packages.wfs.mappings import BasicWfsRecord
from trc_packages.wfs.transaction_builder import AbstractXMLBuilder
T = TypeVar('T', bound=BasicWfsRecord)


class AcisiXMLBuilder(AbstractXMLBuilder[T]):

    namespace: str = None  # type: ignore
    namespace_url: str = None  # type: ignore

    @printtodebugger
    def __init__(self, namespace: str, namespace_url: str, wfs_type: Type[T]) -> None:
        super().__init__(wfs_type)

        self.namespace = namespace
        self.namespace_url = namespace_url

