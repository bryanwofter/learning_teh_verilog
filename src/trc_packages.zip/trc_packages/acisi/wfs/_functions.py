from trc_packages.acisi import datamodels, vectors
from trc_packages.acisi.wfs import wfsrecords
from trc_packages.core.features import protocols
from trc_packages.debugging import printtodebugger
from trc_packages.wfs.transaction_builder import BasicWfsRecord
from typing import Dict, Optional, Type, TypeVar
_T = TypeVar('_T', bound='protocols.Feature[vectors.ACISIVectorObject]')

_TYPE_MAP: Dict[Type['protocols.Feature[vectors.ACISIVectorObject]'], Type[BasicWfsRecord]] = None


@printtodebugger
def _init_type_map() -> None:
    global _TYPE_MAP
    if _TYPE_MAP is None:
        _TYPE_MAP = {datamodels.AddressFeature: wfsrecords.AddressRecord,
                     datamodels.AttacheeFeature: wfsrecords.AttacheeRecord,
                     datamodels.AttachmentFeature: wfsrecords.AttachmentRecord,
                     datamodels.DescriptorFeature: wfsrecords.DescriptorRecord,
                     datamodels.GpsHistoryFeature: wfsrecords.GpsHistoryRecord,
                     datamodels.PoleFeature: wfsrecords.PoleRecord,
                     datamodels.QcFeature: wfsrecords.QcRecord,
                     datamodels.QcSelectionFeature: wfsrecords.QcSelectionRecord,
                     datamodels.UserHistoryFeature: wfsrecords.UserHistoryRecord,
                     datamodels.ViolationFeature: wfsrecords.ViolationRecord,
                     datamodels.AttacheeTransferFeature: wfsrecords.AttacheeTransferRecord,
                     datamodels.AttacheeTransferStepFeature: wfsrecords.AttacheeTransferStepRecord}


@printtodebugger
def get_wfs_type(type_: Type[_T]) -> Optional[Type[BasicWfsRecord[_T]]]:
    """
    Returns the corresponding BasicWfsRecord type if one exists for the given feature type.
    :param type_: The feature type to resolve.
    """
    global _TYPE_MAP
    if _TYPE_MAP is None:
        _init_type_map()

    return _TYPE_MAP.get(type_)

