from enum import Enum, unique
from trc_packages.core import json_handlers


@unique
class PoleStatus(json_handlers.JSONEnum):
    """Provides the common pole statuses."""

    NONE = 'None'
    POWER_ONLY = 'PowerOnly'
    CATV_ONLY = 'CATVOnly'
    TELCO_ONLY = 'TelcoOnly'
    TELCO_CATV = 'Telco_CATV'
    LIGHT_POLE = 'LightPole'
    NOT_APPLICABLE = 'NotApplicable'
    NOT_IN_FIELD = 'NotInField'
    NOT_ACCESSIBLE = 'NotAccessible'
    FOREIGN_DONE = 'ForeignDone'
    DB_CORRECTION = 'DBCorrection'
    PASTE = 'Paste'
    MOVE = 'Move'
    OK = 'Ok'
    QC = 'QC'
    REMOVED = 'Removed'

    def __str__(self) -> str:
        return self.value

