from PyQt5 import QtCore
from trc_packages.asynclib import _trc_service as ts, _trc_service_executor as tse
from trc_packages.symbology import _symbol_generator_service as sgs, _symbol as s, _point_layer as pl, _symbol_type as st, _point_symbol_type as pst
from trc_packages.debugging import Debug, printtodebugger
from typing import Dict, Optional
from qgis.core import QgsCategorizedSymbolRenderer
import sqlite3
import random
import qgis


class ProjectAttacheeStylesBuilderService(ts.TrcService[Dict[str, QgsCategorizedSymbolRenderer]]):
    """
    Provides a TrcService that can be used to build all styles related to the attachees of the ACISI layers.
    """

    db_file: str = None
    attachees: Dict[str, 'sgs.SymbolGeneratorService[QgsCategorizedSymbolRenderer]'] = None

    @printtodebugger
    def __init__(self, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)
        self.attachees = dict()

    async def _run_async(self) -> Dict[str, QgsCategorizedSymbolRenderer]:
        try:
            self.attachees.clear()
            generator: tse.TrcServiceExecutor = tse.TrcServiceExecutor()
            sqlite: sqlite3.Connection
            with sqlite3.connect(self.db_file) as sqlite:
                sqlite.row_factory = sqlite3.Row

                category: sqlite3.Row
                for category in sqlite.execute("""
                                               SELECT "acisientitycategory"."displayname"
                                               FROM "acisientitycategory"
                                               INNER JOIN "acisientity" ON "acisientity"."categoryguid" = "acisientitycategory"."entitycategoryguid"
                                               INNER JOIN "acisiprojectattachees" ON "acisiprojectattachees"."entityguid" = "acisientity"."entityguid"
                                               ORDER BY "acisientitycategory"."displayorder", "acisientitycategory"."displayname"
                                               """):
                    service: sgs.SymbolGeneratorService[QgsCategorizedSymbolRenderer] = self.__make_category_service(category['displayname'])
                    service.setObjectName(category['displayname'])
                    generator.append(service)
                    self.attachees[category['displayname']] = service

            await generator
            return {k: v.result for k, v in self.attachees.items()}
        finally:
            pass

    @printtodebugger
    def __make_category_service(self, display_name: str) -> 'sgs.SymbolGeneratorService[QgsCategorizedSymbolRenderer]':
        """
        Creates a new category generator service.
        """
        def generator(serv: sgs.SymbolGeneratorService[QgsCategorizedSymbolRenderer]) -> QgsCategorizedSymbolRenderer:
            categories: QgsCategorizedSymbolRenderer = serv.make_categorized_renderer('displayname')

            sqlite: sqlite3.Connection
            with sqlite3.connect(self.db_file) as sqlite:
                sqlite.row_factory = sqlite3.Row

                entity: sqlite3.Row
                for row in sqlite.execute("""
                                          SELECT DISTINCT "acisientity"."displayname"
                                          FROM "acisientity"
                                          INNER JOIN "acisiprojectattachees" ON "acisiprojectattachees"."entityguid" = "acisientity"."entityguid"
                                          INNER JOIN "acisientitycategory" ON "acisientitycategory"."entitycategoryguid" = "acisientity"."categoryguid"
                                          WHERE "acisientitycategory"."displayname" = ?
                                          ORDER BY "acisientity"."displayname", "acisiprojectattachees"."frequency"
                                          """, [display_name]):
                    symbol: s.Symbol = s.Symbol(st.SymbolType.POINT, parent=self)
                    layer: pl.PointLayer = pl.PointLayer(symbol)
                    layer.shape = pst.PointSymbolType.ARROW
                    layer.angle = self.parent().next_angle()
                    layer.color = serv.color(*self.parent().next_color())
                    layer.size = 3.0
                    layer.offset = QtCore.QPointF(0.0, 1.0)
                    layer.offset_unit = qgis.core.QgsUnitTypes.RenderUnit.RenderMillimeters
                    layer.vertical_anchor_point = qgis.core.QgsMarkerSymbolLayer.VerticalAnchorPoint.Top
                    layer.horizontal_anchor_point = qgis.core.QgsMarkerSymbolLayer.HorizontalAnchorPoint.HCenter

                    symbol.layers.append(layer)
                    categories.addCategory(serv.make_category(row['displayname'], symbol.to_qgs_symbol()))

            return categories

        return sgs.SymbolGeneratorService(generator)

