from trc_packages.acisi import datamodels
from trc_packages.core.features import featureviewtype, FeatureView
from trc_packages.debugging import printtodebugger
from typing import Callable


class AttacheeTransferView(FeatureView[datamodels.AttacheeTransferFeature], metaclass=featureviewtype[datamodels.AttacheeTransferFeature]):  # type: ignore
    guid: str
    project_guid: str
    job_type_guid: str
    latitude: float
    longitude: float
    pole_guid: str

    set_job_type_guid: Callable[['AttacheeTransferView', str], None]


class AttacheeTransferStepView(FeatureView[datamodels.AttacheeTransferStepFeature], metaclass=featureviewtype[datamodels.AttacheeTransferStepFeature]):  # type:
    guid: str
    transfer_guid: str
    project_guid: str
    pole_guid: str
    latitude: float
    longitude: float
    attachee_guid: str
    attachee_entity_guid: str
    notes: str
    step_order: int

    set_attachee_guid: Callable[['AttacheeTransferStepView', str], None]
    set_step_order: Callable[['AttacheeTransferStepView', int], None]
    set_notes: Callable[['AttacheeTransferStepView', str], None]


class AddressView(FeatureView[datamodels.AddressFeature], metaclass=featureviewtype[datamodels.AddressFeature]):  # type: ignore
    guid: str
    house_no: str
    street: str
    notes: str
    place: str
    county: str
    state: str
    project_guid: str
    latitude: float
    longitude: float

    set_house_no: Callable[['AddressView', str], None]
    set_street: Callable[['AddressView', str], None]
    set_notes: Callable[['AddressView', str], None]
    set_place: Callable[['AddressView', str], None]


class AttacheeView(FeatureView[datamodels.AttacheeFeature], metaclass=featureviewtype[datamodels.AttacheeFeature]):  # type: ignore
    display_name: str
    entity_guid: str
    guid: str
    name: str
    height_location: float
    height_order: int
    project_guid: str
    type_guid: str

    @printtodebugger
    def __str__(self) -> str:
        return self.name


class AttachmentView(FeatureView[datamodels.AttachmentFeature], metaclass=featureviewtype[datamodels.AttachmentFeature]):  # type: ignore
    attachee_guid: str
    attachee_display_name: str
    attachee_entity_guid: str
    attachee_name: str
    guid: str
    height_location: float
    height_order: int
    type_guid: str
    type_display_name: str
    type_name: str
    project_guid: str
    pole_guid: str

    set_attachee_guid: Callable[['AttachmentView', str], None]
    set_attachee_display_name: Callable[['AttachmentView', str], None]
    set_attachee_entity_guid: Callable[['AttachmentView', str], None]
    set_attachee_name: Callable[['AttachmentView', str], None]
    set_guid: Callable[['AttachmentView', str], None]
    set_height_location: Callable[['AttachmentView', float], None]
    set_height_order: Callable[['AttachmentView', int], None]
    set_type_guid: Callable[['AttachmentView', str], None]
    set_type_display_name: Callable[['AttachmentView', str], None]
    set_type_name: Callable[['AttachmentView', str], None]
    set_project_guid: Callable[['AttachmentView', str], None]
    set_pole_guid: Callable[['AttachmentView', str], None]

    @property
    def height_feet(self) -> int:
        return int((self.height_location or 0) // 12)

    @height_feet.setter
    def height_feet(self, value: int) -> None:
        p_height_feet: int = self.height_feet
        self.height_location = (value or 0) * 12 + self.height_inches
        self.property_changed[str, 'PyQt_PyObject', 'PyQt_PyObject'].emit('height_feet', self.height_feet, p_height_feet)  # type: ignore

    @height_feet.deleter
    def height_feet(self) -> None:
        self.height_feet = 0

    @property
    def height_inches(self) -> int:
        return int((self.height_location or 0) % 12)

    @height_inches.setter
    def height_inches(self, value: int) -> None:
        p_height_inches: int = self.height_inches
        self.height_location = self.height_feet * 12 + (value or 0)
        self.property_changed[str, 'PyQt_PyObject', 'PyQt_PyObject'].emit('height_inches', self.height_inches, p_height_inches)  # type: ignore

    @height_inches.deleter
    def height_inches(self) -> None:
        self.height_inches = 0

    @property
    def attachment_no(self) -> int:
        return self.height_order

    @attachment_no.setter
    def attachment_no(self, value: int) -> None:
        self.height_order = value

    @attachment_no.deleter
    def attachment_no(self) -> None:
        self.height_order = 0

    @printtodebugger
    def __str__(self) -> str:
        return f"({self.attachment_no or 0}) {self.type_name or ''} @ {self.height_feet or 0}ft {self.height_inches or 0}in"


class DescriptorView(FeatureView[datamodels.DescriptorFeature], metaclass=featureviewtype[datamodels.DescriptorFeature]):  # type: ignore
    guid: str
    display_name: str
    name: str
    type_guid: str
    description: str
    quantity: int
    value: str


class ViolationView(FeatureView[datamodels.ViolationFeature], metaclass=featureviewtype[datamodels.ViolationFeature]):  # type: ignore
    assessment_guid: str
    attachee_display_name: str
    attachee_guid: str
    attachee_name: str
    entity_guid: str
    type_display_name: str
    type_guid: str
    type_name: str
    guid: str
    notes: str
    project_guid: str
    pole_guid: str

    @property
    def text(self) -> str:
        return self.type_display_name

    @text.setter
    def text(self, value: str) -> None:
        self.type_display_name = value

    @text.deleter
    def text(self) -> None:
        del self.type_display_name

    @printtodebugger
    def __str__(self) -> str:
        return " - ".join(filter(lambda v: v, [self.text, self.notes]))


class TransferStepView(FeatureView[datamodels.TransferStepFeature], metaclass=featureviewtype[datamodels.TransferStepFeature]):  # type: ignore
    step_order: int
    attachee_entity_company_name: str
    attachee_entity_display_name: str
    attachee_entity_name: str
    job_type_display_name: str
    job_type_guid: str
    job_type_name: str
    guid: str
    transfer_guid: str
    notes: str

    @printtodebugger
    def __str__(self) -> str:
        return f"{self.step_order or 0} {self.attachee_entity_display_name or ''}"

