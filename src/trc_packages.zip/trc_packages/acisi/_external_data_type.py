from enum import Enum, unique


@unique
class ExternalDataType(Enum):
    """
    Provides the hard coded GUIDs for acisiexternaldata. This is unfortunately required in a few places.
    """

    ID = '6729B48F-2B0A-4732-9542-287965C3AB34'
    ALIAS_ID = '4F7AF889-15EC-4EA6-8D60-FF96F43BB245'
    OWNER = '24C62A90-E9AB-4A63-B315-4CF07662BF32'
    TYPE = '70287D54-3B3E-4636-9CB3-9841DCEED29A'
    HEIGHT = 'E0E9FDB2-5FAA-4E1C-9856-CC4AD31BF4AC'
    CLASS = '395DDE4E-47D7-48F6-B7E4-F0D651D21C50'
    MATERIAL = '5B773727-07CF-4EF0-85C8-FD48D409625C'
    CID = '79F47293-7E50-4221-93E9-BA6A5B4D031A'

    def __str__(self) -> str:
        return self.value

