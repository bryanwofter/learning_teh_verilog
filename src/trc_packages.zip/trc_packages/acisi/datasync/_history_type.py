from enum import Enum, unique


@unique
class HistoryType(Enum):
    """The type of a history comparison."""

    LOCAL = 'local'
    REMOTE = 'remote'

