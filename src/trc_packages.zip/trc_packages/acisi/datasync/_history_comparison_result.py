from datetime import datetime
from trc_packages.acisi.datasync import _history_type as ht, _history_comparison_action as hca
from trc_packages.core.safecasts import safe_str, safe_datetime, safe_cast
from trc_packages.debugging import printtodebugger
from typing import Any, Tuple
import sqlite3


class HistoryComparisonResult:
    """
    The result of the history comparison.
    """
    guid: str = None
    date: datetime = None
    comparison_date: datetime = None
    history_type: ht.HistoryType = None
    comparison_action: hca.HistoryComparisonAction = None

    @printtodebugger
    def __init__(self, *, guid: str, date: datetime, comparison_date: datetime, history_type: ht.HistoryType, comparison_action: hca.HistoryComparisonAction) -> None:
        self.guid = guid
        self.date = date
        self.comparison_date = comparison_date
        self.history_type = history_type
        self.comparison_action = comparison_action

    @classmethod
    @printtodebugger
    def row_factory(cls, cursor: sqlite3.Cursor, row: Tuple[Any, ...]) -> 'HistoryComparisonResult':
        return cls(guid=safe_str(row[0]),
                   date=safe_datetime(row[1], datetime.max),
                   comparison_date=safe_datetime(row[2], datetime.min),
                   history_type=safe_cast(ht.HistoryType, row[3]),
                   comparison_action=safe_cast(hca.HistoryComparisonAction, row[4]))

    @printtodebugger
    def __eq__(self, other) -> bool:
        return self.guid == other.guid if isinstance(other, type(self)) else NotImplemented

    @printtodebugger
    def __hash__(self) -> int:
        return self.guid.__hash__()

    @printtodebugger
    def __str__(self) -> str:
        return f"guid: {self.guid}, date: {self.date}, comparison_date: {self.comparison_date}, history_type: {self.history_type}, comparison_action: {self.comparison_action}"

    @printtodebugger
    def __repr__(self) -> str:
        return f"<{self}>"

