from enum import auto, Enum, unique


@unique
class DataSyncStatus(Enum):
    """Defines the current status of the ProjectDataSyncService."""

    NOT_STARTED = auto()
    POLES_UPLOADING = auto()
    POLES_UPLOADED = auto()
    POLES_MERGING = auto()
    POLES_MERGED = auto()

