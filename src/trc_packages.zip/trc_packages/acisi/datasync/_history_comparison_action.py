from enum import Enum, unique
from typing import Set


@unique
class HistoryComparisonAction(Enum):
    """The action that was performed based off of the history comparison."""

    OTHER_MODIFIED = 'OTHER_MODIFIED'
    OTHER_REMOVED = 'OTHER_REMOVED'
    MODIFIED = 'MODIFIED'
    REMOVED = 'REMOVED'
    NEW = 'NEW'
    UNCHANGED = 'UNCHANGED'

    @property
    def is_other(self) -> bool:
        return self in _OTHERS


_OTHERS: Set[HistoryComparisonAction] = {HistoryComparisonAction.OTHER_MODIFIED, HistoryComparisonAction.OTHER_REMOVED, HistoryComparisonAction.UNCHANGED}

