from PyQt5 import QtCore
from trc_packages.acisi import _configuration
from trc_packages.asynclib import TrcService, total_steps
from trc_packages.debugging import printtodebugger
from typing import Generic, Optional, TypeVar
import os
T = TypeVar('T')


class ProjectService(Generic[T], TrcService[T]):
    """
    A base for all ACISI project services.
    """

    company_name: str = None
    project_guid: str = None
    project_id: str = None
    project_name: str = None
    user_name: str = None
    db_path: str = None
    output_project_path: str = None
    total_steps: int = None
    step_size: float = None

    @property
    def config(self) -> _configuration.Configuration:
        return _configuration.Configuration()

    @property
    def output_project_file(self) -> str:
        return os.path.join(self.output_project_path, f"{self.project_id}.qgz")

    @property
    def db_file(self) -> str:
        return os.path.join(self.db_path, f"{self.project_id}.sqlite")

    @property
    def history_db_file(self) -> str:
        return os.path.join(self.db_path, f"{self.project_id}_history.sqlite")

    @printtodebugger
    def __init__(self, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)

        self.total_steps = total_steps(type(self))
        self.step_size = 1 / self.total_steps

