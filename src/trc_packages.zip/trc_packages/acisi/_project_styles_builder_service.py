from PyQt5 import QtCore
from qgis.core import QgsCategorizedSymbolRenderer
from trc_packages.acisi import _project_attachee_styles_builder_service as pasbs
from trc_packages.asynclib import _trc_service_executor as tse
from trc_packages.debugging import printtodebugger
from trc_packages.symbology import _symbol_generator_service as sgs, _symbol as s, _point_layer as pl, _symbol_type as st, _point_symbol_type as pst
from typing import Optional, Tuple
import sqlite3
import qgis


class ProjectStylesBuilderService(tse.TrcServiceExecutor):
    """
    Provides a TrcServiceExecutor that can be used to build all styles related to the ACISI layers.
    """

    project_client_guid: str = None
    pole_style_generator: 'sgs.SymbolGeneratorService[QgsCategorizedSymbolRenderer]' = None
    pole_owner_style_generator: 'sgs.SymbolGeneratorService[QgsCategorizedSymbolRenderer]' = None
    descriptor_style_generator: 'sgs.SymbolGeneratorService[QgsCategorizedSymbolRenderer]' = None
    attachee_style_generator: 'pasbs.ProjectAttacheeStylesBuilderService' = None

    db_file: str = None
    _angle: float = 0.0
    _hue: float = 0.0
    _sat: float = 1.0
    _lum: float = 0.5

    @printtodebugger
    def next_angle(self) -> float:
        """
        Returns the next angle of this style builder.
        """
        with self._lock.synchronized(fail_on_timeout=True):
            try:
                return self._angle
            finally:
                self._angle += 45.0

    @printtodebugger
    def _hue_to_rgb(self, part_1: float, part_2: float, hue: float) -> float:
        if 0.0 > hue:
            hue = 1.0 - (-hue % 1.0)
        elif 1.0 < hue:
            hue = hue % 1.0

        if 1.0 > (6.0 * hue):
            return part_1 + (part_2 - part_1) * 6.0 * hue
        elif 1.0 > (2.0 * hue):
            return part_2
        elif 2.0 > (3.0 * hue):
            return part_1 + (part_2 - part_1) * ((2 / 3 - hue) * 6.0)

        return part_1

    @printtodebugger
    def next_color(self) -> Tuple[int, int, int]:
        """
        Returns the next RGB of this style builder.
        """
        with self._lock.synchronized(fail_on_timeout=True, timeout=10000):
            try:
                red: int
                green: int
                blue: int

                if 0.0 == self._lum:
                    red = green = blue = 0
                elif 0.0 == self._sat:
                    red = green = blue = round(self._lum * 255.0)
                else:
                    part_1: float
                    part_2: float

                    if 0.5 > self._lum:
                        part_2 = self._lum * (1.0 + self._sat)
                    else:
                        part_2 = (self._lum + self._sat) - (self._sat * self._lum)

                    part_1 = 2.0 * self._lum - part_2

                    red = round(255.0 * self._hue_to_rgb(part_1, part_2, (self._hue + 1 / 3)))
                    green = round(255.0 * self._hue_to_rgb(part_1, part_2, self._hue))
                    blue = round(255.0 * self._hue_to_rgb(part_1, part_2, (self._hue - 1 / 3)))

                return (red, green, blue)
            finally:
                self._hue += 0.1
                if 1.0 == self._hue:
                    self._hue = 0.0
                    self._sat -= 0.2
                    if 0.0 == self._sat:
                        self._sat = 1.0
                        self._lum -= 0.5
                        if 0.0 == self._lum:
                            self._lum = 0.75

    @printtodebugger
    def __init__(self, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent, total_worker_services=4)
        self.pole_style_generator = sgs.SymbolGeneratorService(self.generate_pole_symbology, parent=self)
        self.pole_style_generator.setObjectName('pole_style_generator')
        self.pole_owner_style_generator = sgs.SymbolGeneratorService(self.generate_pole_owner_symbology, parent=self)
        self.pole_owner_style_generator.setObjectName('pole_owner_style_generator')
        self.descriptor_style_generator = sgs.SymbolGeneratorService(self.generate_descriptor_symbology, parent=self)
        self.descriptor_style_generator.setObjectName('descriptor_style_generator')
        self.attachee_style_generator = pasbs.ProjectAttacheeStylesBuilderService(parent=self)
        self.attachee_style_generator.setObjectName('attachee_style_generator')

        self.append(self.pole_style_generator)
        self.append(self.pole_owner_style_generator)
        self.append(self.descriptor_style_generator)
        self.append(self.attachee_style_generator)

    @printtodebugger
    def generate_descriptor_symbology(self, serv: 'sgs.SymbolGeneratorService[QgsCategorizedSymbolRenderer]') -> QgsCategorizedSymbolRenderer:
        categories: QgsCategorizedSymbolRenderer = serv.make_categorized_renderer('displayname')

        sqlite: sqlite3.Connection
        with sqlite3.connect(self.db_file) as sqlite:
            sqlite.row_factory = sqlite3.Row

            row: sqlite3.Row
            for row in sqlite.execute('SELECT displayname FROM acisidescriptorlookup INNER JOIN acisiprojectdescriptors ON acisiprojectdescriptors.descriptorguid = acisidescriptorlookup.descriptorguid GROUP BY displayname'):
                symbol: s.Symbol = s.Symbol(st.SymbolType.POINT, parent=self)
                layer: pl.PointLayer = pl.PointLayer(symbol)
                layer.shape = pst.PointSymbolType.ARROW
                layer.angle = self.next_angle()
                layer.color = serv.color(*self.next_color())
                layer.size = 3.0
                layer.offset = QtCore.QPointF(0.0, 1.0)
                layer.offset_unit = qgis.core.QgsUnitTypes.RenderUnit.RenderMillimeters
                layer.vertical_anchor_point = qgis.core.QgsMarkerSymbolLayer.VerticalAnchorPoint.Top
                layer.horizontal_anchor_point = qgis.core.QgsMarkerSymbolLayer.HorizontalAnchorPoint.HCenter

                symbol.layers.append(layer)

                categories.addCategory(serv.make_category(row['displayname'], symbol.to_qgs_symbol()))

        return categories

    @printtodebugger
    def generate_pole_symbology(self, serv: 'sgs.SymbolGeneratorService[QgsCategorizedSymbolRenderer]') -> QgsCategorizedSymbolRenderer:
        categories: QgsCategorizedSymbolRenderer = serv.make_categorized_renderer('status')

        sqlite: sqlite3.Connection
        with sqlite3.connect(self.db_file) as sqlite:
            sqlite.row_factory = sqlite3.Row

            row: sqlite3.Row
            for row in sqlite.execute('SELECT status FROM acisipole GROUP BY status'):
                symbol: s.Symbol = s.Symbol(st.SymbolType.POINT, parent=self)
                layer: pl.PointLayer = pl.PointLayer(symbol)
                layer.shape = pst.PointSymbolType.CIRCLE
                layer.size = 2.5
                layer.color = serv.color(*self.next_color())

                symbol.layers.append(layer)

                categories.addCategory(serv.make_category(row['status'], symbol.to_qgs_symbol()))

        return categories

    @printtodebugger
    def generate_pole_owner_symbology(self, serv: 'sgs.SymbolGeneratorService[QgsCategorizedSymbolRenderer]') -> QgsCategorizedSymbolRenderer:
        categories: QgsCategorizedSymbolRenderer = serv.make_categorized_renderer('displayname')

        sqlite: sqlite3.Connection
        with sqlite3.connect(self.db_file) as sqlite:
            sqlite.row_factory = sqlite3.Row

            row: sqlite3.Row
            for row in sqlite.execute('SELECT displayname FROM acisientity INNER JOIN acisiprojectpoleowners ON acisiprojectpoleowners.entityguid = acisientity.entityguid WHERE acisientity.entityguid <> ? GROUP BY displayname ORDER BY acisientity.displayname',
                                      [self.project_client_guid]):
                symbol: s.Symbol = s.Symbol(st.SymbolType.POINT, parent=self)
                layer: pl.PointLayer = pl.PointLayer(symbol)
                layer.shape = pst.PointSymbolType.ARROW
                layer.angle = self.next_angle()
                layer.color = serv.color(*self.next_color())
                layer.size = 3.0
                layer.offset = QtCore.QPointF(0.0, 1.0)
                layer.offset_unit = qgis.core.QgsUnitTypes.RenderUnit.RenderMillimeters
                layer.vertical_anchor_point = qgis.core.QgsMarkerSymbolLayer.VerticalAnchorPoint.Top
                layer.horizontal_anchor_point = qgis.core.QgsMarkerSymbolLayer.HorizontalAnchorPoint.HCenter

                symbol.layers.append(layer)

                categories.addCategory(serv.make_category(row['displayname'], symbol.to_qgs_symbol()))

        return categories

