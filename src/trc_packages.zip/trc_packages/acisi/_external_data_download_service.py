from enum import Enum, unique
from trc_packages.acisi import vectors, datamodels, _configuration as c
from trc_packages.asynclib import _trc_service as ts
from trc_packages.projects import _project_loader_service as pls
from typing import Optional
from PyQt5 import QtCore
from trc_packages.debugging import Debug, printtodebugger
import requests
import requests.auth


class ExternalDataDownloadService(ts.TrcService[bool]):
    """
    Downloads all external data for the given object GUID if it doesn't already exist.
    """

    object_guid: str = None
    guid_field: str = None
    base_url: str = None
    mrisa_user: str = None
    mrisa_pass: str = None

    @property
    def config(self) -> 'c.Configuration':
        return Configuration()

    @printtodebugger
    def __init__(self, guid_field: str, object_guid: str, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)
        self.guid_field = guid_field
        self.object_guid = object_guid

    async def _run_async(self) -> bool:
        config: c.Configuration = c.Configuration()
        layer_loader: pls.ProjectLayerLoader = pls.ProjectLayerLoader(parent=self,
                                                                      project_guid=config.project_guid,
                                                                      base_type=config.base_type,
                                                                      base_url=config.base_url,
                                                                      mrisa_user=config.mrisa_user,
                                                                      mrisa_pass=config.mrisa_pass,
                                                                      redownload_data=True,
                                                                      project_id=config.project_id,
                                                                      db_path=config.db_path,
                                                                      temp_file_name=config.temp_file_name,
                                                                      xml_path=config.xml_path)
        try:
            external_data: vectors.ExternalDataVector = vectors.ExternalDataVector()
            if not external_data.exists(f"{self.guid_field} = " + '{}', self.object_guid):
                layer: pls.BoundLayer = pls.BoundlessLayer(layer='ACISIExternalData',
                                                           uses_project_guid=False,
                                                           filter_=f"{self.guid_field}%3d%27{self.object_guid}%27")

                layer_loader.make_project_layer_chunk(self, 0.0, [layer])
        except ConnectionError as e:
            pass
        Debug.print(layer_loader.validation_messages)
        return not any(layer_loader.validation_messages)

