from collections import defaultdict
from datetime import datetime
from PyQt5 import QtCore
from trc_packages.acisi import _project_service as ps, constants, datamodels, utils, vectors, wfs
from trc_packages.acisi.datasync import HistoryComparisonAction, HistoryComparisonResult, HistoryType
from trc_packages.asynclib import step, protocols, TrcServiceExecutor, TrcFunctionService, TrcReusableFunctionService, copy2_async
from trc_packages.core import flatten, ui, last, json_handlers
from trc_packages.core.features import escape_filter_args, resolve_fields, VectorProvider, protocols as feature_protocols
from trc_packages.debugging import Debug, printtodebugger
from trc_packages.decorators import catchlog
from trc_packages.wfs.transaction_builder import BasicWfsRecord, Operation
from trc_packages.wfs import exceptions, services
from typing import Callable, Dict, Iterable, Iterator, List, Optional, Set, Tuple, Type, TypeVar
from xml.etree import ElementTree as etree
from getpass import getuser
import itertools
import json
import os
import sqlite3
import requests
V = TypeVar('V', bound=vectors.ACISIVectorObject)


class ProjectDataSyncService(ps.ProjectService[bool]):
    """
    Pulls down the most recent server history of all poles for a project and resolves which poles to send and which poles to pull.
    """
    vector_types: Tuple[Type[vectors.ACISIVectorObject], ...] = (vectors.AddressVector, vectors.AttacheeVector, vectors.AttachmentVector,
                                                                 vectors.AttachmentTypeVector, vectors.DescriptorVector,
                                                                 vectors.DescriptorTypeVector, vectors.EntityVector, vectors.EntityCategoryVector,
                                                                 vectors.ExternalDataVector, vectors.GpsHistoryVector, vectors.PoleVector,
                                                                 vectors.PoleCategoryVector, vectors.ProjectVector,
                                                                 vectors.ProjectAttacheeVector, vectors.ProjectAttachmentTypeVector,
                                                                 vectors.ProjectClientOwnerVector, vectors.ProjectDescriptorTypeVector,
                                                                 vectors.ProjectPoleOwnerVector, vectors.ProjectTransferTypeVector,
                                                                 vectors.ProjectViolationTypeVector, vectors.QcVector,
                                                                 vectors.QcSelectionVector, vectors.TransferStepVector,
                                                                 vectors.TransferTypeVector, vectors.UserHistoryVector, vectors.ViolationVector,
                                                                 vectors.ViolationTypeVector, vectors.AttacheeTransferVector,
                                                                 vectors.AttacheeTransferStepVector)

    SELECT_SYNC_HISTORY: str = '''
    SELECT *
    FROM "sync_history";
    '''

    SELECT_JSON_BLOB: str = '''
    SELECT json_blob
    FROM "acisihistory"
    WHERE "project_guid" = ? AND
          "object_guid" = ? AND
          "synced" = 0 AND
          "action" = ?
    ORDER BY datetime("date") {};
    '''

    INSERT_SYNC_HISTORY: str = '''
    INSERT INTO "acisihistory" (
        "type",
        "action",
        "date",
        "project_guid",
        "object_guid",
        "json_blob",
        "synced"
    ) VALUES (
        ?,
        ?,
        ?,
        ?,
        ?,
        ?,
        ?
    );
    '''

    data_normalizing: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='dataNormalizing')
    data_normalized: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='dataNormalized')
    history_preparing: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='historyPreparing')
    history_prepared: QtCore.pyqtSignal = QtCore.pyqtSignal([], [int, int], name='historyPrepared')
    history_uploading: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='historyUploading')
    history_upload_skipped: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='historyUploadSkipped')
    history_uploaded: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='historyUploaded')
    history_processing: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='historyProcessing')
    history_processed: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='historyProcessed')
    local_data_clearing: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='localDataClearing')
    local_data_cleared: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='localDataCleared')
    upp_upload_service: Optional['service.WFSUploadService'] = None

    history_actions_processing: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='historyActionsProcessing')
    history_actions_processed: QtCore.pyqtSignal = QtCore.pyqtSignal([], [int, int, int], name='historyActionsProcessed')

    validation_messages: List[str] = None
    working_db_path: str = None
    base_url: str = None
    mrisa_user: str = None
    mrisa_pass: str = None

    pole_modifications: Dict[HistoryType, Dict[HistoryComparisonAction, Set[HistoryComparisonResult]]] = None

    @property
    def working_db_file(self) -> str:
        return os.path.join(self.working_db_path, f"{self.project_id}.sqlite")

    @printtodebugger
    def __init__(self, db_path: str, output_project_path: str, working_db_path: str, base_url: str, mrisa_user: str, mrisa_pass: str, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)

        self.validation_messages = []
        self.db_path = db_path
        self.working_db_path = working_db_path
        self.output_project_path = output_project_path
        self.pole_modifications = defaultdict(lambda: defaultdict(set))
        self.base_url = base_url
        self.mrisa_user = mrisa_user
        self.mrisa_pass = mrisa_pass

    async def _run_async(self) -> bool:
        """Generates the working project details for ACISI and attempts to merge the projects."""
        self._progress = 0.0
        self.validation_messages.clear()
        self.state = None
        self.pole_modifications.clear()

        if self.project_guid is None:
            self.validation_messages.append('Project GUID is required.')
        if self.project_name is None:
            self.validation_messages.append('Project name is required.')
        if self.project_id is None:
            self.validation_messages.append('Project ID is required.')
        if self.user_name is None:
            self.validation_messages.append('User name is required.')
        if self.company_name is None:
            self.validation_messages.append('Company name is required.')
        if self.db_path is None:
            self.validation_messages.append('DB path is required.')
        elif not os.path.isdir(self.db_path):
            self.validation_messages.append('DB path does not exist.')
        elif not os.path.isfile(self.db_file):
            self.validation_messages.append('DB does not exist.')
        if self.output_project_path is None:
            self.validation_messages.append('Output project path is required.')
        if self.base_url is None:
            self.validation_messages.append('No WFS server provided.')
        if self.mrisa_user is None:
            self.validation_messages.append('No WFS user provided.')
        if self.mrisa_pass is None:
            self.validation_messages.append('No WFS password provided.')

        if any(self.validation_messages):
            return False

        self.data_normalizing.emit()
        if self._correct_datetime_columns():
            self.data_normalized.emit()
        else:
            return False

        """
        self.history_processing.emit()
        if await self._process_history():
            self.history_processed.emit()
        else:
            return False

        self.local_data_clearing.emit()
        if self._clear_local_data():
            self.local_data_cleared.emit()
        else:
            return False
        """

        Debug.print(self.upp_upload_service)
        if self.upp_upload_service is not None:
            Debug.print('here')
            await self.upp_upload_service

        self.history_uploading.emit()
        try:
            base_dir: str = os.path.join('\\\\columbus-vfp\\shared\\CLS\\MRISA_Setup\\ACISI_DB', getuser())
            if not os.path.isdir(base_dir):
                os.mkdir(base_dir)
            await copy2_async(src=self.db_file, dst=os.path.join(base_dir, last(os.path.split(self.db_file))), parent=self)
            await copy2_async(src=self.history_db_file, dst=os.path.join(base_dir, last(os.path.split(self.history_db_file))), parent=self)
            self.history_uploaded.emit()
        except:
            self.validation_messages.append('Unable to upload local data to server. Please make sure you\'re connected to the network.')

        return not any(self.validation_messages)

    @step
    @printtodebugger
    def _correct_datetime_columns(self) -> bool:
        """Converts datetime columns to a valid datetime format."""

        with sqlite3.connect(self.db_file) as sqlite:  # type: sqlite3.Connection
            cursor: sqlite3.Cursor = sqlite.cursor()

            cursor.executescript(constants.CORRECT_DATETIME_COLUMNS)

        return True

    @step
    @printtodebugger
    def _prepare_history(self, service: protocols.Service[None]) -> None:
        """
        Prepares all of the history that needs to be uploaded to the server.
        :param service: The service used to prepare the history for upload.
        """
        self.history_preparing.emit()
        local_vectors: VectorProvider['vectors.ACISIVectorObject'] = VectorProvider()

        # TODO: Simplify this method, it's a bit messy.
        sqlite: sqlite3.Connection
        with sqlite3.connect(self.history_db_file) as sqlite:
            sqlite.row_factory = sqlite3.Row
            xml: str = None
            histories: List[sqlite3.Row] = list(sqlite.execute(self.SELECT_SYNC_HISTORY))
            history_count: int = len(histories)

            collected_features: Dict[str, Dict[type, List[BasicWfsRecord]]] = defaultdict(lambda: defaultdict(list))

            current_count: int = 0
            history: sqlite3.Row
            for history in histories:
                skipped: bool = False
                vector: protocols.Vector = local_vectors[vectors.vector_classes[history['type']]]
                feature: protocols.Feature = vector.by_project_and_guid(history['project_guid'], history['object_guid'])

                if feature is None:
                    if history['action'] == 'delete':
                        data: Dict[str, Any] = json.loads(sqlite.execute(self.SELECT_JSON_BLOB.format('DESC'),
                                                                         [history['project_guid'],
                                                                          history['object_guid'],
                                                                          'delete']).fetchone()['json_blob'] or
                                                          '{}')
                    else:
                        continue
                    feature = vector.new_feature(**(data or {}))
                elif isinstance(feature, datamodels.AttacheeTransferStepFeature) and feature.transfer_guid is None:
                    feature.transfer_guid = local_vectors[vectors.AttacheeTransferVector].by_pole_and_project(feature.pole_guid, feature.project_guid).guid
                elif history['action'] == 'update':
                    data: Dict[str, Any] = json.loads(sqlite.execute(self.SELECT_JSON_BLOB.format('ASC'),
                                                                     [history['project_guid'],
                                                                      history['object_guid'],
                                                                      'update']).fetchone()['json_blob'] or
                                                      '{}')
                    feature_data: Dict[str, Any] = json.loads(json.dumps(dict(feature.items()), cls=json_handlers.TrcJSONEncoder))
                    skipped = data == feature_data

                if not skipped and feature.has_hashable_values:
                    sqlite.execute(self.INSERT_SYNC_HISTORY,
                                   [history['type'],
                                    'sync',
                                    datetime.now(),
                                    history['project_guid'],
                                    history['object_guid'],
                                    json.dumps(dict(feature.items()), cls=json_handlers.TrcJSONEncoder),
                                    1])

                    record_type: Type[BasicWfsRecord] = wfs.get_wfs_type(type(feature))

                    record: BasicWfsRecord = record_type(feature)
                    record.init_attributes()

                    collected_features[history['action']][record_type].append(record)

                current_count += 1

                self.history_prepared[int, int].emit(current_count, history_count)
                service._progress = current_count / history_count

            # Build the XML from the collected features.
            total_deletes: int = 0
            total_inserts: int = 0
            total_updates: int = 0

            self.history_actions_processing.emit()
            action: str
            types: Dict[type, List[BasicWfsRecord]]
            for action, types in collected_features.items():
                xml: str
                type_: type
                records: List[BasicWfsRecord]
                for type_, records in types.items():
                    xml_builder: wfs.AcisiXMLBuilder = wfs.AcisiXMLBuilder('MRISA', 'http://www.spidasoftware.com/mrisa', type_)

                    if action == 'delete':
                        xml = xml_builder.delete_features_xml(records)
                        total_deletes += len(records)
                    elif action == 'insert':
                        xml = xml_builder.insert_features_xml(records)
                        total_inserts += len(records)
                    elif action == 'update':
                        xml = xml_builder.update_features_xml(records)
                        total_updates += len(records)
                    else:
                        continue

                    xml_element: etree.Element = self._flatten_actions(action, etree.fromstring(xml))

                    if service.state is None:
                        service.state = xml_element
                    else:
                        service.state.extend(xml_element)

                    self.history_actions_processed[int, int, int].emit(total_deletes, total_inserts, total_updates)
            self.history_actions_processed.emit()

            oldest_change_date: datetime = sqlite.execute('SELECT MIN(datetime("date")) AS "date" FROM "acisihistory" WHERE "synced" = 0;').fetchone()
            if oldest_change_date:
                record_type = wfs.get_wfs_type(datamodels.UserHistoryFeature)
                xml_builder = wfs.AcisiXMLBuilder('MRISA', 'http://www.spidasoftware.com/mrisa', record_type)
                user_histories: List[BasicWfsRecord] = [record_type(h) for h in local_vectors[vectors.UserHistoryVector].find('[date] >= {}', oldest_change_date)]

                for user_history in user_histories:
                    user_history.init_attributes()
                xml = xml_builder.insert_features_xml(user_histories)
                xml_element = self._flatten_actions('insert', etree.fromstring(xml))

                if service.state is None:
                    service.state = service.state = xml_element
                else:
                    service.state.extend(xml_element)
            sqlite.execute('UPDATE "acisihistory" SET "synced" = 1;')
        self.history_prepared.emit()

    def _flatten_actions(self, action: str, xml_element: etree.Element) -> etree.Element:
        """
        """
        if action == 'delete':
            # Remove all deletes for this XML element that lack an actual filter.
            # TODO: Make this less horrifyingly gross
            delete: etree.Element
            for delete in xml_element.findall('{http://www.opengis.net/wfs/2.0}Delete'):
                root: etree.Eleement
                for root in delete:
                    or_elem: etree.Element
                    for or_elem in root:
                        filter: etree.Element
                        for filter in or_elem.findall('{http://www.opengis.net/fes/2.0}PropertyIsEqualTo'):
                            literal: etree.Element = filter.find('{http://www.opengis.net/fes/2.0}Literal')
                            if literal is None or not literal.text:
                                or_elem.remove(filter)

            return xml_element
        elif action == 'insert':
            # Flatten all inserts for this XML element into a single INSERT block.
            root_insert: etree.Element = None
            insert: etree.Element
            for insert in xml_element.findall('{http://www.opengis.net/wfs/2.0}Insert'):
                xml_element.remove(insert)
                if root_insert is None:
                    root_insert = insert
                else:
                    root_insert.extend(insert)

            xml_element.append(root_insert)
            return xml_element
        elif action == 'update':
            return xml_element
        else:
            return xml_element

    @step
    @printtodebugger
    def _upload_history(self, service: protocols.Service[None]) -> None:
        """
        Uploads all of the history that needs to be uploaded to the server.
        :param service: The service used to send the history.
        """
        service._progress = 0.
        self.history_uploading.emit()
        if service.state is not None:
            xml: str = etree.tostring(service.state, encoding='unicode')

            response: requests.Response = requests.post(self.base_url.format(f"{self.mrisa_user}:{self.mrisa_pass}@"),
                                                        data=xml,
                                                        auth=requests.auth.HTTPBasicAuth(self.mrisa_user,
                                                                                         self.mrisa_pass),
                                                        verify=False)

            if response.status_code not in range(200, 400):
                raise exceptions.WfsExceptionReportError(response.text)
            self.history_uploaded.emit()
        else:
            self.history_upload_skipped.emit()
        service._progress = 1.

    @step
    async def _process_history(self) -> bool:
        """
        Processes the local history and uploads it to the database.
        """
        current_progress: float = self.progress

        def __on_progress_changed(progress: float) -> None:
            nonlocal current_progress
            self._progress = current_progress + (self.step_size * progress)

        service: TrcFunctionService[None] = TrcReusableFunctionService(target=self._prepare_history, parent=self)
        service.progress_changed.connect(__on_progress_changed)
        await service
        current_progress = self.progress
        service.target = self._upload_history
        await service

        return not any(self.validation_messages)

    @step
    @printtodebugger
    def _clear_local_data(self) -> bool:
        """
        Deletes all data from the local database so that new data can be downloaded.
        """
        sqlite: sqlite3.Connection
        with sqlite3.connect(self.db_file) as sqlite:
            cursor: sqlite3.Cursor = sqlite.execute('BEGIN TRANSACTION;')
            try:
                vector_type: Type[vectors.ACISIVectorObject]
                for vector_type in self.vector_types:
                    cursor.execute(f'DELETE FROM "{vector_type.layer_name}";')

                cursor.execute('COMMIT TRANSACTION;')
            except Exception as e:
                cursor.execute('ROLLBACK TRANSACTION;')
                raise e

        with sqlite3.connect(self.db_file) as sqlite:
            sqlite.executescript('VACUUM;').close()

        self._progress += self.step_size
        return not any(self.validation_messages)

