from abc import ABC, abstractmethod
from xml.etree import ElementTree as etree
from trc_packages.acisi import vectors
from trc_packages.core.features import protocols, VectorProvider
from trc_packages.debugging import printtodebugger
from typing import Any, Dict, Generic, Iterable, Type, TypeVar
try: from typing import Final  # type: ignore
except: from typing_extensions import Final
C = TypeVar('C', bound='StructureABC')
F = TypeVar('F', bound='protocols.Feature')
V = TypeVar('V', bound='vectors.ACISIVectorObject')


class StructureABC(Generic[V], ABC):
    NAME: Final[str]
    VECTOR_TYPE: Final[Type[V]]

    @printtodebugger
    def make_element(self, feature: protocols.Feature) -> etree.Element:
        """Returns the element representation of this structure before any attributes or child nodes are added."""
        return etree.Element(self.NAME, self.feature_to_dict(feature))

    @printtodebugger
    def feature_to_dict(self, feature: protocols.Feature) -> Dict[str, Any]:
        """
        Returns a dictionary that represents the given feature.
        :param feature: The feature to convert into a dictionary.
        """
        output: Dict[str, Any] = {}

        if feature is not None:
            for field in feature.get_feature_items_by_field():  # type: str
                if feature[field] is not None:
                    output[field] = str(feature[field])

        return output

    @classmethod
    @printtodebugger
    def feature_from_xml(cls: Type[C], xml: etree.Element, vectors: VectorProvider['vectors.ACISIVectorObject']) -> F:
        """
        Returns a Feature instance based off of the given etree XML element and vector provider.
        :param xml: The etree XML element to convert.
        :param vectors: The vectors to source the Feature instance from.
        """
        return vectors[cls.VECTOR_TYPE].new_feature(**xml.attrib)


    @abstractmethod
    def to_xml(self) -> etree.Element:
        """Returns the etree XML representation of this structure."""
        ...

    @classmethod
    @abstractmethod
    def from_xml(cls: Type[C], xml: etree.Element, vectors: VectorProvider['vectors.ACISIVectorObject']) -> C:
        """
        Returns the StructureABC representation of the given etree XML representation of this structure.
        :param xml: The etree XML to convert to a structure.
        :param vector: The vector that is used to create the backing feature of this structure.
        """
        ...

    @abstractmethod
    def features(self) -> Iterable['protocols.Feature']:
        """Gets all features, including child, of this structure."""
        ...

