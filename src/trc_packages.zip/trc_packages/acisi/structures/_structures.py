from collections import defaultdict
from trc_packages.acisi import datamodels, vectors
from trc_packages.acisi.structures import _structure_abc as sa
from trc_packages.core.features import protocols, VectorProvider
from trc_packages.decorators import deprecated
from trc_packages.debugging import printtodebugger
from typing import Dict, Iterable, Type
from typing_extensions import Final
from xml.etree import ElementTree as etree


class PoleStructure(sa.StructureABC['vectors.PoleVector']):
    NAME: Final[str] = 'tblpoles'
    VECTOR_TYPE: Final[Type['vectors.PoleVector']] = vectors.PoleVector

    pole: datamodels.PoleFeature = None
    address: 'AddressStructure' = None
    attachees: Dict[str, 'AttacheeStructure'] = None
    descriptors: Dict[str, 'DescriptorStructure'] = None
    transfers: datamodels.AttacheeTransferFeature = None

    @printtodebugger
    def __init__(self) -> None:
        self.attachees = defaultdict(AttacheeStructure)
        self.descriptors = defaultdict(DescriptorStructure)

    @printtodebugger
    def to_xml(self) -> etree.Element:
        element: etree.Element = self.make_element(self.pole)

        if self.address is not None:
            element.append(self.address.to_xml())

        if self.attachees is not None:
            for attachee in self.attachees.values():  # type: AttacheeStructure
                element.append(attachee.to_xml())

        if self.descriptors is not None:
            for descriptor in self.descriptors.values():  # type: DescriptorStructure
                element.append(descriptor.to_xml())

        if self.transfers is not None:
            element.append(self.transfers.to_xml())

        return element

    @printtodebugger
    def features(self) -> Iterable[protocols.Feature]:
        if self.pole is not None:
            yield self.pole

        if self.address is not None:
            yield from self.address.features()

        if self.attachees is not None:
            for attachee in self.attachees.values():  # type: AttacheeStructure
                yield from attachee.features()

        if self.descriptors is not None:
            for descriptor in self.descriptors.values():  # type: DescriptorStructure
                yield from descriptor.features()

        if self.transfers is not None:
            yield from self.transfers.features()

    @classmethod
    @printtodebugger
    def from_xml(cls, xml: etree.Element, vectors: VectorProvider['vectors.ACISIVectorObject']) -> 'PoleStructure':
        structure: PoleStructure = cls()

        if xml is not None:
            structure.pole = cls.feature_from_xml(xml, vectors)

            for address_xml in xml.iter(AddressStructure.NAME):  # type: etree.Element
                structure.address = AddressStructure.from_xml(address_xml, vectors)
                break

            for attachee_xml in xml.iter(AttacheeStructure.NAME):  # type: etree.Element
                attachee: AttacheeStructure = AttacheeStructure.from_xml(attachee_xml, vectors)
                structure.attachees[attachee.attachee.entity_guid] = attachee

            for descriptor_xml in xml.iter(DescriptorStructure.NAME):  # type: etree.Element
                descriptor: DescriptorStructure = DescriptorStructure.from_xml(descriptor_xml, vectors)
                structure.descriptors[descriptor.descriptor.type_guid] = descriptor

            for transfers_xml in xml.iter(AttacheeTransferStructure.NAME):  # type: etree.Element
                structure.transfers = AttacheeTransferStructure.from_xml(transfers_xml, vectors)
                break

        return structure

    @printtodebugger
    def __str__(self) -> str:
        return f"({self.pole}, address: {self.address}, attachees: {dict(self.attachees)}, descriptors: {dict(self.descriptors)}, transfers: {self.transfers})"


class AddressStructure(sa.StructureABC['vectors.AddressVector']):
    NAME: Final[str] = 'tbladdress'
    VECTOR_TYPE: Final[Type['vectors.AddressVector']] = vectors.AddressVector
    address: datamodels.AddressFeature = None

    @printtodebugger
    def to_xml(self) -> etree.Element:
        return self.make_element(self.address)

    @printtodebugger
    def features(self) -> Iterable[protocols.Feature]:
        if self.address is not None:
            yield self.address

    @classmethod
    @printtodebugger
    def from_xml(cls, xml: etree.Element, vectors: VectorProvider['vectors.ACISIVectorObject']) -> 'AddressStructure':
        structure: AddressStructure = cls()

        if xml is not None:
            structure.address = cls.feature_from_xml(xml, vectors)

        return structure

    @printtodebugger
    def __str__(self) -> str:
        return str(self.address)


class AttacheeStructure(sa.StructureABC['vectors.AttacheeVector']):
    NAME: Final[str] = 'tblattachees'
    VECTOR_TYPE: Final[Type['vectors.AttacheeVector']] = vectors.AttacheeVector
    attachee: datamodels.AttacheeFeature = None
    transfer_step: 'TransferStepStructure' = None
    attachments: Dict[str, 'AttachmentStructure'] = None
    violations: Dict[str, 'ViolationStructure'] = None

    @printtodebugger
    def __init__(self) -> None:
        self.attachments = defaultdict(AttachmentStructure)
        self.violations = defaultdict(ViolationStructure)

    @printtodebugger
    def to_xml(self) -> etree.Element:
        element: etree.Element = self.make_element(self.attachee)

        if self.transfer_step is not None:
            element.append(self.transfer_step.to_xml())

        if self.attachments is not None:
            for attachment in self.attachments.values():  # type: AttachmentStructure
                element.append(attachment.to_xml())

        if self.violations is not None:
            for violation in self.violations.values():  # type: ViolationStructure
                element.append(violation.to_xml())

        return element

    @printtodebugger
    def features(self) -> Iterable[protocols.Feature]:
        if self.attachee is not None:
            yield self.attachee

        if self.transfer_step is not None:
            yield from self.transfer_step.features()

        if self.attachments is not None:
            for attachment in self.attachments.values():  # type: AttachmentStructure
                yield from attachment.features()

        if self.violations is not None:
            for violation in self.violations.values():  # type: ViolationStructure
                yield from violation.features()

    @classmethod
    @printtodebugger
    def from_xml(cls, xml: etree.Element, vectors: VectorProvider['vectors.ACISIVectorObject']) -> 'AttacheeStructure':
        structure: AttacheeStructure = cls()

        if xml is not None:
            structure.attachee = cls.feature_from_xml(xml, vectors)

            for transfer_step_xml in xml.iter(TransferStepStructure.NAME):  # type: etree.Element
                structure.transfer_step = TransferStepStructure.from_xml(transfer_step_xml, vectors)
                break

            for attachment_xml in xml.iter(AttachmentStructure.NAME):  # type: etree.Element
                attachment: AttachmentStructure = AttachmentStructure.from_xml(attachment_xml, vectors)
                structure.attachments[attachment.attachment.guid] = attachment

            for violation_xml in xml.iter(ViolationStructure.NAME):  # type: etree.Element
                violation: ViolationStructure = ViolationStructure.from_xml(violation_xml, vectors)
                structure.violations[violation.violation.type_guid] = violation

        return structure

    @printtodebugger
    def __str__(self) -> str:
        return f"({self.attachee}, transfer_step: {self.transfer_step}, attachments: {dict(self.attachments)}, violations: {dict(self.violations)})"


class AttachmentStructure(sa.StructureABC['vectors.AttachmentVector']):
    NAME: Final[str] = 'tblattachments'
    VECTOR_TYPE: Final[Type['vectors.AttachmentVector']] = vectors.AttachmentVector
    attachment: datamodels.AttachmentFeature = None

    @printtodebugger
    def to_xml(self) -> etree.Element:
        return self.make_element(self.attachment)

    @printtodebugger
    def features(self) -> Iterable[protocols.Feature]:
        if self.attachment is not None:
            yield self.attachment

    @classmethod
    @printtodebugger
    def from_xml(cls, xml: etree.Element, vectors: VectorProvider['vectors.ACISIVectorObject']) -> 'AttachmentStructure':
        structure: AttachmentStructure = cls()

        if xml is not None:
            structure.attachment = cls.feature_from_xml(xml, vectors)

        return structure

    @printtodebugger
    def __str__(self) -> str:
        return str(self.attachment)


class ViolationStructure(sa.StructureABC['vectors.ViolationVector']):
    NAME: Final[str] = 'tblviolations'
    VECTOR_TYPE: Final[Type['vectors.ViolationVector']] = vectors.ViolationVector
    violation: datamodels.ViolationFeature = None

    @printtodebugger
    def to_xml(self) -> etree.Element:
        return self.make_element(self.violation)

    @printtodebugger
    def features(self) -> Iterable[protocols.Feature]:
        if self.violation is not None:
            yield self.violation

    @classmethod
    @printtodebugger
    def from_xml(cls, xml: etree.Element, vectors: VectorProvider['vectors.ACISIVectorObject']) -> 'ViolationStructure':
        structure: ViolationStructure = cls()

        if xml is not None:
            structure.violation = cls.feature_from_xml(xml, vectors)

        return structure

    @printtodebugger
    def __str__(self) -> str:
        return str(self.violation)


class DescriptorStructure(sa.StructureABC['vectors.DescriptorVector']):
    NAME: Final[str] = 'tbldescriptors'
    VECTOR_TYPE: Final[Type['vectors.DescriptorVector']] = vectors.DescriptorVector
    descriptor: datamodels.DescriptorFeature = None

    @printtodebugger
    def to_xml(self) -> etree.Element:
        if self.descriptor.value is None:
            self.descriptor.value = ''
        return self.make_element(self.descriptor)

    @printtodebugger
    def features(self) -> Iterable[protocols.Feature]:
        if self.descriptor is not None:
            yield self.descriptor

    @classmethod
    @printtodebugger
    def from_xml(cls, xml: etree.Element, vectors: VectorProvider['vectors.ACISIVectorObject']) -> 'DescriptorStructure':
        structure: DescriptorStructure = cls()

        if xml is not None:
            structure.descriptor = cls.feature_from_xml(xml, vectors)

        return structure

    @printtodebugger
    def __str__(self) -> str:
        return str(self.descriptor)


@deprecated
class TransferStepStructure(sa.StructureABC['vectors.TransferStepVector']):
    NAME: Final[str] = 'tbltransfersteps'
    VECTOR_TYPE: Final[Type['vectors.TransferStepVector']] = vectors.TransferStepVector
    transfer_step: datamodels.TransferStepFeature = None

    @printtodebugger
    def to_xml(self) -> etree.Element:
        return self.make_element(self.transfer_step)

    @printtodebugger
    def features(self) -> Iterable[protocols.Feature]:
        if self.transfer_step is not None:
            yield self.transfer_step

    @classmethod
    @printtodebugger
    def from_xml(cls, xml: etree.Element, vectors: VectorProvider['vectors.ACISIVectorObject']) -> 'TransferStepStructure':
        structure: TransferStepStructure = cls()

        if xml is not None:
            structure.transfer_step = cls.feature_from_xml(xml, vectors)

        return structure

    @printtodebugger
    def __str__(self) -> str:
        return str(self.transfer_step)


class AttacheeTransferStepStructure(sa.StructureABC['vectors.AttacheeTransferStepVector']):
    NAME: Final[str] = 'tbltransfersteps'
    VECTOR_TYPE: Final[Type['vectors.AttacheeTransferStepVector']] = vectors.AttacheeTransferStepVector
    transfer_step: datamodels.AttacheeTransferStepFeature = None

    @printtodebugger
    def to_xml(self) -> etree.Element:
        return self.make_element(self.transfer_step)

    @printtodebugger
    def features(self) -> Iterable[protocols.Feature]:
        if self.transfer_step is not None:
            yield self.transfer_step

    @classmethod
    @printtodebugger
    def from_xml(cls, xml: etree.Element, vectors: VectorProvider['vectors.ACISIVectorObject']) -> 'AttacheeTransferStepStructure':
        structure: AttacheeTransferStepStructure = cls()

        if xml is not None:
            structure.transfer_step = cls.feature_from_xml(xml, vectors)

        return structure

    @printtodebugger
    def __str__(self) -> str:
        return str(self.transfer_step)


class AttacheeTransferStructure(sa.StructureABC['vectors.AttacheeTransferVector']):
    NAME: Final[str] = 'tbltransfers'
    VECTOR_TYPE: Final[Type['vectors.AttacheeTransferVector']] = vectors.AttacheeTransferVector
    transfer: datamodels.AttacheeTransferFeature = None
    transfer_steps: Dict[str, 'AttacheeTransferStepStructure'] = None

    @printtodebugger
    def __init__(self) -> None:
        self.transfer_steps = defaultdict(AttacheeTransferStepStructure)

    @printtodebugger
    def to_xml(self) -> etree.Element:
        element: etree.Element = self.make_element(self.transfer)

        if self.transfer_steps:
            for transfer_step in self.transfer_steps.values():  # type: AttacheeTransferStepStructure
                element.append(transfer_step.to_xml())

        return element

    @printtodebugger
    def features(self) -> Iterable[protocols.Feature]:
        if self.transfer_steps is not None:
            for transfer_step in self.transfer_steps.values():
                yield from transfer_step.features()

        if self.transfer is not None:
            yield self.transfer

    @classmethod
    @printtodebugger
    def from_xml(cls, xml: etree.Element, vectors: VectorProvider['vectors.ACISIVectorObject']) -> 'AttacheeTransferStructure':
        structure: AttacheeTransferStructure = cls()

        if xml is not None:
            structure.transfer = cls.feature_from_xml(xml, vectors)

            for transfer_step_xml in xml.iter(AttacheeTransferStepStructure.NAME):  # type: etree.Element
                transfer_step: AttacheeTransferStepStructure = AttacheeTransferStepStructure.from_xml(transfer_step_xml, vectors)
                structure.transfer_steps[transfer_step.transfer_step.guid] = transfer_step

        return structure

    @printtodebugger
    def __str__(self) -> str:
        return f"({self.transfer}, transfer_steps: {dict(self.transfer_steps)})"

