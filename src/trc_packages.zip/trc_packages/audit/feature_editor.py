from distutils.util import strtobool
from typing import TypeVar, Generic, List
from PyQt5.QtWidgets import QLineEdit, QTextEdit, QComboBox, QCheckBox

from trc_packages.core._basetypes import QObjectABC
from trc_packages.core.safecasts import safe_str, safe_bool
from trc_packages.core.features.protocols import Feature

T = TypeVar('T', bound=Feature)

class FeatureEditor(QObjectABC, Generic[T]):

    feature: T
    _shared_fields: List[str]

    def __init__(self, feature: T):
        self.feature = feature
        self._shared_fields = list(filter(lambda x: not x.startswith('__'), set(dir(self.feature)) & set(dir(self))))

    def _commit_feature_values(self) -> bool:
        for field in self._shared_fields:
            dlg_field = getattr(self, field)
            if isinstance(dlg_field, QLineEdit):
                self.feature[field] = dlg_field.text()
            elif isinstance(dlg_field, QComboBox):
                self.feature[field] = dlg_field.currentText()
            elif isinstance(dlg_field, QCheckBox):
                self.feature[field] = dlg_field.isChecked()
            elif isinstance(dlg_field, QTextEdit):
                self.feature[field] = dlg_field.toPlainText()
        return self.feature.save()

    def _repopulate_fields(self) -> None:
        for field in self._shared_fields:
            dlg_field = getattr(self, field)
            feature_value = getattr(self.feature, field)
            if not feature_value:
                continue
            if isinstance(dlg_field, QLineEdit) or isinstance(dlg_field, QTextEdit):
                dlg_field.setText(safe_str(feature_value))
            elif isinstance(dlg_field, QComboBox):
                dlg_field.setCurrentText(safe_str(feature_value))
            elif isinstance(dlg_field, QCheckBox):
                if isinstance(feature_value, str):
                    dlg_field.setChecked(strtobool(feature_value))
                else:
                    dlg_field.setChecked(safe_bool(feature_value))

