from enum import Enum, auto

import cv2
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtWidgets import QWidget, QGraphicsScene, QGraphicsView, QGraphicsPixmapItem

from qgis.PyQt import QtCore

class CameraStatus(Enum):
    OFF = auto()
    SHOWING = auto()
    CAPTURED = auto()

class Camera:

    camera_choice: 0
    camera_status: CameraStatus = CameraStatus.OFF
    image: None

    def __init__(self, camera_choice: int = 0):
        self.camera_choice = camera_choice

    def show(self, view: QGraphicsView):
        self.camera_status = CameraStatus.SHOWING
        camera_choice = self.camera_choice
        self.video_capture = cv2.VideoCapture(self.camera_choice)
        current_scene = view.scene()
        while self.camera_status == CameraStatus.SHOWING:
            if self.camera_choice != camera_choice:
                self.video_capture.release()
                self.video_capture = cv2.VideoCapture(self.camera_choice)
                camera_choice = self.camera_choice
            # Capture frame-by-frame
            et, image = self.video_capture.read()
            self.image = image
            cv2.waitKey(1)
            scene = QGraphicsScene()
            try:
                view.setScene(scene)
            except RuntimeError:
                # view has been closed
                break
            # get the image info
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            height, width, channel = image.shape
            step = channel * width
            # create QImage from image
            qImg = QImage(image.data, width, height, step, QImage.Format_RGB888)
            item = QGraphicsPixmapItem(
                QPixmap.fromImage(qImg).scaled(view.width() - 5, view.height() - 5, QtCore.Qt.KeepAspectRatio))
            scene.addItem(item)
        if self.camera_status == CameraStatus.OFF:
            try:
                view.setScene(current_scene)
            except RuntimeError:
                pass
        self.video_capture.release()
        cv2.destroyAllWindows()

    def hide(self):
        self.camera_status = CameraStatus.OFF

    def capture(self, to_file: str):
        cv2.imwrite(to_file, self.image)
        self.camera_status = CameraStatus.CAPTURED

