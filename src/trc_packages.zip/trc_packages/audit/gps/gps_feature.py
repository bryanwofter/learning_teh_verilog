import datetime
from typing import Optional, Generic, TypeVar

from PyQt5.QtWidgets import QMessageBox, QPushButton, QLineEdit

from trc_packages.core._basetypes import QObjectABC
from PyQt5.QtCore import QPointF
from trc_packages.core.features.protocols import Feature
from qgis.core import *

T = TypeVar('T', bound = Feature)

class GPSFeature(QObjectABC, Generic[T]):

    gps_button: QPushButton
    pole_lat: QLineEdit
    pole_long: QLineEdit
    feature: T
    timestamp_field: Optional[str]

    def __init__(self, gps_button: QPushButton, pole_lat: QLineEdit, pole_long: QLineEdit,
                 feature: T, timestamp_field=None):
        gps_button.clicked.connect(self.set_pole_gps)
        self.pole_lat = pole_lat
        self.pole_long = pole_long
        self.feature = feature
        self.timestamp_field = timestamp_field
        self.display_gps_location()

    def set_pole_gps(self):
        '''
        Set a new location from gps coordinates for a feature
        '''
        gps_connection = QgsApplication.gpsConnectionRegistry()
        connection_list = gps_connection.connectionList()
        if connection_list:
            GPSInfo = connection_list[0].currentGPSInformation()
            latitude, longitude = GPSInfo.latitude, GPSInfo.longitude
            self.pole_lat.setText(str(latitude))
            self.pole_long.setText(str(longitude))
        else:
            QMessageBox.information(None, "GPS", "Please turn on GPS to set the point")

    def _commit_gps(self):
        '''
        Save the GPS point if a new point has been set by the button
        '''
        if not self._valid_gps():
            QMessageBox.information(None, "Warning", "Invalid GPS Point. Please double check Lat and Long. "
                                                     "Feature is not being moved.")
            return
        current_x = str(self.feature.geometry.get().x())
        current_y = str(self.feature.geometry.get().y())
        if self.pole_long.text() != current_x or self.pole_lat.text() != current_y:
            point = QPointF(float(self.pole_long.text()), float(self.pole_lat.text()))
            self.feature.geometry = QgsGeometry.fromQPointF(point)
            self.feature.vector_object.qgs_layer.updateFeature(self.feature.qgs_feature)
            if self.timestamp_field:
                self.feature[self.timestamp_field] = str(datetime.datetime.now())

    def _valid_gps(self) -> bool:
        lat = self.pole_lat.text()
        long = self.pole_long.text()
        stripped_lat = lat.replace('.', '').replace('-', '')
        stripped_long = long.replace('.', '').replace('-', '')
        return stripped_lat.isdigit() and stripped_long.isdigit()

    def display_gps_location(self):
        '''
        Show the GPS location on load in latitude and longitude.
        '''
        if self.feature.geometry:
            current_x = self.feature.geometry.get().x()
            current_y = self.feature.geometry.get().y()
            self.pole_lat.setText(str(current_y))
            self.pole_long.setText(str(current_x))
