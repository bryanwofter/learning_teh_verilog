from inspect import isclass
from PyQt5 import QtCore, QtWidgets
from typing import Any, Callable, Dict, Optional, overload, Tuple, Type, TypeVar
T = TypeVar('T', bound=QtCore.QObject)
P = TypeVar('P', bound=QtCore.QObject)
PARENT: str = '_emulate_setup_ui__parent'


class EmulateSetupUiException(Exception):
    """
    A base exception for all emulate_setup_ui errors.
    """


class EmulateSetupUiError(EmulateSetupUiException):
    """
    Raised when a non-emulatable object is supplied to emulate_setup_ui.
    """


class SetupUiMethodExistsError(EmulateSetupUiException):
    """
    Raised when the setupUi method already exists on the supplied type to emulate_setup_ui.
    """


class NoTypeAnnotationsExistError(EmulateSetupUiException):
    """
    Raised when no type annotations exist on the supplied type to emulate_setup_ui.
    """


@overload
def emulate_setup_ui(*, use_type_annotations: bool=False, source: str=PARENT) -> Callable[[Type[T]], Type[T]]:
    ...


@overload
def emulate_setup_ui(cls: Type[T]) -> Type[T]:
    ...


def emulate_setup_ui(cls: Optional[type]=None, *, use_type_annotations: bool=False, source: str=PARENT):
    """
    Injects a setupUi method into the given type.
    :param cls: The class to inject the setupUi method into.
    :param use_type_annotations: Use the type annotations to resolve the controls of the object.
    :param source: The source of the controls. If not provided, parent() is used. This expects the property to already be set on the object before a call to setupUi is made.
    """
    if cls is None:
        return lambda cls: emulate_setup_ui_decorator(cls, use_type_annotations=use_type_annotations, source=source)
    return emulate_setup_ui_decorator(cls, use_type_annotations, source)


def emulate_setup_ui_decorator(cls: Type[T], use_type_annotations: bool, source: str) -> Type[T]:
    """
    Injects a setupUi method into the given type.
    :param cls: The class to inject the setupUi method into.
    :param use_type_annotations: Use the type annotations to resolve the controls of the object.
    :param source: The source of the controls. If not provided, parent() is used. This expects the property to already be set on the object before a call to setupUi is made.
    """
    if not issubclass(cls, QtCore.QObject):
        raise EmulateSetupUiError()
    elif hasattr(cls, 'setupUi') and not getattr(getattr(cls, 'setupUi'), '__isabstractmethod__', False):
        raise SetupUiMethodExistsError()

    type_annotations: Optional[Dict[str, Type[QtCore.QObject]]] = None
    if use_type_annotations:
        if not hasattr(cls, '__annotations__'):
            raise NoTypeAnnotationsExistError()

        type_annotations = {p: t for p, t in cls.__annotations__.items() if isclass(t) and issubclass(t, QtCore.QObject)}

    def setupUi(self: T, widget: QtWidgets.QWidget) -> None:
        """
        Populates the given widget with the controls of the provided source.
        :param widget: The widget to populate with the source's controls.
        """
        source_v: QtCore.QObject = None

        if source is PARENT:
            source_v = self.parent()
        else:
            source_v = getattr(self, source)

        if type_annotations is None:
            for child in source_v.children():  # type: QtCore.QObject
                setattr(widget, child.objectName(), child)
        else:
            for property, type in type_annotations.items():  # type: Tuple[str, Type[QtCore.QObject]]
                setattr(widget, property, source_v.findChild(type, property))

    setattr(cls, 'setupUi', setupUi)

    return cls

