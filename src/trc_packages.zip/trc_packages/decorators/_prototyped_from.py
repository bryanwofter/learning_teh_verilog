from typing import Any, Callable, Dict, FrozenSet, List, Iterable, Optional, overload, Set, Type, TypeVar, Tuple
C = TypeVar('C')
IGNORED_MEMBERS: FrozenSet[str] = frozenset([
    '__abstractmethods__', '__class__', '__init_subclass__', '__module__',
    '__name__', '_abc_impl', '__class_getitem__', '_is_protocol',
    '_is_runtime_protocol'
])


@overload
def prototyped_from(*args: Type) -> Callable[[C], C]: ...
@overload
def prototyped_from(*, types: Iterable[Type], check_abstractmethods: bool=True, bases_as_prototypes: bool=True) -> Callable[[C], C]: ...


def prototyped_from(*args: Type, types: Optional[Iterable[Type]]=None, check_abstractmethods: bool=True, bases_as_prototypes: bool=True) -> Callable[[C], C]:
    """
    Returns a decorator function used to populate the prototypes of a class.
    :param args: The prototypes of this class given as raw arguments.
    :param types: The prototypes of this class.
    :param check_abstractmethods: True if abstractmethods should be checked and errors should be raised if they aren't implemented, otherwise False.
    :param bases_as_prototypes: True if base types should be used as prototypes, otherwise False.
    """
    prototypes: List[Type] = list(args)
    prototypes.extend(types or [])
    if not any(prototypes):
        raise ValueError('No types provided as prototypes.')
    return lambda cls: prototyped_from_decorator(cls, prototypes, check_abstractmethods, bases_as_prototypes)


def prototyped_from_decorator(cls: C, types: Iterable[Type], check_abstractmethods: bool, bases_as_prototypes: bool) -> C:
    """
    Decorates the given class with the given prototype types, adding any missing methods to the class.
    :param cls: The class being decorated.
    :param types: The types to use as prototypes.
    :param check_abstractmethods: True if abstractmethods should be checked and errors should be raised if they aren't implemented, otherwise False.
    :param bases_as_prototypes: True if base types should be used as prototypes, otherwise False.
    """

    if not getattr(cls, '__prototyped__', False):
        setattr(cls, '__prototyped__', True)
        setattr(cls, '__prototype_classes__', set([]))

    prototypes: Set[Type] = getattr(cls, '__prototype_classes__')

    for t in types:  # type: Type
        pts: Set[Type] = set()
        if bases_as_prototypes:
            pts.update(t.__mro__)
        pts.add(t)

        for p in pts:  # type: Type
            if p not in prototypes and p is not object:
                if hasattr(p, '__annotations__'):
                    if not hasattr(cls, '__annotations__'):
                        setattr(cls, '__annotations__', dict())
                    annotations: Dict[str, Any] = getattr(cls, '__annotations__')

                    for name, value in p.__annotations__.items():  # type: Tuple[str, Any]
                        if name not in annotations:
                            annotations[name] = value

                for name, value in p.__dict__.items():
                    # TODO: Should we also check if the name is a special method?
                    if not hasattr(cls, name):
                        if name in IGNORED_MEMBERS:
                            continue
                        if getattr(value, '__isabstractmethod__', False):
                            if check_abstractmethods:
                                raise NotImplementedError(f"Class {cls} does not implement required prototype method {name}.")
                        else:
                            setattr(cls, name, value)

                prototypes.add(p)
    return cls

