from datetime import date
from typing import Optional, Union


class DeprecatedError(Exception):
    """Raised when a deprecated element is invoked."""

    @property
    def date_of_deprecation(self) -> Optional[Union[date, str]]:
        return self._date_of_deprecation

    @property
    def message(self) -> Optional[str]:
        return self._message

    @property
    def warning(self) -> Optional[str]:
        return self._warning

    def __init__(self, warning: Optional[str], message: Optional[str], date_of_deprecation: Optional[Union[date, str]]) -> None:
        self._date_of_deprecation = date_of_deprecation
        self._message = message
        self._warning = warning

