from typing import Any, Callable, Type, TypeVar, Optional, no_type_check, overload
T = TypeVar('T')


def singleton(cls: Optional[Type[T]]=None, inherited: bool=False):
    """
    Provides a decorator for classes that can be used to mark them as singletons.
    :param cls: The type to decorate.
    :param inherited: True if this singleton type allows for singleton inheritance, otherwise False.
    """
    return (lambda cls: __make_new(cls, inherited)) if cls is None else __make_new(cls, inherited)


def __make_new(cls: Type[T], inherited: bool) -> Callable[[Type[T]], T]:
    """
    Generates the replacement __new__ method for the given type.
    :param cls: The class to create the replacement __new__ method for.
    :param inherited: True if the wrapped singleton type will offer singleton support to inheritors, otherwise false.
    """
    cls.__INSTANCE = None  # type: ignore
    existing_new: Optional[Callable[[Type[T]], T]] = None
    # Attempt to get the original new from the type.
    try:
        existing_new = cls.__new__
    except AttributeError:
        pass
    # Set the accepted type to a meaningful name to not cause a confict with the function.
    base: Type[T] = cls
    @staticmethod  # type: ignore
    @no_type_check
    def __new(cls: Type[T], *vargs: Any, **kwargs: Any) -> T:
        """
        Instantiates the provided type. If the type is decorated with the singleton decoration, the singleton instance will
        be returned instead.
        """
        if cls is base or inherited:
            if not isinstance(cls.__INSTANCE, cls):
                cls.__INSTANCE = (existing_new or super(cls, cls).__new__)(cls)

            return cls.__INSTANCE

        instance: T = (existing_new or super(base, cls).__new__)(cls)
        return instance
    # Update the name of __new to match the method name.
    __new.__name__ = '__new__'
    __new.__doc__ = __new.__doc__ if existing_new is None else existing_new.__doc__
    cls.__new__ = __new  # type: ignore

    return cls

