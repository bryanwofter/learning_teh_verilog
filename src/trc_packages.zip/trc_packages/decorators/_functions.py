from typing import Any, Callable, cast, NoReturn, Optional, Set, Type, TypeVar
from types import FunctionType, ModuleType
import inspect
T = TypeVar('T')
C = TypeVar('C', bound=Callable[..., T])
R = TypeVar('R', staticmethod, classmethod)


def isdecoratable(target: Any) -> bool:
    """
    Determines if the target can have a decorator applied to it.
    :param target: The target to check.
    """
    return isinstance(target, FunctionType) or inspect.isclass(target)


def decoratemodule(output_module: ModuleType, decorator: Callable[..., Any],
                   *target_names: str, input_module: Optional[ModuleType]=None) -> NoReturn:
    """
    Provides a simple method for decorating an entire module with a specific decorator.

    This should only be used in very specific cases, such as module deprecation, and only within the '__init__.py' of a package or
    at the bottom of the module itself.
    :param output_module: The module to apply the decorator to.
    :param decorator: The decorator to apply.
    :param input_module: If provided, the values of this module will be safely copied to the output module.
    :param target_names: If provided, only these names will be decorated.
    """
    input_module = input_module or output_module
    targets: Set[str] = set(target_names)
    for name, value in vars(input_module).items():
        if isdecoratable(value) and (not targets or name in targets):
            # If the target is decoratable and no targets were provided or is in the set of targeted names, decorate the value.
            try:
                if value.__module__ == input_module.__name__:
                    # Only decorate the value if it exists in the target module.
                    if output_module is not input_module and inspect.isclass(value):
                        # If the output module isn't the same as the input module and we're dealing with a class, there's a possibility
                        # that the decorator might change the signal of the class. In this case, to prevent contamination of the
                        # source module, we need to inherit the decorated class instead of directly modifying it.
                        class __(value): pass  # type: ignore
                        __.__name__ = value.__name__
                        value = __
                    decorated_value: Any = decorator(value)
                    decorated_value.__module__ = output_module.__name__
                    vars(output_module)[name] = decorated_value
            except TypeError:
                pass


def decoratespecialmethod(decorator_applier: Callable[..., C], static_class_method: R) -> R:
    """
    Decorates the given static_class_method using the provided decorator_applier.
    :param decorator_applier: The function used to apply the decorator to the static_class_method.
    :param static_class_method: The decoratable static or class method.
    """
    output_type: Type[R] = staticmethod if isinstance(static_class_method, staticmethod) else classmethod
    return output_type(decorator_applier(static_class_method.__func__))

