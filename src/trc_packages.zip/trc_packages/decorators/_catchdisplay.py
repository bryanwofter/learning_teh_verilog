from functools import wraps
from typing import Any, Callable, cast, List, Set, Optional, overload, Type, TypeVar, no_type_check
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMessageBox
from trc_packages.core import _logging as logging
import traceback
F = TypeVar('F', bound=Callable[..., Any])


def catchdisplaywith(*, message: Optional[str]=None, title: Optional[str]=None, log: bool=False, include_traceback: bool=False, catch: Optional[List[Type[BaseException]]]=None) -> Callable[[F], F]:
    """
    Returns a decorator function for catchdisplaydecorator that applies the given parameters.
    :param message: The optional error message to display.
    :param title: The optional title to display.
    :param log: True if the error should be logged, otherwise False.
    :param include_traceback: True if the traceback should be included in the display, otherwise False.
    :param catch: The exceptions to catch.
    """
    return lambda fn: catchdisplaydecorator(fn, message, title, log, include_traceback, catch)


@overload
def catchdisplay(fn: F) -> F:
    ...


@overload
def catchdisplay(*, message: Optional[str]=None, title: Optional[str]=None, log: bool=False, include_traceback: bool=False, catch: Optional[List[Type[BaseException]]]=None) -> Callable[[F], F]:
    ...


def catchdisplay(fn: Callable[..., Any]=None, *, message: Optional[str]=None, title: Optional[str]=None, log: bool=False, include_traceback: bool=False, catch: Optional[List[Type[BaseException]]]=None):
    """
    Provides a decorator that will catch and display an exception so long as the exception is in the provided catch list. If nothing is provided
    for the catch list, an unbound catch is performed.
    :param fn: The function to decorate. If no function is provided, then a wrapper for this function will be returned.
    :param message: The optional error message to display.
    :param title: The optional title to display.
    :param log: True if the error should be logged, otherwise False.
    :param include_traceback: True if the traceback should be included in the display, otherwise False.
    :param catch: The exceptions to catch.
    """
    if fn is None:
        return catchdisplaywith(message=message, title=title, log=log, include_traceback=include_traceback, catch=catch)
    return catchdisplaydecorator(fn, message, title, log, include_traceback, catch)


def catchdisplaydecorator(fn: F, message: Optional[str], title: Optional[str], log: bool, include_traceback: bool, catch: Optional[List[Type[BaseException]]]) -> F:
    """
    Decorates the given function with the catchdisplay decorator.
    :param fn: The function to decorate. If no function is provided, then a wrapper for this function will be returned.
    :param message: The optional error message to display.
    :param title: The optional title to display.
    :param log: True if the error should be logged, otherwise False.
    :param include_traceback: True if the traceback should be included in the display, otherwise False.
    :param catch: The exceptions to catch.
    """
    catches: Set[Type[BaseException]] = set(catch or [])
    @wraps(cast(Callable[..., Any], fn))
    @no_type_check
    def __wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            if not any(catches) or type(e) in catches:
                if log:
                    logging.log.error(f"\n{message or str(e) or '<unknown error>'}\n{traceback.format_exc()}")
                display_message: bool = message or str(e) or '<unknown error>'
                if include_traceback:
                    display_message += f"\n{traceback.format_exc()}"
                window: QtWIdgets.QWidget
                if any(args) and isinstance(args[0], QtWidgets.QWidget):
                    window = args[0]
                else:
                    window = QtWidgets.QApplication.topLevelWidgets()[0]
                QMessageBox.warning(window, title or 'An error has occurred', display_message)
                return None
            else:
                raise e
    return cast(F, __wrapper)

