from typing import Any, Callable, TypeVar
F = TypeVar('F', bound=Callable[..., Any])


def internal(fn: F) -> F:
    """
    Decorates a function as internal.

    If you encounter a function marked as internal, please do not use it outside of the file it's declared within.
    """
    setattr(fn, '_isinternal_', True)
    return fn

