from functools import wraps
from typing import Any, cast, Callable, List, Optional, overload, Set, Type, TypeVar
from trc_packages.core import _logging as l
import logging
import traceback
F = TypeVar('F', bound=Callable[..., Any])


@overload
def catchlog(fn: F) -> F:
    ...
@overload
def catchlog(*, log_level: int=logging.ERROR, catch: List[Type[BaseException]]=[]) -> Callable[[F], F]:
    ...
@overload
def catchlog(*args: Type[BaseException]) -> Callable[[F], F]:
    ...

def catchlog(fn: Optional[Callable[..., Any]]=None, *args: Type[BaseException], log_level: int=logging.ERROR, catch: List[Type[BaseException]]=[]):
    """
    Wraps the given function in a try/catch block that performs logging whenever an exception is raised.
    :param fn: The function to wrap in the try/catch block.
    :param args: The varg variant of the exception types to catch, if any.
    :param log_level: The logging level to write the logs at.
    :param catch: The list variant of the exception types to catch, if any.
    """
    if fn is None:
        return lambda fn: catchlogdecorator(fn, *args, log_level=log_level, catch=catch)
    return catchlogdecorator(fn, *args, log_level=log_level, catch=catch)


def catchlogdecorator(fn: F, *args: Type[BaseException], log_level: int, catch: List[Type[BaseException]]) -> F:
    """
    Wraps the given function in a try/catch block that performs logging whenever an exception is raised.
    :param fn: The function to wrap in the try/catch block.
    :param args: The varg variant of the exception types to catch, if any.
    :param log_level: The logging level to write the logs at.
    :param catch: The list variant of the exception types to catch, if any.
    """
    exception_types: Set[Type[BaseException]] = set()
    exception_types.update(args, catch)

    @wraps(fn)
    def __wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return fn(*args, **kwargs)
        except BaseException as e:
            if not exception_types or type(e) in exception_types:
                l.log.log(log_level, e, exc_info=True, stack_info=True)
            raise e
    
    return cast(F, __wrapper)

