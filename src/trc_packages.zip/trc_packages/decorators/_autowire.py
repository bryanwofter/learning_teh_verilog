"""
Contains the code needed to automatically wire up slots to signals on a QObject that can't have its slots wired through the traditional
QMetaObject.connectSlotsByName function.
"""
from functools import wraps
from PyQt5.QtCore import QObject
from trc_packages.core import ui
from typing import Any, Callable, Optional, Type, TypeVar
T = TypeVar('T', bound=QObject)


class AutowireError(Exception):
    """
    Raised when a non-autowireable object is supplied to autowire.
    """


def autowire(cls: Type[T]) -> Type[T]:
    """
    A decorator equivalent to manually calling trc_packages.core.ui.connect_slots_by_name.
    :param cls: The class  to decorate.
    """
    if not issubclass(cls, QObject):
        raise AutowireError()

    existing_init: Callable[..., None]

    try:
        existing_init = cls.__init__
    except AttributeError:
        # If no existing init exists, we need to declare our own.
        def existing_init(self, parent: Optional[QObject]=None) -> None:
            super().__init__(parent=parent)  # type: ignore
        existing_init.__name__ = '__init__'

    @wraps(existing_init)
    def __init(self, *args: Any, **kwargs: Any) -> None:
        existing_init(self, *args, **kwargs)
        ui.connect_slots_by_name(self)
    cls.__init__ = __init  # type: ignore
    return cls
