from datetime import date
from enum import IntEnum
from functools import partial, wraps
from inspect import currentframe, isclass
from typing import Any, Callable, cast, Generic, List, Optional, overload, Type, TypeVar, Union
from types import FrameType
from trc_packages.core.types import Runnable
from trc_packages.decorators import errors
import traceback
import warnings
C = TypeVar('C', bound=type)
F = TypeVar('F', bound=Callable[..., Any])
T = TypeVar('T', type, Callable[..., Any])
_T = TypeVar('_T')


class OutputMethod(IntEnum):
    """Defines the output method of the deprecated decorator."""

    MESSAGE = 0
    """Display a message of deprecation."""
    TRACEBACK = 1
    """Display a message and the traceback of deprecation. Note: This should only be used during debugging to find deprecated calls."""
    RAISE = 2
    """Raise an exception of deprecation."""


@overload
def deprecated(fn: C) -> C:
    ...
@overload
def deprecated(fn: F) -> F:
    ...
@overload
def deprecated(*, message: Optional[str]=None, date_of_deprecation: Optional[Union[str, date]]=None, error_if_invoked: bool=False,
               output_method: OutputMethod=OutputMethod.MESSAGE) -> Callable[[T], T]:
    ...


def deprecated(fn: Union[type, Callable[..., Any]]=None, *, message: Optional[str]=None, date_of_deprecation: Optional[Union[str, date]]=None, error_if_invoked: bool=False,
               output_method: OutputMethod=OutputMethod.MESSAGE):
    """
    Decorates the given function with a deprecation alert. If the function is already marked as deprecated, this deprecation is appended to it.
    :param fn: The function being marked as deprecated.
    :param message: The message of the deprecation alert.
    :param date_of_deprecation: The date that the deprecation was added, if one is available.
    :param error_if_invokved:
    :param output_method: The type of output used when the deprecated object is accessed.
    """
    output_method = OutputMethod.RAISE if error_if_invoked else output_method
    if fn is None:
        return lambda fn: deprecated_decorator(fn, message, date_of_deprecation, output_method)
    return deprecated_decorator(fn, message, date_of_deprecation, output_method)


def deprecated_decorator(fn: T, message: Optional[str], date_of_deprecation: Optional[Union[str, date]], output_method: OutputMethod) -> T:
    """
    Decorates the given function with a deprecation alert. If the function is already marked as deprecated, this deprecation is appended to it.
    :param fn: The function being marked as deprecated.
    :param message: The message of the deprecation alert.
    :param date_of_deprecation: The date that the deprecation was added, if one is available.
    :param output_method: The type of output used when the deprecated object is accessed.
    """
    if isclass(fn):
        return __deprecated_class_decorator(cast(type, fn), message, date_of_deprecation, output_method)
    return __deprecated_function_decorator(fn, message, date_of_deprecation, output_method)


def __deprecated_class_decorator(cls: C, message: Optional[str], date_of_deprecation: Optional[Union[str, date]], output_method: OutputMethod) -> C:
    existing_new: Callable[..., C] = getattr(cls, '__new__', super(cls, cls).__new__)  # type: ignore

    new_new: Callable[..., C] = __create_wrapper(existing_new, cls, "Usage of deprecated class {} found.", message, date_of_deprecation, output_method)
    
    setattr(cls, '__new__', staticmethod(new_new))

    return cls


def __deprecated_function_decorator(fn: F, message: Optional[str], date_of_deprecation: Optional[Union[str, date]], output_method: OutputMethod) -> F:
    return __create_wrapper(fn, fn, "Usage of deprecated function {} found.", message, date_of_deprecation, output_method)


def __create_wrapper(fn: _T, src: T, format_: str, message: Optional[str], date_of_deprecation: Optional[Union[str, date]], output_method: OutputMethod) -> _T:
    """
    Creates the wrapper function for the given function and source.
    :param fn: The function that is being wrapped.
    :param src: The source of the function. This will be either the class containing the function or the function itself.
    :param format_: The format to apply.
    :param message: The message of the deprecation alert.
    :param date_of_deprecation: The date that the deprecation was added, if one is available.
    :param output_method: The type of output used when the deprecated object is accessed.
    """

    name: str
    if isinstance(src, staticmethod):
        name = src.__func__.__name__
    elif isinstance(src, classmethod):
        name = src.__func__.__name__
    else:
        name = src.__name__
    deprecated_on: Optional[str] = None if date_of_deprecation is None else f"{date_of_deprecation}"
    warning: Optional[str] = None if format_ is None else format_.format(name)

    return cast(_T, DeprecatedDecorator(fn, __create_message_handler(output_method, warning, deprecated_on, message)))


def __create_message_handler(output_method: OutputMethod, warning: Optional[str], deprecated_on: Optional[str], message: Optional[str]) -> Callable[[], None]:
    """Generates a function that handles the deprecation notice per the output_method."""
    if output_method is OutputMethod.RAISE:
        def handle_message() -> None:
            raise errors.DeprecatedError(deprecated_on, message, warning)
    else:
        messages: List[str] = filter(lambda v: v is not None,  # type: ignore
                                     [None if deprecated_on is None else f"Deprecated on {deprecated_on}", warning, message])
        message = "\n".join(messages)
        del messages

        if output_method is OutputMethod.MESSAGE:
            def handle_message() -> None:
                warnings.warn(message, DeprecationWarning)
        elif output_method is OutputMethod.TRACEBACK:
            def handle_message() -> None:
                warnings.warn("\n".join([message, *traceback.format_tb(currentframe().f_back.f_back)]), DeprecationWarning)  # type: ignore
        else:
            raise TypeError(f"Unexpected type for output_method. Received {type(output_method)}, expected {OutputMethod}.")

    handle_message._output_method = output_method  # type: ignore
    return handle_message


class DeprecatedDecorator(Generic[F]):
    """
    Provides a decorator implementation that represents a deprecated function.
    """

    __target: Optional[F] = None
    __message_handler: Optional[Runnable] = None
    __is_staticmethod: bool = False
    __is_classmethod: bool = False

    def __init__(self, target: F, message_handler: Runnable) -> None:
        self.__target = target
        self.__message_handler = message_handler
        self.__is_staticmethod = isinstance(self.__target, staticmethod)
        self.__is_classmethod = isinstance(self.__target, classmethod)

        if self.__is_staticmethod or self.__is_classmethod:
            self.__target = getattr(self.__target, '__func__')

    def __get__(self, instance: Optional[_T], owner: Type[_T]) -> F:
        """Gets this DeprecatedDecorator targeting the given instance. If no instance is provided, this decorator is returned directly."""
        functor: F

        if self.__is_staticmethod:
            functor = cast(F, self)
        elif self.__is_classmethod:
            functor = cast(F, partial(self, owner))
        else:
            functor = cast(F, partial(self, instance))

        return functor

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """Invokes the method targeted by this DeprecatedDecorator instance."""
        message_handler: Runnable = self.__message_handler
        method: F = self.__target

        message_handler()
        return method(*args, **kwargs)

