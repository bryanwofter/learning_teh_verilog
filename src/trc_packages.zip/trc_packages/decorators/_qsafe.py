from typing import Any, Callable, cast, Optional, TypeVar, Union
from PyQt5.QtCore import QVariant
import functools
F = TypeVar('F', bound=Callable[..., Any])
T = TypeVar('T')
U = TypeVar('U')


def qsafe(fn: F) -> F:
    """
    Provides a decorator for de-q-ifying values.
    :param fn: The function to decorate.
    """
    @functools.wraps(fn)
    def __wrapper(*args, **kwargs):
        """
        Converts all arguments from QVariant to their real Python type.
        :param args: The arguments to convert.
        :param kwargs: The keyword arguments to convert.
        """
        return cast(T, unwrap_q_variant(fn(*(unwrap_q_variant(v) for v in args),
                                           **{k: unwrap_q_variant(v) for k, v in kwargs.items()})))
    return cast(F, __wrapper)


def unwrap_q_variant(value: Optional[Union[T, U]]) -> Optional[U]:
    """
    Unwraps the given value if its of the QVariant type to its Python type.
    :param value: The potential QVariant to unwrap.
    """
    if isinstance(value, QVariant):
        if value.isNull():
            value = None
        else:
            value = cast(U, value.value())
    return cast(U, value)

