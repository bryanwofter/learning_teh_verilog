from time import time

from trc_packages.wfs.exceptions import WfsMessageError

from trc_packages.wfs.transaction_builder import AbstractWfsRequester
from trc_packages.asynclib import TrcService
from trc_packages.core import log
from requests.exceptions import ConnectionError
from trc_packages.debugging import Debug


class WFSUploadService(TrcService[str]):

    def __init__(self, requester: AbstractWfsRequester):
        super().__init__()
        self.requester = requester

    def _run(self) -> str:
        log.info(f"Starting upload_objects called for {self.requester.xml_builder.wfs_type}")
        start = time()
        try:
            self.__upload_objects()
        except Exception as e:
            Debug.print(e)
            log.error(e)
            if isinstance(e, ConnectionError):
                self._exception = WfsMessageError("Connection Error. Please check Internet connection and try again. Contact support if the issue continues.")
            else:
                self._exception = e
        log.info(f"Upload_objects finished for {self.requester.xml_builder.wfs_type} in {time() - start} seconds")
        return "Done"

    def __upload_objects(self):
        self.requester.init_wfs_objects()
        self.requester.filter_update_insert()
        self.requester.update_features()
        self.requester.insert_features()
