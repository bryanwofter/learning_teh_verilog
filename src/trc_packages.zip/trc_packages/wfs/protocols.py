from abc import abstractmethod
from typing import Any, Dict, Optional
from typing_extensions import Protocol, runtime, runtime_checkable
from requests import Response

@runtime
@runtime_checkable
class WfsResponseDecoder(Protocol):
    """
    Provides a protocol for classes that can be used to decode a WFS response.
    """

    serialization_type: str = None

    @abstractmethod
    def decode(self, response: Optional[Response]) -> Optional[Dict[str, Any]]:
        """
        Decodes the given response object (if one is returned), returning a dictionary containing the data.

        :param response: The response to decode.
        :return: A dictionary containing the data of the response if it can be decoded or None if no error occurred and nothing was decoded.
        """
        ...


@runtime
@runtime_checkable
class WfsRequestAuthenticator(Protocol):
    """
    Provides a protocol for classes that can be used to inject authentication into argument lists.
    """

    @abstractmethod
    def inject_auth(self, **kwargs: Any) -> Dict[str, Any]:
        """
        Injects the authentication object into the given kwargs and returns the new dictionary back to the caller.

        :param kwargs: All of the parameters being passed into the request.
        :return: A dictionary containing the parameters and the authentication parameter.
        """
        ...

