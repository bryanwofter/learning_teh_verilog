from datetime import datetime
from shutil import copyfile
import os


class WFSService:

    DB_EXTENSION = '.sqlite'

    def __init__(self, circuit, db_dir, epsg, template_db_name="templateDB", temp_db_name="tempDB"):
        '''
        A class to interact with a WFS service
        :param circuit: the circuit you are working with.
        :param db_dir: the path the the db directory you are working out of
        '''
        self.circuit = circuit
        self.db_dir = db_dir
        self.epsg = epsg
        self.template_db_name = template_db_name
        self.temp_db_name = temp_db_name

    def copy_template_db(self):
        '''
        Copy the template db into a new circuit db
        :return: True if copied, False if db already exists
        '''
        if os.path.isfile(self.get_circuit_db_path()):
            return False
        else:
            copyfile(self.get_template_db_path(), self.get_circuit_db_path())
            return True

    def copy_backup_db(self):
        date_time = datetime.today().strftime('%Y-%m-%d')

        if not os.path.isfile(self.db_dir + "/" + self.circuit + "_{}{}".format(date_time, WFSService.DB_EXTENSION)):
            copyfile(self.get_circuit_db_path(),
                     self.db_dir + "/" + self.circuit + "_{}{}".format(date_time, WFSService.DB_EXTENSION))

    def delete_circuit_db(self):
        if os.path.isfile(self.get_circuit_db_path()):
            os.remove(self.get_circuit_db_path())

    def replace_temp_db(self):
        if os.path.isfile(self.get_temp_db_path()):
            os.remove(self.get_temp_db_path())
        copyfile(self.get_template_db_path(), self.get_temp_db_path())

    def get_temp_db_path(self):
        return self.db_dir + "/{}{}".format(self.temp_db_name, WFSService.DB_EXTENSION)

    def get_template_db_path(self):
        return self.db_dir + "/{}{}".format(self.template_db_name, WFSService.DB_EXTENSION)

    def get_circuit_db_path(self):
        return self.db_dir + "/" + self.circuit + WFSService.DB_EXTENSION
