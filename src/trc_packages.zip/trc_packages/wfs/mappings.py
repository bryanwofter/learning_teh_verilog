from abc import ABC
from datetime import datetime
from distutils.util import strtobool
from typing import Optional, Dict, TypeVar, Callable, Type, cast, Any, ClassVar, Set, Generic, Union
from PyQt5.QtCore import QDate, QDateTime

from trc_packages.core.features import BasicFeatureObject, protocols
from trc_packages.core.safecasts import safe_str
from trc_packages.debugging import Debug

T = TypeVar("T")
TPy_co = TypeVar('TPy_co')
TWfs_co = Optional[str]
QDateType = Union[QDate, QDateTime]
TFeature = TypeVar('TFeature', bound=protocols.Feature)


class BasicWfsRecord(Generic[TFeature], ABC):

    NULL_VALUES: ClassVar[Set[Optional[str]]] = {None, "{}", "null"}
    WFS_TABLE_NAME: ClassVar[str]
    WFS_PRIMARY_KEY: ClassVar[str]
    feature: Optional[TFeature] = None
    wfs_values: Dict[str, Any] = None

    def __init__(self, feature: Optional[TFeature] = None) -> None:
        self.feature = feature
        self.wfs_values = {}

    def __getitem__(self, item):
        try:
            return getattr(self, item)
        except AttributeError:
            return self.wfs_values[item]

    def __ne__(self, other) -> bool:
        for key, value in self.items():
            my_value = self[key]
            compare_value = other.get(key)
            if my_value != compare_value and not (compare_value in self.NULL_VALUES and my_value in self.NULL_VALUES):
                return True
        return False

    def __repr__(self):
        return str(self.items())

    def init_attributes(self):
        for var in dir(self):
            if not var.startswith("_"):
                getattr(self, var)

    def items(self):
        return self.wfs_values.items()


class WfsRecordItem(Generic[TPy_co]):
    __field_name: str
    __feature_field_name: str
    _input_converter: Callable[..., TWfs_co]
    _output_converter: Callable[..., Optional[TPy_co]]

    def __init__(self, field_name: Optional[str]=None, feature_field_name: Optional[str]=None, input_converter: Optional[Callable[..., TWfs_co]]=None,
                 output_converter: Optional[Callable[..., TPy_co]]=None):
        self.__field_name = field_name
        self.__feature_field_name = feature_field_name
        if input_converter is not None:
            self._input_converter = input_converter
        if output_converter is not None:
            self._output_converter = output_converter

    def __delete__(self, instance: BasicWfsRecord) -> None:
        if self.__field_name in instance.wfs_values:
            del instance.wfs_values[self.__field_name]
        del instance.feature

    def __get__(self, instance: BasicWfsRecord, owner: Type[BasicWfsRecord]) -> TPy_co:
        if self.__field_name not in instance.wfs_values:
            self.__set__(instance, instance.feature[self.__feature_field_name])
        return self.to_output(instance.wfs_values[self.__field_name])

    def __set__(self, instance: BasicWfsRecord, value: T) -> None:
        instance.wfs_values[self.__field_name] = self.to_input(value)
        instance.feature[self.__feature_field_name] = value

    def __set_name__(self, owner: Type[BasicWfsRecord], name: str) -> None:
        if self.__field_name is None:
            self.__field_name = name
        if self.__feature_field_name is None:
            self.__feature_field_name = name

    def to_input(self, value: T) -> Optional[str]:
        input_converter: Callable[[T], Optional[str]] = cast(Callable[[T], Optional[str]], self._input_converter)
        return input_converter(value)

    def to_output(self, value: T) -> Optional[TPy_co]:
        output_converter: Callable[[T], TPy_co] = cast(Callable[[T], TPy_co], self._output_converter)
        return output_converter(value)

    def strip_string(self, string: Optional[str]) -> Optional[str]:
        safe_string = safe_str(string)
        if safe_string:
            return safe_string.strip()


class WfsStringItem(WfsRecordItem[str]):
    _input_converter = WfsRecordItem.strip_string
    _output_converter = WfsRecordItem.strip_string


class WfsFloatItem(WfsRecordItem[float]):

    def __ouput_converter(self, value: Optional[Union[str, float]]) -> Optional[float]:
        try:
            return float(value)
        except (ValueError, TypeError):
            return None

    _input_converter = WfsRecordItem.strip_string
    _output_converter = __ouput_converter


class WfsIntItem(WfsRecordItem[int]):

    def __output_converter(self, value: Optional[Union[str, bool, int]]) -> Optional[int]:
        try:
            return int(value)
        except (ValueError, TypeError):
            return None

    _input_converter = WfsRecordItem.strip_string
    _output_converter = __output_converter


class WfsDateItem(WfsRecordItem[str]):
    arcgis_format: bool
    Q_DATETIME_FORMAT: str = 'yyyy-MM-ddThh:mm:ssZ'
    Q_DATE_FORMAT: str = 'yyyy-MM-ddT00:00:00Z'
    Q_FLOAT_FORMAT: str = '%Y-%m-%dT%H:%M:%SZ'
    ARC_DATETIME_FORMAT: str = 'MM/dd/yyyy hh:mm:ss'
    ARC_DATE_FORMAT: str = 'MM/dd/yyyy 00:00:00'
    ARC_FLOAT_FORMAT: str = '%m/%d/%Y %H:%M:%S'

    def __init__(self, field_name: Optional[str]=None, feature_field_name: Optional[str]=None, input_converter: Optional[Callable[..., TWfs_co]]=None,
                 output_converter: Optional[Callable[..., TPy_co]]=None, arcgis_format: bool=False):
        super().__init__(field_name=field_name, feature_field_name=feature_field_name, input_converter=input_converter, output_converter=output_converter)
        self.arcgis_format = arcgis_format

    def __input_converter(self, value: Optional[QDateType]) -> Optional[str]:
        if isinstance(value, QDateTime):
            return value.toString(self.ARC_DATETIME_FORMAT if self.arcgis_format else self.Q_DATETIME_FORMAT)
        elif isinstance(value, QDate):
            return value.toString(self.ARC_DATE_FORMAT if self.arcgis_format else self.Q_DATE_FORMAT)
        elif isinstance(value, float):
            return datetime.fromtimestamp(value).strftime(self.ARC_FLOAT_FORMAT if self.arcgis_format else self.Q_FLOAT_FORMAT)

    _input_converter = __input_converter
    _output_converter = WfsRecordItem.strip_string


class WfsBoolItem(WfsRecordItem[bool]):
    __default_output: Optional[bool] = None

    def __init__(self, field_name: Optional[str]=None, feature_field_name: Optional[str]=None, default_output: Optional[bool]=None):
        super().__init__(field_name, feature_field_name)
        self.__default_output = default_output

    def __input_converter(self, value: Optional[bool]) -> Optional[str]:
        if isinstance(value, bool):
            return str(value).lower()

    def __output_converter(self, value: Optional[str]) -> Optional[bool]:
        if isinstance(value, str):
            return strtobool(value)
        elif isinstance(value, bool):
            return value
        else:
            return self.__default_output

    _input_converter = __input_converter
    _output_converter = __output_converter

