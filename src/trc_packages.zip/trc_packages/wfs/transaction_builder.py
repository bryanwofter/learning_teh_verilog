import json
from abc import ABC
from json import JSONDecodeError

from typing import List, Dict, Optional, ClassVar, Type, TypeVar, Generic

from requests.auth import HTTPBasicAuth

import requests
import xmltodict  # type: ignore
from requests import Response
from functools import wraps
from xml.etree import ElementTree
from xml.etree.ElementTree import Element, SubElement
from xml.sax import saxutils as su

from trc_packages.core import log

from trc_packages.wfs import protocols, wfsdecoder, wfsauthenticator
from trc_packages.wfs.mappings import BasicWfsRecord
from enum import Enum
from trc_packages.wfs.exceptions import WfsMessageError, WfsXmlError
from trc_packages.debugging import Debug
from typing import Any

T = TypeVar('T', bound=BasicWfsRecord)

ElementTree.register_namespace('wfs', 'http://www.opengis.net/wfs/2.0')
ElementTree.register_namespace('ogc', 'http://www.opengis.net/ogc')
ElementTree.register_namespace('fes', 'http://www.opengis.net/fes/2.0')
ElementTree.register_namespace('gml', 'http://www.opengis.net/gml/3.2')
ElementTree.register_namespace('xsi', 'http://www.w3.org/2001/XMLSchema-instance')


class Operation(Enum):
    QUERY = 'Query'
    UPDATE = 'Update'
    INSERT = 'Insert'
    DELETE = 'Delete'


class RequestType(Enum):
    '''
    WFS Post Requests we are supporting
    '''
    GET_CAPABILITIES = 'GetCapabilities'
    GET_FEATURE = 'GetFeature'
    TRANSACTION = 'Transaction'


def wfs_request_string(request_type: RequestType):
    def wfs_decorator(func):
        @wraps(func)
        def wrapper(self, *args):
            result = f'''<wfs:{request_type.value}
                         version="2.0.0"
                         service="WFS"
                         outputFormat="application/json"
                         xmlns:wfs="http://www.opengis.net/wfs/2.0"
                         xmlns:ogc="http://www.opengis.net/ogc"
                         xmlns:fes="http://www.opengis.net/fes/2.0"
                         xmlns:gml="http://www.opengis.net/gml/3.2"
                         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"'''
            if self.namespace and self.namespace_url:
                ElementTree.register_namespace(self.namespace, self.namespace_url)
                result = f'''{result}
                             xmlns:{self.namespace}="{self.namespace_url}"'''
            if not self.namespace and self.wfs_type.WFS_TABLE_NAME and self.namespace_url:
                result = f'''{result}
                             xmlns:{self.wfs_type.WFS_TABLE_NAME}="{self.namespace_url}"'''

            return f'''{result}
                       xsi:schemaLocation="http://www.opengis.net/wfs">
                       {func(self, *args)}
                       </wfs:{request_type.value}>'''
        return wrapper
    return wfs_decorator


def wfs_operation_string(operation: Operation):
    def wfs_decorator(func):
        @wraps(func)
        def wrapper(self, *args):
            operation_element = Element(f"wfs:{operation.value}")
            type_name_string = 'typeNames' if operation == Operation.QUERY else 'typeName'
            inner_element = func(self, *args)
            if operation == Operation.INSERT:
                insert_element = SubElement(operation_element, f"{self.namespace}:{self.wfs_type.WFS_TABLE_NAME}")
                insert_element.text = inner_element
            else:
                operation_element.attrib = {type_name_string: f"{self.namespace}:{self.wfs_type.WFS_TABLE_NAME}"}
                operation_element.text = inner_element
            return su.unescape(ElementTree.tostring(operation_element).decode())
        return wrapper
    return wfs_decorator


def get(url: str, layer: str, cql_filter: str, authenticator: protocols.WfsRequestAuthenticator,
        output_format: str = 'application/json') -> Response:
    """
    :param url:
    :param layer: The WFS layer to query. Ex: MRISA:MRISAAttachment
    :param cql_filter: Filter to query the layer on: Ex: MRISA:poleInfoGUID='09122346-1987-4AE3-92D9-0C95CB5928B6'
    :param authorization:
    :param output_format:
    :return: response
    """
    try:
        return requests.post(url, {
            'service': 'WFS',
            'request': 'GetFeature',
            'version': '2.0.0',
            'typeName': layer,
            'cql_filter': cql_filter,
            'outputFormat': output_format
        }, **authenticator.inject_auth(verify=False))
    except Exception as e:
        log.error(e)
        raise e


def post(url: str, xml_data_string: str, authenticator: protocols.WfsRequestAuthenticator, **kwargs: Any) -> Response:
    try:
        return requests.post(url, **authenticator.inject_auth(data=xml_data_string, verify=False))
    except Exception as e:
        log.error(e)
        raise e


class AbstractXMLBuilder(Generic[T], ABC):

    namespace: ClassVar[str]
    namespace_url: ClassVar[str]

    def __init__(self, wfs_type: Type[T]):
        self.wfs_type = wfs_type

    @wfs_request_string(RequestType.GET_CAPABILITIES)
    def get_capabilities_xml(self) -> str:
        return ''

    @wfs_request_string(RequestType.GET_FEATURE)
    @wfs_operation_string(Operation.QUERY)
    def get_features_xml(self, wfs_objects: List[T]) -> str:
        return self.__fes_filter_by_guid(wfs_objects)

    @wfs_request_string(RequestType.TRANSACTION)
    def update_features_xml(self, wfs_objects: List[T]) -> str:
        update_xml = ''
        for wfs_object in wfs_objects:
            update_xml += self.__update_feature_xml(wfs_object)
        return update_xml

    @wfs_request_string(RequestType.TRANSACTION)
    def insert_features_xml(self, wfs_objects: List[T]) -> str:
        insert_xml = ''
        for wfs_object in wfs_objects:
            insert_xml += self.__insert_feature_xml(wfs_object)
        return insert_xml

    @wfs_request_string(RequestType.TRANSACTION)
    @wfs_operation_string(Operation.DELETE)
    def delete_features_xml(self, wfs_objects: List[T]) -> str:
        if (len(wfs_objects) < 1):
            raise WfsXmlError
        return self.__fes_filter_by_guid(wfs_objects)

    @wfs_operation_string(Operation.INSERT)
    def __insert_feature_xml(self, wfs_object: T) -> str:
        xml_string = ''
        for key, value in wfs_object.items():
            if value is not None:
                property_tag = Element(f"{self.namespace}:{key}")
                property_tag.text = value
                xml_string += ElementTree.tostring(property_tag).decode()
        return xml_string

    @wfs_operation_string(Operation.UPDATE)
    def __update_feature_xml(self, wfs_object: T) -> str:
        xml_string = ''
        for key, value in wfs_object.items():
            property_tag = Element('wfs:Property')
            SubElement(property_tag, 'wfs:ValueReference').text = f"{self.namespace}:{key}"
            if value is not None:
                SubElement(property_tag, 'wfs:Value').text = value
            xml_string += ElementTree.tostring(property_tag).decode()
        fes_property_filter = self.__fes_property_filter(wfs_object)
        xml_string += '<fes:Filter>' + ElementTree.tostring(fes_property_filter).decode() + '</fes:Filter>'
        return xml_string

    def __fes_filter_by_guid(self, wfs_objects: List[T]) -> str:
        root = Element('fes:Filter')
        or_tag = SubElement(root, "fes:Or")
        for wfs_upload_object in wfs_objects:
            self.__fes_property_filter(wfs_upload_object, or_tag)
        return ElementTree.tostring(root).decode()

    def __fes_property_filter(self, wfs_object: T, root: Optional[Element] = None) -> Element:
        property_element = SubElement(root, 'fes:PropertyIsEqualTo') if root is not None else Element('fes:PropertyIsEqualTo')
        SubElement(property_element, 'fes:ValueReference').text = f"{self.namespace}:{self.wfs_type.WFS_PRIMARY_KEY}"
        SubElement(property_element, 'fes:Literal').text = wfs_object[self.wfs_type.WFS_PRIMARY_KEY]
        return property_element


class AbstractWfsRequester(ABC):

    url: str
    authorization: HTTPBasicAuth = None
    response_decoder: protocols.WfsResponseDecoder = None
    authenticator: protocols.WfsRequestAuthenticator = None

    def __init__(self,
                 wfs_upload_objects: List[BasicWfsRecord],
                 xml_builder: AbstractXMLBuilder,
                 response_decoder: Optional[protocols.WfsResponseDecoder]=None):
        self.xml_builder = xml_builder
        self.wfs_upload_objects: List[BasicWfsRecord] = wfs_upload_objects
        self.wfs_insert_objects: List[BasicWfsRecord] = []
        self.wfs_update_objects: List[BasicWfsRecord] = []
        self.wfs_delete_objects: List[BasicWfsRecord] = []
        self.response_decoder = response_decoder or self.response_decoder or wfsdecoder.JsonWfsResponseDecoder()
        if self.authorization is not None:
            self.authenticator = wfsauthenticator.HTTPBasicAuthRequestAuthenticator(self.authorization)

    def init_wfs_objects(self) -> None:
        for wfs_object in self.wfs_upload_objects:
            wfs_object.init_attributes()

    def filter_update_insert(self):
        self.wfs_insert_objects = []
        self.wfs_update_objects = []
        id_dict: Dict[str, BasicWfsRecord] = {}
        for wfs_upload_object in self.wfs_upload_objects:
            id_dict[wfs_upload_object[self.xml_builder.wfs_type.WFS_PRIMARY_KEY]] = wfs_upload_object
        existing_features = self.get_features()
        log.debug(f"Features found existing in WFS: {str(existing_features)}")
        for feature in existing_features:
            feature_dict = feature['properties']
            guid: str = feature_dict[self.xml_builder.wfs_type.WFS_PRIMARY_KEY]
            if guid in id_dict:
                # See if the feature has changed
                local_object: BasicWfsRecord = id_dict[guid]
                if feature_dict != local_object:
                    self.wfs_update_objects.append(local_object)
                del id_dict[guid]
        self.wfs_insert_objects = list(id_dict.values())

    def update_features(self) -> Response:
        if self.wfs_update_objects:
            xml_data = self.xml_builder.update_features_xml(self.wfs_update_objects).replace('outputFormat="application/json"',
                                                                                             f'outputFormat="{self.response_decoder.serialization_type}"')
            return self.__send_transaction(xml_data)
        else:
            log.info(f"{self.xml_builder.wfs_type.WFS_TABLE_NAME} has no features that need to be updated")

    def insert_features(self) -> Response:
        if self.wfs_insert_objects:
            xml_data = self.xml_builder.insert_features_xml(self.wfs_insert_objects).replace('outputFormat="application/json"',
                                                                                             f'outputFormat="{self.response_decoder.serialization_type}"')
            return self.__send_transaction(xml_data)
        else:
            log.info(f"{self.xml_builder.wfs_type.WFS_TABLE_NAME} has no features that need to be inserted")

    def get_features(self) -> Dict:
        xml_data_string = self.xml_builder.get_features_xml(self.wfs_upload_objects).replace('outputFormat="application/json"',
                                                                                             f'outputFormat="{self.response_decoder.serialization_type}"')
        post_response = post(self.url, xml_data_string, self.authenticator)
        return self.response_decoder.decode(post_response)['features']

    def delete_features(self) -> Response:
        if self.wfs_delete_objects:
            xml_data = self.xml_builder.delete_features_xml(self.wfs_delete_objects).replace('outputFormat="application/json"',
                                                                                             f'outputFormat="{self.response_decoder.serialization_type}"')
            return self.__send_transaction(xml_data)
        else:
            log.info(f"{self.xml_builder.wfs_type.WFS_TABLE_NAME} has no features that need to be deleted")

    def get_capabilities(self) -> str:
        return post(self.url, self.xml_builder.get_capabilities_xml(), self.authenticator).text

    def __send_transaction(self, xml_data: str) -> Response:
        xml_data = xml_data.replace('outputFormat="application/json"', f'outputFormat="{self.response_decoder.serialization_type}"')
        response = post(self.url, xml_data, self.authenticator)
        self.__check_and_log_transaction_response(response)
        return response

    def __check_and_log_transaction_response(self, response: Response) -> None:
        if response.status_code != 200:
            log.error(f"{self.xml_builder.wfs_type.WFS_TABLE_NAME} failed with response: {response.text}")
            raise(WfsMessageError(response.text))
        else:
            try:
                log.info(f"{self.xml_builder.wfs_type.WFS_TABLE_NAME} result: "
                         f"{xmltodict.parse(response.text)['wfs:TransactionResponse']['wfs:TransactionSummary']}")
            except (JSONDecodeError, KeyError) as e:
                log.error(e)
                raise(e)


