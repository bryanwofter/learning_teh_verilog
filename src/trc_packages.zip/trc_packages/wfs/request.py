import urllib
from xml.etree import cElementTree as ET
import requests
import copy

headers = {'X-Esri-Authorization': 'Bearer XKk9hZs5svsQ7G4f8_5NKzeFcwG0DmzI5MLZqsyxG077X9FV3zptKSLncYKWqYG4',
           'referer': 'gulf_coast'}

post_header = copy.deepcopy(headers)
post_header['Content-Type'] = 'application/xml'


def request_wfs_data(circuit, url, typename, circuit_field):
    '''
    Perform wfs GET request.
    Filter using encoding found here: https://gis.stackexchange.com/questions/288516/wfs-filter-for-property-name
    :param url: WFS server url
    :param typename: the WFS table name
    :param circuit_field: the name of the circuit field (feeder or circuit_id most likely)
    :return: request result
    '''
    fes = ET.Element("fes:Filter")
    property_equals = ET.SubElement(fes, 'PropertyIsEqualTo')
    ET.SubElement(property_equals, 'ValueReference').text = circuit_field
    ET.SubElement(property_equals, 'Literal').text = circuit
    fes_filter = urllib.parse.quote(ET.tostring(fes))

    return requests.get(url, {
        'service': 'WFS',
        'request': 'GetFeature',
        'version': '2.0.0',
        'typeName': typename,
        'FILTER': fes_filter
    }, headers=headers)


def request_wfs_data_from_extent(url, typename, layer, epsg):
    buffered_extent = layer.extent().buffered(1000)
    x_min = str(buffered_extent.xMinimum())
    x_max = str(buffered_extent.xMaximum())
    y_min = str(buffered_extent.yMinimum())
    y_max = str(buffered_extent.yMaximum())

    return requests.get(url, {
        'service': 'WFS',
        'request': 'GetFeature',
        'version': '2.0.0',
        'typeName': typename,
        'srsName': 'urn:ogc:def:crs:EPSG::{}'.format(epsg),
        'bbox': '{},{},{},{}'.format(x_min, y_min, x_max, y_max)
    }, headers=headers)


def post_wfs_data(wfs_url, xml_data):
    return requests.post(wfs_url, data=xml_data, headers=post_header)
