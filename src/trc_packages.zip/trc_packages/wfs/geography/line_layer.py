from trc_packages.wfs.geography.abstractgeographylayer import AbstractGeographyLayer


class WFSLineLayer(AbstractGeographyLayer):

    def __init__(self, wfs_serv, url, qgis_layer_name, qgis_id_field_name, wfs_namespace, wfs_typename,
                 filter_field_name, xml_file_name, sqlite_layer_name, dependent_layer=None, rule_index=-1):
        super().__init__(wfs_serv, url, qgis_layer_name, qgis_id_field_name, wfs_namespace, wfs_typename,
                         filter_field_name, xml_file_name, sqlite_layer_name, dependent_layer, rule_index)

    def get_feature_update_xml(self, properties_string, guid, feature):
        '''
        Generate the XML for a feature update.
        :param properties_string: The feature XML for the properties (Generated in abstractgeographylayer)
        :param guid: the GUID of the feature
        :param feature: the feature to be updated in the WFS
        :return: the feature XML
        '''
        geometry = feature.geometry()
        # Make sure point has valid geometry line
        line = geometry.asMultiPolyline()
        if len(line) > 0:
            points = geometry.asMultiPolyline()[0]
        else:
            return ''
        points_string = ''.join([str(point.x()) + " " + str(point.y()) + " " for point in points]).strip()
        feature_xml = '<wfs:Update typeName="' + self.wfs_namespace + ':' + self.wfs_typename + '">' + \
                      properties_string + \
                      self.property_string('shape',
                                           '''
                                                <gml:MultiCurve
                                                    srsName="urn:ogc:def:crs:EPSG::{0}">
                                                    <gml:curveMember>
                                                        <gml:LineString
                                                            srsName="urn:ogc:def:crs:EPSG::{0}">
                                                            <gml:posList>{1} </gml:posList>
                                                        </gml:LineString>
                                                    </gml:curveMember>
                                                 </gml:MultiCurve>'''.format(self.wfs_serv.epsg, points_string)) + \
                      '''  <fes:Filter>
                                                 <fes:PropertyIsEqualTo>
                                                     <fes:ValueReference>''' + self.wfs_namespace + ':' + \
                      self.qgis_id_field_name + '</fes:ValueReference>' + \
                      '''      <fes:Literal>{}</fes:Literal>
                                                   </fes:PropertyIsEqualTo>
                                                 </fes:Filter>
                                          </wfs:Update>'''.format(guid)
        return feature_xml

    def get_feature_insert_xml(self, attribute_string, guid, feature):
        '''
        Generate the XML for a feature insert
        :param attribute_string: The feature XML for the attributes (Generated in abstract_layer)
        :param guid: the GUID of the feature
        :param feature: the feature to be inserted in the WFS
        :return: insert xml
        '''
        geometry = feature.geometry()
        line = geometry.asMultiPolyline()
        # Make sure point has valid geometry line
        if len(line) > 0:
            points = geometry.asMultiPolyline()[0]
        else:
            return ''
        points_string = ''.join([str(point.x()) + " " + str(point.y()) + " " for point in points]).strip()
        feature_xml = '<wfs:Insert>' + \
                      '<{0}:{1}''> '.format(self.wfs_namespace, self.wfs_typename) + \
                      attribute_string + \
                      '''
                                  <{0}:{2}>{3}</{0}:{2}> 
                                  <{0}:shape> 
                                          <gml:MultiCurve
                                                        srsName="urn:ogc:def:crs:EPSG::{5}">
                                                        <gml:curveMember>
                                                            <gml:LineString
                                                                srsName="urn:ogc:def:crs:EPSG::{5}">
                                                                <gml:posList>{4}</gml:posList>
                                                            </gml:LineString>
                                                        </gml:curveMember>
                                                     </gml:MultiCurve>
                                  </{0}:shape>
                              </{0}:{1}>
                   </wfs:Insert>'''.format(self.wfs_namespace, self.wfs_typename, self.qgis_id_field_name, guid,
                                           points_string, self.wfs_serv.epsg)
        return feature_xml
