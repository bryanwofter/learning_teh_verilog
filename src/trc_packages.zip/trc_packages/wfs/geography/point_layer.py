from trc_packages.wfs.geography.abstractgeographylayer import AbstractGeographyLayer


class WFSPointLayer(AbstractGeographyLayer):

    def __init__(self, wfs_serv, url, qgis_layer_name, qgis_id_field_name, wfs_namespace, wfs_typename,
                 filter_field_name, xml_file_name, sqlite_layer_name, dependent_layer=None, rule_index=-1):
        super().__init__(wfs_serv, url, qgis_layer_name, qgis_id_field_name, wfs_namespace, wfs_typename,
                         filter_field_name, xml_file_name, sqlite_layer_name, dependent_layer, rule_index)

    @staticmethod
    def get_xy(feature):
        '''
        Get the geometry x and y strings for a feature point
        :param feature:
        :return: geometry x and y
        '''
        try:
            geometry_x = str(feature.geometry().get().x())
            geometry_y = str(feature.geometry().get().y())
            return geometry_x, geometry_y
        except AttributeError:
            print('bad geometry')

    def get_feature_update_xml(self, properties_string, guid, feature):
        '''
        Generate the XML for a feature update.
        :param properties_string: The feature XML for the properties (Generated in abstractgeographylayer)
        :param guid: the GUID of the feature
        :param feature: the feature to be updated in the WFS
        :return: the feature XML
        '''
        geometry_x, geometry_y = self.get_xy(feature)
        if not geometry_x or not geometry_y:
            return
        feature_xml = '<wfs:Update typeName="' + self.wfs_namespace + ':' + self.wfs_typename + '">' + \
                      properties_string + \
                      self.property_string('shape',
                                           '''  <gml:Point
                                                    srsName="urn:ogc:def:crs:EPSG::{}">
                                                    <gml:pos>{} {}</gml:pos>
                                                </gml:Point>'''.format(self.wfs_serv.epsg, geometry_x, geometry_y)) + \
                      '''  <fes:Filter>
                            <fes:PropertyIsEqualTo>
                                <fes:ValueReference>''' + self.wfs_namespace + ':' + self.qgis_id_field_name + '</fes:ValueReference>' + \
                      ''''      <fes:Literal>{}</fes:Literal>
                              </fes:PropertyIsEqualTo>
                            </fes:Filter>
                     </wfs:Update>'''.format(guid)
        return feature_xml

    def get_feature_insert_xml(self, attribute_string, guid, feature):
        '''
        Generate the XML for a feature insert
        :param attribute_string: The feature XML for the attributes (Generated in abstract_layer)
        :param guid: the GUID of the feature
        :param feature: the feature to be inserted in the WFS
        :return: insert xml
        '''
        geometry_x, geometry_y = self.get_xy(feature)
        if not geometry_x or not geometry_y:
            return
        feature_xml = '<wfs:Insert>' + \
                      '<{0}:{1}''> '.format(self.wfs_namespace, self.wfs_typename) + \
                      attribute_string + \
                      '''
                                    <{0}:{2}>{3}</{0}:{2}> 
                                    <{0}:shape> 
                                            <gml:Point
                                                srsName="urn:ogc:def:crs:EPSG::{6}">
                                                <gml:pos>{4} {5}</gml:pos>
                                             </gml:Point>
                                    </{0}:shape>
                                </{0}:{1}>
                     </wfs:Insert>'''.format(self.wfs_namespace, self.wfs_typename, self.qgis_id_field_name, guid,
                                             geometry_x, geometry_y, self.wfs_serv.epsg)
        return feature_xml
