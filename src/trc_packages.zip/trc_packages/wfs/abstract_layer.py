import threading
from abc import ABC, abstractmethod
from qgis.core import QgsVectorLayer

import sys
sys.path.append("C:/A_Mapping/GCE/2019/Field/Audit/Master")
from trc_packages import utils


class AbstractLayer(ABC):
    '''
    Abstract Layer class for WFS sync.
    Contains common information to all the WFS layers.
    '''

    xml_update_header = '''
    <?xml version="1.0" ?>
    <wfs:Transaction
       version="2.0.0"
       service="WFS"
       xmlns:wfs="http://www.opengis.net/wfs/2.0"
       xmlns:ogc="http://www.opengis.net/ogc"
       xmlns:fes="http://www.opengis.net/fes/2.0"
       xmlns:gml="http://www.opengis.net/gml/3.2"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '''

    xml_footer = '</wfs:Transaction>'

    no_push_fields = ['shape_length']
    number_fields = ['phase', 'sub']
    FEATURE_LIMIT = 100  # Limit to 100 features at a time so POST request doesn't get too large.
    SUCCESS_CODE = 200
    THREAD_LOCK = threading.Lock()

    def __init__(self, wfs_serv, url, sqlite_layer_name, wfs_namespace, xml_temp_file_name, dependent_layers=None):
        self.wfs_serv = wfs_serv
        self.url = url
        self.sqlite_layer_name = sqlite_layer_name
        self.wfs_namespace = wfs_namespace
        self.xml_temp_file_name = xml_temp_file_name
        self.dependent_layers = dependent_layers

    def xml_insert_header(self):
        return self.xml_update_header + 'xmlns:' + self.wfs_namespace + '="https:' + self.url.split('https://')[1] + '"' + \
                   ''' xsi:schemaLocation="http://www.opengis.net/wfs/2.0
                       http://schemas.opengis.net/wfs/2.0/wfs.xsd
                       http://www.opengis.net/gml/3.2
                       http://schemas.opengis.net/gml/3.2.1/gml.xsd"> '''

    def create_temp_XML(self, result):
        '''
        Create temp xml to hold request data
        :param name: name of the table
        :param result: the GET feature result
        :return: the file path to the new temporary xml
        '''
        xml = self.temp_xml_path()
        file = open(xml, 'w')
        file.write((result.text).encode('ascii', 'ignore').decode('ascii'))
        file.close()
        return xml

    def temp_xml_path(self):
        return self.wfs_serv.db_dir + '//' + self.xml_temp_file_name + '_temp.xml'

    def feature_attribute_string(self, feature):
        '''
        Create the XML for an feature's fields. Used in feature inserts.
        In form <Field>Value</Field>
        :param feature: Feature to generate xml for
        :return: feature's attributes xml
        '''
        fields = self.feature_field_names(feature)
        return"".join(
            ["<{0}>{1}</{0}>".format(self.wfs_namespace + ':' + field, feature[field]) for field in fields if
             not utils.is_null(feature[field])]
        )

    @staticmethod
    def replace_ampersand(string):
        '''
        Removes amperands which are causing errors in the wfs.
        :param string: string to remove ampersands from
        :return: string with and replacing any ampersands
        '''
        if isinstance(string, str):
            return string.replace("&", "and")
        else:
            return string

    def feature_field_names(self, feature):
        '''
        Get a feature's field names, not including fields not to be pushed
        :param feature: feature to get field names from
        :return: list of field names
        '''
        fields = [field.name() for field in feature.fields()]
        self.remove_no_push_fields(fields, feature)
        return fields

    def remove_no_push_fields(self, fields, feature):
        '''
        Remove the no push fields from a feature
        :param fields: fields to check
        :param feature: feature to check number fields
        '''
        for field in fields:
            if field.lower() in self.no_push_fields:
                fields.remove(field)
            if (field.lower() in self.number_fields) and (not utils.is_null(feature[field]) and
                                                          not str(feature[field]).isdigit()):
                fields.remove(field)

    def create_temp_layer(self):
        '''
        creates a temp QgsVectorLayer in the temp db
        '''
        uri = self.temp_uri()
        temp_layer = QgsVectorLayer(uri, self.sqlite_layer_name.lower(), 'spatialite')
        temp_layer.startEditing()
        return temp_layer

    @staticmethod
    def successful_request(request_result):
        return request_result.status_code == 200

    @abstractmethod
    def temp_uri(self):
        pass

    @abstractmethod
    def push_layer_to_wfs(self):
        pass

    @abstractmethod
    def update_current_layer(self):
        pass

    @abstractmethod
    def get_qgis_layer(self):
        pass
