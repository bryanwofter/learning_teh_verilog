from trc_packages import core
from trc_packages.debugging import Debug
from trc_packages.wfs import protocols
from typing import Any, Dict, Optional, overload
from typing_extensions import Final
from requests.auth import HTTPBasicAuth
import requests


class HTTPBasicAuthRequestAuthenticator(protocols.WfsRequestAuthenticator):
    """
    Provides an HTTPBasicAuth authenticator for requests.
    """

    authentication: HTTPBasicAuth = None

    @overload
    def __init__(self, authentication: HTTPBasicAuth) -> None:
        ...

    @overload
    def __init__(self, *, username: str, password: str) -> None:
        ...

    def __init__(self, authentication: Optional[HTTPBasicAuth]=None, *, username: Optional[str]=None, password: Optional[str]=None) -> None:
        self.authentication = authentication or HTTPBasicAuth(username, password)

    def inject_auth(self, **kwargs: Any) -> Dict[str, Any]:
        args: Dict[str, Any] = dict(**kwargs)
        args['auth'] = self.authentication
        return args


class ArcGISTokenRequestAuthenticator(protocols.WfsRequestAuthenticator):
    """
    Provides an ArcGIS token authenticator for requests.
    """

    host: str = None
    username: str = None
    password: str = None
    client: str = None
    referer: Optional[str] = None
    ip: Optional[str] = None
    expiration: int = None
    f: str = None

    @overload
    def __init__(self, host: str, username: str, password: str, expiration: int=60, f: str='json', *, referer: str) -> None:
        ...

    @overload
    def __init__(self, host: str, username: str, password: str, expiration: int=60, f: str='json', *, ip: str) -> None:
        ...

    @overload
    def __init__(self, host: str, username: str, password: str, expiration: int=60, f: str='json') -> None:
        ...

    def __init__(self, host: str, username: str, password: str, expiration: int=60, f: str='json', *, referer: Optional[str]=None, ip: Optional[str]=None) -> None:
        if referer is not None:
            self.client = 'referer'
        elif ip is not None:
            self.client = 'ip'
        else:
            self.client = 'requestip'
        self.host = host
        self.username = username
        self.password = password
        self.referer = referer
        self.ip = ip
        self.expiration = expiration
        self.f = f

    def inject_auth(self, **kwargs: Any) -> Dict[str, Any]:
        response: requests.Response = requests.post(url=f"{self.host}/generateToken?",
                                                    data={'username': self.username,
                                                          'password': self.password,
                                                          'client': self.client,
                                                          'referer': self.referer,
                                                          'ip': self.ip,
                                                          'expiration': self.expiration,
                                                          'f': self.f})

        data: Dict[str, Any] = response.json()

        if 'token' in data:
            args: Dict[str, Any] = dict(**kwargs)
            headers: Dict[str, Any] = args.setdefault('headers', {})
            headers['Authorization'] = f"Bearer {data['token']}"
            headers['referer'] = self.referer or self.ip

            return args
        else:
            # TODO: Implement a meaningful exception here.
            raise Exception(data['error']['details'])

