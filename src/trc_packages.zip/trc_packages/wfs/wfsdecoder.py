from trc_packages import core
from trc_packages.decorators import singleton
from trc_packages.debugging import Debug
from trc_packages.wfs import protocols
from typing import Any, Dict, Optional
from typing_extensions import Final
from requests import Response
from xml.etree import ElementTree as etree
import json


@singleton(inherited=True)
class JsonWfsResponseDecoder(protocols.WfsResponseDecoder):
    """
    Provides a JSON-based decoder for WFS response objects.
    """

    serialization_type: str = 'application/json'

    def decode(self, response: Optional[Response]) -> Optional[Dict[str, Any]]:
        if response is None:
            return None
        elif response.ok:
            # TODO: Implement handling of parsing-specific exceptions.
            return response.json()
        else:
            # TODO: Implement handling of WFS-specific exceptions.
            response.raise_for_status()


class GeoJsonWfsResponseDecoder(JsonWfsResponseDecoder):
    """
    Provides a GEOJSON-based decoder for WFS response objects.
    """

    serialization_type: str = 'GEOJSON'


@singleton
class XmlWfsResponseDecoder(protocols.WfsResponseDecoder):
    """
    Provides an XML-based decoder for WFS response objects.
    """

    serialization_type: str = 'GML2'

    GML_NS: Final[Dict[str, str]] = {'gml': 'http://www.opengis.net/gml'}
    WFS_NS: Final[Dict[str, str]] = {'wfs': 'http://www.opengis.net/wfs/2.0'}
    OGC_NS: Final[Dict[str, str]] = {'fes': 'http://www.opengis.net/fes/2.0'}
    XSI_NS: Final[Dict[str, str]] = {'xsi': 'http://www.w3.org/2001/XMLSchema-instance'}
    NAMESPACES: Final[Dict[str, str]] = {**GML_NS, **WFS_NS, **OGC_NS, **XSI_NS}

    def decode(self, response: Optional[Response]) -> Optional[Dict[str, Any]]:
        if response is None:
            return None
        elif response.ok:
            Debug.print(response.text)
            xml_features: List[etree.Element] = etree.fromstring(response.text).findall('gml:featureMember', self.NAMESPACES)
            data: Dict[str, Any] = {
                'type': 'FeatureCollection',
                'features': []
            }

            xml_feature: etree.Element
            for xml_feature in xml_features:

                xml: etree.Element
                for xml in xml_feature:
                    feature: Dict[str, Any] = {
                        'type': 'Feature',
                        'geometry': None,  # TODO: Should we support decoding the geometry?
                        'id': xml.attrib['fid'],
                        'properties': {}
                    }

                    xml_property: etree.Element
                    for xml_property in xml:
                        name: str = core.last(xml_property.tag.split('}'))
                        value: str = xml_property.text

                        if name != 'SHAPE':
                            feature['properties'][name] = value

                    data['features'].append(feature)

            return data
        else:
            # TODO: Implement handling of WFS-specific exceptions.
            response.raise_for_status()

