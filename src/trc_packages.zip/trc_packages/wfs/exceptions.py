from typing import Any, ClassVar, Dict, Optional
from typing_extensions import overload, Final
import xmltodict


class WfsException(Exception):
    """
    A base exception for all WFS errors.
    """


class WfsExceptionReportError(WfsException):
    """
    An exception used to wrap a Wfs generated exception report.
    """

    EXC_REPORT_NAME: ClassVar[Final[str]] = 'ows:ExceptionReport'
    EXC_NAME: ClassVar[Final[str]] = 'ows:Exception'
    EXC_CODE_NAME: ClassVar[Final[str]] = '@exceptionCode'
    LOCATOR_NAME: ClassVar[Final[str]] = '@locator'
    EXC_TEXT_NAME: ClassVar[Final[str]] = 'ows:ExceptionText'
    VERSION_NAME: ClassVar[Final[str]] = '@version'

    @property
    def version(self) -> Optional[str]:
        return self._version

    @property
    def exc_code(self) -> Optional[str]:
        return self._exc_code

    @property
    def locator(self) -> Optional[str]:
        return self._locator

    @property
    def exc_text(self) -> Optional[str]:
        return self._exc_text

    @overload
    def __init__(self, *, code: Optional[str]=None, locator: Optional[str]=None, text: Optional[str]=None, version: Optional[str]=None) -> None:
        ...

    @overload
    def __init__(self, xml: str) -> None:
        ...

    @overload
    def __init__(self, xml: Dict[str, Any]) -> None:
        ...

    def __init__(self, xml=None, *, code: Optional[str]=None, locator: Optional[str]=None, text: Optional[str]=None, version: Optional[str]=None) -> None:
        super().__init__(xml, code, locator, text)
        if isinstance(xml, str):
            xml = xmltodict.parse(xml, process_namespaces=False)

        if isinstance(xml, dict):
            report: Dict[str, Any] = xml[self.EXC_REPORT_NAME]
            exception: Dict[str, Any] = report[self.EXC_NAME]
            version = report[self.VERSION_NAME]
            code = exception[self.EXC_CODE_NAME]
            locator = exception.get(self.LOCATOR_NAME, None)
            text = exception.get(self.EXC_TEXT_NAME, None)

        self._version: Optional[str] = version
        self._exc_code: Optional[str] = code
        self._locator: Optional[str] = locator
        self._exc_text: Optional[str] = text

    def __str__(self) -> str:
        return self.exc_text


class WfsMessageError(Exception):
    '''Raised when a WFS Transaction fails'''

    def __init__(self, message: str):
        self.message = message

    def __repr__(self) -> str:
        return self.message


class WfsXmlError(Exception):
    '''Raised when a XML creation is invalid'''

