import sqlite3
import time

from PyQt5.QtCore import QVariant
from qgis.core import *

from trc_packages.ogr2ogr_tools.helper import add_all_to_table
from trc_packages.wfs.request import post_wfs_data
from xml.etree import cElementTree as ET

from trc_packages.wfs.abstract_layer import AbstractLayer


class WFSDependentLayer(AbstractLayer):

    LOAD_FEATURE_LIMIT = 2000  # Load feature limit can be significantly higher

    def __init__(self, wfs_serv, url, wfs_layer_name, wfs_field_filter, namespace, pk_table, pk_field_name,
                 fk_table, fk_field_name, xml_temp_file_name, sqlite_layer_name, reference_layer, dependent_layer=None,
                 id_field=None, parent_wfs=None):
        '''
        A WFS dependent layer
        :param wfs_serv: a WFSService object.
        :param url: the layer url.
        :param wfs_layer_name: Name of the layer in WFS. Ex: DEG_GCE_support_structures:equipment
        :param wfs_field_filter: Name of the Field to be filtered by. The foreign key for this layer. Ex: strguid
        :param namespace:
        :param pk_table:
        :param pk_field_name:
        :param fk_table:
        :param fk_field_name:
        :param xml_temp_file_name:
        :param sqlite_layer_name:
        :param reference_layer:
        :param dependent_layer:
        :param id_field:
        :param parent_wfs: Needed when the dependent table has key in its parent table, rather than referencing parent
                           table in its own table.
        '''
        super().__init__(wfs_serv, url, sqlite_layer_name, namespace, xml_temp_file_name, dependent_layer)
        self.wfs_layer_name = wfs_layer_name
        self.wfs_field_filter = wfs_field_filter
        self.pk_table = pk_table
        self.pk_field_name = pk_field_name
        self.fk_table = fk_table
        self.fk_field_name = fk_field_name
        self.xml_temp_file_name = xml_temp_file_name
        self.reference_layer = reference_layer
        self.id_field = id_field
        self.parent_wfs = parent_wfs

    def update_current_layer(self, feature_ids=None):
        '''
        Get/Pull information from server into the current QGIS layer.
        :param feature_ids: The ids of the parent table to pull in (foreign keys).
        :return: the http GET response, or True if no features needed to be updated.
        '''

        # If the parent_wfs is set, change the feature_ids to it.
        if self.parent_wfs:
            with AbstractLayer.THREAD_LOCK:
                feature_ids, x = self.get_ids_from_parent_table(feature_ids)
        successful_result = self.load_new_layer(db_name='tempDB', ids_to_update=feature_ids)

        with AbstractLayer.THREAD_LOCK:
            temp_layer = self.create_temp_layer()
            self.reference_layer.startEditing()
            for feature in self.reference_layer.getFeatures():
                # Foreign key - Ex; Equipment table has STRGUID referencing STR_GUID in Support_Structure table
                guid = feature[self.fk_field_name]
                if guid is None or type(guid) is QVariant or guid not in feature_ids:
                    continue
                # If the GUID is in the feature ids, it is being updated. We need to delete the old features and replace.
                self.reference_layer.deleteFeature(feature.id())
            if len(feature_ids) == 0:
                return True
            for temp_feature in temp_layer.getFeatures():
                guid = temp_feature[self.fk_field_name]
                # Add feature if the foreign key is in the feature_ids
                if type(guid) is not QVariant and guid in feature_ids:
                    temp_feature['ObjectID'] = None
                    self.reference_layer.addFeature(temp_feature)
            self.reference_layer.commitChanges()
        return successful_result

    def get_ids_from_parent_table(self, feature_ids):
        if self.id_field is None:
            id_field = self.parent_wfs.qgis_id_field_name
        else:
            id_field = self.id_field
        if self.parent_wfs:
            current_layer = self.parent_wfs.get_qgis_layer()
            old_layer = QgsVectorLayer(
                "{}{}{}|layername={}".format("C:/A_Mapping/GCE/2019/Field/Audit/DB/", 'tempDB', ".sqlite",
                                             self.parent_wfs.sqlite_layer_name), self.parent_wfs.sqlite_layer_name, "ogr")
            pr_ids = []
            old_ids = []
            for feature_id in feature_ids:
                if type(feature_id) is QVariant:
                    continue
                for feature in current_layer.getFeatures(id_field + "= '" + feature_id + "'"):
                    pr_ids.append(feature[self.pk_field_name])
                for feature in old_layer.getFeatures(id_field + "= '" + feature_id + "'"):
                    old_ids.append(feature[self.pk_field_name])
            return pr_ids, old_ids

    def delete_xml_header(self, include_or):
        '''
        get the delete xml header
        :param include_or: bool - include or filter or not
        :return: xml delete header
        '''
        or_line = '<fes:Or>' if include_or else ''
        return f'''{self.xml_insert_header()}
                               <wfs:Delete typeName="{self.wfs_layer_name}">
                                    <fes:Filter>
                                         {or_line}'''

    def delete_xml_footer(self, include_or):
        '''
        get the delete xml footer
        :param include_or: bool - include or filter or not
        :return: xml delete footer
        '''
        footer = '</fes:Or>' if include_or else ''
        return f'''{footer} </fes:Filter>
                </wfs:Delete> {self.xml_footer}'''

    def delete_features(self, feature_ids):
        '''
        Delete old features from the WFS. Generates XML and send the POST request
        :param feature_ids: foreign key IDs to delete
        :return: True if no Deletes needed, else returns the POST result
        '''
        feature_num = len(feature_ids)
        if feature_num == 0:
            return True, []
        or_filter = feature_num > 1
        xml_delete_data = self.delete_xml_header(or_filter)
        feature_limit = AbstractLayer.FEATURE_LIMIT  # Limit 100 features at a time so request doesn't get too large
        delete_features = []
        for feature_id in feature_ids:
            xml_delete_data += f'''  <fes:PropertyIsEqualTo>
                                        <fes:ValueReference>{self.fk_field_name}</fes:ValueReference>
                                        <fes:Literal>{feature_id}</fes:Literal>
                                    </fes:PropertyIsEqualTo>
                                '''
            feature_limit -= 1  # keep track of limit
            feature_num -= 1  # keep track of number of features
            if feature_limit == 0:
                feature_limit = AbstractLayer.FEATURE_LIMIT  # reset limit

                # Finish generating XML and send request
                xml_delete_data += self.delete_xml_footer(True)
                result = post_wfs_data(self.url, xml_delete_data)
                if not AbstractLayer.successful_request(result):
                    return result, delete_features
                if feature_num == 0:
                    delete_features.append(feature_id)
                    return AbstractLayer.successful_request(result), delete_features
                or_filter = feature_num > 1
                xml_delete_data = self.delete_xml_header(or_filter)
            delete_features.append(feature_id)
        xml_delete_data += self.delete_xml_footer(or_filter)
        result = post_wfs_data(self.url, xml_delete_data)
        return AbstractLayer.successful_request(result), delete_features

    def insert_features(self, feature_ids):
        '''
        Insert the features
        :param feature_ids: foreign key IDs to insert
        :return: Insert POST request result
        '''
        if feature_ids:
            insert_features = []
            xml_data = self.xml_insert_header()
            feature_limit = AbstractLayer.FEATURE_LIMIT  # Limit 100 features at a time
            for feature_id in feature_ids:
                # Filter dependent features
                if type(feature_id) is QVariant:
                    continue
                with AbstractLayer.THREAD_LOCK:
                    for feature in self.reference_layer.getFeatures(self.fk_field_name + "= '" + feature_id + "'"):
                        attribute_string = self.feature_attribute_string(feature)  # from abstractlayer
                        feature_xml = '''
                                        <wfs:Insert>
                                            <{0}>
                                                {1}
                                            </{0}>
                                        </wfs:Insert> '''.format(self.wfs_layer_name, attribute_string)
                        xml_data += feature_xml
                feature_limit -= 1
                if feature_limit == 0:
                    feature_limit = AbstractLayer.FEATURE_LIMIT
                    xml_data += self.xml_footer
                    result = post_wfs_data(self.url, xml_data)
                    successful_result = AbstractLayer.successful_request(result)
                    if not successful_result:
                        return successful_result, insert_features
                    xml_data = self.xml_insert_header()
                insert_features.append(feature_id)
            xml_data += self.xml_footer
            result = post_wfs_data(self.url, xml_data)
            return AbstractLayer.successful_request(result), insert_features
        else:
            return True, []

    def push_layer_to_wfs(self, feature_ids=None, parent_wfs=None):
        '''
        Push the layer to the WFS. Deletes old features and inserts new ones
        :param feature_ids: feature ids to update
        :param parent_wfs:
        :return: delete POST result, insert POST result, deleted feature ids, inserted feature ids
        '''
        if self.parent_wfs:
            with AbstractLayer.THREAD_LOCK:
                feature_ids, delete_ids = self.get_ids_from_parent_table(feature_ids)
        else:
            delete_ids = feature_ids
        delete_result, delete_features = self.delete_features(delete_ids)
        insert_result, insert_features = self.insert_features(feature_ids)
        for did in delete_features:
            if did in insert_features:
                delete_features.remove(did)
        return delete_result, insert_result, delete_features, insert_features

    def xml_request_header(self, include_or):
        '''
        Create the xml get feature request header
        :param include_or: Whether to include the Or filter or not
        :return: xml get feature request header
        '''
        or_string = '<fes:Or>' if include_or else ''
        return f'''<wfs:GetFeature service="WFS" version="2.0.0"
                                      xmlns:wfs="http://www.opengis.net/wfs/2.0"
                                      xmlns:fes="http://www.opengis.net/fes/2.0"
                                      xmlns:gml="http://www.opengis.net/gml/3.2">
                                      <wfs:Query typeNames="{self.wfs_namespace}:{self.fk_table}">
                                          <fes:Filter>
                                            {or_string} '''

    def xml_request_footer(self, include_or):
        '''
        Create the xml request footer
        :param include_or: Whether to include the Or filter or not
        :return: xml request footer
        '''
        or_string = '</fes:Or>' if include_or else ''
        return f'''    {or_string}
                    </fes:Filter>
                   </wfs:Query>
                </wfs:GetFeature>'''

    def load_new_layer(self, db_name=None, ids_to_update=None):
        '''
        Load a new layer from the WFS
        :param db_name: name of the db to write to
        :param ids_to_update: Which foreign key ids to get from WFS
        :return: True if no IDs to get, otherwise the Get request Result
        '''
        if db_name is None:
            db_name = self.wfs_serv.circuit
        with AbstractLayer.THREAD_LOCK:
            conn = sqlite3.connect(self.wfs_serv.db_dir + '/{}.sqlite'.format(db_name))
            # Get the IDs for the table this is dependent on.
            ids = conn.execute("Select Distinct({}) from {}".format(self.pk_field_name, self.pk_table)).fetchall()
            conn.close()

        # Clean IDs and filter if only updating some of them
        ids = [i for sub in ids for i in sub]
        if ids_to_update:
            ids = [x for x in ids if x in ids_to_update]
        ids = [x for x in ids if x is not None and x is not '']

        feature_num = len(ids)
        or_filter = feature_num > 1
        feature_limit = WFSDependentLayer.LOAD_FEATURE_LIMIT
        if feature_num > 0:
            xml_request_string = self.xml_request_header(or_filter)
            loop_time = time.time()
            for fid in ids:
                # Generate the XML. Querying the WFS based on the foreign key
                property_element = ET.Element('fes:PropertyIsEqualTo')
                ET.SubElement(property_element, 'fes:ValueReference').text = f"{self.wfs_namespace}:{self.fk_field_name}"
                ET.SubElement(property_element, 'fes:Literal').text = fid
                xml_request_string += ET.tostring(property_element).decode()
                feature_limit -= 1  # Keep track of limit
                feature_num -= 1  # Keep track of features left

                if feature_limit == 0:  # Limit has been hit
                    feature_limit = WFSDependentLayer.LOAD_FEATURE_LIMIT  # Reset limit

                    # Finish XML and send the request
                    xml_request_string += self.xml_request_footer(True)
                    result = post_wfs_data(self.url, xml_request_string)
                    if not AbstractLayer.successful_request(result):
                        return False
                    with AbstractLayer.THREAD_LOCK:
                        file_path = self.create_temp_XML(result)

                        # New layer, so adding all to the table
                        add_all_to_table(db_name, self.wfs_serv.db_dir, self.fk_table, file_path)
                    if feature_num == 0:
                        return AbstractLayer.successful_request(result)
                    or_filter = feature_num > 1
                    xml_request_string = self.xml_request_header(or_filter)

            xml_request_string += self.xml_request_footer(or_filter)
            result = post_wfs_data(self.url, xml_request_string)
            with AbstractLayer.THREAD_LOCK:
                file_path = self.create_temp_XML(result)
                add_all_to_table(db_name, self.wfs_serv.db_dir, self.fk_table, file_path)
            return AbstractLayer.successful_request(result)
        else:
            return True

    def get_qgis_layer(self):
        return self.reference_layer

    def temp_uri(self):
        return 'dbname=\'{}\' table="{}" sql='.format(self.wfs_serv.get_temp_db_path(),
                                                      self.sqlite_layer_name.lower())
