'''
Helper functions to use the ogr2ogr tool
'''

from trc_packages.ogr2ogr_tools import ogr2ogr


def add_all_to_table(db_name, db_dir, table_name, file_path):
    '''
    Adds a table without filtering
    :param db_name: name of sqlite db file
    :param db_dir: db directory
    :param table_name: the name of the table in the sqlite db
    :param file_path: the xml file path
    '''
    ogr2ogr.main(["", "-f", "SQLite", "-append", "-nln", table_name,
                  "{}".format(db_dir + "/" + db_name + ".sqlite"),
                  "{}".format(file_path)])


def add_null_feeder_to_table(db_dir, circuit, table_name, circuit_field_name, file_path):
    '''
    Add a circuit with a null feeder
    :param db_dir: db directory
    :param circuit: the circuit name
    :param table_name: the table name in sqlite
    :param circuit_field_name: the name of the circuit field (Feeder, Circuit_ID, etc.)
    :param file_path: the xml file path
    '''
    ogr2ogr.main(["", "-f", "SQLite", "-append", "-nln", table_name, "-where",
                  circuit_field_name + ' IS NULL ',
                  "{}".format(db_dir + "/" + circuit + ".sqlite"),
                  "{}".format(file_path)])


def add_to_table(db_name, db_dir, table_name, circuit_field_name, circuit, file_path):
    '''
    Adds to a circuit based on one sql where filter
    :param db_name: name of sqlite db file
    :param db_dir: db directory
    :param table_name: the name of the table in the sqlite db
    :param circuit_field_name: the name of the circuit field (Feeder, Circuit_ID, etc.)
    :param file_path: the xml file path
    '''
    ogr2ogr.main(["", "-f", "SQLite", "-append", "-nln", table_name, "-where",
                  circuit_field_name + "='" + circuit + "'",
                  "{}".format(db_dir + "/" + db_name + ".sqlite"),
                  "{}".format(file_path)])
