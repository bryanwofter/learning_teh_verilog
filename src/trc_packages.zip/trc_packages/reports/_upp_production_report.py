import pkg_resources
import os
import shutil
from PyQt5 import QtCore, QtWidgets
from qgis.core import QgsProject, QgsExpressionContextUtils, QgsVectorLayer, edit, QgsFeature, QgsExpression, QgsFeatureRequest
import qgis
import qgis.core
from datetime import date, datetime
import time
from trc_packages.core.features import BasicFeatureObject, BasicVectorObject
from trc_packages.core.features.factories import str_item, bool_item, date_item, datetime_item, int_item, float_item, time_item
from trc_packages.wfs.mappings import BasicWfsRecord, WfsStringItem, WfsFloatItem, WfsDateItem, WfsIntItem, WfsBoolItem
from trc_packages.wfs.transaction_builder import AbstractXMLBuilder
from trc_packages.wfs.transaction_builder import AbstractWfsRequester
from trc_packages.wfs.services import WFSUploadService
from trc_packages.debugging import Debug
from trc_packages.wfs import protocols, wfsdecoder, wfsauthenticator
from requests.auth import HTTPBasicAuth


class UPPFeature(BasicFeatureObject):
    hash_field = 'pkuid'

    pkuid = str_item()
    project_name = str_item('Project_Name')
    user_name = str_item('User_Name')
    date = datetime_item('Date')
    first_edit_of_the_day = float_item('First_Edit_of_the_Day')
    last_edit_of_the_day = float_item('Last_Edit_of_the_Day')
    number_of_gaps = int_item('Number_of_Gaps')
    total_gap = float_item('Total_Gap')
    total_collection_hours = float_item('Total_Collection_Hours')
    number_of_locations_collected = int_item('Number_of_Locations_Collected')
    number_of_visits_per_hour = float_item('Number_of_Visits_Per_Hour')
    number_of_edited_entries = int_item('Number_of_Edited_Entries')


class UPPRecord(BasicWfsRecord[UPPFeature]):
    WFS_TABLE_NAME = 'upp_report'
    WFS_PRIMARY_KEY = 'pkuid'

    pkuid = WfsStringItem()
    project_name = WfsStringItem('Project_Name')
    user_name = WfsStringItem('User_Name')
    date = WfsDateItem('Date', arcgis_format=True)
    first_edit_of_the_day = WfsDateItem('First_Edit_of_the_Day', arcgis_format=True)
    last_edit_of_the_day = WfsDateItem('Last_Edit_of_the_Day', arcgis_format=True)
    number_of_gaps = WfsIntItem('Number_of_Gaps')
    total_gap = WfsFloatItem('Total_Gap')
    total_collection_hours = WfsFloatItem('Total_Collection_Hours')
    number_of_locations_collected = WfsIntItem('Number_of_Locations_Collected')
    number_of_visits_per_hour = WfsFloatItem('Number_of_Visits_Per_Hour')
    number_of_edited_entries = WfsIntItem('Number_of_Edited_Entries')


class UPPXMLBuilder(AbstractXMLBuilder[UPPRecord]):
    namespace = 'DEG_Web_upp'
    namespace_url = 'https:map.trcsolutions.com/server/services/DEG_Web/upp/MapServer/WFSServer'

    def __init__(self) -> None:
        super().__init__(UPPRecord)


class UPPRequester(AbstractWfsRequester):
    url = 'https://map.trcsolutions.com/server/services/DEG_Web/upp/MapServer/WFSServer'
    authenticator = wfsauthenticator.ArcGISTokenRequestAuthenticator(host='https://map.trcsolutions.com/server/tokens',
                                                                     username='DEG_user',
                                                                     password='Hjfugjrigjf7jfh8h^gdfh',
                                                                     referer='upp')
    response_decoder = wfsdecoder.XmlWfsResponseDecoder()


class UPPVector(BasicVectorObject[UPPFeature]):
    path: str = os.path.join(os.getenv('LOCALAPPDATA'), 'trc_companies', 'qgis')
    current_circuit: str = 'UPP_Production_Report'
    layer_name: str = 'feature_report'
    feature_object_type: type = UPPFeature


class UPPProductionReport(QtCore.QObject):

    def __init__(self, parent=None):
        """Constructor."""
        super().__init__(parent=parent)
        os.makedirs(UPPVector.path, exist_ok=True)
        if not os.path.isfile(os.path.join(UPPVector.path, UPPVector.current_circuit+'.sqlite')):
            shutil.copyfile(pkg_resources.resource_filename(
                'trc_packages.resources.reports',
                UPPVector.current_circuit+'.sqlite'),
                os.path.join(UPPVector.path, UPPVector.current_circuit+'.sqlite'))
        self.database = UPPVector()
        self.ref_text = os.path.join(UPPVector.path, '{}_{}.txt'.format(str(self.project_name), str(self.day)))

    @property
    def project(self):
        return QgsProject.instance()

    @property
    def user(self):
        return QgsExpressionContextUtils.globalScope().variable('user_full_name')

    @property
    def project_name(self):
        return QgsExpressionContextUtils.projectScope(self.project).variable('project_basename')

    @property
    def day(self):
        return date.today()

    def number_of_gaps(self, start):
        for feat in self.database.find("pkuid = {}", str(self.project_name)+'_'+str(self.day)):
            if (start - feat.last_edit_of_the_day) > 300:
                return 1
            else:
                return 0

    def total_gap(self, start):
        for feat in self.database.find("pkuid = {}", str(self.project_name)+'_'+str(self.day)):
            if (start - feat.last_edit_of_the_day) > 300:
                return (start - feat.last_edit_of_the_day)/float(60)
            else:
                return 0

    def num_visits_per_hour(self):
        for feat in self.database.find("pkuid = {}", str(self.project_name)+'_'+str(self.day)):
            if feat.total_collection_hours > 0:
                return feat.number_of_locations_collected/feat.total_collection_hours

    def write_to_db(self):
        start = time.time()
        key: str = f"{self.project_name}_{self.day}"
        if self.database.exists("pkuid = {}", key):
            with self.database.start_transaction():
                for feat in self.database.find("pkuid = {}", key):
                    feat.geometry = qgis.core.QgsGeometry.fromPointXY(qgis.core.QgsPointXY(0, 0))
                    feat.number_of_gaps += self.number_of_gaps(start)
                    feat.total_gap += self.total_gap(start)
                    feat.total_collection_hours = (feat.last_edit_of_the_day - feat.first_edit_of_the_day) / 3600
                    feat.number_of_locations_collected = self.locations_collected()
                    feat.number_of_visits_per_hour = self.num_visits_per_hour()
                    feat.number_of_edited_entries = self.multiple_edited_features()
                    feat.last_edit_of_the_day = time.time()
                    feat.save()
        else:
            with self.database.start_transaction():
                feature = self.database.new_feature(pkuid=key,
                                                    project_name=self.project_name,
                                                    user_name=self.user,
                                                    date=self.day,
                                                    first_edit_of_the_day=time.time(),
                                                    last_edit_of_the_day=time.time(),
                                                    number_of_gaps=0,
                                                    total_gap=0,
                                                    total_collection_hours=0,
                                                    number_of_locations_collected=1)
                feature.geometry = qgis.core.QgsGeometry.fromPointXY(qgis.core.QgsPointXY(0, 0))
                feature.save()

    def multiple_edited_features(self):
        f = open(self.ref_text, 'r+')
        lines = f.read().split(',')
        my_dict = {i:lines.count(i)for i in lines}
        d = dict((k,v) for k, v in my_dict.items() if v > 1)
        multiple_edits = len(d)
        f.close()
        return multiple_edits

    def locations_collected(self):
        f = open(self.ref_text, 'r+')
        lines = f.read().split(',')
        my_dict = {i:lines.count(i)for i in lines}
        d = dict((k,v) for k, v in my_dict.items() if k != '')
        locations = len(d)
        f.close()
        return locations

    def on_feature_identified(self, feature_guid: str) -> None:
        with open(self.ref_text, 'a') as f:
            f.write(', {}'.format(feature_guid))
        self.write_to_db()
