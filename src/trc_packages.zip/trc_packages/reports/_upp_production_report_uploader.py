from trc_packages.reports import _upp_production_report as upr
from trc_packages.wfs.services import WFSUploadService


class UPPProductionReportUploader:

    def get_uploader(self):
        records = upr.UPPVector()
        wfs_records = []  # First argument to upr.UPPRequester
        for feat in records:
            wfs_records.append(upr.UPPRecord(feat))
        xml_builder = upr.UPPXMLBuilder()  # Second argument to upr.UPPRequester

        return WFSUploadService(upr.UPPRequester(wfs_records, xml_builder))
