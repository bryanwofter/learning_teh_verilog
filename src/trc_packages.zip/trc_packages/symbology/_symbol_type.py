from enum import Enum
import qgis


class SymbolType(Enum):
    """
    Provides an alternative naming convention for the QGIS symbol types.
    """
    LINE = qgis.core.QgsWkbTypes.LineGeometry
    POINT = qgis.core.QgsWkbTypes.PointGeometry
    POLYGON = qgis.core.QgsWkbTypes.PolygonGeometry
