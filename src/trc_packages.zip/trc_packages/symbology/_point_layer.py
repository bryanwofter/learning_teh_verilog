from PyQt5 import QtCore
from trc_packages.symbology import _point_symbol_type as pst, _marker_layer as ml
from typing import Optional
import qgis


class PointLayer(ml.MarkerLayer[qgis.core.QgsSimpleMarkerSymbolLayer]):
    """
    Represents a simple point layer in a symbol.
    """

    shape_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='shapeChanged')
    pen_join_style_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='penJoinStyleChanged')
    stroke_style_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='strokeStyleChanged')
    stroke_width_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([float, float], name='strokeWidthChanged')
    stroke_width_map_unit_scale_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='strokeWidthMapUnitScaleChanged')
    stroke_width_map_unit_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='strokeWidthMapUnitChanged')

    # region shape

    _shape: Optional['pst.PointSymbolType'] = None

    @property
    def shape(self) -> Optional['pst.PointSymbolType']:
        return self._shape

    @shape.setter
    def shape(self, value: Optional['pst.PointSymbolType']) -> None:
        old_value: Optional[pst.PointSymbolType] = self._shape

        if old_value != value:
            self._shape = value
            self.shape_changed.emit(value, old_value)

    @shape.deleter
    def shape(self) -> None:
        self.shape = None

    # endregion

    # region pen join style

    _pen_join_style: Optional[QtCore.Qt.PenJoinStyle] = None

    @property
    def pen_join_style(self) -> Optional[QtCore.Qt.PenJoinStyle]:
        return self._pen_join_style

    @pen_join_style.setter
    def pen_join_style(self, value: Optional[QtCore.Qt.PenJoinStyle]) -> None:
        old_value: Optional[QtCore.Qt.PenJoinStyle] = self._pen_join_style

        if old_value != value:
            self._pen_join_style = value
            self.pen_join_style_changed.emit(value, old_value)

    @pen_join_style.deleter
    def pen_join_style(self) -> None:
        self.pen_join_style = None

    # endregion

    # region stroke style

    _stroke_style: Optional[QtCore.Qt.PenStyle] = None

    @property
    def stroke_style(self) -> Optional[QtCore.Qt.PenStyle]:
        return self._stroke_style

    @stroke_style.setter
    def stroke_style(self, value: Optional[QtCore.Qt.PenStyle]) -> None:
        old_value: Optional[QtCore.Qt.PenStyle] = self._stroke_style

        if old_value != value:
            self._stroke_style = value
            self.stroke_style_changed.emit(value, old_value)

    @stroke_style.deleter
    def stroke_style(self) -> None:
        self.stroke_style = None

    # endregion

    # region stroke width

    _stroke_width: float = 0.0

    @property
    def stroke_width(self) -> float:
        return self._stroke_width

    @stroke_width.setter
    def stroke_width(self, value: float) -> None:
        old_value: float = self._stroke_width

        if old_value != value:
            self._stroke_width = value
            self.stroke_width_changed.emit(value, old_value)

    @stroke_width.deleter
    def stroke_width(self) -> None:
        self.stroke_width = 0.0

    # endregion

    # region stroke width map unit scale

    _stroke_width_map_unit_scale: Optional[qgis.core.QgsMapUnitScale] = None

    @property
    def stroke_width_map_unit_scale(self) -> Optional[qgis.core.QgsMapUnitScale]:
        return self._stroke_width_map_unit_scale

    @stroke_width_map_unit_scale.setter
    def stroke_width_map_unit_scale(self, value: Optional[qgis.core.QgsMapUnitScale]) -> None:
        old_value: Optional[qgis.core.QgsMapUnitScale] = self._stroke_width_map_unit_scale

        if old_value != value:
            self._stroke_width_map_unit_scale = value
            self.stroke_width_map_unit_scale_changed.emit(value, old_value)

    @stroke_width_map_unit_scale.deleter
    def stroke_width_map_unit_scale(self) -> None:
        self.stroke_width_map_unit_scale = None

    # endregion

    # region stroke width map unit

    _stroke_width_map_unit: Optional[qgis.core.QgsUnitTypes.RenderUnit] = None

    @property
    def stroke_width_map_unit(self) -> Optional[qgis.core.QgsUnitTypes.RenderUnit]:
        return self._stroke_width_map_unit

    @stroke_width_map_unit.setter
    def stroke_width_map_unit(self, value: Optional[qgis.core.QgsUnitTypes.RenderUnit]) -> None:
        old_value: Optional[qgis.core.QgsUnitTypes.RenderUnit] = self._stroke_width_map_unit

        if old_value != value:
            self._stroke_width_map_unit = value
            self.stroke_width_map_unit_changed.emit(value, old_value)

    @stroke_width_map_unit.deleter
    def stroke_width_map_unit(self) -> None:
        self.stroke_width_map_unit = None

    # endregion

    def _make_symbol_layer(self) -> qgis.core.QgsSimpleMarkerSymbolLayer:
        return qgis.core.QgsSimpleMarkerSymbolLayer()

    def _update_symbol_layer(self, layer: qgis.core.QgsSimpleMarkerSymbolLayer) -> qgis.core.QgsSimpleMarkerSymbolLayer:
        if self.pen_join_style is not None:
            layer.setPenJoinStyle(self.pen_join_style)

        if self.shape is not None:
            layer.setShape(self.shape.value)

        if self.stroke_style is not None:
            layer.setStrokeStyle(self.stroke_style)

        layer.setStrokeWidth(self.stroke_width)

        if self.stroke_width_map_unit is not None:
            layer.setStrokeWidthMapUnit(self.stroke_width_map_unit)

        return super()._update_symbol_layer(layer)

