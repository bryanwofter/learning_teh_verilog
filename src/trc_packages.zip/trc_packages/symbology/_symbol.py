from PyQt5 import QtCore, QtGui
from trc_packages.symbology import _symbol_type as st, _layer as la
from typing import List, Optional, Union
import qgis


class Symbol(QtCore.QObject):
    """
    Provides a symbol-like class for easier manipulation of symbols.
    """

    map_unit_scale_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='mapUnitScaleChanged')
    opacity_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([float, float], name='opacityChanged')
    output_unit_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='outputUnitChanged')
    clip_features_to_extent_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([bool, bool], name='clipFeaturesToExtentChanged')
    color_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='colorChanged')
    force_right_hand_rule_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([bool, bool], name='forceRightHandRuleChanged')
    render_hints_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='renderHintsChanged')

    _symbol_type: 'st.SymbolType' = None

    @property
    def symbol_type(self) -> 'st.SymbolType':
        return self._symbol_type

    # region map unit scale

    _map_unit_scale: Optional[qgis.core.QgsMapUnitScale] = None

    @property
    def map_unit_scale(self) -> Optional[qgis.core.QgsMapUnitScale]:
        return self._map_unit_scale

    @map_unit_scale.setter
    def map_unit_scale(self, value: Optional[qgis.core.QgsMapUnitScale]) -> None:
        old_value: Optional[qgis.core.QgsMapUnitScale] = self._map_unit_scale

        if old_value != value:
            self._map_unit_scale = value
            self.map_unit_scale_changed.emit(value, old_value)

    @map_unit_scale.deleter
    def map_unit_scale(self) -> None:
        self.map_unit_scale = None

    # endregion

    # region opacity

    _opacity: float = 1.0

    @property
    def opacity(self) -> float:
        return self._opacity

    @opacity.setter
    def opacity(self, value: float) -> None:
        old_value: float = self._opacity

        if old_value != value:
            self._opacity = value
            self.opacity_changed.emit(value, old_value)

    @opacity.deleter
    def opacity(self) -> None:
        self.opacity = 0.0

    # endregion

    # region output unit

    _output_unit: qgis.core.QgsUnitTypes.RenderUnit = qgis.core.QgsUnitTypes.RenderUnknownUnit

    @property
    def output_unit(self) -> qgis.core.QgsUnitTypes.RenderUnit:
        return self._output_unit

    @output_unit.setter
    def output_unit(self, value: qgis.core.QgsUnitTypes.RenderUnit) -> None:
        old_value: qgis.core.QgsUnitTypes.RenderUnit = self._output_unit

        if old_value != value:
            self._output_unit = value
            self.output_unit_changed.emit(value, old_value)

    @output_unit.deleter
    def output_unit(self) -> None:
        self.output_unit = qgis.core.QgisUnitTypes.RenderUnknownUnit

    # endregion

    # region clip features

    _clip_features_to_extent: bool = True

    @property
    def clip_features_to_extent(self) -> bool:
        return self._clip_features_to_extent

    @clip_features_to_extent.setter
    def clip_features_to_extent(self, value: bool) -> None:
        old_value: bool = self._clip_features_to_extent

        if old_value != value:
            self._clip_features_to_extent = value
            self.clip_features_to_extent_changed.emit(value, old_value)

    @clip_features_to_extent.deleter
    def clip_features_to_extent(self) -> None:
        self.clip_features_to_extent = False

    # endregion

    # region color

    _color: Optional[QtGui.QColor] = None

    @property
    def color(self) -> Optional[QtGui.QColor]:
        return self._color

    @color.setter
    def color(self, value: Optional[QtGui.QColor]) -> None:
        old_value: Optional[QtGui.QColor] = self._color

        if old_value != value:
            self._color = value
            self.color_changed.emit(value, old_value)

    @color.deleter
    def color(self) -> None:
        self.color = None

    # endregion

    # region force rhr

    _force_right_hand_rule: bool = False

    @property
    def force_right_hand_rule(self) -> bool:
        return self._force_right_hand_rule

    @force_right_hand_rule.setter
    def force_right_hand_rule(self, value: bool) -> None:
        old_value: bool = self._force_right_hand_rule

        if old_value != value:
            self._force_right_hand_rule = value
            self.force_right_hand_rule_changed.emit(value, old_value)

    @force_right_hand_rule.deleter
    def force_right_hand_rule(self) -> None:
        self.force_right_hand_rule = False

    # endregion

    # region render hints

    _render_hints: Optional[Union[qgis.core.QgsSymbol.RenderHints, qgis.core.QgsSymbol.RenderHint]] = None

    @property
    def render_hints(self) -> Union[None, qgis.core.QgsSymbol.RenderHints, qgis.core.QgsSymbol.RenderHint]:
        return self._render_hints

    @render_hints.setter
    def render_hints(self, value: Union[None, qgis.core.QgsSymbol.RenderHints, qgis.core.QgsSymbol.RenderHint]) -> None:
        old_value: Union[None, qgis.core.QgsSymbol.RenderHints, qgis.core.QgsSymbol.RenderHint] = self._render_hints

        if old_value != value:
            self._render_hints = value
            self.render_hints_changed.emit(value, old_value)

    @render_hints.deleter
    def render_hints(self) -> None:
        self.render_hints = None

    # endregion

    # region layers

    _layers: List['la.Layer'] = None

    @property
    def layers(self) -> List['la.Layer']:
        return self._layers

    # endregion

    def __init__(self, symbol_type: 'st.SymbolType', parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent)
        self._symbol_type = symbol_type
        self._layers = []

    def to_qgs_symbol(self) -> qgis.core.QgsSymbol:
        symbol: qgis.core.QgsSymbol = qgis.core.QgsSymbol.defaultSymbol(self.symbol_type.value)
        # Remove the temporary symbol that always exists
        symbol.takeSymbolLayer(0)

        symbol.setClipFeaturesToExtent(self.clip_features_to_extent)

        if self.color is not None:
            symbol.setColor(self.color)

        symbol.setForceRHR(self.force_right_hand_rule)

        if self.map_unit_scale is not None:
            symbol.setMapUnitScale(self.map_unit_scale)

        symbol.setOpacity(self.opacity)

        if self.output_unit is not None:
            symbol.setOutputUnit(self.output_unit)

        if self.render_hints is not None:
            symbol.setRenderHints(self.render_hints)

        layer: la.Layer
        for layer in self.layers:
            symbol.appendSymbolLayer(layer.to_qgs_symbol_layer())

        return symbol

