from abc import ABC, abstractmethod
from PyQt5 import QtCore
from trc_packages.core import QObjectABC
from trc_packages.symbology import _layer as l
from typing import Optional, TypeVar, Union
import qgis
_L = TypeVar('_L', bound=qgis.core.QgsMarkerSymbolLayer)


class MarkerLayer(l.Layer[_L]):

    angle_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([float, float], name='angleChanged')
    horizontal_anchor_point_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='horizontalAnchorPointChanged')
    line_angle_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([float, float], name='lineAngleChanged')
    offset_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='offsetChanged')
    offset_map_unit_scale_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='offsetMapUnitScaleChanged')
    offset_unit_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='offsetUnitChanged')
    scale_method_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='scaleMethodChanged')
    size_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([float, float], name='sizeChanged')
    size_map_unit_scale_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='sizeMapUnitScaleChanged')
    size_unit_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='sizeUnitChanged')
    vertical_anchor_point_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='verticalAnchorPointChanged')

    # region angle

    _angle: float = 0.0

    @property
    def angle(self) -> float:
        return self._angle

    @angle.setter
    def angle(self, value: float) -> None:
        old_value: float = self._angle

        if old_value != value:
            self._angle = value
            self.angle_changed.emit(value, old_value)

    @angle.deleter
    def angle(self) -> None:
        self.angle = 0.0

    # endregion

    # region horizontal anchor point

    _horizontal_anchor_point: Optional[qgis.core.QgsMarkerSymbolLayer.HorizontalAnchorPoint] = None

    @property
    def horizontal_anchor_point(self) -> Optional[qgis.core.QgsMarkerSymbolLayer.HorizontalAnchorPoint]:
        return self._horizontal_anchor_point

    @horizontal_anchor_point.setter
    def horizontal_anchor_point(self, value: Optional[qgis.core.QgsMarkerSymbolLayer.HorizontalAnchorPoint]) -> None:
        old_value: Optional[qgis.core.QgsMarkerSymbolLayer.HorizontalAnchorPoint] = self._horizontal_anchor_point

        if old_value != value:
            self._horizontal_anchor_point = value
            self.horizontal_anchor_point_changed.emit(value, old_value)

    @horizontal_anchor_point.deleter
    def horizontal_anchor_point(self) -> None:
        self.horizontal_anchor_point = None

    # endregion

    # region line angle

    _line_angle: float = 0.0

    @property
    def line_angle(self) -> float:
        return self._line_angle

    @line_angle.setter
    def line_angle(self, value: float) -> None:
        old_value: float = self._line_angle

        if old_value != value:
            self._line_angle = value
            self.line_angle_changed.emit(value, old_value)

    @line_angle.deleter
    def line_angle(self) -> None:
        self.line_angle = 0.0

    # endregion

    # region offset

    _offset: Union[None, QtCore.QPointF, QtCore.QPoint] = None

    @property
    def offset(self) -> Union[None, QtCore.QPointF, QtCore.QPoint]:
        return self._offset

    @offset.setter
    def offset(self, value: Union[None, QtCore.QPointF, QtCore.QPoint]) -> None:
        old_value: Union[None, QtCore.QPointF, QtCore.QPoint] = self._offset

        if old_value != value:
            self._offset = value
            self.offset_changed.emit(value, old_value)

    @offset.deleter
    def offset(self) -> None:
        self.offset = None

    # endregion

    # region offset map unit scale

    _offset_map_unit_scale: Optional[qgis.core.QgsMapUnitScale] = None

    @property
    def offset_map_unit_scale(self) -> Optional[qgis.core.QgsMapUnitScale]:
        return self._offset_map_unit_scale

    @offset_map_unit_scale.setter
    def offset_map_unit_scale(self, value: Optional[qgis.core.QgsMapUnitScale]) -> None:
        old_value: Optional[qgis.core.QgsMapUnitScale] = self._offset_map_unit_scale

        if old_value != value:
            self._offset_map_unit_scale = value
            self.offset_map_unit_scale_changed.emit(value, old_value)

    @offset_map_unit_scale.deleter
    def offset_map_unit_scale(self) -> None:
        self.offset_map_unit_scale = None

    # endregion

    # region offset unit

    _offset_unit: Optional[qgis.core.QgsUnitTypes.RenderUnit] = None

    @property
    def offset_unit(self) -> Optional[qgis.core.QgsUnitTypes.RenderUnit]:
        return self._offset_unit

    @offset_unit.setter
    def offset_unit(self, value: Optional[qgis.core.QgsUnitTypes.RenderUnit]):
        old_value: Optional[qgis.core.QgsUnitTypes.RenderUnit] = self._offset_unit

        if old_value != value:
            self._offset_unit = value
            self.offset_unit_changed.emit(value, old_value)

    @offset_unit.deleter
    def offset_unit(self) -> None:
        self.offset_unit = None

    # endregion

    # region scale method

    _scale_method: Optional[qgis.core.QgsSymbol.ScaleMethod] = None

    @property
    def scale_method(self) -> Optional[qgis.core.QgsSymbol.ScaleMethod]:
        return self._scale_method

    @scale_method.setter
    def scale_method(self, value: Optional[qgis.core.QgsSymbol.ScaleMethod]) -> None:
        old_value: Optional[qgis.core.QgsSymbol.ScaleMethod] = self._scale_method

        if old_value != value:
            self._scale_method = value
            self.scale_method_changed.emit(value, old_value)

    @scale_method.deleter
    def scale_method(self) -> None:
        self.scale_method = None

    # endregion

    # region size

    _size: float = 0.0

    @property
    def size(self) -> float:
        return self._size

    @size.setter
    def size(self, value: float) -> None:
        old_value: float = self._size

        if old_value != value:
            self._size = value
            self.size_changed.emit(value, old_value)

    @size.deleter
    def size(self) -> None:
        self.size = 0.0

    # endregion

    # region size map unit scape

    _size_map_unit_scale: Optional[qgis.core.QgsMapUnitScale] = None

    @property
    def size_map_unit_scale(self) -> Optional[qgis.core.QgsMapUnitScale]:
        return self._size_map_unit_scale

    @size_map_unit_scale.setter
    def size_map_unit_scale(self, value: Optional[qgis.core.QgsMapUnitScale]) -> None:
        old_value: Optional[qgis.core.QgsMapUnitscale] = self._size_map_unit_scale

        if old_value != value:
            self._size_map_unit_scale = value
            self.size_map_unit_scale_changed.emit(value, old_value)

    @size_map_unit_scale.deleter
    def size_map_unit_scale(self) -> None:
        self.size_map_unit_scale = None

    # endregion

    # region size unit

    _size_unit: Optional[qgis.core.QgsUnitTypes.RenderUnit] = None

    @property
    def size_unit(self) -> Optional[qgis.core.QgsUnitTypes.RenderUnit]:
        return self._size_unit

    @size_unit.setter
    def size_unit(self, value: Optional[qgis.core.QgsUnitTypes.RenderUnit]) -> None:
        old_value: Optional[qgis.core.QgsUnitTypes.RenderUnit] = self._size_unit

        if old_value != value:
            self._size_unit = value
            self.size_unit_changed.emit(value, old_value)

    @size_unit.deleter
    def size_unit(self) -> None:
        self.size_unit = None

    # endregion

    # region vertical anchor point

    _vertical_anchor_point: Optional[qgis.core.QgsMarkerSymbolLayer.VerticalAnchorPoint] = None

    @property
    def vertical_anchor_point(self) -> Optional[qgis.core.QgsMarkerSymbolLayer.VerticalAnchorPoint]:
        return self._vertical_anchor_point

    @vertical_anchor_point.setter
    def vertical_anchor_point(self, value: Optional[qgis.core.QgsMarkerSymbolLayer.VerticalAnchorPoint]) -> None:
        old_value: Optional[qgis.core.QgsMarkerSymbolLayer.VerticalAnchorPoint] = self._vertical_anchor_point

        if old_value != value:
            self._vertical_anchor_point = value
            self.vertical_anchor_point_changed.emit(value, old_value)

    @vertical_anchor_point.deleter
    def vertical_anchor_point(self) -> None:
        self.vertical_anchor_point = None

    # endregion

    @abstractmethod
    def _update_symbol_layer(self, layer: _L) -> _L:
        layer.setAngle(self.angle)

        if self.horizontal_anchor_point is not None:
            layer.setHorizontalAnchorPoint(self.horizontal_anchor_point)

        layer.setLineAngle(self.line_angle)

        if self.offset is not None:
            layer.setOffset(self.offset)

        if self.offset_map_unit_scale is not None:
            layer.setOffsetMapUnitScale(self.offset_map_unit_scale)

        if self.offset_unit is not None:
            layer.setOffsetUnit(self.offset_unit)

        if self.scale_method is not None:
            layer.setScaleMethod(self.scale_method)

        layer.setSize(self.size)

        if self.size_map_unit_scale is not None:
            layer.setSizeMapUnitScale(self.size_map_unit_scale)

        if self.size_unit is not None:
            layer.setSizeUnit(self.size_unit)

        if self.vertical_anchor_point is not None:
            layer.setVerticalAnchorPoint(self.vertical_anchor_point)
        return super()._update_symbol_layer(layer)

