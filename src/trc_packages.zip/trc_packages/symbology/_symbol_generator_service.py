from PyQt5 import QtCore, QtGui
from trc_packages import asynclib
from trc_packages.symbology import _symbol_type as st, _point_symbol_type as pst
from typing import Callable, cast, Optional, TypeVar
import qgis
T = TypeVar('T', qgis.core.QgsStyle, qgis.core.QgsFeatureRenderer)
_V = TypeVar('V')
_St = TypeVar('_St', bound=qgis.core.QgsSymbol)
_Lt = TypeVar('_Lt', bound=qgis.core.QgsSymbolLayer)


class SymbolGeneratorService(asynclib.TrcService[T]):
    """
    Provides a service-based symbol generator that can be used alongside other services to dynamically build a project file.
    """

    _fn: Optional[Callable[['SymbolGeneratorService'], T]] = None

    @property
    def fn(self) -> Optional[Callable[['SymbolGeneratorService'], T]]:
        return self._fn

    def __init__(self, fn: Optional[Callable[['SymbolGeneratorService'], T]], parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)
        self._fn = fn

    async def _run_async(self) -> T:
        return self._fn(self)

    # region single

    def make_single_symbol_renderer(self, symbol: qgis.core.QgsSymbol) -> qgis.core.QgsSingleSymbolRenderer:
        """
        Returns a single symbol renderer.
        :param symbol: The symbol of this renderer.
        """
        return qgis.core.QgsSingleSymbolRenderer(symbol)

    # endregion

    # region rule

    def make_rule_renderer(self, default: qgis.core.QgsSymbol) -> qgis.core.QgsRuleBasedRenderer:
        """
        Returns a feature renderer that can be used for rule-based symbols.
        :param default: The default symbol to use for all remaining elements.
        """
        return qgis.core.QgsRuleBasedRenderer(default)

    def make_rule(self, filter: str, symbol: _St, label: str, description: str='', else_rule: bool=False) -> qgis.core.QgsRuleBasedRenderer.Rule:
        """
        Returns a rule for a rule renderer.
        :param filter: The filter to apply.
        :param symbol: The symbol of the rule.
        :param label: The text of the rule.
        :param else_rule: True if the rule is fallback, otherwise False.
        """
        return qgis.core.QgsRuleBasedRenderer.Rule(symbol, 0, 0, filter, label, description, else_rule)

    # endregion

    # region categorized

    def make_categorized_renderer(self, field_name: str) -> qgis.core.QgsCategorizedSymbolRenderer:
        """
        Returns a feature renderer that can be used for categorized symbols.
        :param field_name: The field to categorize the feature on.
        """
        return qgis.core.QgsCategorizedSymbolRenderer(field_name)

    def make_category(self, value: _V, symbol: _St, label: Optional[str]=None) -> qgis.core.QgsRendererCategory:
        """
        Returns a new category.
        :param value: The value of the filter.
        :param symbol: The symbol of the category.
        :param label: The text label of the category.
        """
        return qgis.core.QgsRendererCategory(value, symbol, label or str(value))

    # endregion

    def make_symbol(self, type_: 'st.SymbolType') -> _St:
        """
        Makes a new symbol of the given type.
        :param type_: The type of geometry to make a symbol of.
        """
        return cast(_St, qgis.core.QgsSymbol.defaultSymbol(type_.value))

    def color(self, r: int, g: int, b: int, a: int=255) -> QtGui.QColor:
        """
        Returns an RGBA color with the supplied parameters, forced down to 255 per color.
        :param r: The red channel.
        :param g: The green channel.
        :param b: The blue channel.
        :param a: The alpha channel.
        """
        return QtGui.QColor(r & 0xFF, g & 0xFF, b & 0xFF, a & 0xFF)

    # region lines

    def make_line_symbol(self) -> qgis.core.QgsLineSymbol:
        """
        Returns a line symbol.
        """
        return self.make_symbol(st.SymbolType.LINE)

    # endregion

    # region markers

    def make_point_layer(self, type_: 'pst.PointSymbolType') -> _Lt:
        """
        Returns a point symbol layer of the given type for the given symbol.
        :param type_: The type of the layer.
        """
        return cast(_Lt, qgis.core.QgsSimpleMarkerSymbolLayer(type_.value))

    def make_point_symbol(self) -> qgis.core.QgsMarkerSymbol:
        """
        Returns a point symbol.
        """
        return self.make_symbol(st.SymbolType.POINT)

    # endregion

    # region polygons

    def make_polygon_symbol(self) -> qgis.core.QgsFillSymbol:
        """
        Returns a polygon symbol.
        """
        return self.make_symbol(st.SymbolType.POLYGON)

    # endregion

