from abc import ABC, abstractmethod
from PyQt5 import QtCore, QtGui
from trc_packages.core import QObjectABC
from trc_packages.symbology import _symbol as s
from typing import Generic, Optional, TypeVar
import qgis
_L = TypeVar('_L', bound=qgis.core.QgsSymbolLayer)


class Layer(ABC, QObjectABC, QtCore.QObject, Generic[_L]):
    """
    Represents a layer within a QGIS symbol.
    """

    color_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='colorChanged')
    enabled_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([bool, bool], name='enabledChanged')
    fill_color_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='fillColorChanged')
    is_locked_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([bool, bool], name='isLockedChanged')
    map_unit_scale_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='mapUnitScaleChanged')
    output_unit_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='outputUnitChanged')
    paint_effect_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='paintEffectChanged')
    rendering_pass_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([int, int], name='renderingPassChanged')
    stroke_color_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='strokeColorChanged')
    sub_symbol_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='subSymbolChanged')

    # region color

    _color: Optional[QtGui.QColor] = None

    @property
    def color(self) -> Optional[QtGui.QColor]:
        return self._color

    @color.setter
    def color(self, value: Optional[QtGui.QColor]) -> None:
        old_value: Optional[QtGui.QColor] = self._color

        if old_value != value:
            self._color = value
            self.color_changed.emit(value, old_value)

    @color.deleter
    def color(self) -> None:
        self.color = None

    # endregion

    # region enabled

    _enabled: bool = True

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        old_value: bool = self._enabled

        if old_value != value:
            self._enabled = value
            self.enabled_changed.emit(value, old_value)

    @enabled.deleter
    def enabled(self) -> None:
        self.enabled = False

    # endregion

    # region fill color

    _fill_color: Optional[QtGui.QColor] = None

    @property
    def fill_color(self) -> Optional[QtGui.QColor]:
        return self._fill_color

    @fill_color.setter
    def fill_color(self, value: Optional[QtGui.QColor]) -> None:
        old_value: Optional[QtGui.QColor] = self._fill_color

        if old_value != value:
            self._fill_color = value
            self.fill_color_changed.emit(value, old_value)

    @fill_color.deleter
    def fill_color(self) -> None:
        self.fill_color = None

    # endregion

    # region is locked

    _is_locked: bool = False

    @property
    def is_locked(self) -> bool:
        return self._is_locked

    @is_locked.setter
    def is_locked(self, value: bool) -> None:
        old_value: bool = self._is_locked

        if old_value != value:
            self._is_locked = value
            self.is_locked_changed.emit(value, old_value)

    @is_locked.deleter
    def is_locked(self) -> None:
        self.is_locked = False

    # endregion

    # region map unit scale

    _map_unit_scale: Optional[qgis.core.QgsMapUnitScale] = None

    @property
    def map_unit_scale(self) -> Optional[qgis.core.QgsMapUnitScale]:
        return self._map_unit_scale

    @map_unit_scale.setter
    def map_unit_scale(self, value: Optional[qgis.core.QgsMapUnitScale]) -> None:
        old_value: Optional[qgis.core.QgsMapUnitScale] = self._map_unit_scale

        if old_value != value:
            self._map_unit_scale = value
            self.map_unit_scale_changed.emit(value, old_value)

    @map_unit_scale.deleter
    def map_unit_scale(self) -> None:
        self.map_unit_scale = None

    # endregion

    # region output unit

    _output_unit: Optional[qgis.core.QgsUnitTypes.RenderUnit] = None

    @property
    def output_unit(self) -> Optional[qgis.core.QgsUnitTypes.RenderUnit]:
        return self._output_unit

    @output_unit.setter
    def output_unit(self, value: Optional[qgis.core.QgsUnitTypes.RenderUnit]) -> None:
        old_value: Optional[qgis.core.QgsUnitTypes.RenderUnit] = self._output_unit

        if old_value != value:
            self._output_unit = value
            self.output_unit_changed.emit(value, old_value)

    @output_unit.deleter
    def output_unit(self) -> None:
        self.output_unit = None

    # endregion

    # region paint effect

    _paint_effect: Optional[qgis.core.QgsPaintEffect] = None

    @property
    def paint_effect(self) -> Optional[qgis.core.QgsPaintEffect]:
        return self._paint_effect

    @paint_effect.setter
    def paint_effect(self, value: Optional[qgis.core.QgsPaintEffect]) -> None:
        old_value: Optional[qgis.core.QgsPaintEffect] = self._paint_effect

        if old_value != value:
            self._paint_effect = value
            self.paint_effect_changed.emit(value, old_value)

    @paint_effect.deleter
    def paint_effect(self) -> None:
        self.paint_effect = None

    # endregion

    # region rendering pass

    _rendering_pass: int = 0

    @property
    def rendering_pass(self) -> int:
        return self._rendering_pass

    @rendering_pass.setter
    def rendering_pass(self, value: int) -> None:
        old_value: int = self._rendering_pass

        if old_value != value:
            self._rendering_pass = value
            self.rendering_pass_changed.emit(value, old_value)

    @rendering_pass.deleter
    def rendering_pass(self) -> None:
        self.rendering_pass = 0

    # endregion

    # region stroke color

    _stroke_color: Optional[QtGui.QColor] = None

    @property
    def stroke_color(self) -> Optional[QtGui.QColor]:
        return self._stroke_color

    @stroke_color.setter
    def stroke_color(self, value: Optional[QtGui.QColor]) -> None:
        old_value: Optional[QtGui.QColor] = self._stroke_color

        if old_value != value:
            self._stroke_color = value
            self.stroke_color_changed.emit(value, old_value)

    @stroke_color.deleter
    def stroke_color(self) -> None:
        self.stroke_color = None

    # endregion

    # region sub symbol

    _sub_symbol: Optional['s.Symbol'] = None

    @property
    def sub_symbol(self) -> Optional['s.Symbol']:
        return self._sub_symbol

    @sub_symbol.setter
    def sub_symbol(self, value: Optional['s.Symbol']) -> None:
        old_value: Optional[s.Symbol] = self._sub_symbol

        if old_value != value:
            self._sub_symbol = value
            self.sub_symbol_changed.emit(value, old_value)

    @sub_symbol.deleter
    def sub_symbol(self) -> None:
        self.sub_symbol = None

    # endregion

    def to_qgs_symbol_layer(self) -> _L:
        """
        Converts this layer into a proper symbol layer.
        """
        return self._update_symbol_layer(self._make_symbol_layer())

    @abstractmethod
    def _make_symbol_layer(self) -> _L:
        """
        Creates a new instance of the symbol layer type.
        """
        pass

    @abstractmethod
    def _update_symbol_layer(self, layer: _L) -> _L:
        """
        Updates the provided symbol layer to the current values of this layer.
        :param layer: The layer to update.
        """
        if self.color is not None:
            layer.setColor(self.color)

        layer.setEnabled(self.enabled)

        if self.fill_color is not None:
            layer.setFillColor(self.fill_color)

        layer.setLocked(self.is_locked)

        if self.map_unit_scale is not None:
            layer.setMapUnitScale(self.map_unit_scale)

        if self.output_unit is not None:
            layer.setOutputUnit(self.output_unit)

        if self.paint_effect is not None:
            layer.setPaintEffect(self.paint_effect)

        layer.setRenderingPass(self.rendering_pass)

        if self.stroke_color is not None:
            layer.setStrokeColor(self.stroke_color)

        if self.sub_symbol is not None:
            layer.setSubSymbol(self.sub_symbol.to_qgs_symbol())

        return layer

