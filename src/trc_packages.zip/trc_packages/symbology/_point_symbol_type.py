from enum import Enum
from qgis.core import QgsSimpleMarkerSymbolLayerBase as MarkerType


class PointSymbolType(Enum):
    """
    Provides convenience identifiers for the qgis.core.QgsSimpleMarkerSymbolLayerBase symbol types.
    """
    ARROW = MarkerType.Arrow
    ARROW_HEAD = MarkerType.ArrowHead
    FILLED_ARROW_HEAD = MarkerType.ArrowHeadFilled
    CIRCLE = MarkerType.Circle
    CROSS = MarkerType.Cross
    CROSS_2 = MarkerType.Cross2
    FILLED_CROSS = MarkerType.CrossFill
    DIAGONAL_HALF_SQUARE = MarkerType.DiagonalHalfSquare
    DIAMOND = MarkerType.Diamond
    EQUILATERAL_TRIANGLE = MarkerType.EquilateralTriangle
    HALF_SQUARE = MarkerType.HalfSquare
    HEXAGON = MarkerType.Hexagon
    LEFT_HALF_TRIANGLE = MarkerType.LeftHalfTriangle
    LINE = MarkerType.Line
    PENTAGON = MarkerType.Pentagon
    QUARTER_CIRCLE = MarkerType.QuarterCircle
    QUARTER_SQUARE = MarkerType.QuarterSquare
    RIGHT_HALF_TRIANGLE = MarkerType.RightHalfTriangle
    SEMI_CIRCLE = MarkerType.SemiCircle
    SQUARE = MarkerType.Square
    STAR = MarkerType.Star
    THIRD_CIRCLE = MarkerType.ThirdCircle
    TRIANGLE = MarkerType.Triangle

