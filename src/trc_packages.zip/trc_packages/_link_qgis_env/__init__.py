'''
This is just used for running our tests. We are just adding a path to packages pyqgis can see by default so that we can
use pyqgis specific things in our tests.
'''
import sys
sys.path.append("C:/Program Files/QGIS 3.4/apps/qgis-ltr/python")
import qgis