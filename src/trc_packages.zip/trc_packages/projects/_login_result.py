

class LoginResult:
    """
    A POPO containing the results of a login request to the SPIDAmin system.
    """

    company_name: str = None
    project_name: str = None
    project_id: str = None
    project_guid: str = None
    connection_failed: bool = False

    def __init__(self, *, company_name: str, project_name: str, project_id: str, project_guid: str, connection_failed: bool=False) -> None:
        self.company_name = company_name
        self.project_name = project_name
        self.project_id = project_id
        self.project_guid = project_guid
        self.connection_failed = connection_failed

