from PyQt5 import QtCore
from trc_packages.asynclib import TrcService, step, total_steps
from trc_packages.core import can_connect
from trc_packages.core.spidamin import SPIDAminClient
from trc_packages.projects import _login_result as lr
from typing import Any, Dict, List, Optional


class LoginService(TrcService[Optional['lr.LoginResult']]):
    """
    Provides a login service that uses SPIDAmin's authentication to verify a user.
    """

    authentication_started: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='authenticationStarted')
    authentication_succeeded: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='authenticationSucceeded')
    authentication_failed: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='authenticationFailed')
    company_resolution_started: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='companyResolutionStarted')
    company_resolution_succeeded: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='companyResolutionSucceeded')
    company_resolution_failed: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='companyResolutionFailed')
    project_resolution_started: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='projectResolutionStarted')
    project_resolution_succeeded: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='projectResolutionSucceeded')
    project_resolution_failed: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='projectResolutionFailed')

    host: str = None
    access_token: str = None
    company_name: str = None
    project_name: str = None
    validation_messages: List[str] = None
    total_steps: int = None
    step_size: float = None

    def __init__(self, host: str, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)
        self.host = host
        self.validation_messages = []
        self.total_steps = total_steps(type(self))
        self.step_size = 1 / self.total_steps

    def _run(self) -> Optional['lr.LoginResult']:
        self._progress = 0.0
        self.validation_messages.clear()
        if self.host is None or not self.host:
            self.validation_messages.append('A host is required.')
        if self.access_token is None or not self.access_token:
            self.validation_messages.append('An access token is required.')
        if self.company_name is None or not self.company_name:
            self.validation_messages.append('A company name is required.')
        if self.project_name is None or not self.project_name:
            self.validation_messages.append('A project name is required.')
        if any(self.validation_messages):
            return None

        if not can_connect(self.host, timeout=1):
            return lr.LoginResult(company_name=None,
                                  project_name=None,
                                  project_id=None,
                                  project_guid=None,
                                  connection_failed=True)

        with SPIDAminClient(self.host) as client:  # type: SPIDAminClient
            if self.__authenticate(client):
                self._progress += self.step_size
            else:
                return None

            if self.__resolve_company(client):
                self._progress += self.step_size
            else:
                return None

            result: Optional[lr.LoginResult] = self.__resolve_project(client)

            if result is not None:
                self._progress += self.step_size

            return result

        return None

    @step
    def __authenticate(self, client: SPIDAminClient) -> bool:
        self.authentication_started.emit()

        if client.connect(self.access_token):
            self.authentication_succeeded.emit()
        else:
            self.validation_messages.append('Invalid access token provided.')
            self.authentication_failed.emit()

        return not any(self.validation_messages)

    @step
    def __resolve_company(self, client: SPIDAminClient) -> bool:
        self.company_resolution_started.emit()

        if client.switch_company(self.company_name):
            self.company_resolution_succeeded.emit()
        else:
            self.validation_messages.append('Invalid company provided.')
            self.company_resolution_failed.emit()

        return not any(self.validation_messages)

    @step
    def __resolve_project(self, client: SPIDAminClient) -> Optional['lr.LoginResult']:
        self.project_resolution_started.emit()

        result: Dict[str, Any] = client.request('projectmanager/projectAPI/getProjects', method='POST', project_code_values=f'["{self.project_name}"]', details='false')

        if result is not None and 'projects' in result:
            for project in (p for p in result['projects'] if p is not None and 'projectCodes' in p):
                project_guid: str = None
                project_id: str = None
                project_name: str = project.get('name')

                if project_name is None:
                    continue
                elif ', ' in project_name:
                    project_id, project_name = project_name.split(', ')
                else:
                    project_id = project_name

                for project_code in (p for p in project['projectCodes'] if p is not None and 'type' in p and 'value' in p):  # type: Dict[str, Any]
                    if project_code['type'] == 'AUUID':
                        project_guid = project_code['value']
                        break

                if project_guid is not None and project_id is not None and project_name is not None:
                    self.project_resolution_succeeded.emit()
                    return lr.LoginResult(company_name=self.company_name,
                                          project_name=project_name,
                                          project_id=project_id,
                                          project_guid=project_guid)

        self.validation_messages.append('Invalid project ID provided.')
        self.project_resolution_failed.emit()
        return None

