from abc import abstractmethod
from glob import glob
from PyQt5 import QtCore
from qgis import core, gui, utils  # type: ignore
from trc_packages.asynclib import TrcService, TrcServiceExecutor, total_steps, step, protocols
from trc_packages.core import first, settings, try_or_get
from trc_packages.core.data import conversions
from trc_packages.core.features import protocols as feature_protocols
from trc_packages.debugging import Debug
from trc_packages.ogr2ogr_tools import ogr2ogr
from typing import Any, Dict, FrozenSet, Generic, Iterable, List, Optional, Type, TypeVar
from typing_extensions import Final
import os
import shutil
import sqlite3
TVector = TypeVar('TVector', bound=feature_protocols.Vector)
TConfig = TypeVar('TConfig', bound=settings.SettingsABC)


class MdbProjectLoaderServiceABC(TrcService[bool], Generic[TVector, TConfig]):
    """
    Provides an ABC for MDB-based project loaders with async execution.
    """

    # region Dynamic settings
    user_name: str = None
    created_sqlite_file: bool = False
    created_spatialite_file: bool = False
    created_project_file: bool = False
    validation_messages: List[str] = None
    valid_project: bool = False
    # endregion

    # region Constant settings
    step_size: Final[float]
    layer_data: Final[Dict[str, List[List[Any]]]]
    group_data: Final[Dict[str, List[str]]]
    project_root: Final[str]
    master_root: Final[str]
    remote_template_project_root: Final[Optional[str]]
    remote_aerial_root: Final[Optional[str]]
    template_project_pole_layer: Final[Optional[str]]
    index_definitions: Final[FrozenSet[str]]
    vector_type: Final[Type[TVector]]
    spatialite_definitions: Final[Dict[str, str]]
    # endregion

    # region Project components
    vectors: Dict[str, TVector] = None
    aerial: Optional[core.QgsRasterLayer] = None
    feeders: List[Optional[TVector]] = None
    poles: TVector = None
    working_primaries: Optional[TVector] = None
    working_secondaries: Optional[TVector] = None
    primaries: Optional[TVector] = None
    secondaries: Optional[TVector] = None
    substations: Optional[TVector] = None
    # endregion

    # region Properties
    @property
    @abstractmethod
    def project_name(self) -> Optional[str]:
        ...

    @property
    @abstractmethod
    def project_path(self) -> Optional[str]:
        ...

    @property
    def project_file(self) -> Optional[str]:
        return None if self.project_path is None or self.project_name is None else os.path.join(self.project_path, f"{self.project_name}.qgs")

    @property
    @abstractmethod
    def db_path(self) -> Optional[str]:
        ...

    @property
    def background_gdb_file(self) -> Optional[str]:
        return None if self.db_path is None else first(sorted(glob(os.path.join(self.db_path, 'Background', '*.gdb'))))

    @property
    @abstractmethod
    def mdb_file(self) -> Optional[str]:
        ...

    @property
    @abstractmethod
    def circuit_name(self) -> Optional[str]:
        ...

    @property
    @abstractmethod
    def aerial_path(self) -> Optional[str]:
        ...

    @property
    def aerial_file(self) -> Optional[str]:
        return None if self.aerial_path is None else os.path.join(self.aerial_path, 'aerial.sid')

    @property
    @abstractmethod
    def remote_aerial_file(self) -> Optional[str]:
        ...

    @property
    def working_mdb_file(self) -> Optional[str]:
        return None if self.db_path is None or self.project_name is None else os.path.join(self.db_path, f"{self.project_name}.working.mdb")

    @property
    def sqlite_file(self) -> Optional[str]:
        return None if self.db_path is None or self.project_name is None else os.path.join(self.db_path, f"{self.project_name}.sqlite")

    @property
    def spatialite_file(self) -> Optional[str]:
        return None if self.project_path is None or self.project_name is None else os.path.join(self.project_path, f"{self.project_name}.sqlite")

    @property
    def template_project_file(self) -> Optional[str]:
        return None if self.remote_template_project_root is None else os.path.join(self.master_root, 'template.qgs')

    @property
    def remote_template_project_file(self) -> Optional[str]:
        return None if self.remote_template_project_root is None else os.path.join(self.remote_template_project_root, 'template.qgs')

    @property
    @abstractmethod
    def config(self) -> TConfig:
        ...

    @property
    def project(self) -> core.QgsProject:
        return core.QgsProject.instance()

    @property
    def canvas(self) -> gui.QgsMapCanvas:
        return utils.iface.mapCanvas()
    # endregion

    # region Signals
    project_loading: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='projectLoading')
    project_loaded: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='projectLoaded')

    argument_validation: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='argumentValidation')
    arguments_validated: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='argumentsValidated')

    project_validation: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='projectValidation')
    project_validated: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='projectValidated')

    template_project_downloading: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='templateProjectDownloading')
    template_project_downloaded: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='templateProjectDownloaded')
    template_project_download_skipped: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='templateProjectDownloadSkipped')

    project_building: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='projectBuilding')
    project_built: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='projectBuilt')
    project_build_skipped: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='projectBuildSkipped')

    sqlite_building: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='sqliteBuilding')
    sqlite_built: QtCore.pyqtSignal = QtCore.pyqtSignal([], [str], name='sqliteBuilt')
    sqlite_build_skipped: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='sqliteBuildSkipped')

    project_path_validation: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='projectPathValidation')
    project_path_validated: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='projectPathValidated')

    spatialite_building: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='spatialiteBuilding')
    spatialite_built: QtCore.pyqtSignal = QtCore.pyqtSignal([], [str], name='spatialiteBuilt')
    spatialite_build_skipped: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='spatialiteBuildSkipped')

    vector_layers_preparation: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='vectorLayersPreparation')
    vector_layer_prepared: QtCore.pyqtSignal = QtCore.pyqtSignal([str], name='vectorLayerPrepared')
    vector_layers_prepared: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='vectorLayersPrepared')

    vector_layer_joins_preparation: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='vectorLayerJoinsPreparation')
    vector_layer_joins_prepared: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='vectorLayerJoinsPrepared')

    aerial_layer_downloading: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='aerialLayerDownloading')
    aerial_layer_downloaded: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='aerialLayerDownloaded')
    aerial_layer_download_skipped: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='aerialLayerDownloadSkipped')

    background_gdb_preparation: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='backgroundGdbPreparation')
    background_gdb_prepared: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='backgroundGdbPrepared')

    feeder_layers_preparation: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='feederLayersPreparation')
    feeder_layer_prepared: QtCore.pyqtSignal = QtCore.pyqtSignal([str], name='feederLayerPrepared')
    feeder_layers_prepared: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='feederLayersPrepared')

    pole_layers_preparation: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='poleLayersPreparation')
    pole_layer_prepared: QtCore.pyqtSignal = QtCore.pyqtSignal([str], name='poleLayerPrepared')
    pole_layers_prepared: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='poleLayersPrepared')

    layer_positions_normalization: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='layerPositionsNormalization')
    layer_position_normalized: QtCore.pyqtSignal = QtCore.pyqtSignal([str], name='layerPositionNormalized')
    layer_positions_normalized: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='layerPositionsNormalized')

    layer_styles_loading: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='layerStylesLoading')
    layer_style_loaded: QtCore.pyqtSignal = QtCore.pyqtSignal([str], name='layerStyleLoaded')
    layer_styles_loaded: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='layerStylesLoaded')

    pole_editor_script_loading: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='poleEditorScriptLoading')
    pole_editor_script_loaded: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='poleEditorScriptLoaded')

    extent_updating: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='extentUpdating')
    extent_updated: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='extentUpdated')

    project_finalization: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='projectFinalization')
    project_finalized: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='projectFinalized')
    # endregion

    def __init__(self, project_root: str, master_root: str, vector_type: Type[TVector], layer_data: Dict[str, List[List[Any]]], group_data: Dict[str, List[str]],
                 remote_template_project_root: Optional[str]=None, remote_aerial_root: Optional[str]=None, template_project_pole_layer: Optional[str]=None,
                 index_definitions: Optional[Iterable[str]]=None, spatialite_definitions: Optional[Dict[str, str]]=None, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)

        self.step_size = 1 / total_steps(type(self))
        self.project_root = project_root
        self.master_root = master_root
        self.remote_template_project_root = remote_template_project_root
        self.remote_aerial_root = remote_aerial_root
        self.template_project_pole_layer = template_project_pole_layer
        self.index_definitions = frozenset(index_definitions or [])
        self.group_data = group_data
        self.layer_data = layer_data
        self.spatialite_definitions = dict(spatialite_definitions or {})
        self.vector_type = vector_type

        self.validation_messages = []

    def _restore_initial_state(self) -> None:
        """Restores this service back to its initial state."""
        self.validation_messages.clear()
        self.created_spatialite_file = False
        self.created_sqlite_file = False
        self.created_project_file = False
        self.valid_project = False
        self.vectors = None
        self.aerial = None
        self.feeders = None
        self.poles = None
        self.working_primaries = None
        self.working_secondaries = None
        self.primaries = None
        self.secondaries = None
        self.substations = None
        self._progress = 0.0

    def _set_progress_from_prev(self, prev_progress: float) -> float:
        """
        Updates progress using the previous progress.
        :param prev_progress: The previous complete progress value.
        :return: The new progress.
        """
        self._progress = prev_progress + self.step_size
        return self._progress

    async def _run_async(self) -> bool:
        """Builds the project using the settings that have been provided."""
        Debug.pause()
        self._restore_initial_state()
        prev_progress: float = self._progress

        self.argument_validation.emit()
        if self._validate_arguments():
            self.arguments_validated.emit()
        else:
            return False
        prev_progress = self._progress = prev_progress + self.step_size

        self.sqlite_building.emit()
        if os.path.isfile(self.sqlite_file):
            self.sqlite_build_skipped.emit()
        elif self._build_sqlite():
            self.sqlite_built.emit()
        else:
            return False
        prev_progress = self._set_progress_from_prev(prev_progress)

        self.project_path_validation.emit()
        if self._validate_project_path():
            self.project_path_validated.emit()
        else:
            return False
        prev_progress = self._set_progress_from_prev(prev_progress)

        self.project_validation.emit()
        if self._validate_project():
            self.project_validated.emit()
        else:
            return False
        prev_progress = self._set_progress_from_prev(prev_progress)

        if self.template_project_file is None or os.path.isfile(self.template_project_file):
            self.template_project_download_skipped.emit()
        else:
            self.template_project_downloading.emit()

            if self._download_template_project():
                self.template_project_downloaded.emit()
            else:
                return False
        prev_progress = self._set_progress_from_prev(prev_progress)

        self.project_building.emit()
        if os.path.isfile(self.project_file):
            self.project_build_skipped.emit()
        elif self._build_project():
            self.project_built.emit()
        else:
            return False
        prev_progress = self._set_progress_from_prev(prev_progress)

        if self.created_project_file or self.created_sqlite_file:
            self.vector_layers_preparation.emit()
            if self._prepare_vector_layers():
                self.vector_layers_prepared.emit()
            else:
                return False
            prev_progress = self._set_progress_from_prev(prev_progress)

            self.vector_layer_joins_preparation.emit()
            if self._prepare_vector_layer_joins():
                self.vector_layer_joins_prepared.emit()
            else:
                return False
            prev_progress = self._set_progress_from_prev(prev_progress)

            if await self._handle_special_layers():
                prev_progress = self._progress = prev_progress + self.step_size * 3
            else:
                return False
            prev_progress = self._set_progress_from_prev(prev_progress)

            self.pole_layers_preparation.emit()
            if self._prepare_pole_layers():
                self.pole_layers_prepared.emit()
            else:
                return False
            prev_progress = self._set_progress_from_prev(prev_progress)

            self.feeder_layers_preparation.emit()
            if self._prepare_feeder_layers():
                self.feeder_layers_prepared.emit()
            else:
                return False
            prev_progress = self._set_progress_from_prev(prev_progress)

            self.layer_positions_normalization.emit()
            if self._normalize_layer_positions():
                self.layer_positions_normalized.emit()
            else:
                return False
            prev_progress = self._set_progress_from_prev(prev_progress)

            self.layer_styles_loading.emit()
            if self._load_layer_styles():
                self.layer_styles_loaded.emit()
            else:
                return False
            prev_progress = self._set_progress_from_prev(prev_progress)

            self.pole_editor_script_loading.emit()
            if self._load_pole_editor_script():
                self.pole_editor_script_loaded.emit()
            else:
                return False
            prev_progress = self._set_progress_from_prev(prev_progress)

            self.extent_updating.emit()
            if self._update_extent():
                self.extent_updated.emit()
            else:
                return False
            prev_progress = self._set_progress_from_prev(prev_progress)

            self.project_finalization.emit()
            if self._finalize_project():
                self.project_finalized.emit()
            else:
                return False
            prev_progress = self._set_progress_from_prev(prev_progress)

        return not any(self.validation_messages)

    @step
    @abstractmethod
    def _validate_arguments(self) -> bool:
        return not any(self.validation_messages)

    @step
    @abstractmethod
    def _validate_project(self) -> bool:
        return not any(self.validation_messages)

    @step
    @abstractmethod
    def _download_template_project(self) -> bool:
        template_project_file: Optional[str] = self.template_project_file
        remote_template_project_file: Optional[str] = self.remote_template_project_file

        if template_project_file is None or remote_template_project_file is None:
            return True

        try:
            if not os.path.isfile(template_project_file) and os.path.isfile(remote_template_project_file):
                shutil.copy(remote_template_project_file, template_project_file)
        except IOError:
            self.validation_messages.append('Could not download the template project. Do you have an internet connection?')

        return not any(self.validation_messages)

    @step
    @abstractmethod
    def _build_project(self) -> bool:
        return not any(self.validation_messages)

    @step
    @abstractmethod
    def _build_sqlite(self) -> bool:
        acisi_table_name: Optional[str] = None

        if not os.path.isfile(self.mdb_file):
            self.validation_messages.append('No source MDB was found.')
        elif not os.path.isfile(self.sqlite_file):
            orig_progress: float = self._progress
            total_tables: int = 0
            copied_tables: int = 0

            def __update_progress() -> None:
                nonlocal orig_progress
                nonlocal total_tables
                nonlocal copied_tables

                self._progress = orig_progress + ((copied_tables / total_tables) * self.step_size)
                core.QgsApplication.instance().thread().eventDispatcher().processEvents(QtCore.QEventLoop.AllEvents)

            def __table_count_callback(count: int) -> None:
                nonlocal total_tables

                total_tables += 1
                __update_progress()

            def __table_callback(table: str) -> None:
                nonlocal copied_tables
                nonlocal acisi_table_name

                copied_tables += 1
                __update_progress()

                if acisi_table_name is None and table.upper() == 'ACISIPOLES':
                    acisi_table_name = table

                self.sqlite_built[str].emit(table)  # type: ignore

            self.created_sqlite_file = conversions.copy_mdb_to_sqlite(self.mdb_file,
                                                                      self.sqlite_file,
                                                                      table_count_callback=__table_count_callback,
                                                                      table_callback=__table_callback) and os.path.isfile(self.sqlite_file)

            if self.created_sqlite_file:
                sqlite: sqlite3.Connection
                with sqlite3.connect(self.sqlite_file) as sqlite:
                    cursor: sqlite3.Cursor = sqlite.cursor()

                    index_definition: str
                    for index_definition in self.index_definitions:
                        cursor.execute(index_definition)

                    if acisi_table_name is not None:
                        cursor.execute('INSERT OR IGNORE INTO tblPolesInArea (UniqueClientID, MapX, MapY, Latitude, Longitude, PoleOwner, PoleGUID)\n'
                                       f"SELECT ClientID, MapX, MapY, Lat, Lon, PoleOwner, USSID FROM {acisi_table_name}")

                if os.path.isdir(self.project_path) and os.path.isfile(self.project_file):
                    os.remove(self.project_file)

        return not any(self.validation_messages)

    @step
    @abstractmethod
    def _validate_project_path(self) -> bool:
        try:
            if not os.path.isdir(self.project_path):
                os.makedirs(self.project_path, exist_ok=True)
        except IOError:
            pass

        if not os.path.isdir(self.project_path):
            self.validation_messages.append('Could not create the project folder.')

        return not any(self.validation_messages)

    @step
    @abstractmethod
    def _prepare_vector_layers(self) -> bool:
        self.vectors = {}

        prev_progress: float = self._progress
        step_size: float = self.step_size / len(self.layer_data)
        i: int = 0
        layer_name: str
        for layer_name in self.layer_data:
            def _prepare_vector_layer() -> None:
                self.vectors[layer_name] = self.vector_type(self.created_sqlite_file or self.created_project_file,
                                                            path=self.db_path,
                                                            current_circuit=self.project_name,
                                                            layer_name=layer_name)

            self.yield_until_ran_later(_prepare_vector_layer, attempts=-1)

            if self.vectors[layer_name] is None:
                self.validation_messages.append(f"Layer {layer_name} could not be created.")
            else:
                i += 1
                self._progress = prev_progress + i * step_size
                self.vector_layer_prepared[str].emit(layer_name)  # type: ignore

        return not any(self.validation_messages)

    @step
    @abstractmethod
    def _prepare_vector_layer_joins(self) -> bool:
        if self.created_sqlite_file or self.created_project_file:
            empty_list: List[List[Any]] = []
            empty_dict: Dict[str, Any] = {}

            prev_progress: float = self._progress
            step_size: float = self.step_size / len(self.vectors)
            i: int = 0
            layer_name: str
            vector_object: TVector
            for layer_name, vector_object in self.vectors.items():
                joins: List[List[Any]] = self.layer_data.get(layer_name, empty_list)

                join: List[Any]
                for join in joins:
                    self_field: str = join[0]
                    other_vector: TVector = self.vectors[join[1]]
                    other_field: Optional[str] = join[2] if len(join) > 2 else None
                    kwargs: Dict[str, Any] = join[3] if len(join) > 3 else empty_dict

                    self.yield_until_ran_later(lambda: vector_object.join(self_field, other_vector, other_field, **kwargs), attempts=-1)
                i += 1
                self._progress = prev_progress + i * step_size

        return not any(self.validation_messages)

    @step
    @abstractmethod
    async def _handle_special_layers(self) -> bool:
        step_size: float = self.step_size * 3
        prev_progress: float = self._progress

        @QtCore.pyqtSlot(float, name='on_executor_progressChanged')
        def __on_progress_changed(progress: float) -> None:
            self._progress = prev_progress + step_size * progress

        executor: TrcServiceExecutor = TrcServiceExecutor(self,
                                                          services=[self._create_spatialite_database,
                                                                    self._download_aerial,
                                                                    self._process_background_gdb],
                                                          total_worker_services=3)

        executor.progress_changed.connect(__on_progress_changed)

        await executor
        self._progress += self.step_size
        return not any(self.validation_messages)

    @step
    @abstractmethod
    def _create_spatialite_database(self, service: protocols.Service[None]) -> None:
        try:
            if self.spatialite_file is None:
                return

            self.spatialite_building.emit()

            if os.path.isfile(self.spatialite_file):
                self.spatialite_build_skipped.emit()
            else:
                step_size: float = 1 / len(self.spatialite_definitions)
                name: str
                spatialite_definition: str
                for name, spatialite_definition in self.spatialite_definitions.items():
                    if self._create_spatialite_table(self.spatialite_file, self.sqlite_file, name, spatialite_definition):
                        self.created_spatialite_file = True
                        self.spatialite_built[str].emit(name)  # type: ignore
                        service._progress += step_size
                    else:
                        with self._lock.synchronized(timeout=1_000_000, fail_on_timeout=True):
                            self.validation_messages.append(f"An error occurred while generating map layer {name}.")

                self.spatialite_built.emit()
        finally:
            service._progress = 1.0

    def _create_spatialite_table(self, spatialite_file: str, sqlite_file: str, table_name: str, sql_query: str) -> bool:
        return ogr2ogr.main([
            '-update',
            '-overwrite',
            '-f', 'SQLite', spatialite_file, sqlite_file,
            '-dsco', 'SPATIALITE=YES',
            '-lco', 'LAUNDER=NO',
            '-nln', table_name,
            '-nlt', 'POINT',
            '-s_srs', 'EPSG:4326',
            '-t_srs', 'EPSG:4326',
            '-sql', sql_query
        ])

    @step
    @abstractmethod
    def _download_aerial(self, service: protocols.Service[None]) -> None:
        try:
            if self.aerial_file is None:
                self.aerial_layer_download_skipped.emit()
                return

            self.aerial = first(core.QgsProject.instance().mapLayersByName('Aerial'))

            if self.aerial is None:
                if not os.path.isfile(self.aerial_file) and os.path.isfile(self.remote_aerial_file):
                    self.aerial_layer_downloading.emit()
                    shutil.copy(self.remote_aerial_file, self.aerial_file)
                    self.aerial_layer_downloaded.emit()
                else:
                    self.aerial_layer_download_skipped.emit()

                if os.path.isfile(self.aerial_file):
                    def __attach_aerial() -> None:
                        self.aerial = utils.iface.addRasterLayer(self.aerial_file)
                        self.aerial.setName('Aerial')
                        self.aerial.loadNamedStyle('aerial_style.qml')

                    self.yield_until_ran_later(__attach_aerial, attempts=-1)
            else:
                self.aerial_layer_download_skipped.emit()
        finally:
            service._progress = 1.0

    @step
    @abstractmethod
    def _process_background_gdb(self, service: protocols.Service[None]) -> None:
        ...

    @step
    @abstractmethod
    def _prepare_pole_layers(self) -> bool:
        name: str
        for name in self.spatialite_definitions:
            layer: TVector = None

            def _prepare_pole_layer() -> None:
                nonlocal layer
                layer = self.vector_type(self.created_spatialite_file or self.created_project_file,
                                         path=self.project_path,
                                         current_circuit=self.project_name,
                                         base_name=name,
                                         layer_name=name)
            self.yield_until_ran_later(_prepare_pole_layer, attempts=-1)

            if name.lower() == self.template_project_pole_layer:
                self.poles = layer
            else:
                self.vectors[name] = layer

            if layer.qgs_layer is None:
                self.validation_messages.append(f"Cound not create {name} layer.")
            else:
                self.pole_layer_prepared[str].emit(name)  # type: ignore

        return not any(self.validation_messages)

    @step
    @abstractmethod
    def _prepare_feeder_layers(self) -> bool:
        self.working_primaries, self.working_secondaries, self.primaries, self.secondaries, self.substations = self.feeders

        if self.working_primaries is None or self.working_primaries.qgs_layer is None:
            self.validation_messages.append('Could not create working primaries layer.')
        else:
            self.yield_until_ran_later(lambda: self.working_primaries.qgs_layer.setName('Working Primaries'), attempts=-1)
            self.feeder_layer_prepared[str].emit('Working Primaries')  # type: ignore

        if self.working_secondaries is None or self.working_secondaries.qgs_layer is None:
            self.validation_messages.append('Could not create working secondaries layer.')
        else:
            self.yield_until_ran_later(lambda: self.working_secondaries.qgs_layer.setName('Working Secondaries'), attempts=-1)
            self.feeder_layer_prepared[str].emit('Working Secondaries')  # type: ignore

        return not any(self.validation_messages)

    @step
    @abstractmethod
    def _normalize_layer_positions(self) -> bool:
        Debug.pause()
        layer_tree_root: core.QgsLayerTreeGroup = core.QgsProject.instance().layerTreeRoot()
        base_group: core.QgsLayerTreeGroup = layer_tree_root.findGroup('Base Layers')
        parent_group: core.QgsLayerTreeGroup = layer_tree_root.findGroup('Overview')

        if base_group is None:
            def _add_base_group() -> None:
                nonlocal base_group
                base_group = layer_tree_root.addGroup('Base Layers')

            self.yield_until_ran_later(_add_base_group, attempts=-1)

        if parent_group is None:
            def _add_parent_group() -> None:
                nonlocal parent_group
                parent_group = base_group.addGroup('Overview')

            self.yield_until_ran_later(_add_parent_group, attempts=-1)

        group: str
        layers: List[str]
        for group, layers in self.group_data.items():
            if parent_group.findGroup(group) is None:
                self.yield_until_ran_later(lambda: parent_group.addGroup(group), attempts=-1)

            for layer in layers:
                self.yield_until_ran_later(lambda: try_or_get(lambda: self.vectors[layer].add_to_group(group), None), attempts=-1)
                self.layer_position_normalized[str].emit(layer)  # type: ignore

            self.yield_until_ran_later(lambda: parent_group.findGroup(group).setExpanded(False), attempts=-1)
            self.layer_position_normalized[str].emit(group)  # type: ignore

        all_feeders: core.QgsLayerTreeGroup = layer_tree_root.findGroup('All Feeders')
        self.yield_until_ran_later(lambda: layer_tree_root.insertChildNode(0, core.QgsLayerTreeGroup('All Feeders')), attempts=-1)

        if self.primaries is not None:
            self.yield_until_ran_later(lambda: try_or_get(lambda: self.primaries.add_to_group('All Feeders'), None), attempts=-1)
            self.layer_position_normalized[str].emit(self.primaries.base_name)  # type: ignore

        if self.secondaries is not None:
            self.yield_until_ran_later(lambda: try_or_get(lambda: self.secondaries.add_to_group('All Feeders'), None), attempts=-1)
            self.layer_position_normalized[str].emit(self.secondaries.base_name)  # type: ignore

        if self.substations is not None:
            self.yield_until_ran_later(lambda: try_or_get(lambda: self.substations.add_to_group(index=0), None), attempts=-1)
            self.layer_position_normalized[str].emit(self.substations.base_name)  # type: ignore

        if all_feeders is not None:
            self.yield_until_ran_later(lambda: layer_tree_root.takeChild(all_feeders), attempts=-1)

        self.layer_position_normalized[str].emit('All Feeders')  # type: ignore
        working_feeders: core.QgsLayerTreeGroup = layer_tree_root.findGroup('Working Feeders')
        self.yield_until_ran_later(lambda: layer_tree_root.insertChildNode(0, core.QgsLayerTreeGroup('Working Feeders')), attempts=-1)

        if self.working_primaries is not None:
            self.yield_until_ran_later(lambda: try_or_get(lambda: self.working_primaries.add_to_group('Working Feeders'), None), attempts=-1)
            self.layer_position_normalized[str].emit(self.working_primaries.base_name)  # type: ignore

        if self.working_secondaries is not None:
            self.yield_until_ran_later(lambda: try_or_get(lambda: self.working_secondaries.add_to_group('Working Feeders'), None), attempts=-1)
            self.layer_position_normalized[str].emit(self.working_secondaries.base_name)  # type: ignore

        if working_feeders is not None:
            self.yield_until_ran_later(lambda: layer_tree_root.takeChild(working_feeders), attempts=-1)

        self.layer_position_normalized[str].emit('Working Feeders')  # type: ignore

        def _normalize_poles() -> None:
            self.poles.add_to_group(index=0)
            self.poles.select()

        self.yield_until_ran_later(_normalize_poles, attempts=-1)
        self.layer_position_normalized[str].emit(self.poles.base_name)  # type: ignore

        child_base_group: core.QgsLayerTreeGroup = parent_group.findGroup('Base Layers')

        def _expand_child_groups() -> None:
            if child_base_group is not None:
                child_base_group.setExpanded(False)
            parent_group.setExpanded(False)
            base_group.setExpanded(False)

        self.yield_until_ran_later(_expand_child_groups, attempts=-1)
        self.layer_position_normalized[str].emit('Base Layers')  # type: ignore

        if self.aerial is not None:
            temp_aerial = layer_tree_root.findLayer(self.aerial)
            self.yield_until_ran_later(lambda: layer_tree_root.insertLayer(len(layer_tree_root.children()) - 1, self.aerial), attempts=-1)

            if temp_aerial is not None:
                self.yield_until_ran_later(lambda: layer_tree_root.removeChildNode(temp_aerial), attempts=-1)

            self.yield_until_ran_later(lambda: base_group.removeLayer(self.aerial), attempts=-1)
            self.layer_position_normalized[str].emit(self.aerial.name())  # type: ignore

        return not any(self.validation_messages)

    @step
    @abstractmethod
    def _load_layer_styles(self) -> bool:
        return not any(self.validation_messages)

    @step
    @abstractmethod
    def _load_pole_editor_script(self) -> bool:
        return not any(self.validation_messages)

    @step
    @abstractmethod
    def _update_extent(self) -> bool:
        def __update_extent() -> None:
            self.poles.select_all()
            self.poles.take_focus(True)
            self.canvas.zoomScale(self.canvas.scale() + 500)
            self.canvas.refreshAllLayers()

        self.yield_until_ran_later(__update_extent, attempts=-1)

        return not any(self.validation_messages)

    @step
    @abstractmethod
    def _finalize_project(self) -> bool:
        def __finalize_project() -> None:
            self.project.write()
            utils.iface.addProject(self.project_file)

        self.yield_until_ran_later(__finalize_project, attempts=-1)

        return not any(self.validation_messages)

