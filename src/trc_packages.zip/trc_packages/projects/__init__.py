"""
Provides a set of services that can be shared between projects for uploading, downloading, and authenticating against WFS and SPIDAmin.
"""
import trc_packages

from trc_packages.projects._login_result import LoginResult as LoginResult

from trc_packages.projects._login_service import LoginService as LoginService

from trc_packages.projects._project_loader_service import (ProjectLoaderService as ProjectLoaderService,
                                                           ProjectLayerLoader as ProjectLayerLoader,
                                                           BoundLayer as BoundLayer,
                                                           BoundlessLayer as BoundlessLayer)

if trc_packages.QGIS_EXISTS:
    from trc_packages.projects._mdb_project_loader_service_abc import MdbProjectLoaderServiceABC as MdbProjectLoaderServiceABC

