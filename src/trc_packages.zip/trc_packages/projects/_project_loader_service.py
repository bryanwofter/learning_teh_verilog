from PyQt5 import QtCore
from trc_packages.asynclib import TrcService, step, total_steps, protocols, TrcServiceExecutor
from trc_packages.core.data import XsdModel
from trc_packages.core import chunk
from trc_packages.core.ui import Synchro
from trc_packages.debugging import Debug
from trc_packages.ogr2ogr_tools import ogr2ogr as ogr2ogr
from typing import Callable, Dict, List, NamedTuple, Optional, Union, overload
from xml import etree
import os
import shutil
import sqlite3
import requests
BoundLayer = NamedTuple('BoundLayer', [('layer', str), ('field', str), ('value', str)])
BoundlessLayer = NamedTuple('BoundlessLayer', [('layer', str), ('uses_project_guid', bool), ('filter_', str)])


class ProjectLoaderService(TrcService[bool]):
    """
    Handles the loading logic for ACISI projects from WFS.
    """

    db_path_check_started: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='dbPathCheckStarted')
    db_path_check_succeeded: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='dbPathCheckSucceeded')
    db_path_check_failed: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='dbPathCheckFailed')
    copy_template_db_started: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='copyTemplateDbStarted')
    copy_template_db_skipped: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='copyTemplateDbSkipped')
    copy_template_db_succeeded: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='copyTemplateDbSucceeded')
    copy_template_db_failed: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='copyTemplateDbFailed')
    layer_creation_started: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='layerCreationStarted')
    layer_creation_skipped: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='layerCreationSkipped')
    layer_created: QtCore.pyqtSignal = QtCore.pyqtSignal([], [str], name='layerCreated', arguments=['name'])  # type: ignore
    layer_failed: QtCore.pyqtSignal = QtCore.pyqtSignal([], [str], name='layerFailed', arguments=['name'])  # type: ignore
    layer_creation_succeeded: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='layerCreationSucceeded')
    layer_creation_failed: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='layerCreationFailed')

    base_type: str = None
    project_guid: str = None
    project_name: str = None
    base_url: str = None
    db_path: str = None
    xml_path: str = None
    validation_messages: List[str] = None
    layers: List[Union[str, BoundLayer, BoundlessLayer]] = None
    project_builder: Optional[Callable[['ProjectLoaderService'], bool]] = None
    step_size: float = None
    mrisa_user: str = None
    mrisa_pass: str = None
    template_db_name: str = None
    temp_file_name: str = None
    user_name: str = None
    company_name: str = None
    project_id: str = None
    total_steps: int = None
    redownload_data: bool = False
    __sync: Synchro = None

    def __init__(self, base_type: str, layers: List[Union[str, BoundLayer, BoundlessLayer]], base_url: str, db_path: str, xml_path: str,
                 mrisa_user: str, mrisa_pass: str, template_db_name: str=None, temp_file_name: str=None, project_builder: Optional[Callable[['ProjectLoaderService'], None]]=None,
                 parent: Optional[QtCore.QObject]=None, *,
                 project_guid: Optional[str]=None, project_name: Optional[str]=None, project_id: Optional[str]=None, company_name: Optional[str]=None, user_name: Optional[str]=None) -> None:
        super().__init__(parent=parent)
        self.layers = layers
        self.base_type = base_type
        self.base_url = base_url
        self.db_path = db_path
        self.xml_path = xml_path
        self.project_builder = project_builder
        self.mrisa_user = mrisa_user
        self.mrisa_pass = mrisa_pass
        self.template_db_name = template_db_name
        self.temp_file_name = temp_file_name or 'temp'
        self.validation_messages = []
        self.project_guid = project_guid
        self.project_name = project_name
        self.project_id = project_id
        self.company_name = company_name
        self.user_name = user_name
        self.total_steps = total_steps(type(self))
        self.__sync = Synchro()

        if self.project_builder is not None:
            self.total_steps += 1

        self.step_size = 1 / self.total_steps

    async def _run_async(self) -> bool:
        """Loads the data for the project from the server."""
        self._progress = 0.0
        self.validation_messages.clear()

        if not self._validate_parameters():
            return False

        if not self._ensure_db_path_exists():
            return False

        if self._copy_template_db():
            self._progress += self.step_size
        else:
            return False

        if not await self._make_project_layers():
            return False

        if self.project_builder is not None:
            if not self.project_builder(self):
                return False
        self._progress = 1.0
        return True

    @step
    def _validate_parameters(self) -> bool:
        if self.project_guid is None:
            self.validation_messages.append('Project GUID is required.')
        if self.project_name is None:
            self.validation_messages.append('Project name is required.')
        if self.project_id is None:
            self.validation_messages.append('Project ID is required.')
        if self.user_name is None:
            self.validation_messages.append('User name is required.')
        if self.company_name is None:
            self.validation_messages.append('Company name is required.')
        if self.db_path is None:
            self.validation_messages.append('DB path is required.')
        if self.xml_path is None:
            self.validation_messages.append('XML path is required.')
        if self.layers is None or not any(self.layers):
            self.validation_messages.append('At least 1 layer must be supplied.')
        if self.base_type is None:
            self.validation_messages.append('A base type is required.')
        if self.mrisa_user is None:
            self.validation_messages.append('A MRISA user is required.')
        if self.mrisa_pass is None:
            self.validation_messages.append('A MRISA pass is required.')

        return not any(self.validation_messages)

    @step
    def _ensure_db_path_exists(self) -> bool:
        self.db_path_check_started.emit()
        if not os.path.exists(self.db_path):
            os.mkdir(self.db_path)
            if not os.path.isdir(self.db_path):
                self.validation_messages.append('Could not create the DB storage location.')
        if any(self.validation_messages):
            self.db_path_check_failed.emit()
        else:
            self.db_path_check_succeeded.emit()
        return not any(self.validation_messages)

    @step
    def _copy_template_db(self) -> bool:
        """Copies the template database if one exists."""
        if self.template_db_name is None:
            self.copy_template_db_skipped.emit()
        else:
            self.copy_template_db_started.emit()
            shutil.copy2(os.path.join(self.db_path, f"{self.template_db_name}.sqlite"), os.path.join(self.db_path, f"{self.project_id}.sqlite"))
            if not os.path.isfile(os.path.join(self.db_path, f"{self.project_id}.sqlite")):
                self.validation_messages.append('Could not create DB from template.')

        if any(self.validation_messages):
            self.copy_template_db_failed.emit()
        else:
            self.copy_template_db_succeeded.emit()
        return not any(self.validation_messages)

    @step
    async def _make_project_layers(self) -> bool:
        """Builds all of the project layers."""
        if os.path.isfile(os.path.join(self.db_path, f"{self.project_id}.sqlite")) and not self.redownload_data:
            self.layer_creation_skipped.emit()
            self._progress += self.step_size
            return True

        self.layer_creation_started.emit()
        progress_increment: float = self.step_size / len(self.layers) / 8

        loader: ProjectLayerLoader = ProjectLayerLoader(parent=self)
        services: List[Callable[[protocols.Service[None]], None]] = [loader.make_project_layer_chunk_callable(progress_increment, l) for l in chunk(self.layers, 1)]

        executor: TrcServiceExecutor = TrcServiceExecutor(parent=self, services=services, total_worker_services=8)

        await executor

        if any(self.validation_messages):
            self.layer_creation_failed.emit()
        else:
            self.layer_creation_succeeded.emit()
        return not any(self.validation_messages)


class ProjectLayerLoader(QtCore.QObject):
    has_loader_parent: bool = False
    project_guid: str = None
    base_type: str = None
    base_url: str = None
    mrisa_user: str = None
    mrisa_pass: str = None
    redownload_data: str = None
    project_id: str = None
    db_path: str = None
    temp_file_name: str = None
    xml_path: str = None
    validation_messages: List[str] = None
    loader: Optional['ProjectLoaderService'] = None
    __sync: Synchro = None

    @overload
    def __init__(self, parent: 'ProjectLoaderService') -> None:
        ...

    @overload
    def __init__(self, parent: Optional[QtCore.QObject]=None, *, project_guid: str, base_type: str, base_url: str, mrisa_user: str,
                 mrisa_pass: str, redownload_data: bool, project_id: str, db_path: str, temp_file_name: str, xml_path: str) -> None:
        ...

    def __init__(self, parent: Union['ProjectLoaderService', Optional[QtCore.QObject]]=None, *, project_guid: str=None, base_type: str=None,
                 base_url: str=None, mrisa_user: str=None, mrisa_pass: str=None, redownload_data: bool=None, project_id: str=None,
                 db_path: str=None, temp_file_name: str=None, xml_path: str=None) -> None:
        super().__init__(parent)
        self.has_loader_parent = isinstance(parent, ProjectLoaderService)
        if self.has_loader_parent:
            self.loader = parent
            project_guid = parent.project_guid
            base_type = parent.base_type
            base_url = parent.base_url
            mrisa_user = parent.mrisa_user
            mrisa_pass = parent.mrisa_pass
            redownload_data = parent.redownload_data
            project_id = parent.project_id
            db_path = parent.db_path
            temp_file_name = parent.temp_file_name
            xml_path = parent.xml_path
            self.validation_messages = parent.validation_messages

        self.project_guid = project_guid
        self.base_type = base_type
        self.base_url = base_url
        self.mrisa_user = mrisa_user
        self.mrisa_pass = mrisa_pass
        self.redownload_data = redownload_data
        self.project_id = project_id
        self.db_path = db_path
        self.temp_file_name = temp_file_name
        self.xml_path = xml_path
        self.__sync = Synchro()
        self.validation_messages = self.validation_messages or []

    def make_project_layer_chunk_callable(self, progress_increment: float, layers: List[Union[str, BoundLayer, BoundlessLayer]]) -> Callable[[protocols.Service[None]], None]:
        """
        Produces a callable that represents a service function with the given default arguments.
        :param progress_increment: The amount of progress a single pass produces.
        :param layers: The layers that have been chunked out for independent execution.
        """
        return lambda s: self.make_project_layer_chunk(s, progress_increment, layers)

    def make_project_layer_chunk(self, service: protocols.Service[None], progress_increment: float, layers: List[Union[str, BoundLayer, BoundlessLayer]]) -> None:
        """
        Creates project layers using a chunk of the total layers.
        :param service: The service that is executing this chunk.
        :param progress_increment: The amount of progress a single pass produces.
        :param layers: The layers that have been chunked out for independent execution.
        """
        layer: Union[str, BoundLayer, BoundlessLayer] = None
        try:
            for layer in layers:
                filter_: str

                if isinstance(layer, str):
                    filter_ = f"CQL_FILTER=projectGUID%3d%27{self.project_guid}%27"
                elif isinstance(layer, BoundLayer):
                    filter_ = f"CQL_FILTER={layer.field}%3d%27{layer.value}%27"
                    layer = layer.layer
                elif isinstance(layer, BoundlessLayer):
                    if layer.uses_project_guid:
                        filter_ = f"CQL_FILTER=projectGUID%3d%27{self.project_guid}%27"
                    elif layer.filter_ is None:
                        filter_ = None
                    else:
                        filter_ = f"CQL_FILTER={layer.filter_}"
                    layer = layer.layer
                else:
                    continue

                if service is not None:
                    service.setObjectName(layer)

                type_name: str = f"{self.base_type}:{layer}"
                url_base: str = '&'.join(filter(lambda v: v, [self.base_url.format(f"{self.mrisa_user}:{self.mrisa_pass}@"),
                                                              f"typeNames={type_name}",
                                                              f"typeName={type_name}",  # Needed to support describeFeatureType
                                                              filter_]))

                if self._perform_download(layer, url_base, 100_000, progress_increment, self._populate_table_from_xml):
                    if self.has_loader_parent:
                        self.loader.layer_created.emit()
                        self.loader.layer_created[str].emit(layer)  # type: ignore
                    elif self.has_loader_parent:
                        self.loader.layer_failed.emit()
                        self.loader.layer_failed[str].emit(layer)  # type: ignore
        except FileNotFoundError as e:
            if layer is not None:
                with self.__sync.synchronized(fail_on_timeout=False, timeout=60_000_000) as locked:
                    if locked:
                        self.validation_messages.append(f"Layer {layer} could not be downloaded from the server.")
            else:
                raise e

    def _perform_download(self, layer: str, url: str, count: int, progress_increment: float, callback: Callable[[str, str], bool]) -> bool:
        """
        Executes a repeated request for the given layer against the WFS server.
        :param layer: The layer that is being pulled from WFS.
        :param url: The URL of the WFS server request.
        :param progress_increment: The amount of progress this request represents.
        :param callback: The function used to process the layer once its been pulled from the server.
        """
        namespaces: Dict[str] = {'wfs': 'http://www.opengis.net/wfs/2.0'}
        download_url: str = '&'.join([url, 'request=GetFeature'])
        structure_url: str = '&'.join([url.replace('version=2.0.0', 'version=1.0.0'), 'request=describeFeatureType'])
        number_found: int = None
        number_paged: int = 0
        finished: bool = False
        first: bool = not self.redownload_data
        loop: int = 1

        def __perform_download(ignored: str, xml: str) -> bool:
            nonlocal number_found
            nonlocal number_paged
            nonlocal finished
            nonlocal loop
            tree: etree.Element = etree.ElementTree.fromstring(xml)

            if number_found is None:
                number_found = int(tree.attrib.get('numberReturned', 0))

            size: int = len(tree.findall('wfs:member', namespaces))

            finished = size != count

            number_paged += size
            loop += 1

            return callback(layer, xml)

        while self._perform_request(layer, '&'.join([download_url, f"startIndex={number_paged}", f"count={count}"]), 0, __perform_download):
            if first:
                # Perform the request of the data structure.
                if self._perform_request(layer, structure_url, 0, self._create_table_from_xml):
                    first = False
                else:
                    return False

            if number_paged >= number_found or finished:
                if self.has_loader_parent:
                    self.loader._progress += progress_increment
                return True
        return False

    def _perform_request(self, layer: str, url: str, progress_increment: float, callback: Callable[[str, str], bool]) -> bool:
        """
        Executes a request for the given layer against the WFS server.
        :param layer: The layer that is being pulled from WFS.
        :param url: The URL of the WFS server request.
        :param progress_increment: The amount of progress this request represents.
        :param callback: The function used to process the layer once its been pulled from the server.
        """
        result: requests.Response = requests.get(url, auth=requests.auth.HTTPBasicAuth(self.mrisa_user, self.mrisa_pass))
        result_text: str = result.text
        request_successful: bool = result.status_code < 400
        success: bool = False

        if request_successful:
            success = callback(layer, result_text)
            if success:
                if self.has_loader_parent:
                    self.loader._progress += progress_increment
        else:
            with self.__sync.synchronized(fail_on_timeout=False, timeout=60_000_000) as locked:
                if locked:
                    self.validation_messages.append(f"Layer {layer} could not be retrieved. Reason: {result.text}")

        return success

    def _create_table_from_xml(self, layer: str, xml: str) -> bool:
        """
        Creates the table within the database using the structure defined by the given XML document.
        :param layer: The name of the layer to create.
        :param xml: The XML defining the structure of the layer.
        """
        xsd_model: XsdModel = XsdModel(xml)
        if xsd_model.model is None:
            return False
        layer = layer.lower()
        xsd_model.model.name = f"{layer}_working"

        with self.__sync.synchronized(timeout=60_000_000_000, fail_on_timeout=True):
            with sqlite3.connect(os.path.join(self.db_path, f"{self.project_id}.sqlite")) as sqlite:  # type: sqlite3.Connection
                cursor: sqlite3.Cursor = sqlite.cursor()
                cursor.row_factory = sqlite3.Row
                existing_fields: List[sqlite3.Row] = [r for r in cursor.execute(f"PRAGMA table_info({layer})")]

                for existing_field in existing_fields:  # type: sqlite3.Row
                    if existing_field['name'] not in xsd_model.model.attributes:
                        xsd_model.model.attributes[existing_field['name']] = xsd_model.AttributeModel(name=existing_field['name'],
                                                                                                      type=existing_field['type'],
                                                                                                      nillable=0 == existing_field['notnull'],
                                                                                                      constraint=None)
                    elif xsd_model.model.attributes[existing_field['name']].type != existing_field['type']:
                        xsd_model.model.attributes[existing_field['name']].type = existing_field['type']

                fields: str = ", ".join(r['name'] for r in existing_fields)

                cursor.executescript(xsd_model.model.table_decl())

                if fields:
                    cursor.executescript(f"""INSERT INTO {xsd_model.model.name} ({fields}) SELECT {fields} FROM {layer};""")

                cursor.executescript(f"DROP TABLE IF EXISTS {layer}; ALTER TABLE {xsd_model.model.name} RENAME TO {layer};").close()

        return not any(self.validation_messages)

    def _populate_table_from_xml(self, layer: str, xml: str) -> bool:
        """
        Populates the database with the data of the given XML document.
        :param layer: The name of the layer to populate.
        :param xml: The XML defining the data of the layer.
        """
        temp_file_name: str = f"{layer}_{self.temp_file_name}.gml"
        self._write_temp_file(temp_file_name, xml)
        self._write_layer_from_file(layer, temp_file_name)
        return True

    def _write_temp_file(self, temp_name: str, value: str) -> None:
        """
        Writes the temporary file to the disk.
        :param temp_name: The name of the temporary file.
        :param value: The value to write to the file.
        """
        with open(os.path.join(self.xml_path, temp_name), 'w') as file:
            file.write(value)

    def _write_layer_from_file(self, layer: str, temp_name: str) -> None:
        """
        Writes the temporary file from the disk to the database.
        :param layer: The name of the layer to populate.
        :param temp_name: The name of the temporary file.
        """
        with self.__sync.synchronized(timeout=60_000_000_000, fail_on_timeout=True):
            temp_file: str = os.path.join(self.xml_path, temp_name)
            ogr2ogr.main(['',
                          '--config', 'OGR_SQLITE_CACHE', '256',  # Set the amount of RAM in MB to use for write caching
                          '--config', 'OGR_SQLITE_SYNCHRONOUS', 'OFF',  # Allow writes to be asynchronous
                          '-f', 'SQLite',
                          '-append',
                          '-nln', layer,
                          os.path.join(self.db_path, f"{self.project_id}.sqlite"),
                          temp_file,
                          '-gt', '65536',  # Set the total size of a transaction to 65536 records at a time
                          '-fieldTypeToString', 'DateTime',
                          '-fieldTypeToString', 'Date',
                          '-fieldTypeToString', 'Time'])
            os.remove(temp_file)
            os.remove(f"{os.path.splitext(temp_file)[0]}.gfs")

