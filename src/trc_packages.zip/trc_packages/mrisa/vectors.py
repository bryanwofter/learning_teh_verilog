"""Provides the vector layers for the features of the Make Right application."""

from typing import Any, Dict, Iterable, Optional, Type, TypeVar, NoReturn, overload, Set
from ._configuration import Configuration
from .datamodels import (TypeFeature, RespPartyFeature, ProjectFeature, PoleInAreaFeature,
                         PoleInfoFeature, PoleDescriptorInfoFeature, PictureInfoFeature, LuPoleDescriptorFeature,
                         LuDirectiveVariableValueFeature, LuDirectiveFeature, LuDirectiveGroupFeature, LicCorrectableFeature,
                         FieldVisitTypeFeature, FieldVisitFeature, EmbeddedFileFeature, DirectiveInfoFeature,
                         CrossingTypeFeature, CompanyTypeFeature, CompanyFeature, ClientInfoFeature,
                         AttachmentFeature, ApplicationFeature)
from ._picture_no import PictureNo
from trc_packages.core.features import BasicVectorObject, BasicFeatureObject, feature_sort
from trc_packages.core.safecasts import safe_int
from uuid import UUID

T = TypeVar('T', bound=BasicFeatureObject)

class MakeRightVectorObject(BasicVectorObject[T]):
    """A base for all MRISA Field Make Right vector objects."""

    _path: str = None
    @property  # type: ignore
    def path(self) -> str: return self._path or Configuration().db_path  # type: ignore
    @path.setter
    def path(self, value: str) -> NoReturn: self._path = value
    @path.deleter
    def path(self) -> NoReturn: del self._path

    _current_circuit: str = None
    @property  # type: ignore
    def current_circuit(self) -> str: return self._current_circuit or Configuration().project_name  # type: ignore
    @current_circuit.setter
    def current_circuit(self, value: str) -> NoReturn: self._current_circuit = value
    @current_circuit.deleter
    def current_circuit(self) -> NoReturn: del self._current_circuit

class SpatialPoleInAreaVector(MakeRightVectorObject[BasicFeatureObject]):
    """Represents the Poles_In_Area spatial table."""

    layer_name: str = 'Poles'
    feature_object_type :Type[BasicFeatureObject] = BasicFeatureObject

class TypeVector(MakeRightVectorObject[TypeFeature]):
    """Represents the tblType table."""

    layer_name: str = 'tblType'
    feature_object_type: Type[TypeFeature] = TypeFeature

    def find(self, filter_, *vargs: Any, **kwargs: Any) -> Iterable[TypeFeature]:
        """
        Returns all features from this vector that match the provided filter and are not marked as retired.
        """
        return sorted(filter(lambda v: not v.is_retired, super().find(filter_, *vargs, **kwargs)), key=lambda v: v.code)

    @overload
    def by_company(self, company: CompanyFeature) -> Iterable[TypeFeature]: pass
    @overload
    def by_company(self, company: str) -> Iterable[TypeFeature]: pass
    @overload
    def by_company(self, company: UUID) -> Iterable[TypeFeature]: pass

    def by_company(self, company) -> Iterable[TypeFeature]:
        """
        Returns the features that are associated to the given company.
        :param company: The company to search by.
        """
        empty_set: Set[str] = set()
        attachment_priorities: Dict[str, Set[str]] = Configuration().attachment_priorities
        company: CompanyFeature = company if isinstance(company, CompanyFeature) else CompanyVector().by_guid(company)
        company_type: CompanyTypeFeature = CompanyTypeVector().by_guid(company.company_type_guid)
        results: Iterable[TypeFeature] = self.find("OfficeGUID = {}", company.office_guid)
        return sorted(results, key=lambda t: t.code.upper() in attachment_priorities.get(company_type.company_type.upper(), empty_set), reverse=True)

    @overload
    def by_guid(self, guid: str) -> Optional[TypeFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[TypeFeature]: pass

    def by_guid(self, guid) -> Optional[TypeFeature]:
        """
        Returns the feature that has the given type GUID.
        :param guid: The type GUID to search for.
        """
        return self.find_any("TypeGUID = {}", guid)

class RespPartyVector(MakeRightVectorObject[RespPartyFeature]):
    """Represents the tblRespParty table."""

    layer_name: str = 'tblRespParty'
    feature_object_type: Type[RespPartyFeature]  = RespPartyFeature

    @overload
    def by_company(self, company: CompanyFeature) -> Iterable[RespPartyFeature]: pass
    @overload
    def by_company(self, company: str) -> Iterable[RespPartyFeature]: pass
    @overload
    def by_company(self, company: UUID) -> Iterable[RespPartyFeature]: pass

    def by_company(self, company) -> Iterable[RespPartyFeature]:
        """
        Returns all features that are associated to the given company.
        :param company: The CompanyFeature or its GUID to search for.
        """
        return self.find("CompanyGUID = {}", company.guid if isinstance(company, CompanyFeature) else company)

    @overload
    def by_directive_info(self, directive_info: DirectiveInfoFeature, **kwargs: Any) -> Iterable[RespPartyFeature]: pass
    @overload
    def by_directive_info(self, directive_info: str, **kwargs: Any) -> Iterable[RespPartyFeature]: pass
    @overload
    def by_directive_info(self, directive_info: UUID, **kwargs: Any) -> Iterable[RespPartyFeature]: pass

    def by_directive_info(self, directive_info, **kwargs: Any) -> Iterable[RespPartyFeature]:
        """
        Returns all features that are associated to the given directive info.
        :param directive_info: The DirectiveInfoFeature or its GUID to search for.
        """
        return self.find("DirectiveInfoGUID = {}",
                         directive_info.guid if isinstance(directive_info, DirectiveInfoFeature) else directive_info,
                         **kwargs)

class ProjectVector(MakeRightVectorObject[ProjectFeature]):
    """Represents the tblProjects table."""

    layer_name: str = 'tblProjects'
    feature_object_type: Type[ProjectFeature] = ProjectFeature

    @overload
    def by_guid(self, guid: str) -> Optional[ProjectFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[ProjectFeature]: pass

    def by_guid(self, guid) -> Optional[ProjectFeature]:
        """
        Returns the feature that has the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("ProjectGUID = {}", guid)

class PoleInAreaVector(MakeRightVectorObject[PoleInAreaFeature]):
    """Represents the tblPolesInArea table."""

    layer_name: str = 'tblPolesInArea'
    feature_object_type: Type[PoleInAreaFeature] = PoleInAreaFeature

    @overload
    def by_guid(self, guid: str) -> Optional[PoleInAreaFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[PoleInAreaFeature]: pass

    def by_guid(self, guid) -> Optional[PoleInAreaFeature]:
        """
        Returns the feature that has the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("PoleGUID = {}", guid)

    @overload
    def by_pole(self, pole: BasicFeatureObject) -> Optional[PoleInAreaFeature]: pass
    @overload
    def by_pole(self, pole: str) -> Optional[PoleInAreaFeature]: pass
    @overload
    def by_pole(self, pole: UUID) -> Optional[PoleInAreaFeature]: pass

    def by_pole(self, pole) -> Optional[PoleInAreaFeature]:
        """
        Returns the feature that is associated to the given pole.
        :param pole: The BasicFeatureObject or its associated GUID to search for.
        """
        return self.find_any("PoleGUID = {}", pole['PoleGUID'] if isinstance(pole, BasicFeatureObject) else pole)

class PoleInfoVector(MakeRightVectorObject[PoleInfoFeature]):
    """Represents the tblPoleInfo table."""

    layer_name: str = 'tblPoleInfo'
    feature_object_type: Type[PoleInfoFeature] = PoleInfoFeature

    @property
    def next_seq_no(self) -> Optional[int]:
        return self.qgs_layer.maximumValue(self.qgs_layer.fields().indexOf('PoleSeqNum')) + 1

    @overload
    def by_guid(self, guid: str) -> Optional[PoleInfoFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[PoleInfoFeature]: pass

    def by_guid(self, guid) -> Optional[PoleInfoFeature]:
        """
        Returns the feature that is associated to the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("PoleInfoGUID = {}", guid)

    @overload
    def by_pole(self, pole: BasicFeatureObject) -> Optional[PoleInfoFeature]: pass
    @overload
    def by_pole(self, pole: str) -> Optional[PoleInfoFeature]: pass
    @overload
    def by_pole(self, pole: UUID) -> Optional[PoleInfoFeature]: pass

    def by_pole(self, pole) -> Optional[PoleInfoFeature]:
        """
        Returns the feature that is associated to the given pole.
        :param pole: The BasicFeatureObject of the pole or its GUID to search for.
        """
        return self.find_any("PoleGUID = {}", pole['PoleGUID'] if isinstance(pole, BasicFeatureObject) else pole)

    @overload
    def by_pole_in_area(self, pole_in_area: PoleInAreaFeature) -> Optional[PoleInfoFeature]: pass
    @overload
    def by_pole_in_area(self, pole_in_area: str) -> Optional[PoleInfoFeature]: pass
    @overload
    def by_pole_in_area(self, pole_in_area: UUID) -> Optional[PoleInfoFeature]: pass

    def by_pole_in_area(self, pole_in_area) -> Optional[PoleInfoFeature]:
        """
        Returns the feature that is associated to the given pole in area.
        :param pole_in_area: The PoleInAreaFeature or its GUID to search for.
        """
        return self.find_any("PoleGUID = {}",
                             pole_in_area.pole_guid if isinstance(pole_in_area, PoleInAreaFeature) else pole_in_area)

class PoleDescriptorInfoVector(MakeRightVectorObject[PoleDescriptorInfoFeature]):
    """Represents the tblPoleDescriptorInfo table."""

    layer_name: str = 'tblPoleDescriptorInfo'
    feature_object_type: Type[PoleDescriptorInfoFeature] = PoleDescriptorInfoFeature

    @overload
    def by_pole_info(self, pole_info: PoleInfoFeature) -> Iterable[PoleDescriptorInfoFeature]: pass
    @overload
    def by_pole_info(self, pole_info: str) -> Iterable[PoleDescriptorInfoFeature]: pass
    @overload
    def by_pole_info(self, pole_info: UUID) -> Iterable[PoleDescriptorInfoFeature]: pass

    def by_pole_info(self, pole_info) -> Iterable[PoleDescriptorInfoFeature]:
        """
        Returns all features that are associated to the given pole info.
        :param pole_info: The PoleInfoFeature or its GUID to search for.
        """
        return self.find("PoleInfoGUID = {}", pole_info.guid if isinstance(pole_info, PoleInfoFeature) else pole_info)

class PictureInfoVector(MakeRightVectorObject[PictureInfoFeature]):
    """Represents the tblPictureInfo table."""

    layer_name: str = 'tblPictureInfo'
    feature_object_type: Type[PictureInfoFeature] = PictureInfoFeature

    @overload
    def by_pole_info(self, pole_info: PoleInfoFeature) -> Iterable[PictureInfoFeature]: pass
    @overload
    def by_pole_info(self, pole_info: str) -> Iterable[PictureInfoFeature]: pass
    @overload
    def by_pole_info(self, pole_info: UUID) -> Iterable[PictureInfoFeature]: pass

    def by_pole_info(self, pole_info) -> Iterable[PictureInfoFeature]:
        """
        Returns all features that are associated to the given pole info.
        :param pole_info: The PoleInfoFeature or its GUID to search for.
        """
        return self.find("PoleInfoGUID = {}", pole_info.guid if isinstance(pole_info, PoleInfoFeature) else pole_info)

    @overload
    def by_name(self, name: PictureNo) -> Optional[PictureInfoFeature]: pass
    @overload
    def by_name(self, name: int) -> Optional[PictureInfoFeature]: pass
    @overload
    def by_name(self, name: str) -> Optional[PictureInfoFeature]: pass

    def by_name(self, name) -> Optional[PictureInfoFeature]:
        """
        Returns the feature that is associated to the given name.
        :param name: The name or picture number as either an int or PictureNo to search for.
        """
        return self.find_any("PictureName = {}", str(name if isinstance(name, PictureNo) else PictureNo(name)))

    @overload
    def by_pole_info_and_name(self, pole_info: PoleInfoFeature, name: PictureNo) -> Iterable[PictureInfoFeature]: pass
    @overload
    def by_pole_info_and_name(self, pole_info: str, name: PictureNo) -> Iterable[PictureInfoFeature]: pass
    @overload
    def by_pole_info_and_name(self, pole_info: UUID, name: PictureNo) -> Iterable[PictureInfoFeature]: pass
    @overload
    def by_pole_info_and_name(self, pole_info: PoleInfoFeature, name: int) -> Iterable[PictureInfoFeature]: pass
    @overload
    def by_pole_info_and_name(self, pole_info: str, name: int) -> Iterable[PictureInfoFeature]: pass
    @overload
    def by_pole_info_and_name(self, pole_info: UUID, name: int) -> Iterable[PictureInfoFeature]: pass
    @overload
    def by_pole_info_and_name(self, pole_info: PoleInfoFeature, name: str) -> Iterable[PictureInfoFeature]: pass
    @overload
    def by_pole_info_and_name(self, pole_info: str, name: str) -> Iterable[PictureInfoFeature]: pass
    @overload
    def by_pole_info_and_name(self, pole_info: UUID, name: int) -> Iterable[PictureInfoFeature]: pass  # type: ignore

    def by_pole_info_and_name(self, pole_info, name) -> Iterable[PictureInfoFeature]:
        """
        Returns all features associated to the given pole info and name.
        :param pole_info: The PoleInfoFeature or its GUID to search for.
        :param name: The name or picture number as either an int or PictureNo to search for.
        """
        return self.find("PoleInfoGUID = {} AND PictureName = {}",
                         pole_info.guid if isinstance(pole_info, PoleInfoFeature) else pole_info,
                         str(name if isinstance(name, PictureNo) else PictureNo(name)))

class LuPoleDescriptorVector(MakeRightVectorObject[LuPoleDescriptorFeature]):
    """Represents the tblLuPoleDescriptors table."""

    layer_name: str = 'tblLuPoleDescriptors'
    feature_object_type: Type[LuPoleDescriptorFeature] = LuPoleDescriptorFeature

    def find(self, filter_, *vargs: Any, **kwargs: Any) -> Iterable[LuPoleDescriptorFeature]:
        """Returns all features from this vector that match the provided filter and are not retired."""
        return sorted(filter(lambda v: not v.is_retired, super().find(filter_, *vargs, **kwargs)), key=lambda d: d.sort_order)

    @overload
    def by_guid(self, guid: str) -> Optional[LuPoleDescriptorFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[LuPoleDescriptorFeature]: pass

    def by_guid(self, guid) -> Optional[LuPoleDescriptorFeature]:
        """
        Returns the feature with the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("luPoleDescriptorGUID = {}", guid)

class LuDirectiveVector(MakeRightVectorObject[LuDirectiveFeature]):
    """Represents the tblLuDirectives table."""

    layer_name: str = 'tblLuDirectives'
    feature_object_type: Type[LuDirectiveFeature] = LuDirectiveFeature

    def find(self, filter_, *vargs: Any, **kwargs: Any) -> Iterable[LuDirectiveFeature]:
        """Returns all features from this vector that match the provided filter and are not retired."""
        return sorted(filter(lambda v: not v.is_retired, super().find(filter_, *vargs, **kwargs)), key=lambda d: d.sort_order)

    @overload
    def by_guid(self, guid: str) -> Optional[LuDirectiveFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[LuDirectiveFeature]: pass

    def by_guid(self, guid) -> Optional[LuDirectiveFeature]:
        """
        Returns the feature with the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("luDirectiveGUID = {}", guid)

    @overload
    def by_directive_group(self, directive_group: LuDirectiveGroupFeature) -> Iterable[LuDirectiveFeature]: pass
    @overload
    def by_directive_group(self, directive_group: str) -> Iterable[LuDirectiveFeature]: pass
    @overload
    def by_directive_group(self, directive_group: UUID) -> Iterable[LuDirectiveFeature]: pass

    def by_directive_group(self, directive_group) -> Iterable[LuDirectiveFeature]:
        """
        Returns all features associated to the given directive group.
        :param directive_group: The LuDirectiveGroupFeature or its GUID to search by.
        """
        return self.find("DirectiveGroupGUID = {}",
                         directive_group.guid if isinstance(directive_group, LuDirectiveGroupFeature) else directive_group)

    @overload
    def by_directive_info(self, directive_info: DirectiveInfoFeature) -> Optional[LuDirectiveFeature]: pass
    @overload
    def by_directive_info(self, directive_info: str) -> Optional[LuDirectiveFeature]: pass
    @overload
    def by_directive_info(self, directive_info: UUID) -> Optional[LuDirectiveFeature]: pass

    def by_directive_info(self, directive_info) -> Optional[LuDirectiveFeature]:
        """
        Returns the feature associated with the given directive info.
        :param directive_info: The DirectiveInfoFeature or its GUID to search by.
        """
        return self.find_any("luDirectiveGUID = {}",
                             (directive_info if isinstance(directive_info, DirectiveInfoFeature)
                              else DirectiveInfoVector().by_guid(directive_info, fields=['luDirectiveGUID'])).lu_directive_guid)

class LuDirectiveVariableValueVector(MakeRightVectorObject[LuDirectiveVariableValueFeature]):
    """Represents the tblLuDirectiveVariableValues table."""

    layer_name: str = 'tblLuDirectiveVariableValues'
    feature_object_type: Type[LuDirectiveVariableValueFeature] = LuDirectiveVariableValueFeature

    def find(self, filter_, *vargs: Any, **kwargs: Any) -> Iterable[LuDirectiveVariableValueFeature]:
        """Returns all features from this vector that match the provided filter and are sorted by their sort order."""
        return sorted(super().find(filter_, *vargs, **kwargs), key=lambda v: v.sort_order)

    def by_name(self, name: str) -> Iterable[LuDirectiveVariableValueFeature]:
        """
        Returns all features associated to the given name.
        :param name: The name of the variables to search for.
        """
        return self.find("VariableName = {}", name)

class LuDirectiveGroupVector(MakeRightVectorObject[LuDirectiveGroupFeature]):
    """Represents the tblLuDirectiveGroups table."""

    layer_name: str = 'tblLuDirectiveGroups'
    feature_object_type: Type[LuDirectiveGroupFeature] = LuDirectiveGroupFeature

    def find(self, filter_, *vargs: Any, **kwargs: Any) -> Iterable[LuDirectiveGroupFeature]:
        """Returns all features from this vector that match the provided filter and are sorted by their sort order."""
        return sorted(super().find(filter_, *vargs, **kwargs), key=lambda g: g.sort_order)

    @overload
    def by_guid(self, guid: str) -> Optional[LuDirectiveGroupFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[LuDirectiveGroupFeature]: pass

    def by_guid(self, guid) -> Optional[LuDirectiveGroupFeature]:
        """
        Returns the feature associated to the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("DirectiveGroupGUID = {}", guid)

class LicCorrectableVector(MakeRightVectorObject[LicCorrectableFeature]):
    """Represents the tblLicCorrectable table."""

    layer_name: str = 'tblLicCorrectable'
    feature_object_type: Type[LicCorrectableFeature] = LicCorrectableFeature

    @overload
    def by_pole_info(self, pole_info: PoleInfoFeature) -> Iterable[LicCorrectableFeature]: pass
    @overload
    def by_pole_info(self, pole_info: str) -> Iterable[LicCorrectableFeature]: pass
    @overload
    def by_pole_info(self, pole_info: UUID) -> Iterable[LicCorrectableFeature]: pass

    def by_pole_info(self, pole_info) -> Iterable[LicCorrectableFeature]:
        """
        Returns all features associated to the given pole info.
        :param pole_info: The PoleInfoFeature or its GUID to search for.
        """
        return self.find("PoleInfoGUID = {}", pole_info.guid if isinstance(pole_info, PoleInfoFeature) else pole_info)

    @overload
    def by_company(self, company: CompanyFeature) -> Iterable[LicCorrectableFeature]: pass
    @overload
    def by_company(self, company: str) -> Iterable[LicCorrectableFeature]: pass
    @overload
    def by_company(self, company: UUID) -> Iterable[LicCorrectableFeature]: pass

    def by_company(self, company) -> Iterable[LicCorrectableFeature]:
        """
        Returns all features associated to the given company.
        :param company: The CompanyFeature or its GUID to search for.
        """
        return self.find("CompanyGuid = {}", company.guid if isinstance(company, CompanyFeature) else company)

    @overload
    def by_guid(self, guid: str) -> Optional[LicCorrectableFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[LicCorrectableFeature]: pass

    def by_guid(self, guid) -> Optional[LicCorrectableFeature]:
        """
        Returns the feature associated to the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("LicCorrGUID = {}", guid)

    @overload
    def by_info_guid(self, guid: str) -> Optional[LicCorrectableFeature]: pass
    @overload
    def by_info_guid(self, guid: UUID) -> Optional[LicCorrectableFeature]: pass

    def by_info_guid(self, guid) -> Optional[LicCorrectableFeature]:
        """
        Returns the feature associated to the given info GUID.
        :param guid: The info GUID to search for.
        """
        return self.find_any("LicCorrInfoGUID = {}", guid)

class FieldVisitVector(MakeRightVectorObject[FieldVisitFeature]):
    """Represents the tblFieldVisits table."""

    layer_name: str = 'tblFieldVisits'
    feature_object_type: Type[FieldVisitFeature] = FieldVisitFeature

    @overload
    def by_guid(self, guid: str) -> Optional[FieldVisitFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[FieldVisitFeature]: pass

    def by_guid(self, guid) -> Optional[FieldVisitFeature]:
        """
        Returns the feature associated with the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("FieldVisitGUID = {}", guid)

    @overload
    def by_application(self, application: ApplicationFeature) -> Optional[FieldVisitFeature]: pass
    @overload
    def by_application(self, application: str) -> Optional[FieldVisitFeature]: pass
    @overload
    def by_application(self, application: UUID) -> Optional[FieldVisitFeature]: pass

    def by_application(self, application) -> Optional[FieldVisitFeature]:
        """
        Returns the feature associated with the given application.
        :param application: The application to search by.
        """
        return self.find_any("ApplicationGUID = {}", application.guid if isinstance(application, ApplicationFeature) else application)

class FieldVisitTypeVector(MakeRightVectorObject[FieldVisitTypeFeature]):
    """Represents the tblFieldVisitTypes table."""

    layer_name: str = 'tblFieldVisitTypes'
    feature_object_type: Type[FieldVisitTypeFeature] = FieldVisitTypeFeature

    @overload
    def by_guid(self, guid: str) -> Optional[FieldVisitTypeFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[FieldVisitTypeFeature]: pass

    def by_guid(self, guid) -> Optional[FieldVisitTypeFeature]:
        """
        Returns the feature associated with the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("FieldVisitTypeGUID = {}", guid)

class EmbeddedFileVector(MakeRightVectorObject[EmbeddedFileFeature]):
    """Represents the tblEmbeddedFiles table."""

    layer_name: str = 'tblEmbeddedFiles'
    feature_object_type: Type[EmbeddedFileFeature] = EmbeddedFileFeature

    @overload
    def by_guid(self, guid: str) -> Optional[EmbeddedFileFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[EmbeddedFileFeature]: pass

    def by_guid(self, guid) -> Optional[EmbeddedFileFeature]:
        """
        Returns the feature associated with the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("EmbeddedFileGUID = {}", guid)

class DirectiveInfoVector(MakeRightVectorObject[DirectiveInfoFeature]):
    """Represents the tblDirectiveInfo table."""

    layer_name: str = 'tblDirectiveInfo'
    feature_object_type: Type[DirectiveInfoFeature] = DirectiveInfoFeature

    def find(self, filter_, *vargs: Any, **kwargs: Any) -> Iterable[DirectiveInfoFeature]:
        """Returns all features from this vector that match the provided filter and sorted by their sort order."""
        return sorted(super().find(filter_, *vargs, **kwargs), key=lambda d: d.sort_order)

    @overload
    def by_directive(self, directive: LuDirectiveFeature) -> Iterable[DirectiveInfoFeature]: pass
    @overload
    def by_directive(self, directive: str) -> Iterable[DirectiveInfoFeature]: pass
    @overload
    def by_directive(self, directive: UUID) -> Iterable[DirectiveInfoFeature]: pass

    def by_directive(self, directive) -> Iterable[DirectiveInfoFeature]:
        """
        Returns all features associated to the given directive.
        :param directive: The LuDirectiveFeature or its GUID to search by.
        """
        return self.find("luDirectiveGUID = {}", directive.guid if isinstance(directive, LuDirectiveFeature) else directive)

    @overload
    def by_attachment(self, attachment: AttachmentFeature) -> Iterable[DirectiveInfoFeature]: pass
    @overload
    def by_attachment(self, attachment: str) -> Iterable[DirectiveInfoFeature]: pass
    @overload
    def by_attachment(self, attachment: UUID) -> Iterable[DirectiveInfoFeature]: pass

    def by_attachment(self, attachment) -> Iterable[DirectiveInfoFeature]:
        """
        Returns all features associated to the given attachment.
        :param attachment: The AttachmentFeature or its GUID to search by.
        """
        return self.find("AttachmentInfoGUID = {}",
                         attachment.info_guid if isinstance(attachment, AttachmentFeature) else attachment)

    @overload
    def by_pole_info(self, pole_info: PoleInfoFeature) -> Iterable[DirectiveInfoFeature]: pass
    @overload
    def by_pole_info(self, pole_info: str) -> Iterable[DirectiveInfoFeature]: pass
    @overload
    def by_pole_info(self, pole_info: UUID) -> Iterable[DirectiveInfoFeature]: pass

    def by_pole_info(self, pole_info) -> Iterable[DirectiveInfoFeature]:
        """
        Returns all features associated to the given pole info.
        :param pole_info: The PoleInfoFeature or its GUID to search by.
        """
        attachments: AttachmentVector = AttachmentVector(False, current_circuit=self.current_circuit)
        return self.find("AttachmentInfoGUID IN ({})", [a.info_guid for a in attachments.by_pole_info(pole_info,
                                                                                                      fields=['PoleInfoGUID'])])

    @overload
    def by_guid(self, guid: str, **kwargs: Any) -> Optional[DirectiveInfoFeature]: pass
    @overload
    def by_guid(self, guid: UUID, **kwargs: Any) -> Optional[DirectiveInfoFeature]: pass

    def by_guid(self, guid, **kwargs: Any) -> Optional[DirectiveInfoFeature]:
        """
        Returns the feature associated to  the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("DirectiveInfoGUID = {}", guid, **kwargs)

class CrossingTypeVector(MakeRightVectorObject[CrossingTypeFeature]):
    """Represents the tblCrossingType table."""

    layer_name: str = 'tblCrossingType'
    feature_object_type: Type[CrossingTypeFeature] = CrossingTypeFeature

    def find(self, filter_, *vargs: Any, **kwargs: Any) -> Iterable[CrossingTypeFeature]:
        """Returns all features from this vector that match the provided filter that aren't marked retired and sorted by their sort order."""
        return sorted(filter(lambda v: not v.is_retired, super().find(filter_, *vargs, **kwargs)), key=lambda c: c.sort_order)

    @overload
    def by_guid(self, guid: str) -> Optional[CrossingTypeFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[CrossingTypeFeature]: pass

    def by_guid(self, guid) -> Optional[CrossingTypeFeature]:
        """
        Returns the feature that matches the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("CrossingTypeGUID = {}", guid)

class CompanyTypeVector(MakeRightVectorObject[CompanyTypeFeature]):
    """Represents the tblCompanyType table."""

    layer_name: str = 'tblCompanyType'
    feature_object_type: Type[CompanyTypeFeature] = CompanyTypeFeature

    @overload
    def by_guid(self, guid: str) -> Optional[CompanyTypeFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[CompanyTypeFeature]: pass

    def by_guid(self, guid) -> Optional[CompanyTypeFeature]:
        """
        Returns the feature that matches the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("CompanyTypeGUID = {}", guid)

class CompanyVector(MakeRightVectorObject[CompanyFeature]):
    """Represents the tblCompany table."""

    layer_name: str = 'tblCompany'
    feature_object_type: Type[CompanyFeature] = CompanyFeature

    def find(self, filter_, *vargs: Any, **kwargs: Any) -> Iterable[CompanyFeature]:
        """Returns all features from this vector that match the provided filter and are sorted by their company code."""
        return sorted(super().find(filter_, *vargs, **kwargs), key=lambda c: c.company_code)

    @overload
    def by_guid(self, guid: str) -> Optional[CompanyFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[CompanyFeature]: pass

    def by_guid(self, guid) -> Optional[CompanyFeature]:
        """
        Returns the feature with the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("CompanyGUID = {}", guid)

    @overload
    def by_company_type(self, company_type: CompanyTypeFeature) -> Iterable[CompanyFeature]: pass
    @overload
    def by_company_type(self, company_type: str) -> Iterable[CompanyFeature]: pass
    @overload
    def by_company_type(self, company_type: UUID) -> Iterable[CompanyFeature]: pass

    def by_company_type(self, company_type) -> Iterable[CompanyFeature]:
        """
        Returns all features with the given company type.
        :param company_type: The CompanyTypeFeature or its GUID to search by.
        """
        return self.find("CompanyTypeGUID = {}",
                         company_type.guid if isinstance(company_type, CompanyTypeFeature) else company_type)

    @overload
    def by_pole_info(self, pole_info: PoleInfoFeature) -> Iterable[CompanyFeature]: pass
    @overload
    def by_pole_info(self, pole_info: str) -> Iterable[CompanyFeature]: pass
    @overload
    def by_pole_info(self, pole_info: UUID) -> Iterable[CompanyFeature]: pass

    def by_pole_info(self, pole_info) -> Iterable[CompanyFeature]:
        """
        Returns all features associated with the given pole info.
        :param pole_info: The PoleInfoFeature or its GUID to search by.
        """
        return self.find("CompanyGUID IN ({})",
                         set([a.company_guid for a
                              in AttachmentVector(current_circuit=self.current_circuit).by_pole_info(pole_info,
                                                                                                     fields=['CompanyGUID'])]))

    @overload
    def by_directive_info(self, directive_info: DirectiveInfoFeature) -> Iterable[CompanyFeature]: pass
    @overload
    def by_directive_info(self, directive_info: str) -> Iterable[CompanyFeature]: pass
    @overload
    def by_directive_info(self, directive_info: UUID) -> Iterable[CompanyFeature]: pass

    def by_directive_info(self, directive_info) -> Iterable[CompanyFeature]:
        """
        Returns all features associated with the given directive info.
        :param directive_info: The DirectiveInfoFeature or its GUID to search by.
        """
        return self.find("CompanyGUID IN ({})",
                         set([r.company_guid for r
                              in RespPartyVector(current_circuit=self.current_circuit).by_directive_info(directive_info,
                                                                                                         fields=['CompanyGUID'])]))

class ClientInfoVector(MakeRightVectorObject[ClientInfoFeature]):
    """Represents the tblClientInfo table."""

    layer_name: str = 'tblClientInfo'
    feature_object_type: Type[ClientInfoFeature] = ClientInfoFeature

    @overload
    def by_guid(self, guid: str) -> Optional[ClientInfoFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[ClientInfoFeature]: pass

    def by_guid(self, guid) -> Optional[ClientInfoFeature]:
        """
        Returns the feature with the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("ClientGUID = {}", guid)

class AttachmentVector(MakeRightVectorObject[AttachmentFeature]):
    """Represents the tblAttachments table."""

    layer_name: str = 'tblAttachments'
    feature_object_type: Type[AttachmentFeature] = AttachmentFeature

    @overload
    def by_pole_info(self, pole_info: PoleInfoFeature, **kwargs: Any) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info(self, pole_info: str, **kwargs: Any) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info(self, pole_info: UUID, **kwargs: Any) -> Iterable[AttachmentFeature]: pass

    def by_pole_info(self, pole_info, **kwargs: Any) -> Iterable[AttachmentFeature]:
        """
        Returns all features associated to the given pole info.
        :param pole_info: The PoleInfoFeature or its GUID to search by.
        """
        return self.find("PoleInfoGUID = {}", pole_info.guid if isinstance(pole_info, PoleInfoFeature) else pole_info, **kwargs)

    @overload
    def by_pole_info_and_measure_location(self, pole_info: PoleInfoFeature, measure_location: str, **kwargs: Any) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_measure_location(self, pole_info: str, measure_location: str, **kwargs: Any) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_measure_location(self, pole_info: UUID, measure_location: str, **kwargs: Any) -> Iterable[AttachmentFeature]: pass

    def by_pole_info_and_measure_location(self, pole_info, measure_location: str, **kwargs: Any) -> Iterable[AttachmentFeature]:
        """
        Returns all features associated to the given pole info with the given measure location.
        :param pole_info: The PoleInfoFeature or its GUID to search by.
        :param measure_location: The measure location to search for.
        """
        return self.find("PoleInfoGUID = {} AND MeasureLocation = {}",
                         pole_info.guid if isinstance(pole_info, PoleInfoFeature) else pole_info,
                         measure_location,
                         **kwargs)

    @overload
    def by_pole_info_without_measure_location(self, pole_info: PoleInfoFeature) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_without_measure_location(self, pole_info: str) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_without_measure_location(self, pole_info: UUID) -> Iterable[AttachmentFeature]: pass

    def by_pole_info_without_measure_location(self, pole_info) -> Iterable[AttachmentFeature]:
        """
        Returns all features associated to the given pole info that have no measure location.
        :param pole_info: The PoleInfoFeature or its GUID to search by.
        """
        return self.find("PoleInfoGUID = {} AND MeasureLocation IS NULL",
                         pole_info.guid if isinstance(pole_info, PoleInfoFeature) else pole_info)

    @overload
    def by_pole_info_and_is_critical_power(self, pole_info: PoleInfoFeature) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_is_critical_power(self, pole_info: str) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_is_critical_power(self, pole_info: UUID) -> Iterable[AttachmentFeature]: pass

    def by_pole_info_and_is_critical_power(self, pole_info) -> Iterable[AttachmentFeature]:
        """
        Returns all features associated to the given pole info that qualify as critical power.
        :param pole_info: The PoleInfoFeature or its GUID to search by.
        """
        return self.find("PoleInfoGUID = {} AND CalculationPoint = {} AND IsPwr = {}",
                         pole_info.guid if isinstance(pole_info, PoleInfoFeature) else pole_info, 1, 1)

    @overload
    def by_pole_info_and_power(self, pole_info: PoleInfoFeature, is_power: bool) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_power(self, pole_info: str, is_power: bool) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_power(self, pole_info: UUID, is_power: bool) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_power(self, pole_info: PoleInfoFeature, is_power: int) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_power(self, pole_info: str, is_power: int) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_power(self, pole_info: UUID, is_power: int) -> Iterable[AttachmentFeature]: pass

    def by_pole_info_and_power(self, pole_info, is_power) -> Iterable[AttachmentFeature]:
        """
        Returns all features associated to the given pole info with the given power status.
        :param pole_info: The PoleInfoFeature or its GUID to search by.
        :param is_power: The power status to search for.
        """
        return self.find("PoleInfoGUID = {} AND IsPwr = {}",
                         pole_info.guid if isinstance(pole_info, PoleInfoFeature) else pole_info,
                         1 if is_power else 0)

    @overload
    def by_pole_info_and_type(self, pole_info: PoleInfoFeature, type_: TypeFeature) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_type(self, pole_info: str, type_: TypeFeature) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_type(self, pole_info: UUID, type_: TypeFeature) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_type(self, pole_info: PoleInfoFeature, type_: str) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_type(self, pole_info: str, type_: str) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_type(self, pole_info: UUID, type_: str) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_type(self, pole_info: PoleInfoFeature, type_: UUID) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_type(self, pole_info: str, type_: UUID) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_type(self, pole_info: UUID, type_: UUID) -> Iterable[AttachmentFeature]: pass

    def by_pole_info_and_type(self, pole_info, type_) -> Iterable[AttachmentFeature]:
        """
        Returns all features associated to the given pole info and of the given type.
        :param pole_info: The PoleInfoFeature or its GUID to search by.
        :param type_: The TypeFeature or its GUID to search by.
        """
        return self.find("PoleInfoGUID = {} AND TypeGUID = {}",
                         pole_info.guid if isinstance(pole_info, PoleInfoFeature) else pole_info,
                         type_.guid if isinstance(type_, TypeFeature) else type_)

    @overload
    def by_pole_info_without_type(self, pole_info: PoleInfoFeature) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_without_type(self, pole_info: str) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_without_type(self, pole_info: UUID) -> Iterable[AttachmentFeature]: pass

    def by_pole_info_without_type(self, pole_info) -> Iterable[AttachmentFeature]:
        """
        Returns all features associated to the given pole info that don't have a type.
        :param pole_info: The PoleInfoFeature or its GUID to search by.
        """
        return self.find("PoleInfoGUID = {} AND TypeGUID IS {}",
                         pole_info.guid if isinstance(pole_info, PoleInfoFeature) else pole_info,
                         None)

    @overload
    def by_pole_info_and_company(self, pole_info: PoleInfoFeature, company: CompanyFeature) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_company(self, pole_info: str, company: CompanyFeature) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_company(self, pole_info: UUID, company: CompanyFeature) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_company(self, pole_info: PoleInfoFeature, company: str) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_company(self, pole_info: str, company: str) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_company(self, pole_info: UUID, company: str) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_company(self, pole_info: PoleInfoFeature, company: UUID) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_company(self, pole_info: str, company: UUID) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_and_company(self, pole_info: UUID, company: UUID) -> Iterable[AttachmentFeature]: pass

    def by_pole_info_and_company(self, pole_info, company) -> Iterable[AttachmentFeature]:
        """
        Returns all features associated to the given pole info and company.
        :param pole_info: The PoleInfoFeature or its GUID to search by.
        :param company: The CompanyFeature or its GUID to search by.
        """
        return self.find("PoleInfoGUID = {} AND CompanyGUID = {}",
                         pole_info.guid if isinstance(pole_info, PoleInfoFeature) else pole_info,
                         company.guid if isinstance(company, CompanyFeature) else company)

    @overload
    def by_pole_info_without_company(self, pole_info: PoleInfoFeature) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_without_company(self, pole_info: str) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_pole_info_without_company(self, pole_info: UUID) -> Iterable[AttachmentFeature]: pass

    def by_pole_info_without_company(self, pole_info) -> Iterable[AttachmentFeature]:
        """
        Returns all features associated to the given pole info that don't have a company.
        :param pole_info: The PoleInfoFeature or its GUID to search by.
        """
        return self.find("PoleInfoGUID = {} AND CompanyGUID IS {}",
                         pole_info.guid if isinstance(pole_info, PoleInfoFeature) else pole_info,
                         None)

    @overload
    def by_company(self, company: CompanyFeature) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_company(self, company: str) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_company(self, company: UUID) -> Iterable[AttachmentFeature]: pass

    def by_company(self, company) -> Iterable[AttachmentFeature]:
        """
        Returns all features associated to the given company.
        :param company: The CompanyFeature or its GUID to search by.
        """
        return self.find("CompanyGUID = {}", company.guid if isinstance(company, CompanyFeature) else company)

    @overload
    def by_type(self, type_: TypeFeature) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_type(self, type_: str) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_type(self, type_: UUID) -> Iterable[AttachmentFeature]: pass

    def by_type(self, type_) -> Iterable[AttachmentFeature]:
        """
        Returns all features associated to the given type.
        :param type_: The TypeFeature or its GUID to search by.
        """
        return self.find("TypeGUID = {}", type_.guid if isinstance(type_, TypeFeature) else type_)

    @overload
    def by_crossing_type(self, crossing_type: CrossingTypeFeature) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_crossing_type(self, crossing_type: str) -> Iterable[AttachmentFeature]: pass
    @overload
    def by_crossing_type(self, crossing_type: UUID) -> Iterable[AttachmentFeature]: pass

    def by_crossing_type(self, crossing_type) -> Iterable[AttachmentFeature]:
        """
        Returns all features associated to the given crossing type.
        :param crossing_type: The CrossingTypeFeature or its GUID to search by.
        """
        return self.find("CrossingTypeGUID = {}",
                         crossing_type.guid if isinstance(crossing_type, CrossingTypeFeature) else crossing_type)

    def by_measure_location(self, measure_location: str) -> Iterable[AttachmentFeature]:
        return self.find("MeasureLocation = {}", measure_location)

    @overload
    def by_guid(self, guid: str) -> Optional[AttachmentFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[AttachmentFeature]: pass

    def by_guid(self, guid) -> Optional[AttachmentFeature]:
        """
        Returns the feature with the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("AttachmentGUID = {}", guid)

    @overload
    def by_info_guid(self, guid: str) -> Optional[AttachmentFeature]: pass
    @overload
    def by_info_guid(self, guid: UUID) -> Optional[AttachmentFeature]: pass

    def by_info_guid(self, guid) -> Optional[AttachmentFeature]:
        """
        Returns the feature with the given info GUID.
        :param guid: The info GUID to search for.
        """
        return self.find_any("AttachmentInfoGUID = {}", guid)

class ApplicationVector(MakeRightVectorObject[ApplicationFeature]):
    """Represents the tblApplications table."""

    layer_name: str = 'tblApplications'
    feature_object_type: Type[ApplicationFeature] = ApplicationFeature

    @overload
    def by_guid(self, guid: str) -> Optional[ApplicationFeature]: pass
    @overload
    def by_guid(self, guid: UUID) -> Optional[ApplicationFeature]: pass

    def by_guid(self, guid) -> Optional[ApplicationFeature]:
        """
        Returns the feature with the given GUID.
        :param guid: The GUID to search for.
        """
        return self.find_any("ApplicationGUID = {}", guid)
