import trc_packages

if trc_packages.QGIS_EXISTS:
    from trc_packages.mrisa._circuit_details import CircuitDetails as CircuitDetails

    from trc_packages.mrisa._on_pole_in_area_geometry_changed import on_pole_geometryChanged as on_pole_geometryChanged

    from trc_packages.mrisa._picture_no import PictureNo as PictureNo

    from trc_packages.mrisa._configuration import Configuration as Configuration

    from trc_packages.mrisa import (datamodels as datamodels,
                                    vectors as vectors)

    from trc_packages.mrisa._circuit_resolution_service import CircuitResolutionService as CircuitResolutionService

    from trc_packages.mrisa._mrisa_project_loader_service import MrisaProjectLoaderService as MrisaProjectLoaderService

    from trc_packages.mrisa._project_loader import ProjectLoader as ProjectLoader

