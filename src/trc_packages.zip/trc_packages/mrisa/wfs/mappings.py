from datetime import date
from typing import ClassVar, Set

from trc_packages.mrisa.datamodels import PoleInfoFeature, AttachmentFeature, FieldVisitFeature, DirectiveInfoFeature, \
    PictureInfoFeature, PoleDescriptorInfoFeature, RespPartyFeature

from trc_packages.wfs.mappings import BasicWfsRecord, WfsStringItem, WfsFloatItem, WfsDateItem, WfsIntItem, WfsBoolItem


class MRISAPole(BasicWfsRecord):

    WFS_TABLE_NAME: ClassVar[str] = "MRISAPole"
    WFS_PRIMARY_KEY: ClassVar[str] = "poleInfoGUID"

    poleGUID = WfsStringItem('poleGUID', 'pole_guid')
    poleInfoGUID = WfsStringItem('poleInfoGUID', 'guid')
    fieldVisitGUID = WfsStringItem('fieldVisitGUID', 'field_visit_guid')
    poleOwnerGUID = WfsStringItem('poleOwnerGUID', 'pole_owner_guid')
    DISCode = WfsStringItem('DISCode', 'dis_code')
    NJUNSTicketNumber = WfsStringItem('NJUNSTicketNumber', 'njuns_ticket_no')
    ROW = WfsStringItem('ROW', 'row')
    addressCity = WfsStringItem('addressCity', 'address_city')
    addressNo = WfsStringItem('addressNo', 'address_no')
    addressState = WfsStringItem('addressState', 'address_state')
    addressStreet = WfsStringItem('addressStreet', 'address_street')
    addressZip = WfsStringItem('addressZip', 'address_zip')
    ambTemp = WfsFloatItem('ambTemp', 'ambient_temp')
    applicantPoleNumber = WfsStringItem('applicantPoleNumber', 'applicant_pole_no')
    backSpan = WfsStringItem('backSpan', 'back_span')
    backspanPoleSeqNo = WfsStringItem('backspanPoleSeqNo', 'back_span_pole_seq_no')
    clientMapNumber = WfsStringItem('clientMapNumber', 'client_map_no')
    constructStatus = WfsStringItem('constructStatus', 'construct_status')
    countyTownship = WfsStringItem('countyTownship', 'county_township')
    dateLocate = WfsStringItem('dateLocate', 'date_locate')
    dateOfInspection = WfsDateItem('dateOfInspection', 'date_of_inspection')
    directions = WfsStringItem('directions', 'directions')
    displayStatus = WfsStringItem('displayStatus', 'display_status')
    engineer = WfsStringItem('engineer', 'engineer')
    engrHelper = WfsStringItem('engrHelper', 'engineer_helper')
    eopDistFt = WfsFloatItem('eopDistFt', 'eop_dist_ft')
    eopDistIN = WfsFloatItem('eopDistIN', 'eop_dist_in')
    feeder = WfsStringItem('feeder', 'feeder')
    firstEditDate = WfsDateItem('firstEditDate', 'first_edit_date')
    firstEditUser = WfsStringItem('firstEditUser', 'first_edit_user')
    frontSpan = WfsStringItem('frontSpan', 'front_span')
    frontspanPoleSeqNo = WfsStringItem('frontspanPoleSeqNo', 'front_span_pole_seq_no')
    latitude = WfsFloatItem('latitude', 'latitude')
    loadingCode = WfsStringItem('loadingCode', 'loading_code')
    locateAuthorization = WfsStringItem('locateAuthorization', 'locate_authorization')
    longitude = WfsFloatItem('longitude', 'longitude')
    mapNumber = WfsStringItem('mapNumber', 'map_no')
    mapX = WfsFloatItem('mapX', 'map_x')
    mapY = WfsFloatItem('mapY', 'map_y')
    modifiedDate = WfsDateItem('modifiedDate', 'modified_date')
    modifiedUser = WfsStringItem('modifiedUser', 'modified_user')
    nodeName = WfsStringItem('nodeName', 'node_name')
    notes = WfsStringItem('notes', 'notes')
    poleAngle = WfsStringItem('poleAngle', 'pole_angle')
    poleClass = WfsIntItem('poleClass', 'pole_class')
    poleHeight = WfsIntItem('poleHeight', 'pole_height')
    poleDate = WfsIntItem('poleDate', 'pole_year')
    poleLastUpdate = WfsStringItem('poleLastUpdate', 'pole_last_update')
    poleMaterial = WfsStringItem('poleMaterial', 'pole_material')
    poleOnMap = WfsBoolItem('poleOnMap', 'pole_on_map')
    poleQuality = WfsStringItem('poleQuality', 'pole_quality')
    poleResponsibleParty = WfsStringItem('poleResponsibleParty', 'pole_resp_party')
    poleSeqNum = WfsFloatItem('poleSeqNum', 'pole_seq_no')
    poleTagNumber = WfsStringItem('poleTagNumber', 'pole_tag_no')
    poleType = WfsStringItem('poleType', 'pole_type')
    sideSpan1 = WfsStringItem('sideSpan1', 'side_span1')
    sideSpan2 = WfsStringItem('sideSpan2', 'side_span2')
    sidespanPoleSeqNo1 = WfsStringItem('sidespanPoleSeqNo1', 'side_span_pole_seq_no1')
    sidespanPoleSeqNo2 = WfsStringItem('sidespanPoleSeqNo2', 'side_span_pole_seq_no2')
    speedLimit = WfsStringItem('speedLimit', 'speed_limit')
    structureType = WfsStringItem('structureType', 'structure_type')
    subStation = WfsStringItem('subStation', 'sub_station')
    terrain = WfsStringItem('terrain', 'terrain')
    uniqueClientID = WfsStringItem('uniqueClientID', 'unique_client_id')
    workType = WfsStringItem('workType', 'work_type')

    def __init__(self, pole_info: PoleInfoFeature):
        super().__init__(pole_info)


class MRISAAttachment(BasicWfsRecord):

    WFS_TABLE_NAME: ClassVar[str] = "MRISAAttachment"
    WFS_PRIMARY_KEY: ClassVar[str] = "attachmentGUID"

    attachmentGUID = WfsStringItem('attachmentGUID', 'guid')
    attachmentInfoGUID = WfsStringItem('attachmentInfoGUID', 'info_guid')
    companyGUID = WfsStringItem('companyGUID', 'company_guid')
    crossingTypeGUID = WfsStringItem('crossingTypeGUID', 'crossing_type_guid')
    poleInfoGUID = WfsStringItem('poleInfoGUID', 'pole_info_guid')
    typeGUID = WfsStringItem('typeGUID', 'type_guid')
    MRSequenceNo = WfsIntItem('MRSequenceNo', 'work_sequence_no')
    NESCViolation = WfsBoolItem('NESCViolation', 'nesc_violation')
    NSEW = WfsStringItem('NSEW', 'compass_direction')
    attachLastUpdate = WfsDateItem('attachLastUpdate', 'attach_last_update')
    calculationPoint = WfsBoolItem('calculationPoint', 'calculation_point')
    feet = WfsIntItem('feet', 'feet')
    inches = WfsIntItem('inches', 'inches')
    isPwr = WfsBoolItem('isPwr', 'is_power')
    measureLocation = WfsStringItem('measureLocation', 'measure_location')
    newAttach = WfsStringItem('newAttach', 'new_attach')
    newPOAFeet = WfsIntItem('newPOAFeet', 'new_poa_feet')
    newPOAInches = WfsIntItem('newPOAInches', 'new_poa_inches')
    notes = WfsStringItem('notes', 'notes')
    specialHandle = WfsBoolItem('specialHandle', 'special_handle', False)

    def __init__(self, attachment: AttachmentFeature):
        super().__init__(attachment)


class MRISAFieldVisit(BasicWfsRecord):

    WFS_TABLE_NAME: ClassVar[str] = "MRISAFieldVisit"
    WFS_PRIMARY_KEY: ClassVar[str] = "fieldVisitGUID"

    # TODO - Figure out how to set this without just hard-coding guid
    __FINISHED_FIELDSTATUSGUID = 'EA2DEB61-3154-479B-9091-28BF58B6C3AE'
    applicationGUID = WfsStringItem('applicationGUID', 'application_guid')
    fieldVisitGUID = WfsStringItem('fieldVisitGUID', 'guid')
    fieldVisitTypeGUID = WfsStringItem('fieldVisitTypeGUID', 'field_visit_type_guid')
    stepNo = WfsIntItem('stepNo', 'step_no')

    def __init__(self, field_visit: FieldVisitFeature):
        super().__init__(field_visit)
        self.wfs_values['returnedDate'] = str(date.today()) + "T00:00:00Z"
        self.wfs_values['fieldVisitStatusGUID'] = self.__FINISHED_FIELDSTATUSGUID


class MRISADirective(BasicWfsRecord):
    NULL_VALUES: ClassVar[Set] = {None, "{}", "null", ''}

    WFS_TABLE_NAME: ClassVar[str] = "MRISADirective"
    WFS_PRIMARY_KEY: ClassVar[str] = "directiveInfoGUID"

    attachmentInfoGUID = WfsStringItem('attachmentInfoGUID', 'attachment_info_guid')
    directive = WfsStringItem('directive', 'directive')
    directiveGUID = WfsStringItem('directiveGUID', 'directive_guid')
    directiveInfoGUID = WfsStringItem('directiveInfoGUID', 'guid')
    luDirectiveGUID = WfsStringItem('luDirectiveGUID', 'lu_directive_guid')
    directiveSeq = WfsIntItem('directiveSeq', 'sort_order')
    isComplete = WfsBoolItem('isComplete', 'is_complete', False)

    def __init__(self, directive_info: DirectiveInfoFeature):
        super().__init__(directive_info)
        # MRISA db won't let update/insert with this being null, so we are just inserting an empty string.
        self.wfs_values['directiveStatusNote'] = ''


class MRISAPhoto(BasicWfsRecord):
    WFS_TABLE_NAME: ClassVar[str] = "MRISAPhoto"
    WFS_PRIMARY_KEY: ClassVar[str] = "pictureInfoGUID"

    pictureInfoGUID = WfsStringItem('pictureInfoGUID', 'guid')
    poleInfoGUID = WfsStringItem('poleInfoGUID', 'pole_info_guid')
    embeddedFileGUID = WfsStringItem('embeddedFileGUID', 'embedded_file_guid')
    pictureName = WfsStringItem('pictureName', 'picture_name')

    def __init__(self, picture_info: PictureInfoFeature):
        super().__init__(picture_info)


class MRISAPoleDescriptorInfo(BasicWfsRecord):
    WFS_TABLE_NAME: ClassVar[str] = "MRISAPoleDescriptorInfo"
    WFS_PRIMARY_KEY: ClassVar[str] = "poleDescriptorInfoGUID"

    poleDescriptorInfoGUID = WfsStringItem('poleDescriptorInfoGUID', 'guid')
    poleDescriptorGUID = WfsStringItem('poleDescriptorGUID', 'pole_descriptor_guid')
    poleInfoGUID = WfsStringItem('poleInfoGUID', 'pole_info_guid')
    luPoleDescriptorGUID = WfsStringItem('luPoleDescriptorGUID', 'lu_pole_descriptor_guid')
    isComplete = WfsBoolItem('isComplete', 'is_complete', False)

    def __init__(self, pole_descriptor_info: PoleDescriptorInfoFeature):
        super().__init__(pole_descriptor_info)


class MRISARespParty(BasicWfsRecord):
    WFS_TABLE_NAME: ClassVar[str] = "MRISARespParty"
    WFS_PRIMARY_KEY: ClassVar[str] = "respPartyGUID"

    respPartyGUID = WfsStringItem('respPartyGUID', 'guid')
    respPartyInfoGUID = WfsStringItem('respPartyInfoGUID', 'info_guid')
    directiveInfoGUID = WfsStringItem('directiveInfoGUID', 'directive_info_guid')
    companyGUID = WfsStringItem('companyGUID', 'company_guid')

    def __init__(self, resp_party: RespPartyFeature):
        super().__init__(resp_party)
