from requests.auth import HTTPBasicAuth

from trc_packages.wfs.transaction_builder import AbstractXMLBuilder, AbstractWfsRequester


class MrisaXmlBuilder(AbstractXMLBuilder):
    namespace = "MRISA"
    namespace_url = "http://www.spidasoftware.com/mrisa"


class MrisaWfsRequester(AbstractWfsRequester):
    url = "http://localhost:8080/geoserver/wfs"
    authorization = HTTPBasicAuth('mrisa', 'userpass')
