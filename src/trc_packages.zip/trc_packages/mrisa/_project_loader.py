from glob import glob
import os
from os import path
import shutil
from PyQt5.QtCore import QEventLoop
from qgis.utils import iface  # type: ignore
from qgis.gui import QgisInterface, QgsMapCanvas  # type: ignore
from qgis.core import (QgsCoordinateReferenceSystem, QgsMapLayer, QgsStyle, QgsProject, QgsEditFormConfig, QgsError,  # type: ignore
                       QgsVectorLayer, QgsLayerTreeGroup, QgsRasterLayer, QgsApplication)
from typing import List, Optional, Dict, Any, Tuple, TypeVar, Generator, ClassVar
from trc_packages import asynclib
from trc_packages.core import first, flatten, last, attrempty, try_or_get, log
from trc_packages.core.data.conversions import copy_sqlite_to_mdb, copy_mdb_to_sqlite
from trc_packages.core.features import BasicVectorObject
from trc_packages.core.ui import LoadingProgressDialog
from trc_packages.ogr2ogr_tools import ogr2ogr
from trc_packages.debugging import debuggable
from trc_packages.decorators import deprecated
from trc_packages.mrisa import _configuration as configuration, datamodels, vectors, _on_pole_in_area_geometry_changed as geometry_changed_listener, _loader as loader
from concurrent import futures
import sqlite3
T = TypeVar('T')


class ProjectLoader(loader.Loader):
    """Handles building the project and its components for a MRISA Field application."""

    REMOTE_AERIAL_PATH: ClassVar[str] = '\\\\columbus-vfp\\shared\\CLS\\MRISA_Setup\\Apps\\Make_Right\\Aerials'
    REMOTE_TEMPLATE_PROJECT_PATH: ClassVar[str] = '\\\\columbus-vfp\\shared\\CLS\\MRISA_Setup\\Apps\\Make_Right'
    MASTER_PATH: ClassVar[str] = 'C:\\A_Mapping\\MRISA_Field\\Field\\Audit\\Master'
    BASE_PATH: ClassVar[str] = path.dirname(MASTER_PATH)
    PROJECT_PATH: ClassVar[str] = path.join(BASE_PATH, 'Projects')
    DB_PATH: ClassVar[str] = path.join(BASE_PATH, 'DB')
    OLD_LAYER_NAME: ClassVar[str] = 'poles'

    project_name: str = None
    user_name: str = None
    project: QgsProject = None
    canvas: QgsMapCanvas = None

    created_spatialite_file: bool = False
    created_sqlite_file: bool = False
    created_project_file: bool = False

    _project_path: str = None
    @property
    def project_path(self) -> str:
        return self._project_path or path.join(self.PROJECT_PATH, self.project_name)
    @project_path.setter
    def project_path(self, project_path: str) -> None:
        self._project_path = project_path
    @project_path.deleter
    def project_path(self) -> None:
        del self._project_path

    _project_file: str = None
    @property
    def project_file(self) -> str:
        return self._project_file or path.join(self.project_path, f"{self.project_name}.qgs")
    @project_file.setter
    def project_file(self, project_file: str) -> None:
        self._project_file = project_file
    @project_file.deleter
    def project_file(self) -> None:
        del self._project_file

    _db_path: str = None
    @property
    def db_path(self) -> str:
        return self._db_path or self.DB_PATH
    @db_path.setter
    def db_path(self, db_path: str) -> None:
        self._db_path = db_path
    @db_path.deleter
    def db_path(self) -> None:
        del self._db_path

    _background_gdb_file: str = None
    @property
    def background_gdb_file(self) -> str:
        return self._background_gdb_file or first(sorted(glob(path.join(self.db_path, 'Background', '*.gdb'))))
    @background_gdb_file.setter
    def background_gdb_file(self, background_gdb_file: str) -> None:
        self._background_gdb_file = background_gdb_file
    @background_gdb_file.deleter
    def background_gdb_file(self) -> None:
        del self._background_gdb_file

    _mdb_file: str = None
    @property
    def mdb_file(self) -> str:
        return self._mdb_file or path.join(self.db_path, f"{self.project_name}.mdb")
    @mdb_file.setter
    def mdb_file(self, mdb_file: str) -> None:
        self._mdb_file = mdb_file
    @mdb_file.deleter
    def mdb_file(self) -> None:
        del self._mdb_file

    _attachment_priority_file: str = None
    @property
    def attachment_priority_file(self) -> str:
        return self._attachment_priority_file or path.join(self.db_path, f"{self.project_name}.csv")
    @attachment_priority_file.setter
    def attachment_priority_file(self, attachment_priority_file: str) -> None:
        self._attachment_priority_file
    @attachment_priority_file.deleter
    def attachment_priority_file(self) -> None:
        del self._attachment_priority_file

    _circuit_name: str = None
    @property
    def circuit_name(self) -> str:
        return self._circuit_name or last(self.project_name.split('_'))
    @circuit_name.setter
    def circuit_name(self, circuit_name: str) -> None:
        self._circuit_name = circuit_name
    @circuit_name.deleter
    def circuit_name(self) -> None:
        del self._circuit_name

    _packet_name: str = None
    @property
    def packet_name(self) -> str:
        return self._packet_name or path.dirname(self.db_path)
    @packet_name.setter
    def packet_name(self, packet_name: str) -> None:
        self._packet_name = packet_name
    @packet_name.deleter
    def packet_name(self) -> None:
        del self._packet_name

    _working_mdb_file: str = None
    @property
    def working_mdb_file(self) -> str:
        return self._working_mdb_file or path.join(self.db_path, f"{self.project_name}.working.mdb")
    @working_mdb_file.setter
    def working_mdb_file(self, working_mdb_file: str) -> None:
        self._working_mdb_file = working_mdb_file
    @working_mdb_file.deleter
    def working_mdb_file(self) -> None:
        del self._working_mdb_file

    _sqlite_file: str = None
    @property
    def sqlite_file(self) -> str:
        return self._sqlite_file or path.join(self.db_path, f"{self.project_name}.sqlite")
    @sqlite_file.setter
    def sqlite_file(self, sqlite_file: str) -> None:
        self._sqlite_file = sqlite_file
    @sqlite_file.deleter
    def sqlite_file(self) -> None:
        del self._sqlite_file

    _spatialite_file: str = None
    @property
    def spatialite_file(self) -> str:
        return self._spatialite_file or path.join(self.project_path, f"{self.project_name}.sqlite")
    @spatialite_file.setter
    def spatialite_file(self, spatialite_file: str) -> None:
        self._spatialite_file = spatialite_file
    @spatialite_file.deleter
    def spatialite_file(self) -> None:
        del self._spatialite_file

    _projects: Dict[str, str] = None
    @property
    def projects(self) -> Dict[str, str]:
        if self._projects is None:
            self._projects = {}
            for packet_name in os.listdir(self.DB_PATH):
                packet: str = path.join(self.DB_PATH, packet_name)
                for circuit_name in os.listdir(packet):
                    circuit: str = path.join(packet, circuit_name)
                    if path.isdir(circuit):
                        self._projects[circuit_name] = circuit
        return self._projects
    @projects.deleter
    def projects(self) -> None:
        del self._projects

    @property
    def config(self) -> configuration.Configuration:
        return configuration.Configuration()

    validation_messages: List[str] = None
    loading: LoadingProgressDialog = None
    valid_project: bool = False
    layer_data: Dict[str, List[List]] = None
    group_data: Dict[str, List[str]] = None
    vectors: Dict[str, BasicVectorObject] = None
    aerial_layer: Optional[QgsRasterLayer] = None
    feeder_layers: List[BasicVectorObject] = None
    area_poles: BasicVectorObject = None
    working_primaries: BasicVectorObject = None
    working_secondaries: BasicVectorObject = None
    primaries: BasicVectorObject = None
    secondaries: BasicVectorObject = None
    substations: BasicVectorObject = None

    def __init__(self) -> None:
        self.project = QgsProject.instance()
        self.canvas = iface.mapCanvas()
        self.validation_messages = []
        self.loading = LoadingProgressDialog()

    @asynclib.progressivewith(steps=1, synchronous=True)
    def _progression_create_export(self) -> None:
        shutil.copy(self.mdb_file, self.working_mdb_file)

    @asynclib.progressivewith(steps=1, synchronous=True)
    def _progression_export_data(self) -> None:
        shutil.copy(self.mdb_file, self.working_mdb_file)
        def __table_count_callback(count: int) -> None:
            self.loading.maximum += count
        def __table_callback(table: str) -> None:
            self.loading.text = f"Finished exporting {table}"
            self.loading.value += 1
        if not copy_sqlite_to_mdb(self.sqlite_file, self.working_mdb_file, table_count_callback=__table_count_callback,
                                  table_callback=__table_callback):
            self.validation_messages.append('An error has occurred while exporting project.')

    @asynclib.progressivewith(steps=2, synchronous=True)
    def _progression_finish_export(self) -> None:
        shutil.copy(self.working_mdb_file, self.mdb_file)
        os.remove(self.working_mdb_file)

    @asynclib.progressivemethod
    def _export_mdb_progression(self) -> Generator:
        self.loading.text = 'Exporting project'
        yield self._progression_create_export
        if any(self.validation_messages):
            return
        yield self._progression_export_data
        if any(self.validation_messages):
            return
        self.loading.text = 'Finishing up'
        yield self._progression_finish_export

    @debuggable
    def export_mdb(self) -> bool:
        """Exports the data set to an mdb file."""
        self.loading.value = 0
        self.loading.maximum = 4
        self.loading.setWindowTitle('Exporting')
        self.loading.open()
        asynclib.exec_progressive_method(self._export_mdb_progression, self.loading.progress)
        self.loading.close()
        return not any(self.validation_messages)

    @asynclib.progressivewith(steps=2, synchronous=True)
    def _progression_valid_arguments(self) -> None:
        if self.project_name is None:
            self.validation_messages.append('No project selected.')
        if self.user_name is None:
            self.validation_messages.append('No username entered.')

    @asynclib.progressivewith(steps=1, synchronous=True)
    def _progression_valid_project(self) -> None:
        self.valid_project = path.isfile(self.project_file)
        if self.valid_project:
            iface.addProject(self.project_file)
            self.valid_project = all([l.error().isEmpty() for l in QgsProject.instance().mapLayers().values()
                                      if l.name in self.layer_data])

    @asynclib.progressivewith(steps=1, synchronous=True)
    def _progression_download_project_template(self) -> None:
        if not path.isfile(path.join(self.MASTER_PATH, 'template.qgs')):
            shutil.copy(path.join(self.REMOTE_TEMPLATE_PROJECT_PATH, 'template.qgs'),
                        path.join(self.MASTER_PATH, 'template.qgs'))

    @asynclib.progressivewith(steps=1, synchronous=True)
    def _progression_project(self) -> None:
        if not self.valid_project:
            iface.addProject(path.join(self.MASTER_PATH, 'template.qgs'))
            self.config.project_name = self.project_name
            self.config.user_name = self.user_name.upper()
            self.config.project_dir = self.project_path
            self.config.source_db_file = self.mdb_file
            self.config.output_db_file = self.sqlite_file
            self.config.db_path = self.db_path
            self.config.attachment_priority_file = self.attachment_priority_file
            self.project.setFileName(self.project_file)
            self.created_project_file = True
            self.project.removeMapLayer(first(self.project.mapLayersByName('poles')))

    @asynclib.progressivewith(steps=1, synchronous=True)
    def _progression_project_path(self) -> None:
        if not path.isdir(self.project_path):
            os.makedirs(self.project_path, exist_ok=True)
        if not path.isdir(self.project_path):
            self.validation_messages.append('Could not create the project folder.')

    @asynclib.progressivewith(steps=3, synchronous=True)
    def _progression_sqlite(self) -> None:
        acisi_table_name: str = None
        if not path.isfile(self.mdb_file):
            self.validation_messages.append('No source MDB was found.')

        if not path.isfile(self.sqlite_file):
            def __table_count_callback(count: int) -> None:
                self.loading.maximum += count
            def __table_callback(table: str) -> None:
                nonlocal acisi_table_name
                if acisi_table_name is None and table.upper() == 'ACISIPOLES':
                    acisi_table_name = table
                self.loading.text = f"Finished loading {table}"
                self.loading.value += 1
            self.created_sqlite_file = copy_mdb_to_sqlite(self.mdb_file, self.sqlite_file,
                                                          table_count_callback=__table_count_callback,
                                                          table_callback=__table_callback) and path.isfile(self.sqlite_file)

            if not self.created_sqlite_file:
                self.validation_messages.append('The SQLite data source could not be created.')
            else:
                with sqlite3.connect(self.sqlite_file) as sqlite:  # type: sqlite3.Connection
                    # We need to add in a few indexes.
                    cursor: sqlite3.Cursor = sqlite.cursor()
                    cursor.execute('CREATE UNIQUE INDEX IF NOT EXISTS poles_in_area_pole_guid ON tblPolesInArea (PoleGUID)')
                    cursor.execute('CREATE UNIQUE INDEX IF NOT EXISTS poles_in_area_unique_client_id ON tblPolesInArea (UniqueClientID)')
                    cursor.execute('CREATE UNIQUE INDEX IF NOT EXISTS pole_info_pole_guid ON tblPoleInfo (PoleGUID)')
                    cursor.execute('CREATE UNIQUE INDEX IF NOT EXISTS pole_info_unique_client_id on tblPoleInfo (UniqueClientID)')
                if acisi_table_name is not None:
                    with sqlite3.connect(self.sqlite_file) as sqlite:
                        # Migrating the ACISI table to the poles in area table. The fact this table ever exists in shenanigans, yet here we are.
                        cursor = sqlite.cursor()
                        cursor.execute('INSERT OR IGNORE INTO tblPolesInArea (UniqueClientID, MapX, MapY, Latitude, Longitude, PoleOwner, PoleGUID)\n'
                                       f"SELECT ClientID, MapX, MapY, Lat, Lon, PoleOwner, USSID FROM {acisi_table_name}")

                if path.exists(self.project_path):
                    shutil.rmtree(self.project_path)


    @asynclib.progressivewith(steps=2)
    def _progression_spatialite(self) -> None:
        if not path.isfile(self.spatialite_file):
            if not self.__create_spatialite_table(self.spatialite_file, self.sqlite_file, 'Poles', 'SELECT *, MakePoint(Longitude, Latitude) FROM tblPolesInArea'):
                self.validation_messages.append('An error occurred while generating the map data source.')
            else:
                self.created_spatialite_file = True

    @asynclib.progressivewith(steps=1, synchronous=True)
    def _progression_vector_layers(self) -> None:
        self.vectors = {d: BasicVectorObject(self.created_sqlite_file or self.created_project_file, path=self.db_path,
                                             current_circuit=self.project_name, layer_name=d) for d in self.layer_data}

    @asynclib.progressivewith(steps=1, synchronous=True)
    def _progression_vector_layer_joins(self) -> None:
        if self.created_sqlite_file or self.created_project_file:
            empty_list: List[List] = []
            empty_dict: Dict[str, Any] = dict()
            for layer_name, vector_object in self.vectors.items():
                joins: List[List] = self.layer_data.get(layer_name, empty_list)
                for join in joins:
                    self_field: str = join[0]
                    other_vector: BasicVectorObject = self.vectors[join[1]]
                    other_field: Optional[str] = join[2] if len(join) > 2 else None
                    kwargs: Dict[str, Any] = join[3] if len(join) > 3 else empty_dict
                    vector_object.join(self_field, other_vector, other_field, **kwargs)

    @asynclib.progressivewith(steps=2)
    def _progression_aerial(self) -> None:
        # Begin building the raster layer.
        aerial_path: str = path.join(self.packet_name, 'aerial.sid')
        self.aerial_layer = first(QgsProject.instance().mapLayersByName('Aerial'))
        if self.aerial_layer is None:
            if not path.isfile(aerial_path):
                self.loading.text = 'Downloading aerial, this may take a few minutes.'
                try:
                    shutil.copy(path.join(self.REMOTE_AERIAL_PATH, f"{path.basename(self.packet_name)}_aerial.sid"),
                                aerial_path)
                except FileNotFoundError:
                    pass
            if path.isfile(aerial_path):
                # If an aerial was found and no aerial layer already exists, load it and prepare it.
                self.aerial_layer = iface.addRasterLayer(aerial_path)
                self.aerial_layer.setName('Aerial')
                self.aerial_layer.loadNamedStyle('aerial_style.qml')

    @asynclib.progressivewith(steps=5, synchronous=True)
    def _progression_background_gdb(self) -> None:
        if self.background_gdb_file is not None and path.isdir(self.background_gdb_file):
            self.feeder_layers = [
                try_or_get(lambda: BasicVectorObject(self.created_project_file, qgs_layer_path=f"{self.background_gdb_file}|layername=Primaries|subset=\"CIRCUIT1\"='{self.circuit_name}'", base_name='Working Primaries'), None),
                try_or_get(lambda: BasicVectorObject(self.created_project_file, qgs_layer_path=f"{self.background_gdb_file}|layername=Secondaries|subset=\"CIRCUIT1\"='{self.circuit_name}'", base_name='Working Secondaries'), None),
                try_or_get(lambda: BasicVectorObject(self.created_project_file, qgs_layer_path=f"{self.background_gdb_file}|layername=Primaries", base_name='Primaries'), None),
                try_or_get(lambda: BasicVectorObject(self.created_project_file, qgs_layer_path=f"{self.background_gdb_file}|layername=Secondaries", base_name='Secondaries'), None),
                try_or_get(lambda: BasicVectorObject(self.created_project_file, qgs_layer_path=f"{self.background_gdb_file}|layername=Substations", base_name='Substations'), None)
            ]
        else:
            self.validation_messages.append('No source background GDB was found.')
            self.feeder_layers = []

    @asynclib.progressivewith(steps=1, synchronous=True)
    def _progression_prepare_feeder_layers(self) -> None:
        self.working_primaries, self.working_secondaries, self.primaries, self.secondaries, self.substations = self.feeder_layers
        self.working_primaries.qgs_layer.setName('Working Primaries')
        self.working_secondaries.qgs_layer.setName('Working Secondaries')

    @asynclib.progressivewith(steps=1, synchronous=True)
    def _progression_prepare_pole_layers(self) -> None:
        self.area_poles: BasicVectorObject = BasicVectorObject(self.created_spatialite_file or self.created_project_file,
                                                               path=self.project_path, current_circuit=self.project_name,
                                                               base_name='Poles', layer_name='Poles')
        self.area_poles.qgs_layer.setName('Poles')

    @asynclib.progressivewith(steps=1, synchronous=True)
    def _progression_normalize_layer_positions(self) -> None:
        log.debug('Handling layer positions')
        self.__handle_layer_positions(self.vectors, self.group_data, self.primaries, self.secondaries, self.substations,
                                      self.working_primaries, self.working_secondaries, self.area_poles,
                                      self.aerial_layer)
        if self.created_spatialite_file or self.created_project_file:
            log.debug('Adding join to Poles in Area')
            self.area_poles.join('PoleGUID', self.vectors['tblPoleInfo'], included_fields=['PoleSeqNum', 'DisplayStatus'],
                                 prefix='pole_info.')

    @asynclib.progressivewith(steps=6, synchronous=True)
    def _progression_load_layer_styles(self) -> None:
        if self.secondaries is not None:
            self.secondaries.load_named_style(path.join(self.MASTER_PATH, 'all_feders_secondaries_style.qml'))
        if self.primaries is not None:
            self.primaries.load_named_style(path.join(self.MASTER_PATH, 'all_feders_primaries_style.qml'))
        if self.substations is not None:
            self.substations.load_named_style(path.join(self.MASTER_PATH, 'substations_style.qml'))
        if self.working_secondaries is not None:
            self.working_secondaries.load_named_style(path.join(self.MASTER_PATH, 'working_feders_style.qml'))
        if self.working_primaries is not None:
            self.working_primaries.load_named_style(path.join(self.MASTER_PATH, 'working_feders_style.qml'))
        self.area_poles.load_named_style(path.join(self.MASTER_PATH, 'pole_in_area_layer_style.qml'))
        if self.aerial_layer is not None:
            self.aerial_layer.loadNamedStyle(path.join(self.MASTER_PATH, 'aerial_style.qml'))

    @asynclib.progressivewith(steps=6, synchronous=True)
    def _progression_loading_area_poles_script(self) -> None:
        area_poles_editor: QgsEditFormConfig = QgsEditFormConfig()
        area_poles_editor.setUiForm(path.join(self.MASTER_PATH, 'pole_in_area_dialog.ui'))
        area_poles_editor.setInitFilePath(path.join(self.MASTER_PATH, 'pole_in_area_dialog.py'))
        area_poles_editor.setInitFunction('main')
        area_poles_editor.setInitCodeSource(QgsEditFormConfig.PythonInitCodeSource.CodeSourceFile)
        self.area_poles.qgs_layer.setEditFormConfig(area_poles_editor)

    @asynclib.progressivewith(steps=1, synchronous=True)
    def _progression_update_extent(self) -> None:
        extent: Any = self.area_poles.qgs_layer.extent()
        self.canvas.setExtent(extent)
        self.canvas.refresh()
        if self.canvas.scale() < 20000:
            self.canvas.zoomScale(20000)
        self.canvas.zoomScale(self.canvas.scale() + 500)

    @asynclib.progressivewith(steps=2, synchronous=True)
    def _progression_finalize_project(self) -> None:
        self.area_poles.qgs_layer.geometryChanged.connect(geometry_changed_listener.on_pole_geometryChanged)
        self.project.write()

    @asynclib.progressivemethod
    def _load_or_create_map_progression(self) -> Generator:
        self.loading.text = 'Loading project'
        yield self._progression_valid_arguments
        if any(self.validation_messages):
            return
        yield self._progression_valid_project
        if any(self.validation_messages):
            return
        yield self._progression_download_project_template
        if any(self.validation_messages):
            return
        yield self._progression_project
        if any(self.validation_messages):
            return
        self.loading.text = 'Checking temporary database'
        yield self._progression_sqlite
        if any(self.validation_messages):
            return
        self.loading.text = 'Checking working folder'
        yield self._progression_project_path
        if any(self.validation_messages):
            return
        self.loading.text = 'Checking vector layers'
        yield [self._progression_spatialite,
               self._progression_vector_layers,
               self._progression_vector_layer_joins]
        if any(self.validation_messages):
            return
        self.loading.text = 'Checking map layers'
        yield [self._progression_aerial,
               self._progression_background_gdb]
        if any(self.validation_messages):
            return
        self.loading.text = 'Preparing vector layers'
        yield [self._progression_prepare_feeder_layers,
               self._progression_prepare_pole_layers]
        self.loading.text = ' Finishing up'
        yield [self._progression_normalize_layer_positions,
               self._progression_load_layer_styles,
               self._progression_loading_area_poles_script,
               self._progression_update_extent,
               self._progression_finalize_project]

    @debuggable
    def load_or_create_map(self, layer_data: Dict[str, List[List]], group_data: Dict[str, List[str]]) -> bool:
        """
        Loads or creates the map and project files for the selected MRISA Field dataset.
        :param layer_data: The extra layers to load for this project.
        :param group_data: The groups to place the layers with for this project.
        """
        self.layer_data = layer_data
        self.group_data = group_data
        self.loading.value = 0
        self.loading.maximum = 37
        self.loading.setWindowTitle('Loading')
        self.loading.open()
        asynclib.exec_progressive_method(self._load_or_create_map_progression, self.loading.progress)
        self.loading.close()
        try:
            return not any(self.validation_messages) and self.area_poles.start_editing()
        finally:
            self.__cleanup_properties()

    def __cleanup_properties(self) -> None:
        """Attempts to clean up the properties of the loader (hopefully to prevent leaks)."""
        if not attrempty(self, 'vectors'):
            del self.vectors
        if not attrempty(self, 'aerial_layer'):
            del self.aerial_layer
        if not attrempty(self, 'feeder_layers'):
            del self.feeder_layers
        if not attrempty(self, 'area_poles'):
            del self.area_poles
        if not attrempty(self, 'working_primaries'):
            del self.working_primaries
        if not attrempty(self, 'working_secondaries'):
            del self.working_secondaries
        if not attrempty(self, 'primaries'):
            del self.primaries
        if not attrempty(self, 'secondaries'):
            del self.secondaries
        if not attrempty(self, 'substations'):
            del self.substations

    def __handle_layer_positions(self, vectors: Dict[str, BasicVectorObject], group_data: Dict[str, List[str]],
                                 primaries: Optional[BasicVectorObject], secondaries: Optional[BasicVectorObject],
                                 substations: Optional[BasicVectorObject], working_primaries: Optional[BasicVectorObject],
                                 working_secondaries: Optional[BasicVectorObject], area_poles: BasicVectorObject,
                                 aerial: Optional[QgsRasterLayer]) -> None:

        log.debug('Finding tree components')
        layer_tree_root: QgsLayerTreeGroup = QgsProject.instance().layerTreeRoot()
        base_group: QgsLayerTreeGroup = layer_tree_root.findGroup('Base Layers')
        parent_group: QgsLayerTreeGroup = layer_tree_root.findGroup('Overview')
        log.debug(f"Tree components found: {layer_tree_root}, {base_group}, {parent_group}")
        for group, layers in group_data.items():  # type: Tuple[str, List[str]]
            log.debug(f"Updating layer of {layers} to group {group}")
            if parent_group.findGroup(group) is None:
                parent_group.addGroup(group)
            for layer in layers:
                try_or_get(lambda: vectors[layer].add_to_group(group), None)
            parent_group.findGroup(group).setExpanded(False)
            log.debug(f"Updated layer {layers}")

        all_feeders: QgsLayerTreeGroup = layer_tree_root.findGroup('All Feeders')
        layer_tree_root.insertChildNode(0, QgsLayerTreeGroup('All Feeders'))
        log.debug('Updating primaries and secondaries')
        if primaries is not None:
            try_or_get(lambda: primaries.add_to_group('All Feeders'), None)
        if secondaries is not None:
            try_or_get(lambda: secondaries.add_to_group('All Feeders'), None)

        if all_feeders is not None:
            log.debug('All Feeders group already exists - removing original')
            layer_tree_root.takeChild(all_feeders)

        if substations is not None:
            log.debug('Substations layer exists - adding')
            try_or_get(lambda: substations.add_to_group(index=0), None)
        working_feeders: QgsLayerTreeGroup = layer_tree_root.findGroup('Working Feeders')
        layer_tree_root.insertChildNode(0, QgsLayerTreeGroup('Working Feeders'))
        log.debug('Updating working primaries and secondaries')
        if working_primaries is not None:
            try_or_get(lambda: working_primaries.add_to_group('Working Feeders'), None)
        if working_secondaries is not None:
            try_or_get(lambda: working_secondaries.add_to_group('Working Feeders'), None)

        if working_feeders is not None:
            log.debug('Working Feeders group already exists - removing original')
            layer_tree_root.takeChild(working_feeders)

        log.debug('Moving Poles in Area to root index 0')
        area_poles.add_to_group(index=0)
        area_poles.select()

        # Ensure that the layer groups are all collapsed
        log.debug('Collapsing')
        parent_group.findGroup('Base Layers').setExpanded(False)
        parent_group.setExpanded(False)
        base_group.setExpanded(False)
        temp_aerial = layer_tree_root.findLayer(aerial)
        layer_tree_root.insertLayer(len(layer_tree_root.children()) - 1, aerial)
        if temp_aerial is not None:
            log.debug('Removing aerial')
            layer_tree_root.removeChildNode(temp_aerial)
        base_group.removeLayer(aerial)
        log.debug('Done')

    def __create_spatialite_table(self, spatialite_file: str, sqlite_file: str, table_name: str, sql_query: str) -> bool:
        return ogr2ogr.main([
            '-update',
            '-overwrite',
            '-f', 'SQLite', spatialite_file, sqlite_file,
            '-dsco', 'SPATIALITE=YES',
            '-lco', 'LAUNDER=NO',
            '-nln', table_name,
            '-nlt', 'POINT',
            '-s_srs', 'EPSG:4326',
            '-t_srs', 'EPSG:4326',
            '-sql', sql_query
        ])
