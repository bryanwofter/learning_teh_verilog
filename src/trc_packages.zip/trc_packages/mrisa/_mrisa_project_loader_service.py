from PyQt5 import QtCore
from qgis import core, utils  # type: ignore
from trc_packages.asynclib import step, protocols as async_protocols
from trc_packages.core import first, last, try_or_get
from trc_packages.core.features import BasicVectorObject
from trc_packages.mrisa import _circuit_details as cd, _configuration as conf, _on_pole_in_area_geometry_changed as geometry_changed_listener, vectors
from trc_packages.projects import MdbProjectLoaderServiceABC
from typing import Any, Dict, List, Optional
import os


class MrisaProjectLoaderService(MdbProjectLoaderServiceABC['vectors.MakeRightVectorObject', 'conf.Configuration']):
    """
    Provides an MDB project loader for the MRISA project.
    """

    circuit: Optional['cd.CircuitDetails'] = None

    @property
    def project_name(self) -> Optional[str]:
        return None if self.circuit is None else self.circuit.circuit_name

    @property
    def project_path(self) -> Optional[str]:
        return None if self.circuit is None else os.path.join(self.project_root, self.project_name)

    @property
    def db_path(self) -> Optional[str]:
        return None if self.circuit is None else self.circuit.circuit_path

    @property
    def mdb_file(self) -> Optional[str]:
        return None if self.circuit is None else self.circuit.mdb_file

    @property
    def attachment_priority_file(self) -> Optional[str]:
        return None if self.circuit is None else os.path.join(self.db_path, f"{self.project_name}.csv")

    @property
    def circuit_name(self) -> Optional[str]:
        return None if self.circuit is None else last(self.project_name.split('_'))

    @property
    def aerial_path(self) -> Optional[str]:
        return self.packet_path

    @property
    def remote_aerial_file(self) -> Optional[str]:
        return None if self.circuit is None or self.remote_aerial_root is None else os.path.join(self.remote_aerial_root, f"{self.packet_name}_aerial.sid")

    @property
    def packet_name(self) -> Optional[str]:
        return None if self.circuit is None else self.circuit.packet_name

    @property
    def packet_path(self) -> Optional[str]:
        return None if self.circuit is None else self.circuit.packet_path

    @property
    def config(self) -> 'conf.Configuration':
        return conf.Configuration()

    def __init__(self, project_root: str, master_root: str, layer_data: Dict[str, List[List[Any]]], group_data: Dict[str, List[str]],
                 remote_template_project_root: str, remote_aerial_root: str, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(project_root=project_root,
                         master_root=master_root,
                         layer_data=layer_data,
                         group_data=group_data,
                         remote_template_project_root=remote_template_project_root,
                         remote_aerial_root=remote_aerial_root,
                         template_project_pole_layer='poles',
                         vector_type=vectors.MakeRightVectorObject,
                         index_definitions=['CREATE UNIQUE INDEX IF NOT EXISTS poles_in_area_pole_guid ON tblPolesInArea (PoleGUID)',
                                            'CREATE UNIQUE INDEX IF NOT EXISTS poles_in_area_unique_client_id ON tblPolesInArea (UniqueClientID)',
                                            'CREATE UNIQUE INDEX IF NOT EXISTS pole_info_pole_guid ON tblPoleInfo (PoleGUID)',
                                            'CREATE UNIQUE INDEX IF NOT EXISTS pole_info_unique_client_id on tblPoleInfo (UniqueClientID)'],
                         spatialite_definitions={'Poles': 'SELECT *, MakePoint(Longitude, Latitude) FROM tblPolesInArea'},
                         parent=parent)

    @step
    def _validate_arguments(self) -> bool:
        if self.circuit is None:
            self.validation_messages.append('A circuit must be selected to load.')
        else:
            if not os.path.isdir(self.circuit.packet_path):
                self.validation_messages.append('An invalid packet path has been selected. Has the packet been moved or deleted?')
            elif not os.path.isdir(self.circuit.circuit_path):
                self.validation_messages.append('An invalid circuit path has been selected. Has the circuit or packet been moved or deleted?')

        return super()._validate_arguments()

    @step
    def _validate_project(self) -> bool:
        self.valid_project = os.path.isfile(self.project_file)

        if self.valid_project:
            def __validate_project() -> None:
                utils.iface.addProject(self.project_file)
                self.valid_project = all(l.error().isEmpty() for l in self.project.mapLayers().values() if l.name in self.layer_data)

            self.yield_until_ran_later(__validate_project, attempts=-1)

        return super()._validate_project()

    @step
    def _build_project(self) -> bool:
        template_project_file: Optional[str] = self.template_project_file
        if not self.valid_project:
            def __build_project() -> None:
                if template_project_file is not None:
                    utils.iface.addProject(template_project_file)

                self.config.project_name = self.project_name
                self.config.user_name = self.user_name.upper()
                self.config.project_dir = self.project_path
                self.config.source_db_file = self.mdb_file
                self.config.output_db_file = self.sqlite_file
                self.config.db_path = self.db_path
                self.config.attachment_priority_file = self.attachment_priority_file
                self.project.setFileName(self.project_file)
                self.created_project_file = True

                if self.template_project_pole_layer is not None:
                    self.project.removeMapLayer(first(self.project.mapLayersByName(self.template_project_pole_layer)))

            self.yield_until_ran_later(__build_project, attempts=-1)

        return super()._build_project()

    @step
    def _process_background_gdb(self, service: async_protocols.Service) -> None:
        try:
            if self.background_gdb_file is not None and os.path.isdir(self.background_gdb_file):
                self.background_gdb_preparation.emit()
                self.feeders = [
                    try_or_get(lambda: BasicVectorObject(self.created_project_file, qgs_layer_path=f"{self.background_gdb_file}|layername=Primaries|subset=\"CIRCUIT1\"='{self.circuit_name}'", base_name='Working Primaries'), None),
                    try_or_get(lambda: BasicVectorObject(self.created_project_file, qgs_layer_path=f"{self.background_gdb_file}|layername=Secondaries|subset=\"CIRCUIT1\"='{self.circuit_name}'", base_name='Working Secondaries'), None),
                    try_or_get(lambda: BasicVectorObject(self.created_project_file, qgs_layer_path=f"{self.background_gdb_file}|layername=Primaries", base_name='Primaries'), None),
                    try_or_get(lambda: BasicVectorObject(self.created_project_file, qgs_layer_path=f"{self.background_gdb_file}|layername=Secondaries", base_name='Secondaries'), None),
                    try_or_get(lambda: BasicVectorObject(self.created_project_file, qgs_layer_path=f"{self.background_gdb_file}|layername=Substations", base_name='Substations'), None)
                ]
                self.background_gdb_prepared.emit()
            else:
                with self._lock.synchronized(timeout=1_000_000, fail_on_timeout=True):
                    self.validation_messages.append('No source background GDB was found.')
                    self.feeders = []
        finally:
            service._progress = 1.0

    @step
    def _load_layer_styles(self) -> bool:

        def __load_layer_styles() -> None:
            if self.secondaries is not None:
                self.secondaries.load_named_style(os.path.join(self.master_root, 'all_feders_secondaries_style.qml'))

            if self.primaries is not None:
                self.primaries.load_named_style(os.path.join(self.master_root, 'all_feders_primaries_style.qml'))

            if self.substations is not None:
                self.substations.load_named_style(os.path.join(self.master_root, 'substations_style.qml'))

            if self.working_secondaries is not None:
                self.working_secondaries.load_named_style(os.path.join(self.master_root, 'working_feders_style.qml'))

            if self.working_primaries is not None:
                self.working_primaries.load_named_style(os.path.join(self.master_root, 'working_feders_style.qml'))

            self.poles.load_named_style(os.path.join(self.master_root, 'pole_in_area_layer_style.qml'))

            if self.aerial is not None:
                self.aerial.loadNamedStyle(os.path.join(self.master_root, 'aerial_style.qml'))

        self.yield_until_ran_later(__load_layer_styles, attempts=-1)

        return super()._load_layer_styles()

    @step
    def _load_pole_editor_script(self) -> bool:
        def __load_pole_editor_script() -> None:
            area_poles_editor: core.QgsEditFormConfig = core.QgsEditFormConfig()
            area_poles_editor.setUiForm(os.path.join(self.master_root, 'pole_in_area_dialog.ui'))
            area_poles_editor.setInitFilePath(os.path.join(self.master_root, 'pole_in_area_dialog.py'))
            area_poles_editor.setInitFunction('main')
            area_poles_editor.setInitCodeSource(core.QgsEditFormConfig.PythonInitCodeSource.CodeSourceFile)
            self.poles.qgs_layer.setEditFormConfig(area_poles_editor)

        self.yield_until_ran_later(__load_pole_editor_script, attempts=-1)

        return super()._load_pole_editor_script()

    @step
    def _finalize_project(self) -> bool:

        def __finalize_project() -> None:
            self.poles.qgs_layer.geometryChanged.connect(geometry_changed_listener.on_pole_geometryChanged)

        self.yield_until_ran_later(__finalize_project, attempts=-1)

        return super()._finalize_project()

    @step
    def _build_sqlite(self) -> bool:
        return super()._build_sqlite()

    @step
    def _create_spatialite_database(self, service: async_protocols.Service[None]) -> None:
        super()._create_spatialite_database(service)

    @step
    def _download_aerial(self, service: async_protocols.Service[None]) -> None:
        super()._download_aerial(service)

    @step
    def _download_template_project(self) -> bool:
        return super()._download_template_project()

    @step
    async def _handle_special_layers(self) -> bool:
        return await super()._handle_special_layers()

    @step
    def _normalize_layer_positions(self) -> bool:
        if self.created_spatialite_file or self.created_project_file:
            self.yield_until_ran_later(lambda: self.poles.join('PoleGUID', self.vectors['tblPoleInfo'], included_fields=['PoleSeqNum', 'DisplayStatus'], prefix='pole_info.'),
                                       attempts=-1)

        return super()._normalize_layer_positions()

    @step
    def _prepare_feeder_layers(self) -> bool:
        return super()._prepare_feeder_layers()

    @step
    def _prepare_pole_layers(self) -> bool:
        return super()._prepare_pole_layers()

    @step
    def _prepare_vector_layer_joins(self) -> bool:
        return super()._prepare_vector_layer_joins()

    @step
    def _prepare_vector_layers(self) -> bool:
        return super()._prepare_vector_layers()

    @step
    def _update_extent(self) -> bool:
        return super()._update_extent()

    @step
    def _validate_project_path(self) -> bool:
        return super()._validate_project_path()

