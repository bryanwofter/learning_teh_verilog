from PyQt5 import QtCore
from trc_packages.asynclib import TrcService
from trc_packages.mrisa import _circuit_details as cd
from typing import List, Optional
import os


class CircuitResolutionService(TrcService[List['cd.CircuitDetails']]):
    """
    Resolves all circuits available in the database directory.
    """

    db_path: str = None
    validation_messages: List[str] = None

    def __init__(self, db_path: str, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)
        self.db_path = db_path
        self.validation_messages = []

    def _run(self) -> List['cd.CircuitDetails']:
        """Returns all circuits available in the database directory."""
        self.validation_messages.clear()
        results: List[cd.CircuitDetails] = []

        if self.db_path is None:
            self.validation_messages.append('Database path is required.')
        elif not os.path.isdir(self.db_path):
            self.validation_messages.append('Database path must be a directory.')

        if any(self.validation_messages):
            return results

        for packet_name in os.listdir(self.db_path):  # type: str
            packet_path: str = os.path.join(self.db_path, packet_name)

            if os.path.isdir(packet_path):
                for circuit_name in os.listdir(packet_path):  # type: str
                    circuit_path: str = os.path.join(packet_path, circuit_name)

                    if os.path.isdir(circuit_path) and os.path.isfile(os.path.join(circuit_path, f"{circuit_name}.mdb")):
                        results.append(cd.CircuitDetails(packet_name=packet_name,
                                                         packet_path=packet_path,
                                                         circuit_name=circuit_name,
                                                         circuit_path=circuit_path,
                                                         mdb_file=os.path.join(circuit_path, f"{circuit_name}.mdb")))

        return sorted(results)

