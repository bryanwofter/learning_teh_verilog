from typing import NoReturn, Optional
from ._configuration import Configuration
from trc_packages.core.features import (BasicFeatureObject, FeatureItem, BinaryItem,
                                        FeatureItemProvider, BoolFeatureItem, FloatFeatureItem, IntFeatureItem,
                                        StrFeatureItem, DateTimeFeatureItem, DateFeatureItem, EnumFeatureItem)
from trc_packages.core.features.factories import (item, bin_item, bool_item, date_item,
                                                  datetime_item, enum_item, float_item, int_item,
                                                  str_item)
from trc_packages.core.json_handlers import JSONEnum
import sqlite3

OptStr = Optional[str]
OptInt = Optional[int]
OptFloat = Optional[float]


class TypeFeature(BasicFeatureObject):
    """Provides a feature object for tblType in the project."""

    hash_field: str = 'TypeGUID'

    guid: StrFeatureItem = str_item('TypeGUID')
    office_guid: StrFeatureItem = str_item('OfficeGUID')
    code: StrFeatureItem = str_item('TypeCode')
    description: StrFeatureItem = str_item('TypeDescr')
    is_retired: BoolFeatureItem = bool_item('IsRetired')


class RespPartyFeature(BasicFeatureObject):
    """Provides a feature object for tblRespParty in the project."""

    hash_field: str = 'RespPartyInfoGUID'

    info_guid: StrFeatureItem = str_item('RespPartyInfoGUID')
    guid: StrFeatureItem = str_item('RespPartyGUID')
    directive_info_guid: StrFeatureItem = str_item('DirectiveInfoGUID')
    company_guid: StrFeatureItem = str_item('CompanyGUID')


class ProjectFeature(BasicFeatureObject):
    """Provides a feature object for tblProjects in the project."""

    hash_field: str = 'ProjectGUID'

    guid: StrFeatureItem = str_item('ProjectGUID')
    client_guid: StrFeatureItem = str_item('ClientGUID')
    client_data_source_guid: StrFeatureItem = str_item('ClientDataSourceGUID')
    project_name: StrFeatureItem = str_item('ProjectName')
    project_description: StrFeatureItem = str_item('ProjectDescription')
    field_folder: StrFeatureItem = str_item('FieldFolder')
    base_map_type: StrFeatureItem = str_item('BaseMapType')
    map_units: StrFeatureItem = str_item('MapUnits')
    client_info_id: IntFeatureItem = int_item('client_info.rowid', True)


class AddressFeature(FeatureItemProvider):
    address_no: StrFeatureItem = str_item('AddressNo')
    address_street: StrFeatureItem = str_item('AddressStreet')
    address_city: StrFeatureItem = str_item('AddressCity')
    address_state: StrFeatureItem = str_item('AddressState')
    address_zip: StrFeatureItem = str_item('AddressZip')
    county_township: StrFeatureItem = str_item('CountyTownship')


class MapCoordinateFeature(FeatureItemProvider):
    map_x: FloatFeatureItem = float_item('MapX')
    map_y: FloatFeatureItem = float_item('MapY')
    client_map_no: StrFeatureItem = str_item('ClientMapNumber')


class PositionedFeature(FeatureItemProvider):
    longitude: FloatFeatureItem = float_item('Longitude')
    latitude: FloatFeatureItem = float_item('Latitude')


class PoleInAreaFeature(AddressFeature, MapCoordinateFeature, PositionedFeature, BasicFeatureObject):
    """Provides a feature object for tblPolesInArea in the project."""

    hash_field: str = 'PoleGUID'

    object_id: IntFeatureItem = int_item('ObjectID')
    pole_guid: StrFeatureItem = str_item('PoleGUID')
    unique_client_id: IntFeatureItem = int_item('UniqueClientID')
    pole_tag_no: StrFeatureItem = str_item('PoleTagNumber')
    structure_type: StrFeatureItem = str_item('StructureType')
    pole_owner: StrFeatureItem = str_item('PoleOwner')
    pole_height: IntFeatureItem = int_item('PoleHeight')
    pole_class: IntFeatureItem = int_item('PoleClass')
    pole_year: IntFeatureItem = int_item('PoleDate')
    pole_on_map: BoolFeatureItem = bool_item('PoleOnMap')
    sub_station: StrFeatureItem = str_item('SubStation')
    feeder: StrFeatureItem = str_item('Feeder')
    pole_material: StrFeatureItem = str_item('PoleMaterial')
    feat_st_c: StrFeatureItem = str_item('FEAT_ST_C')


class Quality(JSONEnum):
    """Provides constant values for the quality field in the pole info feature."""
    OK = 'OK'
    POOR = 'Poor'

    def __str__(self) -> str: return self.value


class DisplayStatus(JSONEnum):
    """Provides constant values for the display status field in the pole info feature."""
    NONE = 'NONE'
    NOT_IN_FIELD = 'NIF'
    DONE = 'DONE'
    INCOMPLETE = 'INCOMPLETE'
    LICENSEE_CORRECTABLE = 'LICCORR'

    def __str__(self) -> str: return self.value


class PoleType(JSONEnum):
    """Provides constant values for the pole type field in the pole info feature."""
    NONE = ''
    DISTRIBUTION = 'Distribution'
    SERVICE = 'Service'

    def __str__(self) -> str: return self.value


class PoleMaterial(JSONEnum):
    """Provides constant values for the pole material field in the pole info feature."""
    NONE = ''
    WOOD = 'WOOD'
    CONCRETE = 'CONCRETE'
    FIBERGLASS = 'FIBERGLASS'
    STEEL = 'STEEL'

    def __str__(self) -> str: return self.value


class PoleInfoFeature(AddressFeature, MapCoordinateFeature, PositionedFeature, BasicFeatureObject):
    """Provides a feature object for tblPoleInfo in the project."""

    hash_field: str = 'PoleInfoGUID'

    object_id: IntFeatureItem = int_item('ObjectID')
    guid: StrFeatureItem = str_item('PoleInfoGUID')
    pole_guid: StrFeatureItem = str_item('PoleGUID')
    field_visit_guid: StrFeatureItem = str_item('FieldVisitGUID')
    pole_owner_guid: StrFeatureItem = str_item('PoleOwnerGUID')
    engineer: StrFeatureItem = str_item('Engineer')
    engineer_helper: StrFeatureItem = str_item('EngrHelper')
    unique_client_id: IntFeatureItem = int_item('UniqueClientID')
    pole_seq_no: FloatFeatureItem = float_item('PoleSeqNum')
    pole_tag_no: StrFeatureItem = str_item('PoleTagNumber')
    display_status: EnumFeatureItem[DisplayStatus, OptStr] = enum_item('DisplayStatus', DisplayStatus)
    node_name: StrFeatureItem = str_item('NodeName')
    directions: StrFeatureItem = str_item('Directions')
    structure_type: StrFeatureItem = str_item('StructureType')
    back_span: IntFeatureItem = int_item('BackSpan')
    front_span: IntFeatureItem = int_item('FrontSpan')
    side_span1: IntFeatureItem = int_item('SideSpan1')
    side_span2: IntFeatureItem = int_item('SideSpan2')
    back_span_pole_seq_no: FloatFeatureItem = float_item('BackspanPoleSeqNo')
    front_span_pole_seq_no: FloatFeatureItem = float_item('FrontspanPoleSeqNo')
    side_span_pole_seq_no1: FloatFeatureItem = float_item('SidespanPoleSeqNo1')
    side_span_pole_seq_no2: FloatFeatureItem = float_item('SidespanPoleSeqNo2')
    applicant_pole_no: StrFeatureItem = str_item('ApplicantPoleNumber')
    date_of_inspection: DateFeatureItem = date_item('DateOfInspection')
    pole_height: IntFeatureItem = int_item('PoleHeight')
    pole_class: IntFeatureItem = int_item('PoleClass')
    pole_quality: EnumFeatureItem[Quality, OptStr] = enum_item('PoleQuality', Quality)
    pole_year: IntFeatureItem = int_item('PoleDate')
    pole_angle: FloatFeatureItem = float_item('PoleAngle')
    row: StrFeatureItem = str_item('ROW')
    construct_status: StrFeatureItem = str_item('ConstructStatus')
    pole_on_map: BoolFeatureItem = bool_item('PoleOnMap')
    speed_limit: IntFeatureItem = int_item('SpeedLimit')
    terrain: StrFeatureItem = str_item('Terrain')
    eop_dist_ft: FloatFeatureItem = float_item('EopDistFt')
    eop_dist_in: FloatFeatureItem = float_item('EopDistIN')
    notes: StrFeatureItem = str_item('Notes')
    date_locate: DateFeatureItem = date_item('DateLocate')
    locate_authorization: StrFeatureItem = str_item('LocateAuthorization')
    pole_last_update: DateFeatureItem = date_item('PoleLastUpdate')
    loading_code: StrFeatureItem = str_item('LoadingCode')
    pole_resp_party: StrFeatureItem = str_item('PoleResponsibleParty')
    dis_code: StrFeatureItem = str_item('DISCode')
    ambient_temp: FloatFeatureItem = float_item('AmbTemp')
    map_no: StrFeatureItem = str_item('MapNumber')
    sub_station: StrFeatureItem = str_item('SubStation')
    feeder: StrFeatureItem = str_item('Feeder')
    pole_type: EnumFeatureItem[PoleType, OptStr] = enum_item('PoleType', PoleType)
    first_edit_user: StrFeatureItem = str_item('FirstEditUser')
    first_edit_date: DateFeatureItem = date_item('FirstEditDate')
    modified_user: StrFeatureItem = str_item('ModifiedUser')
    modified_date: DateFeatureItem = date_item('ModifiedDate')
    njuns_ticket_no: StrFeatureItem = str_item('NJUNSTicketNumber')
    pole_material: EnumFeatureItem[PoleMaterial, OptStr] = enum_item('PoleMaterial', PoleMaterial)
    work_type: StrFeatureItem = str_item('WorkType')
    # pole_in_area_id: IntFeatureItem = int_item('pole_in_area.rowid', is_read_only=True)
    # field_visit_id: IntFeatureItem = int_item('field_visit.rowid', is_read_only=True)
    # pole_owner_id: IntFeatureItem = int_item('pole_owner.rowid', is_read_only=True)


class PoleDescriptorInfoFeature(BasicFeatureObject):
    """Provides a feature object for tblPoleDescriptorInfo in the project."""

    hash_field: str = 'PoleDescriptorInfoGUID'

    guid: StrFeatureItem = str_item('PoleDescriptorInfoGUID')
    pole_descriptor_guid: StrFeatureItem = str_item('PoleDescriptorGUID')
    pole_info_guid: StrFeatureItem = str_item('PoleInfoGUID')
    lu_pole_descriptor_guid: StrFeatureItem = str_item('luPoleDescriptorGUID')
    is_complete: BoolFeatureItem = bool_item('IsComplete')


class PictureInfoFeature(BasicFeatureObject):
    """Provides a feature object for tblPictureInfo in the project."""

    hash_field: str = 'PictureInfoGUID'

    guid: StrFeatureItem = str_item('PictureInfoGUID')
    pole_info_guid: StrFeatureItem = str_item('PoleInfoGUID')
    embedded_file_guid: StrFeatureItem = str_item('EmbeddedFileGUID')
    picture_name: StrFeatureItem = str_item('PictureName')


class LuPoleDescriptorFeature(BasicFeatureObject):
    """Provides a feature object for tblLuPoleDescriptors in the project."""

    hash_field: str = 'luPoleDescriptorGUID'

    guid: StrFeatureItem = str_item('luPoleDescriptorGUID')
    descriptor: StrFeatureItem = str_item('Descriptor')
    is_directive: BoolFeatureItem = bool_item('IsDirective')
    is_retired: BoolFeatureItem = bool_item('lu_project_pole_descriptor.Retired', True)
    sort_order: IntFeatureItem = int_item('lu_project_pole_descriptor.SortOrder', True)


class LuDirectiveVariableValueFeature(BasicFeatureObject):
    """Provides a feature object for tblLuDirectiveVariableValues in the project."""

    hash_field: str = 'DirectiveVariableGUID'

    guid: StrFeatureItem = str_item('DirectiveVariableGUID')
    variable_name: StrFeatureItem = str_item('VariableName')
    available_value: StrFeatureItem = str_item('AvailableValue')
    sort_order: IntFeatureItem = int_item('SortOrder')


class LuDirectiveFeature(BasicFeatureObject):
    """Provides a feature object for tblLuDirectives in the project."""

    hash_field: str = 'luDirectiveGUID'

    guid: StrFeatureItem = str_item('luDirectiveGUID')
    directive_group_guid: StrFeatureItem = str_item('DirectiveGroupGUID')
    directive_code: StrFeatureItem = str_item('DirectiveCode')
    directive_label: StrFeatureItem = str_item('DirectiveLabel')
    directive_template: StrFeatureItem = str_item('DirectiveTemplate')
    is_retired: BoolFeatureItem = bool_item('lu_project_directive.Retired', True)
    sort_order: IntFeatureItem = int_item('lu_project_directive.SortOrder', True)


class LuDirectiveGroupFeature(BasicFeatureObject):
    """Provides a feature object for tblLuDirectiveGroups in the project."""

    hash_field: str = 'DirectiveGroupGUID'

    guid: StrFeatureItem = str_item('DirectiveGroupGUID')
    directive_group_description: StrFeatureItem = str_item('DirectiveGroupDescription')
    directive_group_label: StrFeatureItem = str_item('DirectiveGroupLabel')
    is_violation_default: BoolFeatureItem = bool_item('IsViolationDefault')
    sort_order: IntFeatureItem = int_item('SortOrder')


class LicCorrectableFeature(BasicFeatureObject):
    """Provides a feature object for tblLicCorrectable in the project."""

    hash_field: str = 'LicCorrGUID'

    guid: StrFeatureItem = str_item('LicCorrGUID')
    lic_correctable_info_guid: StrFeatureItem = str_item('LicCorrInfoGUID')
    pole_info_guid: StrFeatureItem = str_item('PoleInfoGUID')
    company_guid: StrFeatureItem = str_item('CompanyGuid')
    description: StrFeatureItem = str_item('Description')


class FieldVisitTypeFeature(BasicFeatureObject):
    """Provides a feature object for tblFieldVisitTypes in the project."""

    hash_field: str = 'FieldVisitTypeGUID'

    guid: StrFeatureItem = str_item('FieldVisitTypeGUID')
    description: StrFeatureItem = str_item('Description')


class FieldVisitFeature(BasicFeatureObject):
    """Provides a feature object for tblFieldVisits in the project."""

    hash_field: str = 'FieldVisitGUID'

    guid: StrFeatureItem = str_item('FieldVisitGUID')
    application_guid: StrFeatureItem = str_item('ApplicationGUID')
    field_visit_type_guid: StrFeatureItem = str_item('FieldVisitTypeGUID')
    step_no: IntFeatureItem = int_item('StepNo')
    status_guid: StrFeatureItem = str_item('StatusGUID')
    application_id: IntFeatureItem = int_item('application.rowid', True)


class EmbeddedFileFeature(BasicFeatureObject):
    """Provides a feature object for tblEmbeddedFiles in the project."""

    hash_field: str = 'EmbeddedFileGUID'

    guid: StrFeatureItem = str_item('EmbeddedFileGUID')
    file_image = bin_item('FileImage', table_name='tblEmbeddedFiles', id_name='EmbeddedFileGUID',
                          factory=lambda: sqlite3.connect(Configuration().output_db_file)) #type: BinaryItem


class DirectiveInfoFeature(BasicFeatureObject):
    """Provides a feature object for tblDirectiveInfo in the project."""

    hash_field: str = 'DirectiveInfoGUID'

    guid: StrFeatureItem = str_item('DirectiveInfoGUID')
    directive_guid: StrFeatureItem = str_item('DirectiveGUID')
    attachment_info_guid: StrFeatureItem = str_item('AttachmentInfoGUID')
    lu_directive_guid: StrFeatureItem = str_item('luDirectiveGUID')
    directive: StrFeatureItem = str_item('Directive')
    sort_order: IntFeatureItem = int_item('DirectiveSeq')
    is_complete: BoolFeatureItem = bool_item('IsComplete')


class CrossingTypeFeature(BasicFeatureObject):
    """Provides a feature object for tblCrossingType in the project."""

    hash_field: str = 'CrossingTypeGUID'

    guid: StrFeatureItem = str_item('CrossingTypeGUID')
    project_guid: StrFeatureItem = str_item('ProjectGUID')
    crossing_type: StrFeatureItem = str_item('CrossingType')
    description: StrFeatureItem = str_item('Description')
    directive_type: StrFeatureItem = str_item('DirectiveTypeText')
    sort_order: IntFeatureItem = int_item('DisplayOrder')
    is_retired: BoolFeatureItem = bool_item('IsRetired')


class CompanyTypeFeature(BasicFeatureObject):
    """Provides a feature object for tblCompanyType in the project."""

    hash_field: str = 'CompanyTypeGUID'

    guid: StrFeatureItem = str_item('CompanyTypeGUID')
    company_type: StrFeatureItem = str_item('CompanyType')


class CompanyFeature(BasicFeatureObject):
    """Provides a feature object for tblCompany in the project."""

    hash_field: str = 'CompanyGUID'

    guid: StrFeatureItem = str_item('CompanyGUID')
    company_type_guid: StrFeatureItem = str_item('CompanyTypeGUID')
    office_guid: StrFeatureItem = str_item('OfficeGUID')
    company_code: StrFeatureItem = str_item('CompCode')
    company_name: StrFeatureItem = str_item('CompanyName')
    joint_use_contract: FeatureItem = item('JointUseContract')
    owns_poles: BoolFeatureItem = bool_item('OwnsPoles')
    grouping_company_name: StrFeatureItem = str_item('Grouping_CompanyName')
    grouping_company_type: StrFeatureItem = str_item('Grouping_CompanyType')


class ClientInfoFeature(BasicFeatureObject):
    """Provides a feature object for tblClientInfo in the project."""

    hash_field: str = 'ClientGUID'

    guid: StrFeatureItem = str_item('ClientGUID')
    office_guid: StrFeatureItem = str_item('OfficeGUID')
    client_logo: StrFeatureItem = str_item('ClientLogo')
    client_name: StrFeatureItem = str_item('ClientName')
    client_full_name: StrFeatureItem = str_item('ClientFullName')


class MeasureLocation(JSONEnum):
    """Provides the values for the measure location."""
    AT_POLE = '@ Pole'
    AT_MIDSPAN = 'Midspan'
    UNKNOWN = 'Unknown'

    def __str__(self) -> str: return self.value


class AttachmentFeature(BasicFeatureObject):
    """Provides a feature object for tblAttachments in the project."""

    hash_field: str = 'AttachmentGUID'

    guid: StrFeatureItem = str_item('AttachmentGUID')
    pole_info_guid: StrFeatureItem = str_item('PoleInfoGUID')
    company_guid: StrFeatureItem = str_item('CompanyGUID')
    type_guid: StrFeatureItem = str_item('TypeGUID')
    crossing_type_guid: StrFeatureItem = str_item('CrossingTypeGUID')
    compass_direction: StrFeatureItem = str_item('NSEW')
    measure_location: EnumFeatureItem[MeasureLocation, OptStr] = enum_item('MeasureLocation', MeasureLocation)
    feet: IntFeatureItem = int_item('Feet')
    inches: IntFeatureItem = int_item('Inches')
    new_poa_feet: IntFeatureItem = int_item('NewPOAFeet')
    new_poa_inches: IntFeatureItem = int_item('NewPOAInches')
    nesc_violation: BoolFeatureItem = bool_item('NESCViolation')
    new_attach: StrFeatureItem = str_item('NewAttach')
    notes: StrFeatureItem = str_item('Notes')
    attach_last_update: DateTimeFeatureItem = datetime_item('AttachLastUpdate')
    special_handle: IntFeatureItem = int_item('SpecialHandle')
    calculation_point: BoolFeatureItem = bool_item('CalculationPoint')
    is_power: BoolFeatureItem = bool_item('IsPwr')
    info_guid: StrFeatureItem = str_item('AttachmentInfoGUID')
    work_sequence_no: IntFeatureItem = int_item('MRSequenceNo')

    @property
    def is_critical_power(self) -> bool: return self.is_power and self.calculation_point
    @is_critical_power.setter
    def is_critical_power(self, val: bool) -> NoReturn:
        if val: self.is_power = self.calculation_point = True
        else: self.calculation_point = False
    @is_critical_power.deleter
    def is_critical_power(self) -> NoReturn: del self.calculation_point

    @property
    def total_inches(self) -> int: return ((self.feet or 0) * 12) + (self.inches or 0)

    @property
    def total_new_poa_inches(self) -> int: return ((self.new_poa_feet or 0) * 12) + (self.new_poa_inches or 0)


class ApplicationFeature(BasicFeatureObject):
    """Provides a feature object for tblApplications in the project."""

    hash_field: str = 'ApplicationGUID'

    guid: StrFeatureItem = str_item('ApplicationGUID')
    company_guid: StrFeatureItem = str_item('CompanyGUID')
    contact_guid: StrFeatureItem = str_item('ContactGUID')
    job_type_guid: StrFeatureItem = str_item('JobTypeGUID')
    project_guid: StrFeatureItem = str_item('ProjectGUID')
    attachment_job_type_guid: StrFeatureItem = str_item('AttachmentJobTypeGUID')
    application_project_guid: StrFeatureItem = str_item('ApplicantProjectGUID')
    uss_tracking_no: StrFeatureItem = str_item('USSTrackingNo')
    applicant_job_no: StrFeatureItem = str_item('ApplicantJobNumber')
    application_description: StrFeatureItem = str_item('ApplicationDescription')
    application_address: StrFeatureItem = str_item('ApplicationAddress')
    proposed_attachments: StrFeatureItem = str_item('ProposedAttachments')
    proposed_attachments_trns: StrFeatureItem = str_item('ProposedAttachmentsTrns')
    priority: StrFeatureItem = str_item('Priority')
    memo: StrFeatureItem = str_item('Memo')
    application_last_update: DateTimeFeatureItem = datetime_item('AppLastUpdate')
    uss_job_no: StrFeatureItem = str_item('UssJobNum')
    uss_job_no_inspection: StrFeatureItem = str_item('UssJobNumInspection')
    node_name: StrFeatureItem = str_item('NodeName')
    application_date_received: DateTimeFeatureItem = datetime_item('ApplicationDateReceived')
    permit_no: StrFeatureItem = str_item('PermitNumber')
    cable_size: StrFeatureItem = str_item('CableSize')
    messenger_size: StrFeatureItem = str_item('MessengerSize')
    application_map_no: StrFeatureItem = str_item('appMapNumber')
    is_built_for_paper: IntFeatureItem = int_item('isBuiltForPaper')
    area_guid: StrFeatureItem = str_item('AreaGUID')
    applicant_project_coordinator: StrFeatureItem = str_item('ApplicantProjectCoordinator')
    company_id: IntFeatureItem = int_item('company.rowid', True)
    project_id: IntFeatureItem = int_item('project.rowid', True)

