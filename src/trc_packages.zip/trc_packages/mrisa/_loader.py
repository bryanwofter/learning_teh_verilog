from typing import Any, ClassVar, Dict, NoReturn, TypeVar
try:
    from typing import Protocol, runtime
except:
    from typing_extensions import Protocol, runtime  # type: ignore
from trc_packages.core.settings import SettingsABC
import abc
TConfig_co = TypeVar('TConfig_co', covariant=True, bound=SettingsABC)


@runtime
class Loader(Protocol[TConfig_co]):
    """
    Provides a protocol that defines the methods needed to load a project.
    """

    REMOTE_AERIAL_PATH: ClassVar[str]
    MASTER_PATH: ClassVar[str]
    BASE_PATH: ClassVar[str]
    PROJECT_PATH: ClassVar[str]
    DB_PATH: ClassVar[str]

    @property  # type: ignore
    @abc.abstractmethod
    def project_name(self) -> str:
        ...

    @project_name.setter  # type: ignore
    @abc.abstractmethod
    def project_name(self, project_name: str) -> NoReturn:
        ...

    @project_name.deleter  # type: ignore
    @abc.abstractmethod
    def project_name(self) -> NoReturn:
        ...

    @property
    @abc.abstractmethod
    def created_spatialite_file(self) -> bool:
        ...

    @property
    @abc.abstractmethod
    def created_sqlite_file(self) -> bool:
        ...


    @property
    @abc.abstractmethod
    def created_project_file(self) -> bool:
        ...

    @property  # type: ignore
    @abc.abstractmethod
    def project_path(self) -> str:
        ...

    @project_path.setter  # type: ignore
    @abc.abstractmethod
    def project_path(self, project_path: str) -> NoReturn:
        ...

    @project_path.deleter  # type: ignore
    @abc.abstractmethod
    def project_path(self) -> NoReturn:
        ...

    @property  # type: ignore
    @abc.abstractmethod
    def project_file(self) -> str:
        ...

    @project_file.setter  # type: ignore
    @abc.abstractmethod
    def project_file(self, project_file: str) -> NoReturn:
        ...

    @project_file.deleter  # type: ignore
    @abc.abstractmethod
    def project_file(self) -> NoReturn:
        ...

    @property  # type: ignore
    @abc.abstractmethod
    def db_path(self) -> str:
        ...

    @db_path.setter  # type: ignore
    @abc.abstractmethod
    def db_path(self, db_path: str) -> NoReturn:
        ...

    @db_path.deleter  # type: ignore
    @abc.abstractmethod
    def db_path(self) -> NoReturn:
        ...

    @property  # type: ignore
    @abc.abstractmethod
    def background_gdb_file(self) -> str:
        ...

    @background_gdb_file.setter  # type: ignore
    @abc.abstractmethod
    def background_gdb_file(self, background_gdb_file: str) -> NoReturn:
        ...

    @background_gdb_file.deleter  # type: ignore
    @abc.abstractmethod
    def background_gdb_file(self) -> NoReturn:
        ...

    @property  # type: ignore
    @abc.abstractmethod
    def mdb_file(self) -> str:
        ...

    @mdb_file.setter  # type: ignore
    @abc.abstractmethod
    def mdb_file(self, mdb_file: str) -> NoReturn:
        ...

    @mdb_file.deleter  # type: ignore
    @abc.abstractmethod
    def mdb_file(self) -> NoReturn:
        ...

    @property  # type: ignore
    @abc.abstractmethod
    def circuit_name(self) -> str:
        ...

    @circuit_name.setter  # type: ignore
    @abc.abstractmethod
    def circuit_name(self, circuit_name: str) -> NoReturn:
        ...

    @circuit_name.deleter  # type: ignore
    @abc.abstractmethod
    def circuit_name(self) -> NoReturn:
        ...

    @property  # type: ignore
    @abc.abstractmethod
    def packet_name(self) -> str:
        ...

    @packet_name.setter  # type: ignore
    @abc.abstractmethod
    def packet_name(self, packet_name: str) -> NoReturn:
        ...

    @packet_name.deleter  # type: ignore
    @abc.abstractmethod
    def packet_name(self) -> NoReturn:
        ...

    @property  # type: ignore
    @abc.abstractmethod
    def working_mdb_file(self) -> str:
        ...

    @working_mdb_file.setter  # type: ignore
    @abc.abstractmethod
    def working_mdb_file(self, working_mdb_file: str) -> NoReturn:
        ...

    @working_mdb_file.deleter  # type: ignore
    @abc.abstractmethod
    def working_mdb_file(self) -> NoReturn:
        ...

    @property  # type: ignore
    @abc.abstractmethod
    def sqlite_file(self) -> str:
        ...

    @sqlite_file.setter  # type: ignore
    @abc.abstractmethod
    def sqlite_file(self, sqlite_file: str) -> NoReturn:
        ...

    @sqlite_file.deleter  # type: ignore
    @abc.abstractmethod
    def sqlite_file(self) -> NoReturn:
        ...

    @property  # type: ignore
    @abc.abstractmethod
    def spatialite_file(self) -> str:
        ...

    @spatialite_file.setter  # type: ignore
    @abc.abstractmethod
    def spatialite_file(self, spatialite_file: str) -> NoReturn:
        ...

    @spatialite_file.deleter  # type: ignore
    @abc.abstractmethod
    def spatialite_file(self) -> NoReturn:
        ...
    @property  # type: ignore
    @abc.abstractmethod
    def projects(self) -> Dict[str, str]:
        ...

    @projects.deleter  # type: ignore
    @abc.abstractmethod
    def projects(self) -> NoReturn:
        ...

    @property
    @abc.abstractmethod
    def config(self) -> TConfig_co:
        """Gets the configuration singleton of this loader."""
        ...

    @abc.abstractmethod
    def export_mdb(self) -> bool:
        """Exports the project to its MDB file."""
        ...

    @abc.abstractmethod
    def load_or_create_map(self, *args: Any, **kwargs: Any) -> bool:
        """
        Loads or creates the map and project files for the selected dataset.
        """
        ...
