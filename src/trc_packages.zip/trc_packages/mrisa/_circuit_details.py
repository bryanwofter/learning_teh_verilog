from typing import Any


class CircuitDetails:
    """
    Provides a POD class that represents a circuit and its details.
    """
    packet_name: str = None
    packet_path: str = None
    circuit_name: str = None
    circuit_path: str = None
    mdb_file: str = None

    def __init__(self, *, packet_name: str, packet_path: str, circuit_name: str, circuit_path: str, mdb_file: str) -> None:
        self.packet_name = packet_name
        self.packet_path = packet_path
        self.circuit_name = circuit_name
        self.circuit_path = circuit_path
        self.mdb_file = mdb_file

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, type(self)):
            return self.packet_name == other.packet_name and self.circuit_name == other.circuit_name
        else:
            return NotImplemented

    def __gt__(self, other: Any) -> bool:
        if isinstance(other, type(self)):
            return (self.packet_name, self.circuit_name) > (other.packet_name, other.circuit_name)
        else:
            return NotImplemented

    def __hash__(self) -> int:
        return hash((self.packet_name, self.circuit_name))

