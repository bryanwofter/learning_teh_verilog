from PyQt5 import QtCore
from qgis.core import QgsGeometry, QgsPointXY  # type: ignore
from trc_packages.core.context_helpers import contexts
from trc_packages.core.features import BasicFeatureObject
from trc_packages.mrisa import _configuration as conf, datamodels, vectors


@QtCore.pyqtSlot(int, QgsGeometry)
def on_pole_geometryChanged(feature_id: int, geometry: QgsGeometry) -> None:
    """
    Listens for geometry changes on the Poles layer.
    :param feature_id: The ID of the updated feature.
    :param geometry: The new geometry of the updated feature.
    """

    config: conf.Configuration = conf.Configuration()

    m_area_poles: vectors.SpatialPoleInAreaVector = vectors.SpatialPoleInAreaVector()
    poles: vectors.PoleInfoVector = vectors.PoleInfoVector()
    area_poles: vectors.PoleInAreaVector = vectors.PoleInAreaVector()

    m_area_pole: BasicFeatureObject = m_area_poles[feature_id]
    pole: datamodels.PoleInfoFeature = poles.by_pole(m_area_pole)
    area_pole: datamodels.PoleInAreaFeature = area_poles.by_pole(m_area_pole)
    
    if not geometry.isNull():
        with contexts(m_area_poles.start_transaction(), poles.start_transaction(), area_poles.start_transaction()) as (m_area_pole_trans, pole_trans, area_pole_trans):
            point: QgsPointXY = geometry.asPoint()

            m_area_pole['MapX'] = m_area_pole['MapY'] = None
            m_area_pole['Longitude'] = point.x()
            m_area_pole['Latitude'] = point.y()
            m_area_pole.save()

            if pole is not None:
                pole.map_x = pole.map_y = None
                pole.longitude = point.x()
                pole.latitude = point.y()
                pole.save()

            if area_pole is not None:
                area_pole.map_x = area_pole.map_y = None
                area_pole.longitude = point.x()
                area_pole.latitude = point.y()
                area_pole.save()

        m_area_poles.start_editing()
