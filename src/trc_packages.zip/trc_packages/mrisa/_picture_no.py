from typing import overload
from trc_packages.core.safecasts import safe_int

class PictureNo:
    """Provides a picture number."""

    value = None #type: int

    @property
    def has_value(self) -> bool: return self.value is not None

    @overload
    def __init__(self, value: str) -> None: pass
    @overload
    def __init__(self, value: int) -> None: pass
    def __init__(self, value) -> None: self.value = safe_int(value)

    def __str__(self) -> str: return str(self.value).rjust(4, '0')

    def __int__(self) -> int: return self.value

    def __eq__(self, other) -> bool:
        if isinstance(other, PictureNo): return self.value == other.value
        else: return self == PictureNo(other)

    def __hash__(self) -> int: return hash(self.value)
