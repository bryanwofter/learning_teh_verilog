from typing import Any, Dict, Optional, List, Set, Tuple
from qgis.core import QgsProject, QgsMapLayer  # type: ignore
from trc_packages.core import first
from trc_packages.core.features import BasicVectorObject
from trc_packages.core.json_handlers import TrcJSONEncoder, TrcJSONDecoder
from trc_packages.core.settings import ProjectSettings, setting
from trc_packages.decorators import deprecated
import json
import os
import csv
import shutil
import collections


class Configuration(ProjectSettings):
    """Provides a configuration for the MRISA Field Make Right project."""

    plugin_name: str = 'mrisa_field.make_right'

    user_name = setting[str]('user_name')
    project_dir = setting[str]('project_dir')
    project_name = setting[str]('project_name')
    source_db_file = setting[str]('source_db_file')
    output_db_file = setting[str]('output_db_file')
    attachment_priority_file = setting[str]('attachment_priority_file')
    db_path = setting[str]('db_path')

    @property
    def project_loaded(self) -> bool:
        return self.db_path is not None and self.project_name is not None and os.path.isfile(self.output_db_file)

    @property
    def previous_settings(self) -> Optional[Dict[str, Any]]:
        return json.loads(self.get('previous_settings', '{}'), cls=TrcJSONDecoder)

    @previous_settings.setter
    def previous_settings(self, value: Optional[object]) -> None:
        self.set('previous_settings', json.dumps(value or {}, cls=TrcJSONEncoder))

    @previous_settings.deleter
    def previous_settings(self) -> None:
        self.delete('previous_settings')

    @property
    def attachment_priorities(self) -> Dict[str, Set[str]]:
        try:
            with open(self.attachment_priority_file, 'r') as f:
                data: Dict[str, Set[str]] = collections.defaultdict(set)
                for line in csv.DictReader(f):  # type: Dict[str, str]
                    data[line['CompanyType'].upper()].add(line['AttachmentType'].upper())
                return data
        except:
            return {}

    @attachment_priorities.setter
    def attachment_priorities(self, value: Optional[Dict[str, Set[str]]]) -> None:
        try:
            if value is None:
                shutil.rmtree(self.attachment_priority_file)
            else:
                with open(self.attachment_priority_file, 'w') as f:
                    writer: csv.DictWriter = csv.DictWriter(f, fieldnames=['AttachmentType', 'CompanyType'])
                    writer.writeheader()
                    for company, attachments in value.items():  # type: Tuple[str, Set[str]]
                        for attachment in attachments:  # type: str
                            writer.writerow({'AttachmentType': attachment.upper(), 'CompanyType': company.upper()})
        except:
            pass

    @attachment_priorities.deleter
    def attachment_priorities(self) -> None:
        self.attachment_priorities = None

