from functools import partial
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtWidgets import QProgressBar
from typing import Iterable, Any, Callable, cast, List, Optional, Tuple, Type, Union
from types import TracebackType
from queue import Queue
from trc_packages.asynclib import (protocols as protocols,
                                   _trc_function_service as tfs,
                                   _progressive_decorator as pd,
                                   _trc_runnable as tr,
                                   _functions as f,
                                   errors as errors)
from trc_packages.core import log
from trc_packages.core.ui import _synchro as synchro
from trc_packages.core.types import ExceptionType, ExceptionHandler, Runnable
import sys
CallableResult = Union[Tuple[int, Optional[Any]], int]
CallableSignature = Callable[..., CallableResult]
Callables = Union[CallableSignature, List[CallableSignature]]


def _make_progress_executor(progress_handler: Callable[[int], None], runnable: CallableSignature, results: Queue, timeout: int) -> 'tr.TrcRunnable':
    """
    Returns a runnable that wraps the given callable, results list, synchro, and timeout.
    :param progress_handler: Handles the progress produced by this executor.
    :param runnable: The runnable to execute within the thread.
    :param results: The list of results to add the runnable's result to.
    :param sync: The synchro to lock when adding a result to the list.
    :param timeout: The amount of time to wait for the lock before erroring.
    """
    def __runnable() -> None:
        log.debug(f"Calling {runnable}")
        result: CallableResult = runnable()
        progress: int
        if isinstance(result, int):
            progress = result
            result = None
        elif isinstance(result, tuple):
            progress, result = result
        else:
            progress = 0

        log.debug(f"{runnable} produced {progress}, {result}")
        if progress > 0:
            progress_handler(progress)
        results.put(result, True, None if timeout < 0 else timeout)

    return tr.TrcRunnable(__runnable)


def _await_run_later(run_later_target: protocols.Service[None], runnable: Runnable, attempts: int) -> None:
    """
    Executes the given runnable on the main thread, awaiting its completion and raising an exception if the await fails.
    :param run_later_target: The target providing the run later functionality.
    :param runnable: The runnable to execute.
    :param attempts: The number of attempts to make.
    """
    completed: bool = False

    def __exec_run_later() -> None:
        nonlocal completed
        nonlocal runnable
        log.debug('Executing on UI thread' if f.on_ui_thread() else 'Executing on non-UI thread - DANGER!!!')
        log.debug(f'Starting {runnable}')
        try:
            log.debug(f'Running {runnable}')
            runnable()
            log.debug(f'{runnable} ran')
        finally:
            del runnable
            completed = True

    log.debug(f'Placing {runnable} on UI thread')
    run_later_target.run_later(__exec_run_later)

    if not run_later_target.yield_until(lambda: completed, attempts=attempts):
        log.info('Await timed out')
        raise errors.ProgressiveTimeoutError()


def _qt_progressive_exec(progress_bar: QProgressBar, *runnables: Callables, worker_threads: int=1, timeout: int=-1,
                         startup: Optional[Runnable]=None, exception_handler: Optional[ExceptionHandler]=None,
                         finishup: Optional[Runnable]=None, cleanup: Optional[Runnable]=None,
                         parent: Optional[QtCore.QObject]=None) -> Tuple[Any, ...]:
    """
    A Qt implementation of progressive_exec.
    """
    # Setup the variables needed for the handlers to run on the UI thread.
    run_later_target: protocols.Service[None] = None
    thread_pool: QtCore.QThreadPool = None
    try:
        log.debug('Progressive execution in Qt context started')

        run_later_target = cast(protocols.Service[None], tfs.TrcFunctionService(lambda service: None, parent=parent))
        sync: synchro.Synchro = synchro.Synchro()
        results: Queue = Queue()

        def __handle_progress(progress: int) -> None:
            def __update_progress() -> None:
                with sync.synchronized(timeout=timeout, fail_on_timeout=True):
                    progress_bar.setValue(progress_bar.value() + progress)

            run_later_target.run_later(__update_progress)

        if startup is not None:
            _await_run_later(run_later_target, startup, 100000)

        log.debug(f'Creating thread pool with {worker_threads} threads.')
        thread_pool = QtCore.QThreadPool(parent=parent)
        thread_pool.setMaxThreadCount(worker_threads)
        log.debug('Thread pool created.')

        log.debug('Beginning progression')
        for runnable in runnables:  # type: Callables
            _progressive_exec_loop(run_later_target,
                                   thread_pool,
                                   *_progressive_exec_build_queues(__handle_progress,
                                                                   [runnable] if callable(runnable) else runnable,
                                                                   results,
                                                                   timeout),
                                   timeout)
        log.debug('Progression complete')
        if finishup is not None:
            _await_run_later(run_later_target, finishup, 100000)
    except BaseException:
        exc_type, exc, tb = sys.exc_info()  # type: Tuple[Type[BaseException], BaseException, TracebackType]
        if exception_handler is not None:
            def __handle_exception() -> None:
                if not exception_handler(exc_type, exc, tb):
                    raise exc
            _await_run_later(run_later_target, __handle_exception, 100000)
        else:
            raise exc
    finally:
        if thread_pool is not None:
            thread_pool.clear()
            thread_pool.waitForDone()

        if cleanup is not None:
            _await_run_later(run_later_target, cleanup, 100000)

    output: List[Any] = []

    while not results.empty():
        output.append(results.get(True, None if timeout < 0 else timeout))

    return tuple(output)


def _progressive_exec_build_queues(progress_handler: Callable[[int], None], runnables: Iterable[CallableSignature], results: Queue, timeout: int) -> Tuple[Queue, Queue]:
    log.debug('Building execution queues')
    asynchronous: Queue = Queue()
    synchronous: Queue = Queue()

    for runnable in runnables:  # type: CallableSignature
        if pd.progressivetype(runnable).is_asynchronous_type:
            log.debug(f"{runnable} is of type {pd.progressivetype(runnable)}")
            if pd.isprogressivecallable(runnable):
                log.debug(f"Adding call_flag to {runnable}")
                runnable = partial(runnable, pd.ProgressiveDecorator.call_flag())
            log.debug(f"{runnable} is asynchronous")
            queue = asynchronous
        else:
            log.debug(f"{runnable} is synchronous")
            runnable = partial(runnable, pd.ProgressiveDecorator.call_flag())
            queue = synchronous

        log.debug(f"Adding {runnable} to the queue")
        queue.put(_make_progress_executor(progress_handler, runnable, results, timeout), True, None if timeout < 0 else timeout)

    log.debug('Execution queues built')
    return (asynchronous, synchronous)


def _progressive_exec_loop(run_later_target: protocols.Service[None], thread_pool: QtCore.QThreadPool, asynchronous: Queue, synchronous: Queue, timeout: int) -> None:
    log.debug('Starting progress loop')
    while not (synchronous.empty() and asynchronous.empty()):
        log.debug('Loop advancing')

        while not asynchronous.empty():
            log.debug('Trying async execution')
            async_callable: tr.TrcRunnable = asynchronous.get(True, None if timeout < 0 else timeout)

            log.debug(f"{async_callable} taken from queue")

            if thread_pool.tryStart(async_callable):
                log.debug(f"{async_callable} successfully started")
            else:
                log.debug(f"{async_callable} could not be started, adding back to the queue")
                asynchronous.put(async_callable, True, None if timeout < 0 else timeout)
                break

        if not synchronous.empty():
            log.debug('Trying sync execution')
            sync_callable: tr.TrcRunnable = synchronous.get(True, None if timeout < 0 else timeout)

            log.debug(f"Starting {sync_callable}")
            _await_run_later(run_later_target, sync_callable, -1)
            log.debug(f"{sync_callable} finished")
    thread_pool.waitForDone()
    log.debug('Progression loop completed')


def progressive_exec(progress_bar: QtWidgets.QProgressBar, *fns: Callables, worker_threads: int=1, timeout: int=-1, on_ui_thread: bool=True,
                     startup: Optional[Runnable]=None, catch: Optional[ExceptionHandler]=None, finishup: Optional[Runnable]=None,
                     cleanup: Optional[Runnable]=None, parent: Optional[QtCore.QObject]=None) -> Tuple[Any, ...]:
    """
    Executes all provided callables in a thread pool, adding their return result to the total progress.
    :param progress_bar: The progress bar to update.
    :param fns: The functions to execute.
    :param worker_threads: The number of worker threads to reserve within the thread pool.
    :param timeout: The amount of time to wait for completion.
    :param on_ui_thread: Deprecated - This argument is no longer used
    :param startup: The startup function to call.
    :param catch: The exception handler function to call.
    :param finishup: The finisher function to call.
    :param cleanup: The resource cleanup function to call.
    :param parent: The optional parent of the thread pool.
    """
    return _qt_progressive_exec(progress_bar, *fns, worker_threads=worker_threads, timeout=timeout, startup=startup, exception_handler=catch,
                                finishup=finishup, cleanup=cleanup)

