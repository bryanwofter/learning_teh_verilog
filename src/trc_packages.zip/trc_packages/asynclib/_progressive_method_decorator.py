from functools import partial, wraps
from PyQt5.QtWidgets import QProgressBar
from trc_packages import core
from trc_packages.core.types import ExceptionHandler, Runnable
from typing import Any, Callable, cast, Iterable, Generic, Generator, Type, TypeVar, Optional, Tuple
from trc_packages.asynclib import _progressive_exec as progressive_exec
T = TypeVar('T')
F = TypeVar('F')


class ProgressiveMethodDecorator(Generic[F]):
    """
    Marks a function as yielding functions that should be called using progressive_exec.

    If the first argument of the progressive method is a QProgressBar, the method will be executed through progressive_exec.
    Otherwise, it will be executed as a normal generator.
    """

    __target: Optional[F]
    __worker_threads: int = 2
    __startup: Optional[Runnable] = None
    __catch: Optional[ExceptionHandler] = None
    __finishup: Optional[Runnable] = None
    __cleanup: Optional[Runnable] = None
    _is_progressive_method: bool = True

    def __init__(self, target: F, worker_threads: int, startup: Optional[Runnable], catch: Optional[ExceptionHandler],
                 finishup: Optional[Runnable], cleanup: Optional[Runnable]) -> None:
        self.__target = target
        self.__worker_threads = worker_threads
        self.__startup = startup
        self.__catch = catch
        self.__finishup = finishup
        self.__cleanup = cleanup

    def target(self, target: F) -> 'ProgressiveMethodDecorator[F]':
        self.__target = target
        return self

    def startup(self, startup: Optional[Runnable]) -> 'ProgressiveMethodDecorator[F]':
        self.__startup = startup
        return self

    def catch(self, catch: Optional[ExceptionHandler]) -> 'ProgressiveMethodDecorator[F]':
        self.__catch = catch
        return self

    def finishup(self, finishup: Optional[Runnable]) -> 'ProgressiveMethodDecorator[F]':
        self.__finishup = finishup
        return self

    def cleanup(self, cleanup: Optional[Runnable]) -> 'ProgressiveMethodDecorator[F]':
        self.__cleanup = cleanup
        return self

    def __get__(self, instance: T, owner: Type[T]) -> F:
        functor: F
        if instance is None:
            functor = cast(F, self)
        else:
            functor = cast(F, wraps(cast(Callable[..., Any], self.__target))(partial(self, instance)))
        return functor

    def __call__(self, *args: Any, **kwargs: Any) -> Generator:
        method: F = self.__target
        if callable(method):
            if self.has_progress_bar(args):
                progress_bar, params = self.extract_progress_bar(args)  # type: Tuple[QProgressBar, Iterable[Any]]
                for progressive_fn in method(*params, **kwargs):
                    yield from progressive_exec.progressive_exec(progress_bar, progressive_fn, worker_threads=self.__worker_threads, startup=self.__startup,
                                                                 catch=self.__catch, finishup=self.__finishup, cleanup=self.__cleanup)
            else:
                for fn in method(*args, **kwargs):
                    if callable(fn):
                        fn = [fn]
                    yield from (f() for f in fn)

    def has_progress_bar(self, args: Tuple[Any, ...]) -> bool:
        """
        Checks for the progress bar in the first 2 arguments of the call.
        :param args: The arguments used to call the function wrapper.
        """
        return isinstance(core.first(args), QProgressBar) or len(args) > 1 and isinstance(args[1], QProgressBar)

    def extract_progress_bar(self, args: Tuple[Any, ...]) -> Tuple[QProgressBar, Iterable[Any]]:
        """
        Extracts the progress bar from the first 2 arguments of the call.
        :param args: The arguments used to call the function wrapper.
        """
        progress_bar: QProgressBar
        params: Iterable[Any]
        if isinstance(core.first(args), QProgressBar):
            progress_bar = cast(QProgressBar, core.first(args))
            params = args[1:]
        else:
            progress_bar = args[1]
            params = [args[0]]
            params.extend(args[2:])
        return progress_bar, params

    def __str__(self) -> str:
        return str(self.__target)

    def __repr__(self) -> str:
        return f"<ProgressiveMethodDecorator on {self.__target.__repr__()}>"

