from abc import abstractmethod
from PyQt5 import QtCore
from trc_packages.asynclib import _service_status as s, errors as e
from trc_packages.core import protocolhelpers, QObjectProtocol
from typing import Any, Callable, Optional, Type, TypeVar, TYPE_CHECKING
from types import TracebackType
from typing_extensions import Protocol, runtime, runtime_checkable  # type: ignore
R = TypeVar('R', covariant=True)
Runnable = Callable[[], None]


def isservice(obj) -> bool:
    """
    NOTE: Due to limitations with Qt and Python metaclasses, you must use this function instead of issubclass and isinstance.
    :param obj: The object to check.
    :return: True if the object is a service, otherwise False.
    """
    return isinstance(obj, Service)


class ServiceErrorDetails:
    """Provides a container for service errors."""

    _exc_type: Type[BaseException] = None
    _exc: BaseException = None
    _tb: TracebackType = None

    @property
    def exc_type(self) -> Type[BaseException]:
        return self._exc_type

    @property
    def exc(self) -> BaseException:
        return self._exc

    @property
    def tb(self) -> TracebackType:
        return self._tb

    @property
    def is_aggregate_error(self) -> bool:
        return self.exc_type is e.AggregateServiceError

    def __init__(self, exc_type: Type[BaseException], exc: BaseException, tb: TracebackType) -> None:
        self._exc_type = exc_type
        self._exc = exc
        self._tb = tb

    def __str__(self) -> str:
        return f"{self.exc}"

    def __repr__(self) -> str:
        return 'exc_type=' + repr(self.exc_type) + ', exc=' + repr(self.exc) + ', tb=' + repr(self.tb)


@runtime
@runtime_checkable
class Service(Protocol[R], QObjectProtocol):
    """Provides a protocol base for service-like objects. While this class doesn't inherit from the Protocol type, it does essentially behave the same as the protocol type."""

    aborted: QtCore.pyqtSignal = None
    exception_changed: QtCore.pyqtSignal = None
    progress_changed: QtCore.pyqtSignal = None
    status_changed: QtCore.pyqtSignal = None
    result_changed: QtCore.pyqtSignal = None
    started: QtCore.pyqtSignal = None
    canceled: QtCore.pyqtSignal = None
    completed: QtCore.pyqtSignal = None
    faulted: QtCore.pyqtSignal = None
    finished: QtCore.pyqtSignal = None
    running_later: QtCore.pyqtSignal = None

    @property
    @abstractmethod
    def is_ready(self) -> bool:
        """Gets whether or not the current code is ready to be executed on this service."""
        ...

    @property
    @abstractmethod
    def is_active(self) -> bool:
        """Gets whether or not the current code is being executed on this service."""
        ...

    @property
    @abstractmethod
    def is_running(self) -> bool:
        """Gets whether or not this service is currently considered running."""
        ...

    @property
    @abstractmethod
    def event_dispatcher(self) -> Optional[QtCore.QAbstractEventDispatcher]:
        """Gets the event dispatcher of this service if one is available."""
        ...

    @property
    @abstractmethod
    def error_details(self) -> Optional[ServiceErrorDetails]:
        """Gets the current exception details of this service if the service is faulted."""
        ...

    @property
    @abstractmethod
    def exception(self) -> Optional[BaseException]:
        """Gets the current exception of this service if the service is faulted."""
        ...

    @property
    @abstractmethod
    def parent_service(self) -> Optional['Service']:
        """Gets the parent service that owns this service."""
        ...

    @property
    @abstractmethod
    def progress(self) -> float:
        """Gets the current progress of this service if the service has progress set."""
        ...

    @property
    def _progress(self) -> float:
        """Gets the current progress of this service if the service has progress set. This *must* only be used by inheritors."""
        raise NotImplementedError()

    @_progress.setter
    def _progress(self, progress: float) -> None:
        """Sets the current progress of this service. This *must* only be used by inheritors."""
        raise NotImplementedError()

    @_progress.deleter
    def _progress(self) -> None:
        """Sets the current progress of this service to 0. This *must* only be used by inheritors."""
        self._progress = 0.0

    @property
    def state(self) -> Optional[Any]:
        """Gets the current shared state of this service."""
        raise NotImplementedError()

    @state.setter
    def state(self, state: Optional[Any]) -> None:
        """Sets the current shared state of this service. Modifications to state should ensure that either the service isn't currently running or the modification is being performed on the service itself."""
        raise NotImplementedError()

    @state.deleter
    def state(self) -> None:
        """Deletes the current shared state of this service. Modifications to state should ensure that either the service isn't currently running or the modification is being performed on the service itself."""
        raise NotImplementedError()

    @property
    @abstractmethod
    def status(self) -> s.ServiceStatus:
        """Gets the current status of this service."""
        ...

    @property
    @abstractmethod
    def result(self) -> Optional[R]:
        """Gets the result of this service if the service has completed."""
        ...

    @abstractmethod
    def start(self) -> bool:
        """
        Attempts to begin the execution of this service.
        :return: True if this service is started successfully, otherwise False.
        """
        ...

    @abstractmethod
    def abort(self) -> bool:
        """Attempts to abort the execution of this service before its started."""
        ...

    @abstractmethod
    def clear_abort(self) -> bool:
        """Attempts to clear the abort flag of this service."""
        ...

    @abstractmethod
    def __await__(self):
        """
        Attempts to wait for this service to complete execution.
        :return: The result of this service.
        """
        ...

    @abstractmethod
    def await_result(self, *, timeout: int=0) -> Optional[R]:
        """
        Attempts to wait for this service to complete execution, returning its result upon completion.
        :param timeout: The optional amount of time to wait on the result. If a value greater than 0 is provided, an error will be raised if the timeout (in ms) is surpassed.
        """
        ...

    @abstractmethod
    def process_events(self, *args: Any, **kwargs: Any) -> bool:
        """Informs the event loop that it should process any incoming events at the point of calling. This should only ever be invoked within the thread that owns it."""
        ...

    @abstractmethod
    def stop(self, timeout: int=10000) -> bool:
        """
        Attempts to stop the execution of this server.
        :param timeout: The amount of time to wait for the service to stop.
        :return: True if this service is stopped successfully, otherwise False.
        """
        ...

    @abstractmethod
    def raise_if_faulted(self) -> None:
        """
        Raises an exception wrapping this Service if its status is currently set to faulted.
        This should only be used by this Service. External callers should not consume this method directly.
        """
        ...

    @abstractmethod
    def raise_if_interrupted(self) -> None:
        """
        Raises an InterruptionRequested error if the thread represented by this Service has been interrupted.
        This should only be used by this Service on its thread. External callers that attempt to consume this method directly will cause an InvalidRaiseInterruptionRequestedError to be raised instead.
        """
        ...

    @abstractmethod
    def reset_progress(self) -> None:
        """
        Safely resets the progress of this service to 0 if it isn't currently running.
        This should be used by external code that might need to reset the service's progress before the progress's run method is called again.
        """
        ...

    @abstractmethod
    def restart(self, timeout: int=10000) -> bool:
        """
        Attempts to restart the execution of this service. Restarting is equivalent to calling stop() and start().
        :param timeout: The amount of time to wait for the service to stop.
        :return: True if this service is restarted successfully, otherwise False.
        """
        return self.stop() and self.start()

    @abstractmethod
    def request_interruption(self) -> None:
        """Attempts to request an interruption of this service's thread."""
        ...

    @abstractmethod
    def run(self) -> None:
        """Begins execution of this service, updating the status along with catching any potential exceptions that may arise."""
        ...

    @abstractmethod
    def run_later(self, runnable: Runnable) -> None:
        """
        Schedules the given runnable to run on the thread that this service belongs to.
        :param runnable: The runnable to execute on the parent thread of this service.
        """
        ...

    @abstractmethod
    def yield_until(self, predicate: Callable[[], bool], *, attempts: int=10) -> bool:
        """
        Yields the execution of this thread until the provided predicate returns True, returning True if this occurs, or False otherwise.
        :param predicate: The predicate to check.
        :param attempts: The number of times to check the predicate before considering the yield_until a failure.
        """
        ...

    @abstractmethod
    def yield_while(self, predicate: Callable[[], bool], *, attempts: int=10) -> bool:
        """
        Yields the execution of this thread until the provided predicate returns False, returning True if this occurs, or False otherwise.
        :param predicate: The predicate to check.
        :param attempts: The number of times to check the predicate before considering the yield_until a failure.
        """
        ...

    @abstractmethod
    def wait(self, timeout: int=10000) -> bool:
        """
        Waits for this service to complete for up to the given timeout.
        :param timeout: The amount of time to wait for this service.
        :return: True if the wait is successful, otherwise False.
        """
        ...

    @classmethod
    def __subclasshook__(cls, C) -> bool:
        """
        Attempts to determine if C is a subclass of this class.
        :param C: The class to check against this class.
        """
        if cls is Service:
            type_: Type = C if isinstance(C, type) else type(C)
            if cls is type_:
                return True
            return protocolhelpers.follows_protocol(C, cls,
                                                    'exception', 'progress', 'restart',
                                                    'result', 'run', 'start', 'status',
                                                    'stop', 'canceled', 'completed',
                                                    'finished', 'progress_changed',
                                                    'result_changed', 'started',
                                                    'status_changed', 'wait',
                                                    '__await__', 'is_running',
                                                    'reset_progress', 'run_later',
                                                    'parent_service', 'running_later',
                                                    'yield_until', 'yield_while',
                                                    'raise_if_faulted',
                                                    'raise_if_interrupted',
                                                    'request_interruption',
                                                    'await_result', 'process_events',
                                                    'event_dispatcher', 'is_ready',
                                                    'aborted', 'abort', 'clear_abort',
                                                    check_type_annotations=True)
        return NotImplemented


@runtime
@runtime_checkable
class ProtoThread(Protocol, QObjectProtocol):

    if not TYPE_CHECKING:
        finished: QtCore.pyqtSignal = None
        started: QtCore.pyqtSignal = None

    @property
    def event_dispatcher(self) -> Optional[QtCore.QAbstractEventDispatcher]:
        """Gets the event dispatcher of this thread if one exists."""
        pass

    @event_dispatcher.setter
    def event_dispatcher(self, value: Optional[QtCore.QAbstractEventDispatcher]) -> None:
        """Sets the event dispatcher of this thread."""
        pass

    @event_dispatcher.deleter
    def event_dispatcher(self) -> None:
        """Removes the event dispatcher of this thread."""
        self.event_dispatcher = None

    @property
    @abstractmethod
    def is_finished(self) -> bool:
        """Gets whether or not this thread has completed."""
        ...

    @property
    @abstractmethod
    def is_interruption_requested(self) -> bool:
        """Gets whether or not an interruption has been requested on this thread."""
        ...

    @property
    @abstractmethod
    def is_running(self) -> bool:
        """Gets whether or not this thread is currently running."""
        ...

    @property
    @abstractmethod
    def loop_level(self) -> int:
        """Gets the loop level of this thread."""
        ...

    @abstractmethod
    def event(self, event: QtCore.QEvent) -> bool:
        """
        Raises the given event within this thread's event loop.
        :param event: The event to raise.
        :return: True if the event was successfully handled, otherwise False.
        """
        ...

    @abstractmethod
    def exec_(self) -> int:
        """
        Begins the event loop of this thread.
        """
        ...

    @abstractmethod
    def exit(self, return_code: int=0) -> None:
        """
        Requests that the thread cleanly exit its event loop.
        :param return_code: The return code of the exit event.
        """
        ...

    @abstractmethod
    def raise_if_interruption_requested(self) -> None:
        """
        Raises an InterruptionRequested exception on this Thread if is_interruption_requested is set to True.
        This method may only be consumed by its own thread. If an external thread invokes this method, an InvalidRaiseInterruptionRequestedError will be raised on the calling thread instead.
        """
        ...

    @abstractmethod
    def request_interruption(self) -> None:
        """Requests an interruption of this thread."""
        ...

    @abstractmethod
    def run(self) -> None:
        """Begins execution of this thread."""

    @abstractmethod
    def start(self, priority: QtCore.QThread.Priority=QtCore.QThread.InheritPriority) -> None:
        """
        Starts this thread if it hasn't been started yet.
        :param priority: The priority to start this thread at.
        """
        ...

    @abstractmethod
    def terminate(self) -> None:
        """Terminates the execution of this thread forcefully."""

    @abstractmethod
    def wait(self, timeout: int=-1) -> bool:
        """
        Waits for the given amount of time.
        :param timeout: The amount of time to wait for the thread.
        :return: True if the thread completed during the timeout, otherwise False.
        """
        ...

    @classmethod
    def __subclasshook__(cls, C) -> bool:
        """
        Attempts to determine if C is a subclass of this class.
        :param C: The class to check against this class.
        """
        if cls is ProtoThread:
            type_: Type = C if isinstance(C, type) else type(C)
            if cls is type_:
                return True
            return protocolhelpers.follows_protocol(C, cls,
                                                    'finished', 'started', 'event_dispatcher',
                                                    'is_finished', 'is_interruption_requested',
                                                    'is_running', 'loop_level', 'event', 'exit',
                                                    'request_interruption', 'run', 'start',
                                                    'terminate', 'wait',
                                                    'raise_if_interruption_requested', 'exec_',
                                                    check_type_annotations=True)
        return NotImplemented

