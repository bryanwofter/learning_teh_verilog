from PyQt5 import QtCore
from trc_packages.asynclib import protocols as protocols, errors, _service_status as s
from trc_packages.core import log
from typing import Callable, no_type_check, Optional, TypeVar
import time
Runnable = Callable[[], None]
R = TypeVar('R')


class _SharedServiceImpl:
    """
    This class is for internal use. Its only purpose is to implement a couple of functions that are always identical between the TrcService and TrcServiceManager classes.
    """

    @staticmethod
    def current_time() -> int:
        """Returns the current time of the system."""
        return int(round(time.time() * 1000))

    @no_type_check
    def _await_result(self, *, timeout: int=0) -> Optional[R]:
        """
        Attempts to await for the result of this service using the optional timeout.
        :param timeout: If greater than 0, the amount of time to wait between starting and forcefully ending the service.
        """
        if self.start():
            _is_running: Callable[[], bool] = lambda: self.is_running
            start_time: int = self.current_time() if timeout > 0 else 0

            while not self.yield_while(_is_running, attempts=10000 if timeout > 0 else -1):
                current_time: int = self.current_time() if timeout > 0 else 0

                if abs(current_time - start_time) > timeout:
                    raise errors.AwaitResultTimeoutError()

        return self.result

    @no_type_check
    def _raise_if_faulted(self) -> None:
        """Raises an exception if the service is currently considered faulted."""
        if self._status is s.ServiceStatus.FAULTED:
            exc: BaseException = self._exception

            if isinstance(exc, errors.WrappedServiceExceptionError):
                exc._raise(self)
            elif isinstance(exc, errors.ServiceException):
                raise exc
            else:
                raise errors.ServiceFaultedError(self, error_details=self._error_details) from exc

    @staticmethod
    @no_type_check
    def _running_later(runnable: Runnable) -> None:
        log.debug(f"Running {runnable} on UI thread")
        runnable()
        log.debug(f"{runnable} ran on UI thread")

    @no_type_check
    def _find_parent_service(self) -> Optional[protocols.Service]:
        """Attempts to find the parent service of this service."""
        main_thread: QtCore.QThread = QtCore.QCoreApplication.instance().thread()
        current_thread: QtCore.QThread = QtCore.QThread.currentThread()

        while current_thread is not None and current_thread != main_thread:
            parent: QtCore.QObject = current_thread.parent()
            if isinstance(current_thread, protocols.ProtoThread) and isinstance(parent, protocols.Service):
                return parent
            else:
                current_thread = current_thread.thread()

        return None

    @no_type_check
    def _run_later(self, runnable: Runnable) -> None:
        """
        Executes the provided runnable on the UI thread.
        :param runnable: The runnable to execute on the UI thread.
        """
        self._find_run_later_service().running_later.emit(runnable)

    @no_type_check
    def _find_run_later_service(self) -> protocols.Service:
        """Attempts to find the service that is used for emitting run_later calls."""
        current_service: protocols.Service = self

        while current_service.parent_service is not None:
            current_service = current_service.parent_service

        return current_service

    @no_type_check
    def _yield_until(self, expectation: bool, predicate: Callable[[], bool], *, attempts: int=10) -> bool:
        """
        Yields the execution of this thread until the provided predicate returns False.
        :param expectation: The expected result of the yield_until's predicate.
        :param predicate: The predicate to check.
        :param attempts: The number of times to check the predicate. A negative value means that there is no limit to the number of attempts.
        :return: True if the predicate evaluates to False within the given number of attempts, otherwise False.
        """
        tries: int = 0

        while predicate() is expectation:
            QtCore.QThread.yieldCurrentThread()
            self.raise_if_interrupted()
            if attempts > tries:
                tries += 1
            elif attempts > -1:
                return False

        return True

