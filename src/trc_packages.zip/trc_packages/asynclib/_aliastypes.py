from trc_packages.asynclib import protocols as protocols
from typing import Any, Callable, TypeVar
R = TypeVar('R')


ServiceLikeCallable = Callable[['protocols.Service[R]'], R]

