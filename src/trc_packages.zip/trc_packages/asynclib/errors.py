from PyQt5 import QtCore
from trc_packages.asynclib import protocols as protocols
from trc_packages.decorators import _singleton as s
from typing import Any, Iterable, List, Optional, Type
from types import TracebackType
import traceback
import weakref


@s.singleton
class InterruptionRequested(BaseException):
    """Raised whenever a service has an interruption requested. This is not a true exception and does not require catching."""


class AsyncException(Exception):
    """A base type for full exceptions within the asynclib."""


class InvalidRaiseInterruptionRequestedError(AsyncException):
    """Raised whenever _raise_if_interruption_requested is invoked from a thread other than the thread that the interruption was requested on."""

    @property
    def requesting_thread(self) -> QtCore.QThread:
        return self._requesting_thread

    @property
    def target_thread(self) -> QtCore.QThread:
        return self._target_thread

    def __init__(self, requesting_thread: QtCore.QThread, target_thread: QtCore.QThread, *args: Any, **kwargs: Any) -> None:
        super().__init__(requesting_thread, target_thread, *args, kwargs)

        self._requesting_thread: QtCore.QThread = requesting_thread
        self._target_thread: QtCore.QThread = target_thread


class CannotTakeLockError(AsyncException):
    """Raised when a lock cannot be taken."""


class ServiceException(AsyncException):
    """A base for all async exceptions related to the operation of Service instances."""


class ServiceStateException(ServiceException):
    """A base for all exceptions related to the service state."""


class ExternalStateAccessWhileRunningError(ServiceStateException):
    """Raised whenever a state access is requested external to the service while the service is running."""


class ExternalStateChangeWhileRunningError(ServiceStateException):
    """Raised whenever a state change is requested external to the service while the service is running."""


class YieldUntilRanLaterFaultedError(ServiceException):
    """Raised whenever yield_until_ran_later raises an exception."""


class AwaitResultTimeoutError(ServiceException):
    """Raised whenever a caller provides a timeout to the await_result function and that timeout is surpassed."""


class ReplacingRunningServiceTargetError(ServiceException):
    """Raised whenever a caller attempts to change the target of a TrcReusableFunctionService that is currently running."""


class ReplacingRunningServiceReadyPredicateError(ServiceException):
    """Raised whenever a caller attempts to change the ready predicate of a TrcReusableFunctionService that is currently running."""


class StartingUnboundServiceTargetError(ServiceException):
    """Raised whenever a caller attempts to start a TrcReusableFunctionService that is currently unbound."""


class ReturnCodeError(ServiceException):
    """Raised whenever an unknown return code is returned by the event loop of a TrcServiceExecutor."""

    @property
    def return_code(self) -> int:
        return self._return_code

    def __init__(self, return_code: int, *args: Any, **kwargs: Any) -> None:
        super().__init__(return_code, *args, kwargs)

        self._return_code: int = return_code


class ServiceFaultedError(ServiceException):
    """Raised whenever a service that is faulted is accessed."""

    @property
    def service(self) -> 'protocols.Service':
        return self._service

    def __init__(self, service: 'protocols.Service', *args: Any, **kwargs: Any) -> None:
        super().__init__(service, *args, kwargs)
        self._service = service


class AggregateServiceError(ServiceException):
    """Raised whenever multiple exceptions are raised within a service that can be aggregated."""

    @property
    def errors(self) -> List['protocols.ServiceErrorDetails']:
        return self._errors

    @property
    def service(self) -> Optional['protocols.Service']:
        return self._service

    def __init__(self, service: 'protocols.Service', errors: Iterable['protocols.ServiceErrorDetails'], *args: Any, **kwargs: Any) -> None:
        super().__init__(self, service, errors, *args, kwargs)
        self._service: weakref.ReferenceType = weakref.ref(service)
        self._errors = list(errors)


class AggregateServiceFaultedError(ServiceException):
    """Raised whenever a service executor has 1 or more child services fault."""

    @property
    def executor(self) -> 'protocols.Service':
        return self._executor

    @property
    def services(self) -> List['protocols.Service']:
        return self._services

    def __init__(self, executor: 'protocols.Service', services: List['protocols.Service'], *args: Any, **kwargs: Any) -> None:
        super().__init__(executor, services, *args, kwargs)
        self._executor: 'protocols.Service' = executor
        self._services: List['protocols.Service'] = services


class WrappedServiceExceptionError(ServiceException):
    """Wraps an exception raised within a service."""

    @property
    def exc_type(self) -> Type[BaseException]:
        return self._exc_type

    @property
    def exc(self) -> BaseException:
        return self._exc

    @property
    def tb(self) -> TracebackType:
        return self._tb

    def __init__(self, exc_type: Type[BaseException], exc: BaseException, tb: TracebackType, *args: Any, **kwargs: Any) -> None:
        super().__init__(exc_type, exc, tb, *args, kwargs)
        self._exc_type: Type[BaseException] = exc_type
        self._exc: BaseException = exc
        self._tb: TracebackType = tb

    def _raise(self, service: 'protocols.Service') -> None:
        """
        Raises the exception wrapped by this wrapper.
        :param service: The service that is re-raising this service exception.
        """
        raise ServiceFaultedError(service) from self.exc

    def __str__(self) -> str:
        return "\n".join(traceback.format_exception(self.exc_type, self.exc, self.tb))


class CannotAddServiceError(ServiceException):
    """Raised when a service cannot be added to a distributor."""


class CannotStartServiceError(ServiceException):
    """Raised when a service cannot be started."""


class CannotStartServiceManagerError(CannotStartServiceError):
    """Raised when services cannot be started by a distributor."""


class CannotStopServiceError(ServiceException):
    """Raised when a service cannot be stopped."""


class CannotStopServiceManagerError(CannotStopServiceError):
    """Raised when services cannot be stopped by a distributor."""


class ProgressiveException(AsyncException):
    """Represents a base for progressive and progressivemethod based exception."""


class NonProgressiveMethodError(ProgressiveException):
    """Raised when a non-progressive method is supplied to a call that epects a @progressivemethod decorated value."""


class ProgressiveTimeoutError(ProgressiveException):
    """Raised when a progressive step times out."""

