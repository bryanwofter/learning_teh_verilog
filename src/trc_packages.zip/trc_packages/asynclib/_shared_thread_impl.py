from PyQt5 import QtCore
from trc_packages.asynclib import errors
from typing import no_type_check


class _SharedThreadImpl:
    """
    Provides a small set of shared methods for ProtoThread inheritors.
    """

    @no_type_check
    def _raise_if_interruption_requested(self) -> None:
        """
        Raises an InterruptionRequested exception on this thread.
        
        This *must* be called on the thread that is being interrupted. If it is not, an InvalidRaiseInterruptionRequestedError will be raised.
        """
        if self.is_interruption_requested:
            current_thread: QtCore.QThread = QtCore.QThread.currentThread()
            if self is current_thread:
                raise errors.InterruptionRequested()
            else:
                raise errors.InvalidRaiseInterruptionRequestedError(current_thread, self)

