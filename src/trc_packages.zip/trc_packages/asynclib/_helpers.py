from PyQt5 import QtCore
from trc_packages.asynclib import _trc_service_executor as tse, _service_status as ss, protocols, _trc_reusable_function_service as trfs
from trc_packages.core.ui import _functions as f, _synchro as s
from typing import Any, Iterable, List, Optional
try:
    from typing import Final  # type: ignore
except ImportError:
    from typing_extensions import Final


class TrcExecutionContext(QtCore.QObject):
    """
    Used to execute the services within a TrcServiceExecutor so that the executor can focus on the event loop. Execution contexts should be used only once.
    """

    SUCCESS: Final[int] = 0
    CANNOT_START_SERVICE: Final[int] = 1
    SERVICE_FAULTED: Final[int] = 2

    lock: 's.Synchro' = None

    @property
    def is_faulted(self) -> bool:
        return any(self.exceptions)

    executor: 'tse.TrcServiceExecutor' = None
    started: bool = False
    exited: bool = False
    services: List['tse.ServiceTypeUnion'] = None
    current_services: List['protocols.Service[Any]'] = None
    results: List[Any] = None
    exceptions: List[protocols.ServiceErrorDetails] = None
    current_item: int = None
    timer_id: Optional[int] = None

    def __init__(self, parent: 'tse.TrcServiceExecutor') -> None:
        super().__init__(parent=None)
        self.current_item = 0
        self.executor = parent
        self.lock = s.Synchro()
        self.services = list(self.executor.services)
        self.current_services = []
        self.results = []
        self.exceptions = []

    def exec_(self) -> None:
        """
        Starts the execution of this execution context's services.
        """
        self.resume()

    def resume(self) -> None:
        """
        Continues the execution of this execution context's services.
        """
        with self.lock.synchronized(timeout=1_000_000_000, fail_on_timeout=True):
            if not self.exited:
                self.clear_completed_services()
                self.prepare_next_services()
                self.ensure_services_runnable()

                if self.ready_to_exit:
                    self.perform_exit(self.SUCCESS)
            self.started = True

    def _resolve_aggregates(self, error_details: Iterable['protocols.ServiceErrorDetails']) -> None:
        error_detail: protocols.ServiceErrorDetails
        for error_detail in error_details:
            if error_detail.is_aggregate_error:
                self._resolve_aggregates(error_detail.errors)
            else:
                self.exceptions.append(error_detail)

    def clear_completed_services(self) -> None:
        """
        Clears all services that have been completed and adds their results to the result list.
        """
        completed_services: List[protocols.Service[Any]] = [s for s in self.current_services if s.status in ss.ServiceStatus.FINISHED]

        completed_service: protocols.Service[Any]
        for completed_service in completed_services:
            f.safe_disconnect(completed_service.finished, self.resume)

            if completed_service.status is ss.ServiceStatus.FAULTED:
                self._resolve_aggregates([completed_service.error_details])
            else:
                self.results.append(completed_service.result)

            if isinstance(completed_service, trfs.TrcReusableFunctionService):
                completed_service.result_handled = True

            self.current_services.remove(completed_service)

        if any(self.exceptions):
            self.perform_exit(self.SERVICE_FAULTED)

    @property
    def ready_to_exit(self) -> bool:
        """
        Determines if the executor is ready to exit.
        """
        return self.started and not self.exited and self.current_item >= len(self.services) and not any(self.current_services)

    def perform_exit(self, return_code: int) -> None:
        """
        Handles exiting the event loop of the executor's thread using the given exit code.
        :param exit_code: The exit code to inform the executor why the context is being exited.
        """
        if not self.exited:
            self.exited = True
            self.executor._thread.exit(return_code)

    def prepare_next_services(self) -> None:
        """
        Prepares the next set of services for execution, adding them to the current services list and starting them.
        """
        original_blocker: tse.ServiceTypeUnion = None
        while self.current_item < len(self.services) and len(self.current_services) < self.executor.total_worker_services:
            next_service: tse.ServiceTypeUnion = self.services[self.current_item]

            if not isinstance(next_service, protocols.Service):
                replace_service: bool = False

                if self.executor._has_free_worker:
                    next_service = self.executor._next_worker(next_service)

                    if not next_service.is_ready:
                        replace_service = True
                    elif isinstance(next_service, trfs.TrcReusableFunctionService):
                        next_service.result_handled = False
                else:
                    replace_service = True

                if replace_service:
                    if original_blocker is None:
                        original_blocker = next_service
                    elif original_blocker is next_service:
                        break

                    self.services.remove(next_service)
                    self.services.append(next_service)
                    continue

            if next_service.status is ss.ServiceStatus.ABORTED:
                self.current_item += 1
                continue

            next_service.finished.connect(self.resume)

            if next_service.start():
                self.current_services.append(next_service)
                self.current_item += 1
            else:
                self.perform_exit(self.CANNOT_START_SERVICE)

    def ensure_services_runnable(self) -> None:
        """
        Determines if there are services runnable but no services currently running.
        """
        has_services_remaining: bool = self.current_item < len(self.services)
        has_services_running: bool = any(self.current_services)

        if self.timer_id is None:
            if has_services_remaining and not has_services_running:
                self.timer_id = self.executor.event_dispatcher.registerTime(1000, QtCore.Qt.VeryCoarseTimer, self)
        elif has_services_running:
            self.executor.event_dispatcher.unregisterTimer(self.timer_id)

    def timerEvent(self, event: QtCore.QTimerEvent) -> None:
        """
        Attempts to start the next service within this execution context if no services are currently executing.
        :param event: The timer event.
        """
        if event.timerId() == self.timer_id:
            event.accept()
            self.resume()

