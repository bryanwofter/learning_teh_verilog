from trc_packages.asynclib import _trc_service as ts
from typing import Any, Dict, Type, TypeVar
F = TypeVar('F')
S = TypeVar('S', bound='ts.TrcService')


_TOTAL_STEPS_CACHE: Dict[Type['ts.TrcService'], int] = {}


def step(fn: F) -> F:
    """
    Decorates a function as being a step.

    This decorator isn't directly used by the TrcService code. Instead, it provides a way for functions to be counted in a class that are going to act as a step within a service so that incrementing the progress
    property can be done easily.

    :param fn: The function to decorate.
    """
    if callable(fn):
        setattr(fn, '_isservicestep_', True)
    return fn


def total_steps(C: Type[S]) -> int:
    """
    Counts the total number of steps within the provided class.

    This will only include steps that are directly declared on the type. Parent-declared steps must be overridden and redeclared as steps to be counted.

    :param C: The class to count the steps of.
    """
    if C in _TOTAL_STEPS_CACHE:
        return _TOTAL_STEPS_CACHE[C]

    count: int = 0
    for value in C.__dict__.values():  # type: Any
        if callable(value) and hasattr(value, '_isservicestep_') and getattr(value, '_isservicestep_') is True:
            count += 1
    _TOTAL_STEPS_CACHE[C] = count

    return count
    
