from PyQt5 import QtCore
from trc_packages.core.ui import _synchro as s
from typing import Dict, Generic, no_type_check, Optional, Type, TypeVar
T = TypeVar('T')


class _ValueStorage(Generic[T]):

    __sync: s.Synchro = None
    __storage: Dict[int, T] = None

    @property
    def _local_data(self) -> T:
        return self.__storage.get(int(QtCore.QThread.currentThreadId()))

    @_local_data.setter
    def _local_data(self, local_data: T) -> None:
        id: int = int(QtCore.QThread.currentThreadId())
        current_thread: QtCore.QThread = QtCore.QThread.currentThread()
        if id not in self.__storage:
            def __dealloc() -> None:
                with self.__sync.synchronized(timeout=-1):
                    if id in self.__storage:
                        del self.__storage[id]
            with self.__sync.synchronized(timeout=-1):
                self.__storage[id] = None
                current_thread.finished.connect(__dealloc)  # type: ignore
        self.__storage[id] = local_data

    @_local_data.deleter
    def _local_data(self) -> None:
        self._local_data = None

    def __init__(self) -> None:
        self.__storage = {}
        self.__sync = s.Synchro()


class TrcThreadStorage(Generic[T]):
    """Provides a decorator that can be used to expose thread-dependent data."""

    __sync: s.Synchro = None

    name: Optional[str] = None

    def __init__(self, name: str) -> None:
        self.name = name
        self.__sync = s.Synchro()

    def __get__(self, instance: Optional[object], type: Type[object]) -> T:
        if instance is None:
            raise AttributeError(self.name)
        return self.__get_thread_storage(instance)._local_data

    def __set__(self, instance: object, value: T) -> None:
        self.__get_thread_storage(instance)._local_data = value

    def __delete__(self, instance: object) -> None:
        del self.__get_thread_storage(instance)._local_data

    @no_type_check
    def __get_thread_storage(self, instance: object) -> _ValueStorage[T]:
        if not hasattr(instance, self.name):
            with self.__sync.synchronized(timeout=-1):
                if not hasattr(instance, self.name):
                    setattr(instance, self.name, _ValueStorage())
        return getattr(instance, self.name)

