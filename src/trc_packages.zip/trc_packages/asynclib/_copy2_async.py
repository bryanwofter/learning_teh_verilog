from PyQt5 import QtCore
from trc_packages.asynclib import _trc_service as ts, _trc_function_service as tfs, _trc_reusable_function_service as trfs, _trc_service_executor as tse
from typing import Callable, Optional, overload
import os
import shutil


@overload
async def copy2_async(src: os.PathLike, dst: os.PathLike, *, executor: 'tse.TrcServiceExecutor', follow_symlinks: bool=True, parent: Optional[QtCore.QObject]=None) -> None:
    ...

@overload
async def copy2_async(src: os.PathLike, dst: os.PathLike, *, reusable_service: 'trfs.TrcReusableFunctionService', follow_symlinks: bool=True, parent: Optional[QtCore.QObject]=None) -> None:
    ...

@overload
async def copy2_async(src: os.PathLike, dst: os.PathLike, *, follow_symlinks: bool=True, parent: Optional[QtCore.QObject]=None) -> None:
    ...


async def copy2_async(src: os.PathLike,
                      dst: os.PathLike,
                      *,
                      executor: Optional['tse.TrcServiceExecutor']=None,
                      reusable_service: Optional['trfs.TrcReusableFunctionService']=None,
                      follow_symlinks: bool=True,
                      parent: Optional[QtCore.QObject]=None) -> None:
    """
    Performs the shutil.copy2 functionality using a TrcService.
    :param src: The source to copy.
    :param dst: The destination to copy to.
    :param executor: The executor to append this shutil.copy2 call to if needed.
    :param reusable_service: The reusable function service to execute this shutil.copy2 in.
    :param follow_symlinks: True if symbolic links should be followed, otherwise False.
    :param parent: The parent QtCore.QObject of the newly created service if one is needed.
    """
    __copy2: Callable[[ts.TrcService[None]], None] = lambda s: shutil.copy2(src, dst, follow_symlinks=follow_symlinks)

    service: ts.TrcService[None] = None
    maintained_locally: bool = False

    if executor is not None:
        executor.append(__copy2)
        service = executor
    elif reusable_service is not None:
        reusable_service.target = __copy2
        service = reusable_service
    else:
        service = tfs.TrcFunctionService(__copy2, parent=parent)
        maintained_locally = True

    await service

    if maintained_locally:
        service.deleteLater()

