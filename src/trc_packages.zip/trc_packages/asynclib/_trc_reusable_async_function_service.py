from trc_packages.asynclib import _trc_reusable_function_service as trfs


class TrcReusableAsyncFunctionService(trfs.TrcReusableFunctionService[trfs.R]):
    """
    Provides a TrcService implementation that wraps around an async function that accepts a TrcService as its argument and that can have the function replaced at any given time.
    """

    async def _run_async(self) -> trfs.R:
        return await self.target(self)

