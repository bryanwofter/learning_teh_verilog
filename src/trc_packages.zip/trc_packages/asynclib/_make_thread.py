from PyQt5 import QtCore
from trc_packages.asynclib import protocols, _trc_mock_thread as tmt, _trc_thread as tt
from trc_packages.core.types import Runnable
from typing import Optional
import trc_packages


def make_thread(runnable: Runnable, parent: Optional[QtCore.QObject]=None) -> protocols.ProtoThread:
    """
    Creates a new TrcThread or TrcMockThread that executes the given runnable.
    :param runnable: The runnable to execute within the thread.
    :param parent: The optional parent object of the thread.
    :return: The thread to execute the runnable on.
    """
    return tmt.TrcMockThread(runnable, parent=parent) if trc_packages.UNIT_TEST or trc_packages.MOCK_THREADS else tt.TrcThread(runnable, parent=parent)

