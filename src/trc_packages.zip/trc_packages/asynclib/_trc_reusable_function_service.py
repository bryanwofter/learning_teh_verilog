from PyQt5 import QtCore
from trc_packages.asynclib import _trc_service as t, errors
from trc_packages.core.types import Predicate
from typing import Optional, TypeVar
R = TypeVar('R')


class TrcReusableFunctionService(t.TrcService[R]):
    """
    Provides a TrcService implementation that wraps around a function that accepts a TrcService as its argument and that can have the function replaced at any given time.
    """

    __target: Optional['at.ServiceLikeCallable[R]'] = None

    __result_handled: bool = True
    @property
    def result_handled(self) -> bool:
        return self.__result_handled

    @result_handled.setter
    def result_handled(self, result_handled: bool) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            self.__result_handled = result_handled

    @result_handled.deleter
    def result_handled(self) -> None:
        self.result_handled = False

    @property
    def target(self) -> Optional['at.ServiceLikeCallable[R]']:
        return self.__target

    @target.setter
    def target(self, target: Optional['at.ServiceLikeCallable[R]']) -> None:
        if not self.is_running:
            with self._lock.synchronized(fail_on_timeout=True):
                if not self.is_running:
                    del self._exception
                    del self._progress
                    del self._status
                    del self._result
                    del self.ready_predicate
                    del self.result_handled
                    self.__target = target
                else:
                    raise errors.ReplacingRunningServiceTargetError()

        else:
            raise errors.ReplacingRunningServiceTargetError()

    @target.deleter
    def target(self) -> None:
        self.target = None

    @property
    def ready_predicate(self) -> Optional[Predicate]:
        return self._ready_predicate

    @ready_predicate.setter
    def ready_predicate(self, ready_predicate: Optional[Predicate]) -> None:
        if not self.is_running:
            with self._lock.synchronized(fail_on_timeout=True):
                if not self.is_running:
                    self._ready_predicate = ready_predicate
                else:
                    raise errors.ReplacingRunningServiceReadyPredicateError()
        else:
            raise errors.ReplacingRunningServiceReadyPredicateError()

    @ready_predicate.deleter
    def ready_predicate(self) -> None:
        self.ready_predicate = None

    @property
    def is_bound(self) -> bool:
        return self.__target is not None

    def __init__(self, target: Optional['at.ServiceLikeCallable[R]']=None, parent: Optional[QtCore.QObject]=None, *, ready_predicate: Optional[Predicate]=None) -> None:
        super().__init__(parent=parent, ready_predicate=ready_predicate)

        self.__target = target

    def start(self) -> bool:
        if self.__target is None:
            raise errors.StartingUnboundServiceTargetError()
        return super().start()

    def _run(self) -> R:
        return super()._run()

    async def _run_async(self) -> R:
        return self.__target(self)

