from PyQt5 import QtCore
from trc_packages.asynclib import protocols, _shared_thread_impl as _st
from trc_packages.core.types import Runnable
from typing import Optional
import functools
_process_events: Runnable = functools.partial(QtCore.QCoreApplication.processEvents, QtCore.QEventLoop.ExcludeUserInputEvents)


class TrcMockThread(_st._SharedThreadImpl, QtCore.QObject, protocols.ProtoThread):
    """
    Provides a thread-like object for use in unit test.
    """

    finished: QtCore.pyqtSignal = QtCore.pyqtSignal()
    started: QtCore.pyqtSignal = QtCore.pyqtSignal()

    _run: Optional[Runnable] = None

    @property
    def event_dispatcher(self) -> Optional[QtCore.QAbstractEventDispatcher]:
        return self._event_dispatcher

    @event_dispatcher.setter
    def event_dispatcher(self, value: Optional[QtCore.QAbstractEventDispatcher]) -> None:
        self._event_dispatcher = value

    @event_dispatcher.deleter
    def event_dispatcher(self) -> None:
        self.event_dispatcher = None

    @property
    def is_finished(self) -> bool:
        return self._is_finished

    @is_finished.setter
    def is_finished(self, value: bool) -> None:
        self._is_finished = value
        if value:
            self.finished.emit()

    @is_finished.deleter
    def is_finished(self) -> None:
        self.is_finished = False

    @property
    def is_interruption_requested(self) -> bool:
        return self._is_interruption_requested

    @is_interruption_requested.setter
    def is_interruption_requested(self, value: bool) -> None:
        self._is_interruption_requested = value

    @is_interruption_requested.deleter
    def is_interruption_requested(self) -> None:
        self.is_interruption_requested = None

    @property
    def is_running(self) -> bool:
        return self._is_running

    @is_running.setter
    def is_running(self, value: bool) -> None:
        self._is_running = value
        if value:
            self.started.emit()

    @is_running.deleter
    def is_running(self) -> None:
        self.is_running = False

    @property
    def loop_level(self) -> int:
        return 1

    def __init__(self, runnable: Runnable, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)
        self._run = runnable
        self._is_running = False
        self._is_finished = False
        self._is_interruption_requested = False
        self._event_dispatcher = None
        self.started.connect(_process_events)
        self.finished.connect(_process_events)

    def event(self, event: QtCore.QEvent) -> bool:
        return False

    def exec_(self) -> int:
        return 0

    def exit(self, return_code: int=0) -> None:
        pass

    def raise_if_interruption_requested(self) -> None:
        self._raise_if_interruption_requested()

    def request_interruption(self) -> None:
        self.is_interruption_requested = True

    def run(self) -> None:
        self._run()

    def start(self, priority: QtCore.QThread.Priority=QtCore.QThread.InheritPriority) -> None:
        if not self.is_running:
            try:
                self.is_finished = False
                self.is_running = True
                self.run()
            finally:
                self.is_running = False
                self.is_finished = True

    def terminate(self) -> None:
        self.exit(0)

    def wait(self, timeout: int=-1) -> bool:
        _process_events()
        return True

