from PyQt5 import QtCore
from trc_packages.core.types import Runnable
from typing import Optional


class TrcRunnable(QtCore.QRunnable):
    """
    Provides a runnable type that can be used to execute code in QThreadPool instances.
    """

    _run: Optional[Runnable] = None

    def __init__(self, run: Runnable) -> None:
        super().__init__()
        self._run = run

    def run(self) -> None:
        """Executes this runnable within the QThreadPool."""
        self._run()

    def __call__(self) -> None:
        """Executes this runnable inline."""
        self._run()

    def __str__(self) -> str:
        return str(self._run)

    def __repr__(self) -> str:
        return f"TrcRunnable({self._run})"

