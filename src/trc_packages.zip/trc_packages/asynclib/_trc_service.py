from PyQt5 import QtCore
from trc_packages.asynclib import (_service_status as s,
                                   errors as errors,
                                   protocols as protocols,
                                   _shared_service_impl as _ssi,
                                   _make_thread as mt)
from trc_packages.core import _functions as f, log
from trc_packages.core.types import Runnable, Predicate
from trc_packages.core.ui import _synchro as sync, _block_signals as bs
from typing import (Any, Callable, Generic, Optional, TypeVar)
import asyncio
import traceback
import sys
R = TypeVar('R')


class TrcService(Generic[R], _ssi._SharedServiceImpl, QtCore.QObject, protocols.Service[R]):
    """
    Provides a service framework that simplifies (or at least attempts to?) threading by abstracting away the thread management aspect and providing
    convenience signals for knowing when steps are completed within the service.
    """

    exception_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([], ['PyQt_PyObject'], name='exceptionChanged', arguments=['exception'])  # type: ignore
    progress_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([], [float], name='progressChanged', arguments=['progress'])  # type: ignore
    status_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([], ['PyQt_PyObject'], name='statusChanged', arguments=['status'])  # type: ignore
    result_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([], ['PyQt_PyObject'], name='resultChanged', arguments=['result'])  # type: ignore
    aborted: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='aborted')
    started: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='started')
    canceled: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='canceled')
    completed: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='completed')
    faulted: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='faulted')
    finished: QtCore.pyqtSignal = QtCore.pyqtSignal([], ['PyQt_PyObject'], name='finished', arguments=['result'])  # type: ignore
    running_later: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject'], name='runningLater', arguments=['callable'])  # type: ignore

    # region Is Ready
    _ready_predicate: Optional[Predicate] = None
    @property
    def is_ready(self) -> bool:
        return self._ready_predicate is None or self._ready_predicate()
    # endregion

    # region Is Active
    @property
    def is_active(self) -> bool:
        return self.__thread == QtCore.QThread.currentThread()
    # endregion

    # region Is Running
    @property
    def is_running(self) -> bool:
        return self._status is s.ServiceStatus.RUNNING or self.__thread.is_running
    # endregion

    # region State
    __state: Optional[Any] = None

    @property
    def state(self) -> Optional[Any]:
        if not self.is_running or self.is_active:
            return self.__state
        else:
            raise errors.ExternalStateAccessWhileRunningError()

    @state.setter
    def state(self, state: Optional[Any]) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            if not self.is_running or self.is_active:
                self.__state = state
            else:
                raise errors.ExternalStateChangeWhileRunningError()

    @state.deleter
    def state(self) -> None:
        self.state = None
    # endregion

    # region Event Dispatcher
    @property
    def event_dispatcher(self) -> Optional[QtCore.QAbstractEventDispatcher]:
        return self.__thread.event_dispatcher

    # region Error Details
    __error_details: Optional[protocols.ServiceErrorDetails] = None

    @property
    def _error_details(self) -> Optional[protocols.ServiceErrorDetails]:
        with self._lock.synchronized(fail_on_timeout=True):
            return self.__error_details

    @_error_details.setter
    def _error_details(self, error_details: Optional[protocols.ServiceErrorDetails]) -> None:
        previous_error_details: Optional[protocols.ServiceErrorDetails] = None

        with self._lock.synchronized(fail_on_timeout=True):
            previous_error_details = self.__error_details
            self.__error_details = error_details

        if previous_error_details != error_details:
            self._exception = None if error_details is None else error_details.exc

    @_error_details.deleter
    def _error_details(self) -> None:
        self._error_details = None

    @property
    def error_details(self) -> Optional[protocols.ServiceErrorDetails]:
        return self.__error_details

    # endregion

    # region Exception
    __exception: Optional[BaseException] = None

    @property
    def _exception(self) -> Optional[BaseException]:
        with self._lock.synchronized(fail_on_timeout=True):
            return self.__exception

    @_exception.setter
    def _exception(self, exception: Optional[BaseException]) -> None:
        previous_exception: Optional[BaseException] = None

        with self._lock.synchronized(fail_on_timeout=True):
            previous_exception = self.__exception
            self.__exception = exception

        if previous_exception != exception:
            self.exception_changed.emit()
            self.exception_changed['PyQt_PyObject'].emit(exception)  # type: ignore
            if isinstance(exception, errors.AggregateServiceError):
                for error in exception.errors:
                    log.error('Internal async aggregate exception encountered: ', exc_info=(error.exc_type, error.exc, error.tb))
            if exception is not None:
                log.error('Exception encountered: ', exc_info=exception)

    @_exception.deleter
    def _exception(self) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            if not f.attrempty(self, '_TrcService__exception'):
                del self.__exception

    @property
    def exception(self) -> Optional[BaseException]:
        return self.__exception
    # endregion

    # region Progress
    __progress: float = 0.0

    @property
    def _progress(self) -> float:
        with self._lock.synchronized(fail_on_timeout=True):
            return self.__progress

    @_progress.setter
    def _progress(self, progress: float) -> None:
        previous_progress: float = 0.0

        with self._lock.synchronized(fail_on_timeout=True):
            previous_progress = self.__progress
            self.__progress = progress

        if previous_progress != progress:
            self.progress_changed.emit()
            self.progress_changed[float].emit(progress)  # type: ignore

    @_progress.deleter
    def _progress(self) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            if not f.attrempty(self, '_TrcService__progress'):
                self.__progress = 0.0

    @property
    def progress(self) -> float:
        self.raise_if_faulted()
        return self.__progress
    # endregion

    # region Status
    __status: s.ServiceStatus = s.ServiceStatus.CREATED

    @property
    def _status(self) -> s.ServiceStatus:
        with self._lock.synchronized(fail_on_timeout=True):
            return self.__status

    @_status.setter
    def _status(self, status: s.ServiceStatus) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            previous_status: s.ServiceStatus = self.__status
            if previous_status is s.ServiceStatus.RUNNING and status is s.ServiceStatus.ABORTED:
                return

            self.__status = status

            if previous_status is not status:
                self.status_changed.emit()
                self.status_changed['PyQt_PyObject'].emit(status)  # type: ignore
                if previous_status is s.ServiceStatus.RUNNING:
                    finished: bool = True
                    if status is s.ServiceStatus.CANCELED:
                        self.canceled.emit()
                    elif status is s.ServiceStatus.COMPLETED:
                        self.completed.emit()
                    elif status is s.ServiceStatus.FAULTED:
                        self.faulted.emit()
                    else:
                        finished = False
                    if finished:
                        self.finished.emit()
                        self.finished['PyQt_PyObject'].emit(self.__result)  # type: ignore
                elif status is s.ServiceStatus.RUNNING:
                    self.started.emit()
                elif status is s.ServiceStatus.ABORTED:
                    self.aborted.emit()

    @_status.deleter
    def _status(self) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            if not f.attrempty(self, '_TrcService__status'):
                self.__status = s.ServiceStatus.CREATED

    @property
    def status(self) -> s.ServiceStatus:
        return self.__status
    # endregion

    # region Result
    __result: R = None

    @property
    def _result(self) -> R:
        with self._lock.synchronized(fail_on_timeout=True):
            return self.__result

    @_result.setter
    def _result(self, result: R) -> None:
        previous_result: R = None

        with self._lock.synchronized(fail_on_timeout=True):
            previous_result = self.__result
            self.__result = result

        if previous_result != result:
            self.result_changed.emit()
            self.result_changed['PyQt_PyObject'].emit(result)  # type: ignore

    @_result.deleter
    def _result(self) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            if not f.attrempty(self, '_TrcService__result'):
                del self.__result

    @property
    def result(self) -> R:
        self.raise_if_faulted()
        return self.__result
    # endregion

    # region Parent Service
    __parent_service: Optional[protocols.Service] = None

    @property
    def parent_service(self) -> Optional[protocols.Service]:
        return self.__parent_service
    # endregion

    _lock: 'sync.Synchro' = None
    __thread: protocols.ProtoThread = None

    @property
    def _thread(self) -> protocols.ProtoThread:
        return self.__thread

    def __init__(self, parent: Optional[QtCore.QObject]=None, *, ready_predicate: Optional[Callable[[], bool]]=None) -> None:
        super().__init__(parent=parent)
        self._lock = sync.Synchro()
        self.__thread = mt.make_thread(self.run, parent=self)
        self.__parent_service = self._find_parent_service()
        self._ready_predicate = ready_predicate
        self.running_later.connect(self._running_later)

    @QtCore.pyqtSlot(result=bool, name='start')  # type: ignore
    def start(self) -> bool:
        """
        Attempts to begin execution of this service.
        :return: True if the service is started successfully, otherwise False.
        """
        if not self.is_running and self.is_ready and self.status is not s.ServiceStatus.ABORTED:
            log.debug(f"Starting thread {self.__thread}")
            del self._status
            del self._exception
            del self._result
            del self._progress
            self.__thread.start()
            log.debug(f"{self.__thread} started")
        return self.is_running

    @QtCore.pyqtSlot(result='bool', name='abort')
    def abort(self) -> bool:
        """
        Attempts to abort this service so long as it hasn't been started yet.
        """
        if not self.is_running:
            self._status = s.ServiceStatus.ABORTED
            return not self.is_running and self.status is s.ServiceStatus.ABORTED
        return False

    @QtCore.pyqtSlot(result='bool', name='clear_abort')
    def clear_abort(self) -> bool:
        """
        Attempts to clear the abort flag of this service.
        """
        if not self.is_running and self.status is s.ServiceStatus.ABORTED:
            self._status = s.ServiceStatus.CREATED
        return self.status is not s.ServiceStatus.ABORTED

    def __await__(self):
        """
        Attempts to wait for this service to complete execution.
        :return: The result of this service.
        """
        if self.start():
            log.debug(f"Awaiting {self.__thread}")
            _is_running: Predicate = lambda: self.is_running
            while not self.yield_while(_is_running, attempts=100):
                yield
            log.debug(f"{self.__thread} awaited")
        return self.result

    def await_result(self, *, timeout: int=0) -> Optional[R]:
        """
        Attempts to await for the result of this service using the optional timeout.
        :param timeout: If greater than 0, the amount of time to wait between starting and forcefully ending the service.
        """
        try:
            log.debug(f"Awaiting result of {self.__thread}")
            return self._await_result(timeout=timeout)
        finally:
            log.debug(f"Result awaited of {self.__thread}")

    def process_events(self, *args: Any, **kwargs: Any) -> bool:
        """
        Processes the events of the thread.
        """
        try:
            log.debug(f"Processing events of {self.__thread}")
            return self.__thread.event_dispatcher.processEvents(QtCore.QEventLoop.AllEvents)
        finally:
            log.debug(f"Events of {self.__thread} processed")

    @QtCore.pyqtSlot(int, result=bool, name='stop')  # type: ignore
    @QtCore.pyqtSlot(result=bool, name='stop')  # type: ignore
    def stop(self, timeout: int=10000) -> bool:
        """
        Attempts to stop the execution of this service.
        :param timeout: The amount of time to wait for the thread to stop.
        :return: True if the service is stopped successfully, otherwise False.
        """
        if self.is_running:
            log.debug(f"Stopping thread {self.__thread}")
            self.__thread.terminate()
            self.__thread.wait(timeout)
            if self._status is s.ServiceStatus.RUNNING and not self.__thread.is_running:
                self.reset_progress()
                self._status = s.ServiceStatus.CANCELED
                log.debug(f"{self.__thread} stopped")
            else:
                log.debug(f"Failed to stop {self.__thread} - Deadlocked?")
        return not self.is_running

    @QtCore.pyqtSlot(name='raiseIfFaulted')
    def raise_if_faulted(self) -> None:
        """Raises the exception of this service if one exists."""
        self._raise_if_faulted()

    @QtCore.pyqtSlot(name='raiseIfInterrupted')
    def raise_if_interrupted(self) -> None:
        """
        Raises an InterruptionRequested error if the service's thread has had an interruption requested.
        This must only be called on the thread represented by this service. If called anywhere else, an InvalidRaiseInterruptionRequestedError will be raised on the calling thread.
        """
        self.__thread.raise_if_interruption_requested()

    @QtCore.pyqtSlot(name='resetProgress')
    def reset_progress(self) -> None:
        """
        Safely resets the progress of this service if it isn't running. This is to allow external code to set the
        progress to 0 safely without having to interact with the properties.
        """
        log.debug(f"Resetting progress of {self.__thread}")
        if not self.is_running:
            with bs.block_signals(self):
                del self._exception
                del self._result
                del self._progress
                self._status = s.ServiceStatus.CREATED
            log.debug(f"Reset progress of {self.__thread}")
        else:
            log.debug(f"Failed resetting progress of {self.__thread} - Already running?")

    @QtCore.pyqtSlot(int, result=bool, name='restart')  # type: ignore
    @QtCore.pyqtSlot(result=bool, name='restart')  # type: ignore
    def restart(self, timeout: int=10000) -> bool:
        """
        Attempts to restart execution of this service. Restart is equivalent to calling stop() and start().
        :return: True if the service is stopped and then started successfully, otherwise False.
        """
        return self.stop(timeout) and self.start()

    @QtCore.pyqtSlot(name='requestInterruption')
    def request_interruption(self) -> None:
        """Attempts to interrupt the thread of this service."""
        self.__thread.request_interruption()

    def run(self) -> None:
        """Executes this service, updating the status along with catching any potential exceptions that may arise."""
        try:
            log.debug(f"Executing thread {self.__thread}")
            self._status = s.ServiceStatus.RUNNING
            self._result = self._run()
            self._status = s.ServiceStatus.COMPLETED
            log.debug(f"{self.__thread} executed")
        except errors.InterruptionRequested:
            self._status = s.ServiceStatus.INTERRUPTED
        except BaseException as e:
            log.error(f"{self.__thread} faulted", exc_info=e)
            self._status = s.ServiceStatus.FAULTED
            self._error_details = protocols.ServiceErrorDetails(*sys.exc_info())
        finally:
            self.yield_while(self.process_events, attempts=-1)
            if self.is_active and self.event_dispatcher is not None:
                self.__thread.exit()

    def run_later(self, runnable: Callable[[], None]) -> None:
        """
        Executes the provided runnable on the UI thread.
        :param runnable: The runnable to execute on the UI thread.
        """
        self._run_later(runnable)

    def yield_until(self, predicate: Predicate, *, attempts: int=10) -> bool:
        """
        Yields the execution of this thread until the provided predicate returns True, returning True if this occurs, or False otherwise.
        :param predicate: The predicate to check.
        :param attempts: The number of times to check the predicate before considering the yield_until a failure.
        """
        return self._yield_until(False, predicate, attempts=attempts)

    def yield_until_ran_later(self, runnable: Runnable, *, attempts: int=10) -> bool:
        """
        Yields the execution of this thread until the provided runnable is executed on the main thread. If an exception is raised during execution,
        it will be captured and raised in the calling context.
        :param runnable: The runnable to execute on the main thread.
        :param attempts: The number of times to yield execution before considering the yield_until a failure.
        """
        ran_later: bool = False
        exception: Optional[BaseException] = None

        def __run_later() -> None:
            nonlocal ran_later
            nonlocal exception

            try:
                runnable()
            except BaseException as e:
                exception = e
            finally:
                ran_later = True

        self.run_later(__run_later)
        self.yield_until(lambda: ran_later, attempts=attempts)

        if exception is None:
            return ran_later
        else:
            raise errors.YieldUntilRanLaterFaultedError() from exception

    def yield_while(self, predicate: Callable[[], bool], *, attempts: int=10) -> bool:
        """
        Yields the execution of this thread until the provided predicate returns False, returning True if this occurs, or False otherwise.
        :param predicate: The predicate to check.
        :param attempts: The number of times to check the predicate before considering the yield_until a failure.
        """
        return self._yield_until(True, predicate, attempts=attempts)

    @QtCore.pyqtSlot(int, result=bool, name='wait')  # type: ignore
    @QtCore.pyqtSlot(result=bool, name='wait')  # type: ignore
    def wait(self, timeout: int=10000) -> bool:
        """
        Waits for this service to complete for up to the given timeout.
        :param timeout: The amount of time to wait for this service.
        :return: True if the wait is successful, otherwise False.
        """
        return self.__thread.wait(timeout)

    def _run(self) -> R:
        """The code to execute within the service. This should not be called directly."""
        return asyncio.run(self._run_async())

    async def _run_async(self) -> R:
        """The async equivalent to the _run method so that 'await' syntax may be used within the service body."""
        return None

