from PyQt5 import QtCore
from trc_packages.asynclib import protocols as protocols, _service_status as s, _trc_function_service as t, _shared_service_impl as _ssi
from trc_packages.core import _functions as f
from trc_packages.core.ui import _synchro as sync
from typing import Any, Callable, Iterable, List, NamedTuple, Optional, Union
ServiceErrorPair = NamedTuple('ServiceErrorPair', [('service', protocols.Service), ('exc', BaseException)])
ServiceProgressPair = NamedTuple('ServiceProgressPair', [('service', protocols.Service), ('progress', float)])
ServiceStatusPair = NamedTuple('ServiceStatusPair', [('service', protocols.Service), ('status', s.ServiceStatus)])
ServiceResultPair = NamedTuple('ServiceResultPair', [('service', protocols.Service), ('result', Any)])
Servable = Union[protocols.Service, Callable[[protocols.Service], Any]]


class TrcServiceManager(_ssi._SharedServiceImpl, QtCore.QObject, protocols.Service[Any]):
    """
    Provides a manager for multiple TrcServices at once.
    """

    exception_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([], ['PyQt_PyObject', 'PyQt_PyObject'], name='exceptionChanged')
    progress_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([], ['PyQt_PyObject', float], [float], name='progressChanged')
    status_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], ['PyQt_PyObject'], name='statusChanged')
    result_changed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='resultChanged')
    started: QtCore.pyqtSignal = QtCore.pyqtSignal([], ['PyQt_PyObject'], name='started')
    canceled: QtCore.pyqtSignal = QtCore.pyqtSignal([], ['PyQt_PyObject'], name='canceled')
    completed: QtCore.pyqtSignal = QtCore.pyqtSignal([], ['PyQt_PyObject'], name='completed')
    faulted: QtCore.pyqtSignal = QtCore.pyqtSignal([], ['PyQt_PyObject'], name='faulted')
    finished: QtCore.pyqtSignal = QtCore.pyqtSignal([], ['PyQt_PyObject', 'PyQt_PyObject'], ['PyQt_PyObject'], name='finished')
    running_later: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject'], name='runningLater')

    # region Is Running
    @property
    def is_running(self) -> bool:
        return self._status is s.ServiceStatus.RUNNING
    # endregion

    # region Exception
    __exception: Optional[ServiceErrorPair] = None

    @property
    def _exception(self) -> Optional[ServiceErrorPair]:
        with self._lock.synchronized(fail_on_timeout=True):
            return self.__exception

    @_exception.setter
    def _exception(self, exception: Optional[ServiceErrorPair]) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            if self.__exception != exception:
                self.__exception = exception
                if exception is not None:
                    self.exception_changed['PyQt_PyObject', 'PyQt_PyObject'].emit(*exception)  # type: ignore

    @_exception.deleter
    def _exception(self) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            if not f.attrempty(self, '_TrcServiceManager__exception'):
                del self.__exception

    @property
    def exception(self) -> Optional[ServiceErrorPair]:  # type: ignore
        """Gets the *most recent* exception raised along with its associated service."""
        return self.__exception
    # endregion

    # region Progress
    __progress: float = 0.0

    @property
    def _progress(self) -> float:
        with self._lock.synchronized(fail_on_timeout=True):
            return self.__progress

    @_progress.setter
    def _progress(self, progress: float) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            if self.__progress != progress:
                self.__progress = progress
                self.progress_changed[float].emit(progress)  # type: ignore

    @_progress.deleter
    def _progress(self) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            if not f.attrempty(self, '_TrcServiceManager__progress'):
                del self.__progress

    @property
    def progress(self) -> float:
        """Gets the *total* progress of all services."""
        return self.__progress
    # endregion

    # region most_recent_progress
    __most_recent_progress: Optional[ServiceProgressPair] = None

    @property
    def _most_recent_progress(self) -> Optional[ServiceProgressPair]:
        with self._lock.synchronized(fail_on_timeout=True):
            return self.__most_recent_progress

    @_most_recent_progress.setter
    def _most_recent_progress(self, most_recent_progress: Optional[ServiceProgressPair]) -> None:
        progess_changed: bool = False
        total_progress: float = 0.0
        with self._lock.synchronized(fail_on_timeout=True):
            if self.__most_recent_progress != most_recent_progress:
                self.__most_recent_progress = most_recent_progress
                if most_recent_progress is not None:
                    self.progress_changed['PyQt_PyObject', float].emit(*most_recent_progress)  # type: ignore
                    progress_changed = True
                    total_services: int = len(self._services)

                    for service in self._services:
                        total_progress += (service.progress / total_services)

        if progress_changed:
            self._progress = total_progress

    @_most_recent_progress.deleter
    def _most_recent_progress(self) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            if not f.attrempty(self, '_TrcServiceManager__most_recent_progress'):
                del self.__most_recent_progress

    @property
    def most_recent_progress(self) -> Optional[ServiceProgressPair]:
        """Gets the *most recent* progress of any service."""
        return self.__most_recent_progress
    # endregion

    # region status
    def __emit_specialized_status_changed(self, service: Optional[protocols.Service], pstatus: s.ServiceStatus, status: s.ServiceStatus) -> None:
        """
        Emits a more specialized signal for the optional service and its status.
        :param service: The service that triggered the status change.
        :param pstatus: The previous status.
        :param status: The new status.
        """
        if pstatus is s.ServiceStatus.RUNNING or pstatus is None:
            finished: bool = True
            if status is s.ServiceStatus.CANCELED:
                if service is None:
                    self.canceled.emit()
                else:
                    self.canceled['PyQt_PyObject'].emit(service)  # type: ignore
            elif status is s.ServiceStatus.COMPLETED:
                if service is None:
                    self.completed.emit()
                else:
                    self.completed['PyQt_PyObject'].emit(service)  # type: ignore
            elif status is s.ServiceStatus.FAULTED:
                if service is None:
                    self.faulted.emit()
                else:
                    self.faulted['PyQt_PyObject'].emit(service)  # type: ignore
            else:
                finished = False
                if finished:
                    if service is None:
                        # Trigger the global finished with a list of results.
                        self.finished['PyQt_PyObject'].emit([s.result for s in self._services])  # type: ignore
                    else:
                        self.finished['PyQt_PyObject'].emit(service, service.result)  # type: ignore
        elif status is s.ServiceStatus.RUNNING:
            if service is None:
                self.started.emit()
            else:
                self.started['PyQt_PyObject'].emit(service)  # type: ignore

    __status: s.ServiceStatus = s.ServiceStatus.CREATED

    @property
    def _status(self) -> s.ServiceStatus:
        with self._lock.synchronized(fail_on_timeout=True):
            return self.__status

    @_status.setter
    def _status(self, status: s.ServiceStatus) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            if self.__status != status:
                pstatus: s.ServiceStatus = self.__status
                self.__status = status
                self.status_changed['PyQt_PyObject'].emit(status)  # type: ignore
                self.__emit_specialized_status_changed(None, pstatus, status)

    @_status.deleter
    def _status(self) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            if not f.attrempty(self, '_TrcServiceManager__status'):
                del self.__status

    @property
    def status(self) -> s.ServiceStatus:
        """Gets the total running status of this TrcServiceManager."""
        return self.__status
    # endregion

    # region most_recent_status
    __most_recent_status: Optional[ServiceStatusPair] = None

    @property
    def _most_recent_status(self) -> Optional[ServiceStatusPair]:
        with self._lock.synchronized(fail_on_timeout=True):
            return self.__most_recent_status

    @_most_recent_status.setter
    def _most_recent_status(self, most_recent_status: Optional[ServiceStatusPair]) -> None:
        new_status: s.ServiceStatus = s.ServiceStatus.CREATED
        status_changed: bool = False
        with self._lock.synchronized(fail_on_timeout=True):
            if self.__most_recent_status != most_recent_status:
                self.__most_recent_status = most_recent_status
                if most_recent_status is not None:
                    status_changed = True
                    self.status_changed['PyQt_PyObject', 'PyQt_PyObject'].emit(*most_recent_status)  # type: ignore
                    self.__emit_specialized_status_changed(most_recent_status.service, None, most_recent_status.status)

                    if all((service.status & s.ServiceStatus.FINISHED) for service in self._services):
                        new_status = s.ServiceStatus.COMPLETED
                    elif any((service.status is s.ServiceStatus.RUNNING) for service in self._services):
                        new_status = s.ServiceStatus.RUNNING

        if status_changed:
            self._status = new_status

    @_most_recent_status.deleter
    def _most_recent_status(self) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            if not f.attrempty(self, '_TrcServiceManager__most_recent_status'):
                del self.__most_recent_status

    @property
    def most_recent_status(self) -> Optional[ServiceStatusPair]:
        """Gets the *most recent* status of any service."""
        return self.__most_recent_status
    # endregion

    # region Result
    __result: Optional[ServiceResultPair] = None

    @property
    def _result(self) -> Optional[ServiceResultPair]:
        with self._lock.synchronized(fail_on_timeout=True):
            return self.__result

    @_result.setter
    def _result(self, result: Optional[ServiceResultPair]) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            if self.__result != result:
                self.__result = result
                if result is not None:
                    self.result_changed['PyQt_PyObject', 'PyQt_PyObject'].emit(*result)  # type: ignore

    @_result.deleter
    def _result(self) -> None:
        with self._lock.synchronized(fail_on_timeout=True):
            if not f.attrempty(self, '_TrcServiceManager__result'):
                del self.__result

    @property
    def result(self) -> Optional[ServiceResultPair]:
        return self.__result
    # endregion

    # region Parent Service
    __parent_service: Optional[protocols.Service] = None

    @property
    def parent_service(self) -> Optional[protocols.Service]:
        return self.__parent_service
    # endregion

    _lock: 'sync.Synchro' = None
    _services: List[protocols.Service] = None
    _execution_count: int = 2
    _current_service: int = 0

    def __start_next_service(self) -> bool:
        starting_service: bool = False
        current_service: int = 0
        with self._lock.synchronized(timeout=60000, fail_on_timeout=True):
            if self._current_service < len(self._services):
                current_service = self._current_service
                self._current_service += 1
                starting_service = True
        return starting_service and self._services[current_service].start()

    def __bind_service_signals(self, service: protocols.Service[Any]) -> protocols.Service[Any]:
        @QtCore.pyqtSlot('PyQt_PyObject')
        def __exception_changed(exc: BaseException) -> None:
            self._exception = ServiceErrorPair(service=service, exc=exc)

        @QtCore.pyqtSlot(float)
        def __progress_changed(progress: float) -> None:
            self._most_recent_progress = ServiceProgressPair(service=service, progress=progress)

        @QtCore.pyqtSlot('PyQt_PyObject')
        def __status_changed(status: s.ServiceStatus) -> None:
            self._most_recent_status = ServiceStatusPair(service=service, status=status)
            if status & s.ServiceStatus.FINISHED:
                self.__start_next_service()

        @QtCore.pyqtSlot('PyQt_PyObject')
        def __result_changed(result: Any) -> None:
            self._result = ServiceResultPair(service=service, result=result)

        service.exception_changed.connect(__exception_changed)
        service.progress_changed.connect(__progress_changed)
        service.status_changed.connect(__status_changed)
        service.result_changed.connect(__result_changed)
        return service

    def __init__(self, services: Iterable[protocols.Service], execution_count: int=2, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)
        self._services = [self.__bind_service_signals(s if isinstance(s, protocols.Service) else t.TrcFunctionService(s)) for s in services]  # type: ignore
        self._lock = sync.Synchro()
        self._execution_count = execution_count
        self._current_service = 0
        self.__parent_service = self._find_parent_service()
        self.running_later.connect(self._running_later)

    @QtCore.pyqtSlot(result=bool, name='start')  # type: ignore
    def start(self) -> bool:
        """
        Attempts to begin execution of the inner services of this manager.
        :return: True if this manager is started successfully, otherwise False.
        """
        if self._status is not s.ServiceStatus.RUNNING:
            i: int = 0
            while i < self._execution_count:
                if not self.__start_next_service():
                    return False
                i += 1
            return True

    def __await__(self):
        """
        Attempts to wait for this service to complete execution.
        :return: The result of this service.
        """
        self.start()
        while not self.wait(100):
            yield
        if self.exception is None:
            return self.result
        else:
            raise self.exception

    @QtCore.pyqtSlot(int, result=bool, name='wait')  # type: ignore
    @QtCore.pyqtSlot(result=bool, name='wait')  # type: ignore
    def wait(self, timeout: int=10000) -> bool:
        """
        Attempts to await all services left within this service.
        :param timeout: The amount of time to await.
        :return: True if no service is left running, otherwise False.
        """
        for service in self._services:
            if service.status is s.ServiceStatus.RUNNING:
                service.wait(timeout)
                return False
        return True

    @QtCore.pyqtSlot(int, result=bool, name='stop')  # type: ignore
    @QtCore.pyqtSlot(result=bool, name='stop')  # type: ignore
    def stop(self, timeout: int=10000) -> bool:
        """
        Attempts to stop execution of the inner services of this manager.
        :param timeout: The amount of time to wait for the services to stop.
        :return: True if this manager is stopped successfully, otherwise False.
        """
        for service in self._services:
            if not service.stop(timeout):
                return False
        self._current_service = 0
        del self._exception
        del self._most_recent_progress
        del self._most_recent_status
        del self._progress
        del self._result
        del self._status
        return self._status is not s.ServiceStatus.RUNNING

    @QtCore.pyqtSlot(name='resetProgress')
    def reset_progress(self) -> None:
        """
        Attempts to reset the progress of this service.
        """
        if not self.is_running:
            for service in self._services:  # type: protocols.Service
                service.reset_progress
            self._progress = 0.0

    @QtCore.pyqtSlot(int, result=bool, name='restart')  # type: ignore
    @QtCore.pyqtSlot(result=bool, name='restart')  # type: ignore
    def restart(self, timeout: int=10000) -> bool:
        """
        Attempts to restart execution of the inner services of this manager. Restarting is equivalent to calling stop() and start().
        :param timeout: The amount of time to wait for the service to stop.
        :return: True if this manager is restarted successfully, otherwise False.
        """
        return self.stop(timeout) and self.start()

    def run(self) -> None:
        """This is a no-op call. TrcServiceManager does not call this method."""

    def run_later(self, runnable: Callable[[], None]) -> None:
        """
        Executes the provided runnable on the UI thread.
        :param runnable: The runnable to execute on the UI thread.
        """
        self._run_later(runnable)

    def yield_until(self, predicate: Callable[[], bool], *, attempts: int=10) -> bool:
        """
        Yields the execution of this thread until the provided predicate returns True, returning True if this occurs, or False otherwise.
        :param predicate: The predicate to check.
        :param attempts: The number of times to check the predicate before considering the yield_until a failure.
        """
        return self._yield_until(False, predicate, attempts=attempts)

    def yield_while(self, predicate: Callable[[], bool], *, attempts: int=10) -> bool:
        """
        Yields the execution of this thread until the provided predicate returns False, returning True if this occurs, or False otherwise.
        :param predicate: The predicate to check.
        :param attempts: The number of times to check the predicate before considering the yield_until a failure.
        """
        return self._yield_until(True, predicate, attempts=attempts)

    def await_result(self, *, timeout: int=0) -> Optional[List[Any]]:
        return self._await_result(timeout=timeout)

    def raise_if_faulted(self) -> None:
        self._raise_if_faulted()

    def raise_if_interrupted(self) -> None:
        """Service managers cannot raise interruption requests. They pass all interruption requests to their children."""
        pass

    def request_interruption(self) -> None:
        for se in self._services:  # type: protocols.Service[Any]
            se.request_interruption()

