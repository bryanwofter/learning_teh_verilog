from PyQt5 import QtCore
from trc_packages.asynclib import protocols as protocols, _shared_thread_impl as _st
from trc_packages.core.types import Runnable
from typing import Optional


class TrcThread(_st._SharedThreadImpl, QtCore.QThread, protocols.ProtoThread):
    """
    Provides a thread for use with the TrcService class or other threading functionality we might need.
    """

    @property
    def event_dispatcher(self) -> Optional[QtCore.QAbstractEventDispatcher]:
        return self.eventDispatcher()

    @event_dispatcher.setter
    def event_dispatcher(self, value: Optional[QtCore.QAbstractEventDispatcher]) -> None:
        self.setEventDispatcher(value)

    @event_dispatcher.deleter
    def event_dispatcher(self) -> None:
        self.event_dispatcher = None

    @property
    def is_finished(self) -> bool:
        return self.isFinished()

    @property
    def is_interruption_requested(self) -> bool:
        return self.isInterruptionRequested()

    @property
    def is_running(self) -> bool:
        return self.isRunning()

    @property
    def loop_level(self) -> int:
        return self.loopLevel()

    _run: Optional[Runnable] = None
    _accepts_thread_argument: bool = False

    def __init__(self, run: Runnable, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)
        self._run = run

    def raise_if_interruption_requested(self) -> None:
        self._raise_if_interruption_requested()

    def request_interruption(self) -> None:
        self.requestInterruption()

    def run(self) -> None:
        if self.event_dispatcher is None:
            self.event_dispatcher = QtCore.QAbstractEventDispatcher(self)
        self._run()

