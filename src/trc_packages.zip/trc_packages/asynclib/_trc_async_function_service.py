from trc_packages.asynclib import _trc_function_service as tfs


class TrcAsyncFunctionService(tfs.TrcFunctionService[tfs.R]):
    """
    Provides a TrcService implementation that wraps around an async function that accepts a TrcService as its argument.
    """

    async def _run_async(self) -> tfs.R:
        return await self.fn(self)

