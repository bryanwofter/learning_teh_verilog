from enum import IntFlag


class ServiceStatus(IntFlag):
    """
    Represents the current status of a service.
    """

    CREATED     = 0b00000001
    RUNNING     = 0b00000010
    ABORTED     = 0b00001000
    CANCELED    = 0b00010000
    COMPLETED   = 0b00100000
    FAULTED     = 0b01000000
    INTERRUPTED = 0b10000000
    FINISHED    = 0b11111000
