from functools import partial, wraps
from PyQt5 import QtCore, QtWidgets
from typing import Any, Callable, cast, List, Optional, overload, Generator, Tuple, TypeVar, Union
from trc_packages.asynclib import _progressive_decorator as pd, _progressive_method_decorator as pmd, errors, protocols
from trc_packages.core.types import Runnable, ExceptionHandler
CallableResult = Union[Tuple[int, Optional[Any]], int]
CallableSignature = Callable[..., CallableResult]
Callables = Union[CallableSignature, List[CallableSignature]]
T = TypeVar('T')
F = TypeVar('F', bound=Callable[..., Any])


def current_service() -> Optional[protocols.Service[T]]:
    """Returns the current service if one is available."""
    thread: QtCore.QThread = QtCore.QThread.currentThread()

    while not is_ui_thread(thread):
        parent: Optional[QtCore.QObject] = thread.parent()
        if isinstance(thread, protocols.ProtoThread) and isinstance(parent, protocols.Service):
            return cast(protocols.Service[T], parent)
        else:
            thread = thread.thread()

    return None


def on_ui_thread() -> bool:
    """Gets True if code is currently being executed on the UI thread, otherwise False."""
    return is_ui_thread(QtCore.QThread.currentThread())


def is_ui_thread(thread: QtCore.QThread) -> bool:
    """
    Gets True if the given thread is the UI thread, otherwise False.
    :param thread: The thread to check.
    """
    return thread == QtCore.QCoreApplication.instance().thread()


def isprogressivemethod(fn: F) -> bool:
    """
    Determines if the callable is a progressive method.
    :param fn: The callable to check.
    """
    return ((hasattr(fn, '_is_progressive_method') and fn._is_progressive_method) or  # type: ignore
            (isinstance(fn, partial) and isprogressivemethod(fn.func)))


def exec_progressive_method(progressive_method: Callable[..., Generator], progress: QtWidgets.QProgressBar, *args: Any, **kwargs: Any) -> List[Any]:
    """
    Executes the provided progressive method with the given progress bar and additional arguments, returning its results as a List instead of
    a generator.
    :param progressive_method: The method to invoke.
    :param progress: The progress bar to supply.
    """
    if isprogressivemethod(progressive_method):
        return list(progressive_method(progress, *args, **kwargs))
    else:
        raise errors.NonProgressiveMethodError()


def progressivewith(*, steps: int=0, synchronous: bool=False) -> Callable[[F], 'pd.ProgressiveDecorator[F]']:
    """
    Returns a decorator function that wraps a function with a ProgressiveDecorator and the given configuration options.
    :param fn: The function to wrap in the ProgressiveDecorator.
    :param steps: The number of steps that this function consumes within the progressive context.
    :param synchronous: True if this function should be executed on the calling thread, otherwise False.
    """
    return lambda fn: progressive_decorator(fn, steps, synchronous)


@overload
def progressive(*, steps: int=0, synchronous: bool=False) -> Callable[[F], 'pd.ProgressiveDecorator[F]']:
    ...


@overload
def progressive(fn: F) -> 'pd.ProgressiveDecorator':
    ...


def progressive(fn: Optional[Callable[..., Any]]=None, *, steps: int=0, synchronous: bool=False):
    """
    Returns a ProgressiveDecorator instance that wraps the given function with the given configuration options.
    :param fn: The function to wrap in the ProgressiveDecorator.
    :param steps: The number of steps that this function consumes within the progressive context.
    :param synchronous: True if this function should be executed on the calling thread, otherwise False.
    """
    if fn is None:
        return lambda fn: progressive_decorator(fn, steps, synchronous)
    return progressive_decorator(fn, steps, synchronous)


def progressive_decorator(fn: F, steps: int, synchronous: bool) -> 'pd.ProgressiveDecorator[F]':
    """
    Returns a ProgressiveDecorator instance that wraps the given function with the given configuration options.
    :param fn: The function to wrap in the ProgressiveDecorator.
    :param steps: The number of steps that this function consumes within the progressive context.
    :param synchronous: True if this function should be executed on the calling thread, otherwise False.
    """
    return cast(pd.ProgressiveDecorator[F], wraps(cast(Callable[..., Any], fn))(pd.ProgressiveDecorator(steps=steps, synchronous=synchronous, target=fn)))


def progressivemethodwith(worker_threads: int=2, startup: Optional[Runnable]=None, exception_handler: Optional[ExceptionHandler]=None,
                       finishup: Optional[Runnable]=None, cleanup: Optional[Runnable]=None) -> Callable[[F], 'pmd.ProgressiveMethodDecorator[F]']:
    """
    Returns a ProgressiveMethodDecorator decorator function that wraps the given function with the given configuration options.
    :param fn: The function tyo wrap in the ProgressiveMethodDecorator.
    :param worker_threads: The number of worker threads to allocate.
    :param startup: The startup function.
    :param exception_handler: The exception handler function.
    :param finishup: The finisher function.
    :param cleanup: The resource cleanup function.
    """
    return lambda fn: progressive_method_decorator(fn, worker_threads, startup, exception_handler, finishup, cleanup)


@overload
def progressivemethod(*, worker_threads: int=2, startup: Optional[Runnable]=None, exception_handler: Optional[ExceptionHandler]=None,
                      finishup: Optional[Runnable]=None, cleanup: Optional[Runnable]=None) -> Callable[[F], 'pmd.ProgressiveMethodDecorator[F]']:
    ...


@overload
def progressivemethod(fn: F) -> 'pmd.ProgressiveMethodDecorator[F]':
    ...


def progressivemethod(fn: Optional[Callable[..., Any]]=None, *, worker_threads: int=2, startup: Optional[Runnable]=None, exception_handler: Optional[ExceptionHandler]=None,
                      finishup: Optional[Runnable]=None, cleanup: Optional[Runnable]=None):
    """
    Returns a ProgressiveMethodDecorator instance that wraps the given function with the given configuration options.
    :param fn: The function tyo wrap in the ProgressiveMethodDecorator.
    :param worker_threads: The number of worker threads to allocate.
    :param startup: The startup function.
    :param exception_handler: The exception handler function.
    :param finishup: The finisher function.
    :param cleanup: The resource cleanup function.
    """
    if fn is None:
        return lambda fn: progressive_method_decorator(fn, worker_threads, startup, exception_handler, finishup, cleanup)
    return progressive_method_decorator(fn, worker_threads, startup, exception_handler, finishup, cleanup)


def progressive_method_decorator(fn: F, worker_threads: int, startup: Optional[Runnable], exception_handler: Optional[ExceptionHandler],
                                 finishup: Optional[Runnable], cleanup: Optional[Runnable]) -> 'pmd.ProgressiveMethodDecorator[F]':
    """
    Returns a ProgressiveMethodDecorator instance that wraps the given function with the given configuration options.
    :param fn: The function tyo wrap in the ProgressiveMethodDecorator.
    :param worker_threads: The number of worker threads to allocate.
    :param startup: The startup function.
    :param exception_handler: The exception handler function.
    :param finishup: The finisher function.
    :param cleanup: The resource cleanup function.
    """
    return pmd.ProgressiveMethodDecorator(target=fn, worker_threads=worker_threads, startup=startup, catch=exception_handler, finishup=finishup, cleanup=cleanup)

