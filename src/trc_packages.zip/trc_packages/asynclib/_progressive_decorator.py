from functools import partial, wraps
from typing import Any, cast, Callable, Generic, Iterable, overload, Type, TypeVar, Tuple, Optional
from trc_packages import core, decorators
from trc_packages.asynclib import _progressive_type as pt
T = TypeVar('T')
F = TypeVar('F')


def isprogressivecallable(fn: F) -> bool:
    """
    Determines if the provided function is considered a progressive callable.
    :param fn: The function to check.
    """
    return (isinstance(fn, ProgressiveDecorator) or
            (hasattr(fn, 'progressive_call') and fn.progressive_call) or  # type: ignore
            (isinstance(fn, partial) and isprogressivecallable(fn.func)))


def progressivetype(fn: F) -> pt.ProgressiveType:
    """
    Returns the progressive type of the function. This function assumes that isprogressivecallable has already been called.
    :param fn: The function to check.
    """
    if isinstance(fn, ProgressiveDecorator) or hasattr(fn, 'synchronous'):
        return pt.ProgressiveType.SYNC if fn.synchronous else pt.ProgressiveType.ASYNC  # type: ignore
    elif isinstance(fn, partial):
        return progressivetype(fn.func)
    else:
        return pt.ProgressiveType.RAW


class ProgressiveDecorator(Generic[F]):
    """Provides a decorator that assists with progressive_exec calls."""

    @classmethod
    def call_flag(cls) -> object:
        return cls.__ProgressiveCallFlag()

    @decorators.singleton
    class __ProgressiveCallFlag:
        """Used to signal that a progressive call has been invoked."""

    __target: Optional[F] = None
    __steps: int = 0
    __synchronous: bool = False

    @property
    def steps(self) -> int:
        return self.__steps

    @property
    def synchronous(self) -> bool:
        return self.__synchronous

    def __init__(self, steps: int, synchronous: bool, target: F) -> None:
        self.__target = target
        self.__synchronous = synchronous
        self.__steps = steps

    def __get__(self, instance: T, owner: Type[T]) -> F:
        functor: F
        if instance is None:
            functor = cast(F, self)
        else:
            functor = cast(F, partial(self, instance))
        return functor

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        method: F = self.__target
        if callable(method):
            # This should never actually be an issue. This is just to make mypy happy.
            if self.has_call_flag(args):
                return (self.__steps, method(*self.remove_call_flag(args), **kwargs))
            else:
                return method(*args, **kwargs)
        return None

    def has_call_flag(self, args: Tuple[Any, ...]) -> bool:
        """
        Checks for the call flag in the first 2 arguments of the call.
        :param args: The arguments used to call the function wrapper.
        """
        return core.first(args) is self.call_flag() or (len(args) > 1 and args[1] is self.call_flag())

    def remove_call_flag(self, args: Tuple[Any, ...]) -> Iterable[Any]:
        """
        Removes the call flag and yields the results back to the caller.
        :param args: The arguments used to call the function wrapper.
        """
        return (a for a in args if a is not self.call_flag())

    def __str__(self) -> str:
        return str(self.__target)

    def __repr__(self) -> str:
        return f"<ProgressiveDecorator on {self.__target.__repr__()}>"

