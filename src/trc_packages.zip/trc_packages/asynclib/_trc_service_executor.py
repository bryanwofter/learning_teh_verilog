from PyQt5 import QtCore
from trc_packages.asynclib import _trc_service as ts, _trc_reusable_function_service as trfs, protocols, errors, _helpers as helpers
from trc_packages.core.types import Predicate
from typing import Any, Iterable, List, Optional, Tuple, Union
ServiceTypeUnion = Union['protocols.Service[Any]', 'ts.TrcService[Any]', 'at.ServiceLikeCallable[Any]', Tuple['at.ServiceLikeCallable[Any]', Predicate]]


class TrcServiceExecutor(ts.TrcService[Tuple[Any, ...]]):
    """
    Provides a TrcService implementation that wraps around protocols.Service, TrcService, TrcRunnable, or Runnable instances.
    """

    __services: Tuple[ServiceTypeUnion, ...] = None

    @property
    def services(self) -> Iterable[ServiceTypeUnion]:
        return iter(self.__services)

    @property
    def all_services(self) -> Iterable['protocols.Service[Any]']:
        service: protocols.Service[Any]

        for service in (s for s in self.__services if isinstance(s, protocols.Service)):
            yield service

        for service in self.__allocated_workers:
            yield service

    __allocated_workers: List['trfs.TrcReusableFunctionService[Any]'] = None

    __total_worker_services: int = None

    @property
    def total_worker_services(self) -> int:
        return self.__total_worker_services

    def __init__(self, parent: Optional[QtCore.QObject]=None, *args: ServiceTypeUnion, services: Iterable[ServiceTypeUnion]=[], total_worker_services: int=2, ready_predicate: Optional[Predicate]=None) -> None:
        """
        Initializes this executor with the given services and optional worker count.
        :param services: The service or service-like objects being executed under this executor.
        :param total_worker_services: The total number of service workers maintained by this executor when encountering service-likes that are not services themselves.
        """
        super().__init__(parent=parent, ready_predicate=ready_predicate)
        self.__services = (*args, *services)
        self.__allocated_workers = []
        self.__total_worker_services = total_worker_services
        for service in self.__services:  # type: ServiceTypeUnion
            if isinstance(service, protocols.Service):
                service.progress_changed.connect(self._child_progress_changed)

    def append(self, service: ServiceTypeUnion, *, timeout: int=1000) -> bool:
        """
        Attempts to append the service to this executor, returning True if the executor is not currently running and the service was successfully appended, otherwise False.
        :param service: The service being appended to this executor.
        :param timeout: The amount of time to wait for the lock to be taken before giving up.
        """
        if not self.is_running:
            self.__services = (*self.services, service)
            if isinstance(service, protocols.Service):
                service.progress_changed.connect(self._child_progress_changed)
            return True
        return False

    def _run(self) -> Tuple[Any, ...]:
        """
        Executes this executor's services.
        """
        self._interrupt_services()

        execution_context: helpers.TrcExecutionContext = helpers.TrcExecutionContext(parent=self)
        execution_context.exec_()
        return_code: int = self._thread.exec_()

        if return_code is execution_context.SUCCESS:
            return tuple(execution_context.results)
        else:
            self._interrupt_services()
            if return_code is execution_context.SERVICE_FAULTED:
                raise errors.AggregateServiceError(self, execution_context.exceptions)
            elif return_code is execution_context.CANNOT_START_SERVICE:
                raise errors.CannotStartServiceError()
            else:
                raise errors.ReturnCodeError(return_code)

    @QtCore.pyqtSlot()
    def _child_progress_changed(self) -> None:
        """Handles summing all child service progress."""
        services: List[protocols.Service[Any]] = list(self.all_services)

        self._progress = sum(s.progress for s in services) / len(services)

    def _has_free_worker(self) -> bool:
        """Returns True if at least 1 free worker is available to perform work, otherwise False."""
        return len(self.__allocated_workers) < self.__total_worker_services or any(not w.is_running and w.result_handled for w in self.__allocated_workers)

    def _next_worker(self, service_like: Union['at.ServiceLikeCallable[Any]', Tuple['at.ServiceLikeCallable[Any]', Predicate]]) -> 'trfs.TrcReusableFunctionService[Any]':
        """
        Attempts to find the next worker that can be used for executing the service-like.
        :param service_like: The service-like callable to execute within the service.
        """
        ready_predicate: Optional[Predicate] = None
        if isinstance(service_like, tuple):
            service_like, ready_predicate = service_like

        for worker in self.__allocated_workers:  # type: trfs.TrcReusableFunctionService[Any]
            if not worker.is_running and worker.result_handled:
                worker.target = service_like
                worker.ready_predicate = ready_predicate
                return worker

        if len(self.__allocated_workers) < self.__total_worker_services:
            worker = trfs.TrcReusableFunctionService(service_like, parent=self, ready_predicate=ready_predicate)
            worker.progress_changed.connect(self._child_progress_changed)
            self.__allocated_workers.append(worker)
            return worker
        else:
            raise errors.CannotAddServiceError()

    def _interrupt_services(self) -> None:
        """
        Interrupts all child services.
        """
        service: protocols.Service[Any]

        for service in self.all_services:
            service.request_interruption()

        # Wait for all of the services to no longer be considered running
        self.yield_while(lambda: any(s.is_running for s in self.all_services), attempts=-1)

