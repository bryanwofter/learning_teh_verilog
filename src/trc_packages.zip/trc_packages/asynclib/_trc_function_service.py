from PyQt5 import QtCore
from trc_packages.asynclib import _trc_service as t, protocols, _aliastypes as at
from typing import cast, Optional, TypeVar
R = TypeVar('R')


class TrcFunctionService(t.TrcService[R]):
    """
    Provides a TrcService implementation that wraps around a function that accepts a TrcService as its argument.
    """

    __fn: Optional['at.ServiceLikeCallable[R]'] = None

    @property
    def fn(self) -> 'at.ServiceLikeCallable[R]':
        return self.__fn

    def __init__(self, fn: 'at.ServiceLikeCallable[R]', parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)
        self.__fn = fn

    def _run(self) -> R:
        return super()._run()

    async def _run_async(self) -> R:
        return self.__fn(self)

