from enum import auto, Enum, unique


@unique
class ProgressiveType(Enum):
    """
    Provides an enum for defining the type of a progressive function.
    """
    RAW = auto()
    """Flags the function as an undecorated function."""

    ASYNC = auto()
    """Flags the function as a decorated asynchronously executed function."""

    SYNC = auto()
    """Flags the function as a decorated synchronously executed function."""

    @property
    def is_asynchronous_type(self) -> bool:
        """Returns True if this ProgressiveType is an async type, otherwise False."""
        return self is self.RAW or self is self.ASYNC

    @property
    def is_synchronous_type(self) -> bool:
        """Returns True if this ProgressiveType is a sync type, otherwise False."""
        return self is self.SYNC

