from PyQt5 import QtCore
from typing import Callable
Runnable = Callable[[], None]


def run_on_ui_thread(fn: Runnable) -> QtCore.QTimer:
    """
    Executes the provided callable on the main thread.
    :param fn: The function to execute on the main thread.
    """
    timer: QtCore.QTimer = QtCore.QTimer()
    @QtCore.pyqtSlot()
    def __exec() -> None:
        nonlocal timer
        nonlocal fn
        fn()
        timer.deleteLater()
    timer.moveToThread(QtCore.QCoreApplication.instance().thread())
    timer.setSingleShot(True)
    timer.timeout.connect(__exec)
    timer.start(0)
    return timer

