from typing import Any, Callable, Type, TypeVar, Optional, no_type_check, overload

T = TypeVar('T')

def singleton(cls: Type[T]=None, inherited: bool=False):
    """
    Provides a decorator for classes that can be used to mark them as singletons.
    :param cls: The type to decorate.
    :param inherited: True if this singleton type allows for singleton inheritance, otherwise False.
    """
    return (lambda cls: __make_new(cls, inherited)) if cls is None else __make_new(cls, inherited)

def __make_new(cls: Type[T], inherited: bool) -> Callable[[Type[T]], T]:
    cls.__INSTANCE = None  # type: ignore
    existing_new = None  # type: Optional[Callable[[Type[T]], T]]
    # Attempt to get the original new from the type.
    try:
        existing_new = cls.__new__
    except AttributeError:
        pass
    # Set the accepted type to a meaningful name to not cause a confict with the function.
    base = cls  # type: Type[T]
    @staticmethod  # type: ignore
    @no_type_check
    def __new(cls: Type[T], *vargs: Any, **kwargs: Any) -> T:
        """Instantiates the provided type. If the type is decorated with the singleton decoration, the singleton instance will
        be returned instead."""
        if cls is base or inherited:
            if not isinstance(cls.__INSTANCE, cls):
                cls.__INSTANCE = (existing_new or super(cls, cls).__new__)(cls)
            return cls.__INSTANCE
        return (existing_new or super(base, cls).__new__)(cls)
    # Update the name of __new to match the method name.
    __new.__name__ = '__new__'
    cls.__new__ = __new  # type: ignore
    return cls
