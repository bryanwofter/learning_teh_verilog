from trc_packages import decorators
from typing import Any, Callable, cast, Generic, List, NoReturn, Optional, overload, Type, TypeVar, Union
from datetime import datetime, date, time
from uuid import UUID
T = TypeVar('T')
U = TypeVar('U')
V = TypeVar('V')


@overload
def safe_cast(creator: Type[T], val: Optional[V], default: Optional[T]=None) -> Optional[T]: pass
@overload
def safe_cast(creator: Callable[[Optional[V]], Optional[T]], val: Optional[V], default: Optional[T]=None) -> Optional[T]: pass
def safe_cast(creator, val: Optional[V], default: Optional[T]=None) -> Optional[T]:
    """
    Safely casts to the provided type, returning default if the cast fails.
    :param creator: The type to cast to.
    :param val: The value to cast.
    :param default: The default value to use if the cast fails.
    :return: The value produced by the cast.
    """
    if val is None:
        return default
    elif isinstance(creator, type) and isinstance(val, creator):
        return cast(T, val)
    try:
        return creator(val)
    except (ValueError, TypeError):
        return default


def safe_bool(val: Optional[V], default: Optional[bool]=None) -> Optional[bool]:
    """
    Safely casts the value to bool.
    :param val: The value to cast.
    :param default: The default value to use if the cast fails.
    :return: The value produced by the cast.
    """
    return safe_cast(bool, val, default)


def safe_int(val: Optional[V], default: Optional[int]=None) -> Optional[int]:
    """
    Safely casts the value to int.
    :param val: The value to cast.
    :param default: The default value to use if the cast fails.
    :return: The value produced by the cast.
    """
    #Due to bools being treated as ints (they inherit from int), we need to add an extra check in here for it.
    return int(val) if isinstance(val, bool) else safe_cast(int, val, default)


def safe_float(val: Optional[V], default: Optional[float]=None) -> Optional[float]:
    """
    Safely casts the value to float.
    :param val: The value to cast.
    :param default: The default value to use if the cast fails.
    :return: The value produced by the cast.
    """
    return safe_cast(float, val, default)


@overload
def safe_str(val: Optional[V], default: Optional[str]=None, formatter: Optional[Type[U]]=None) -> Optional[str]: pass
@overload
def safe_str(val: Optional[V], default: Optional[str]=None, formatter: Optional[Callable[[Optional[V]], Optional[U]]]=None) -> Optional[str]: pass
def safe_str(val: Optional[V], default: Optional[str]=None, formatter=None) -> Optional[str]:
    """
    Safely casts the value to str.
    :param val: The value to cast.
    :param default: The default value to use if the cast fails.
    :param formatter: The formatter to apply to the value before the cast.
    :return: The value produced by the cast.
    """
    return safe_cast(str, val if formatter is None else safe_cast(formatter, val), default)


def safe_bytes(val: Optional[V], default: Optional[bytes]=None) -> Optional[bytes]:
    """
    Safely casts the value to bytes.
    :param val: The value to cast.
    :param default: The default value to use if the cast fails.
    :return: The value produced by the cast.
    """
    return safe_cast(bytes, val, default)


def safe_date(val: Optional[str], default: Optional[date]=None, custom_formats: Optional[Union[str, List[str]]]=None) -> Optional[date]:
    """
    Safely casts the string to a date, optionally using additional formats if provided.
    :param val: The value to cast.
    :param default: The default value to use if the cast fails.
    :param custom_formats: Additional formats to attempt during the conversion.
    :return: The value produced by the cast.
    """
    if isinstance(custom_formats, str):
        custom_formats = [custom_formats]
    elif custom_formats is None:
        custom_formats = []
    custom_formats.append('%Y-%m-%d')
    custom_formats.append('%Y-%m-%dT')
    datetime_: Optional[datetime] = safe_datetime(val, custom_formats=custom_formats)
    return default if datetime_ is None else datetime_.date()


def safe_time(val: Optional[str], default: Optional[time]=None, custom_formats: Optional[Union[str, List[str]]]=None) -> Optional[time]:
    """
    Safely casts the string to a time, optionally using additional formats if provided.
    :param val: The value to cast.
    :param default: The default value to use if the cast fails.
    :param custom_formats: Additional formats to attempt during the conversion.
    :return: The value produced by the cast.
    """
    if isinstance(custom_formats, str):
        custom_formats = [custom_formats]
    elif custom_formats is None:
        custom_formats = []
    custom_formats.append('%H:%M:%S.%fZ')
    custom_formats.append('T%H:%M:%S.%fZ')
    custom_formats.append('%H:%M:%SZ')
    custom_formats.append('T%H:%M:%SZ')
    custom_formats.append('%H:%M:%S.%f')
    custom_formats.append('T%H:%M:%S.%f')
    custom_formats.append('%H:%M:%S')
    custom_formats.append('T%H:%M:%S')
    datetime_: Optional[datetime] = safe_datetime(val, custom_formats=custom_formats)
    return default if datetime_ is None else datetime_.time()


def safe_datetime(val: Optional[str], default: Optional[datetime]=None, custom_formats: Optional[Union[str, List[str]]]=None) -> Optional[datetime]:
    """
    Safely casts the string to a datetime, optionally using additional formats if provided.
    :param val: The value to cast.
    :param default: The default value to use if the cast fails.
    :param custom_formats: Additional formats to attempt during the conversion.
    :return: The value produced by the cast.
    """
    if isinstance(custom_formats, str):
        custom_formats = [custom_formats]
    elif custom_formats is None:
        custom_formats = []
    custom_formats.append('%Y-%m-%d %H:%M:%S.%fZ')
    custom_formats.append('%Y-%m-%dT%H:%M:%S.%fZ')
    custom_formats.append('%Y-%m-%d %H:%M:%SZ')
    custom_formats.append('%Y-%m-%dT%H:%M:%SZ')
    custom_formats.append('%Y-%m-%d %H:%M:%S.%f')
    custom_formats.append('%Y-%m-%dT%H:%M:%S.%f')
    custom_formats.append('%Y-%m-%d %H:%M:%S')
    custom_formats.append('%Y-%m-%dT%H:%M:%S')

    def __conversion(v: Optional[str]) -> Optional[datetime]:
        if v is None:
            return None
        for custom_format in cast(List[str], custom_formats):
            try: return datetime.strptime(v, custom_format)
            except: pass
        return None

    return safe_cast(__conversion, val, default)


def safe_uuid(val: Optional[V], default: Optional[UUID]=None) -> Optional[UUID]:
    """
    Safely casts the value to UUID.
    :param val: The value to cast.
    :param default: The default value to use if the cast fails.
    :return: The value produced by the cast.
    """
    if isinstance(val, str):
        try: return UUID(f"urn:uuid:{val}")
        except: pass
    return safe_cast(UUID, val, default)


class safe_none(Generic[T]):
    __value: Optional[T] = None
    __EMPTY: Optional['safe_none[T]'] = None

    def __del__(self):
        del self.__value

    def __new__(cls, *args: Any, **kwargs: Any) -> 'safe_none[T]':
        if not any(args) and cls.__EMPTY is not None:
            return cls.__EMPTY
        return super().__new__(cls)

    def __init__(self, value: Optional[T]) -> None:
        self.__value = value

    def __getattr__(self, name: str) -> 'safe_none[T]':
        return safe_none(None if self.__value is None else getattr(self.__value, name))

    def __setattr__(self, name: str, value: Any) -> NoReturn:
        if self.__value is not None:
            setattr(self.__value, name, value)

    def __delattr__(self, name: str) -> NoReturn:
        if self.__value is not None:
            delattr(self.__value, name)

    def __getitem__(self, key: Any) -> 'safe_none[T]':
        return safe_none(None if self.__value is None else self.__value[key])  # type: ignore

    def __setitem__(self, key: Any, value: Any) -> NoReturn:
        if self.__value is not None:
            self.__value[key] = value  # type: ignore

    def __deleteitem__(self, key: Any) -> NoReturn:
        if self.__value is not None:
            del self.__value[key]  # type: ignore

    def __call__(self, *args, **kwargs) -> 'safe_none[T]':
        return safe_none(None if self.__value is None else self.__value(*args, **kwargs))  # type: ignore
