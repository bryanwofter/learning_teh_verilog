from abc import ABC
from PyQt5 import QtCore
try: from typing import Protocol
except: from typing_extensions import Protocol  # type: ignore
from typing import Any

ABC_TYPE: Any = type(ABC)
QOBJECT_TYPE: Any = type(QtCore.QObject)
PROTOCOL_TYPE: Any = type(Protocol)


class QObjectABCMeta(ABC_TYPE, QOBJECT_TYPE):
    """
    Defines the metaclass for all QObjectABC inheritors.
    """
    pass


class QObjectABC(metaclass=QObjectABCMeta):
    """
    Defines an abstract base class that can be used with QObject inheritance.
    """
    pass


class QObjectProtocolMeta(PROTOCOL_TYPE, QOBJECT_TYPE):
    """
    Defines the metaclass for all QObjectProtocol inheritors.
    """
    pass


class QObjectProtocol(metaclass=QObjectProtocolMeta):
    """
    Defines a protocol base class that can be used with QObject inheritance.
    """
    _is_protocol: bool = True

