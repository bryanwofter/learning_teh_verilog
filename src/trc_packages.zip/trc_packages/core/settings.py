import trc_packages
import json
from abc import ABC, abstractmethod
from trc_packages.core.safecasts import safe_bool
from trc_packages.core.json_handlers import TrcJSONDecoder, TrcJSONEncoder
from trc_packages.decorators import singleton
from typing import Any, Callable, cast, ClassVar, Dict, Generic, List, Optional, Tuple, Type, TypeVar, Iterator
from qgis.core import QgsProject  # type: ignore
import json
T = TypeVar('T')


class setting(Generic[T]):
    """Provides a single option that is associated to a SettingsABC."""

    name: str
    __converter: Callable[[str], T]

    def __init__(self, name: str, *, converter: Callable[[str], T]=lambda v: cast(T, v)) -> None:
        self.name = name
        self.__converter = converter  # type: ignore

    def __delete__(self, instance: 'SettingsABC') -> None:
        instance.delete(self.name)

    def __get__(self, instance: 'SettingsABC', owner: Type['SettingsABC']) -> Optional[T]:
        return self.__converter(instance.get(self.name))  # type: ignore

    def __set__(self, instance: 'SettingsABC', value: Optional[T]) -> None:
        instance.set(self.name, value)


class dict_setting:
    """Provides an option that stores a JSON-serialized object associated to a SettingsABC."""

    name: str
    json_encoder: Type[TrcJSONEncoder]
    json_decoder: Type[TrcJSONDecoder]

    def __init__(self, name: str, *, json_encoder: Type[TrcJSONEncoder]=TrcJSONEncoder, json_decoder: Type[TrcJSONDecoder]=TrcJSONDecoder) -> None:
        self.name = name
        self.json_encoder = json_encoder
        self.json_decoder = json_decoder

    def __delete__(self, instance: 'SettingsABC') -> None:
        instance.delete(self.name)

    def __get__(self, instance: 'SettingsABC', owner: Type['SettingsABC']) -> Optional[Dict[str, str]]:
        return json.loads(instance.get(self.name, '{}'), cls=self.json_decoder)

    def __set__(self, instance: 'SettingsABC', value: Optional[Dict[str, str]]) -> None:
        instance.set(self.name, json.dumps(value or {}, cls=self.json_encoder))


class list_setting(Generic[T]):
    """Provides an option that stores a JSON-serialized list associated to a SettingsABC."""

    name: str
    json_encoder: Type[TrcJSONEncoder]
    json_decoder: Type[TrcJSONDecoder]

    def __init__(self, name: str, *, json_encoder: Type[TrcJSONEncoder]=TrcJSONEncoder, json_decoder: Type[TrcJSONDecoder]=TrcJSONDecoder) -> None:
        self.name=  name
        self.json_encoder = json_encoder
        self.json_decoder = json_decoder

    def __delete__(self, instance: 'SettingsABC') -> None:
        instance.delete(self.name)

    def __get__(self, instance: 'SettingsABC', owner: Type['SettingsABC']) -> Optional[List[T]]:
        return json.loads(instance.get(self.name, '[]'), cls=self.json_decoder)

    def __set__(self, instance: 'SettingsABC', value: Optional[List[T]]) -> None:
        instance.set(self.name, json.dumps(value or [], cls=self.json_encoder))


class SettingsABC(ABC):
    """Provides an abstract class defining the needed attributes of a setting object."""

    @abstractmethod
    def delete(self, field: str) -> None:
        """
        Deletes a value from this configuration.
        :param field: The field to remove from the project.
        """
        pass

    @abstractmethod
    def get(self, field: str, default: Optional[T]=None) -> Optional[T]:
        """
        Gets a value from this configuration.
        :param field: The field to read from the project.
        :param default: The default value to use if the field cannot be read.
        """
        pass

    @abstractmethod
    def set(self, field: str, value: Optional[T]) -> None:
        """
        Puts a value into this configuration.
        :param field: The field to put the value into.
        :param value: The value to put into the field.
        """
        pass

    def __getitem__(self, field: str) -> Optional[T]: return self.get(field)
    def __setitem__(self, field: str, value: Optional[T]) -> None: self.set(field, value)
    def __delitem__(self, field: str) -> None: self.delete(field)


if trc_packages.QGIS_EXISTS:
    @singleton(inherited=True)
    class ProjectSettings(SettingsABC):
        """Provides configurable options that can be saved into the client of a project."""

        plugin_name: str = 'trc'

        qc_enabled = setting[bool]('qc_enabled', converter=safe_bool)

        QC_WIDGET_TYPE: ClassVar[Type] = None

        @property
        def project(self) -> QgsProject:
            return QgsProject.instance()

        @property
        def qc_widget_type(self) -> Type[Any]:
            return ProjectSettings.QC_WIDGET_TYPE

        @qc_widget_type.setter
        def qc_widget_type(self, qc_widget_type: Type) -> None:
            ProjectSettings.QC_WIDGET_TYPE = qc_widget_type

        @qc_widget_type.deleter
        def qc_widget_type(self) -> None:
            ProjectSettings.QC_WIDGET_TYPE = None

        def delete(self, field: str) -> None:
            self.set(field, None)

        def get(self, field: str, default: Optional[T]=None) -> Optional[T]:
            value, status = self.project.readEntry(self.plugin_name, field, default)  # type: Tuple[Optional[T], Any]
            return value

        def set(self, field: str, value: Optional[T]) -> None:
            self.project.writeEntry(self.plugin_name, field, value)


class JSONSettingsABC(SettingsABC, ABC):
    """Provides a base for all settings that are backed by a JSON object with an abitrary method for loading and saving."""

    decoder: Optional[Type[json.JSONDecoder]] = None
    encoder: Optional[Type[json.JSONEncoder]] = None
    save_on_change: bool = False

    _settings: Optional[Dict[str, Any]] = None
    @property
    def settings(self) -> Dict[str, Any]:
        if self._settings is None:
            self.load()
        return cast(Dict[str, Any], self._settings)

    def __init__(self, decoder: Optional[Type[json.JSONDecoder]]=TrcJSONDecoder, encoder: Optional[Type[json.JSONEncoder]]=None,
                 save_on_change: bool=False) -> None:
        self.decoder = decoder
        self.encoder = encoder
        self.save_on_change = save_on_change

    def delete(self, field: str) -> None:
        del self.settings[field]
        if self.save_on_change:
            self.save()

    def get(self, field: str, default: Optional[T]=None) -> Optional[T]:
        return self.settings.get(field, default)

    @abstractmethod
    def load(self) -> None:
        """Loads the JSON of this instance."""
        pass

    @abstractmethod
    def save(self) -> None:
        """Saves the JSON of this instance."""
        pass

    def set(self, field: str, value: Optional[T]) -> None:
        self.settings[field] = value
        if self.save_on_change:
            self.save()

    # region Dictionary support
    def __contains__(self, field: str) -> bool:
        return self.settings.__contains__(field)

    def __iter__(self) -> Iterator:
        return iter(self.settings)

    def __len__(self) -> int:
        return len(self.settings)

    def clear(self) -> None:
        self.settings.clear()
        if self.save_on_change:
            self.save()

    def items(self) -> Any:
        return self.settings.items()

    def keys(self) -> Any:
        return self.settings.keys()

    def pop(self, field: str) -> Any:
        try:
            return self.settings.pop(field)
        finally:
            if self.save_on_change:
                self.save()

    def popitem(self) -> Any:
        try:
            return self.settings.popitem()
        finally:
            if self.save_on_change:
                self.save()

    def setdefault(self, default: Any) -> None:
        self.settings.setdefault(default)

    def update(self, other: Dict[str, Any]) -> None:
        self.settings.update(other)
        if self.save_on_change:
            self.save()

    def values(self) -> Any:
        return self.settings.values()
    # endregion


class HandledJSONSettings(JSONSettingsABC):
    """Provides settings that are read and written to handler functions."""

    reader: Callable[..., str]
    writer: Callable[..., None]

    def __init__(self, reader: Callable[[], str], writer: Callable[[str], None], decoder: Optional[Type[json.JSONDecoder]]=TrcJSONDecoder,
                 encoder: Optional[Type[json.JSONEncoder]]=TrcJSONEncoder, save_on_change: bool=False) -> None:
        super().__init__(decoder=decoder, encoder=encoder, save_on_change=save_on_change)
        self.reader = reader  # type: ignore
        self.writer = writer  # type: ignore

    def load(self) -> None:
        self._settings = json.loads(self.reader(), cls=self.decoder)

    def save(self) -> None:
        self.writer(json.dumps(self._settings, cls=self.encoder))


class FileJSONSettings(JSONSettingsABC):
    """Provides settings that are read and written to a JSON file."""

    file_path: str

    def __init__(self, file_path: str, decoder: Optional[Type[json.JSONDecoder]]=TrcJSONDecoder,
                 encoder: Optional[Type[json.JSONEncoder]]=TrcJSONEncoder, save_on_change: bool=False) -> None:
        super().__init__(decoder=decoder, encoder=encoder, save_on_change=save_on_change)
        self.file_path = file_path

    def load(self) -> None:
        with open(self.file_path) as file:
            self._settings = json.load(file, cls=self.decoder)

    def save(self) -> None:
        with open(self.file_path) as file:
            json.dump(self._settings, file, cls=self.encoder)

