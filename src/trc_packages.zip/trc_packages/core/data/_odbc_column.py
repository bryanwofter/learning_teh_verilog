from typing import Any, Dict, Optional
from typing_extensions import final
import pyodbc  # type: ignore


@final
class OdbcColumn:
    """
    Provides a class that represents a column within an ODBC table.
    """

    DATA_TYPES: Dict[int, str] = {
        pyodbc.SQL_CHAR: 'CHAR({s})',
        pyodbc.SQL_VARCHAR: 'VARCHAR({s})',
        pyodbc.SQL_LONGVARCHAR: 'VARCHAR({s})',
        pyodbc.SQL_WCHAR: 'CHAR({s})',
        pyodbc.SQL_WVARCHAR: 'VARCHAR({s})',
        pyodbc.SQL_WLONGVARCHAR: 'VARCHAR({s})',
        pyodbc.SQL_DECIMAL: 'NUMERIC({p}, {s})',
        pyodbc.SQL_NUMERIC: 'NUMERIC({p}, {s})',
        pyodbc.SQL_SMALLINT: 'INTEGER',
        pyodbc.SQL_INTEGER: 'INTEGER',
        pyodbc.SQL_REAL: 'FLOAT',
        pyodbc.SQL_FLOAT: 'FLOAT',
        pyodbc.SQL_DOUBLE: 'FLOAT',
        pyodbc.SQL_BIT: 'BOOLEAN',
        pyodbc.SQL_TINYINT: 'INTEGER',
        pyodbc.SQL_BIGINT: 'INTEGER',
        pyodbc.SQL_BINARY: 'BLOB',
        pyodbc.SQL_VARBINARY: 'BLOB',
        pyodbc.SQL_LONGVARBINARY: 'BLOB',
        pyodbc.SQL_TYPE_DATE: 'DATE',
        pyodbc.SQL_TYPE_TIME: 'TIME({p})',
        pyodbc.SQL_TYPE_TIMESTAMP: 'DATETIME',
        pyodbc.SQL_GUID: 'CHAR(36)',
        pyodbc.SQL_UNKNOWN_TYPE: 'BLOB'
    }

    table_name: str = None
    name: str = None
    data_type: int = None
    type_name: str = None
    size: int = None
    precision: Optional[int] = None
    position: int = None
    is_nullable: bool = None

    @property
    def real_type_name(self) -> str:
        type_name: str = self.DATA_TYPES.get(self.data_type, self.type_name).format(p=self.precision, s=self.size)
        if type_name == 'COUNTER':
            type_name = 'INTEGER'
        if not self.is_nullable:
            type_name += ' NOT NULL'
        return type_name

    def __init__(self, table_name: str, position: int, name: str, *, data_type: int=None, type_name: str=None, size: int=None,
                 precision: Optional[int]=None, is_nullable: bool=False) -> None:
        self.table_name = table_name
        self.position = position
        self.name = name
        self.data_type = data_type
        self.type_name = type_name
        self.size = size
        self.precision = precision
        self.is_nullable = is_nullable

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, type(self)):
            return (self.table_name, self.position, self.name) == (other.table_name, other.position, other.name)
        return NotImplemented

    def __gt__(self, other: Any) -> bool:
        if isinstance(other, type(self)):
            return (self.table_name, self.position, self.name) > (other.table_name, other.position, other.name)
        return NotImplemented

    def __hash__(self) -> int:
        return hash((self.table_name, self.position, self.name))

    def __str__(self) -> str:
        return f'"{self.name}" {self.real_type_name}'

    def __repr__(self) -> str:
        return f"""(table_name: {self.table_name},
                    name: {self.name},
                    data_type: {self.data_type},
                    type_name: {self.type_name},
                    size: {self.size},
                    precision: {self.precision},
                    position: {self.position},
                    is_nullable: {self.is_nullable},
                    real_type_name: {self.real_type_name})"""

