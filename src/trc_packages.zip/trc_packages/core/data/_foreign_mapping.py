from trc_packages.core import _functions as f
from trc_packages.core.data import _foreign_reference as fr
from typing import Dict, List, Tuple
try: from typing import final  # type: ignore
except: from typing_extensions import final
_INSERT_TRIGGER_STATEMENT: str = '''
CREATE TRIGGER IF NOT EXISTS {}
AFTER INSERT
ON {}
FOR EACH ROW BEGIN
{}
END;
'''
_UPDATE_TRIGGER_STATEMENT: str = '''
CREATE TRIGGER IF NOT EXISTS {}
AFTER UPDATE
ON {}
FOR EACH ROW BEGIN
{}
END;
'''


@final
class ForeignMapping:
    """Defines a collection of foreign references between multiple tables."""
    mappings: Dict[str, List['fr.ForeignReference']]

    def __init__(self, **kwargs: List['fr.ForeignReference']) -> None:
        self.mappings = kwargs

    def trigger_stmts(self) -> str:
        buffer: str = ''
        for table, foreign_refs in self.mappings.items():  # type: Tuple[str, List[fr.ForeignReference]]
            update_statements: List[str] = []
            new_reference: fr.ForeignReference = f.first(f for f in foreign_refs if f.foreign_table == 'new')

            for foreign_ref in (f for f in foreign_refs if f.foreign_table != 'new'):  # type: fr.ForeignReference
                if not foreign_ref.no_trigger:
                    buffer += foreign_ref.on_update_stmt(table, new_reference)
                    update_statements.append(foreign_ref.update_stmt(table, new_reference))

            update_statement: str = "\n".join(update_statements)
            buffer += _INSERT_TRIGGER_STATEMENT.format(f"{table}_after_insert", table, update_statement)
        return buffer

    def index_stmts(self) -> str:
        buffer: str = ''
        for table, foreign_refs in self.mappings.items():  # type: Tuple[str, List[fr.ForeignReference]]

            for foreign_ref in (f for f in foreign_refs if f.foreign_table != 'new' or f.local_is_unique):  # type: fr.ForeignReference
                buffer += foreign_ref.index_stmt(table)

        return buffer

