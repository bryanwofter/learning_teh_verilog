from trc_packages.core.data import _column_reference as cr, _foreign_mapping as fm, _foreign_reference as fr
from typing import Dict, Iterable, List, Tuple, Union, overload
ColumnReferenceType =Union['cr.ColumnReference', str, Tuple[str, str]]


@overload
def column_ref(column: 'cr.ColumnReference') -> 'cr.ColumnReference': pass
@overload
def column_ref(column: Tuple[str, str]) -> 'cr.ColumnReference': pass
@overload
def column_ref(column: str, foreign: str=None) -> 'cr.ColumnReference': pass

def column_ref(column, foreign: str=None) -> 'cr.ColumnReference':
    """
    Creates a column reference for the given column and foreign_column.
    :param column: The column of the local table that is being populated by the trigger.
    :param foreign_column: The column of  the foreign table that is being sourced by the trigger. If none is provided, the same name provided for column will be used.
    :return: A ColumnReference instance that represents the foreign_column and column pair.
    """
    if isinstance(column, cr.ColumnReference):
        return column
    elif isinstance(column, tuple):
        foreign = None if 1 == len(column) else column[1]
        column = column[0]
    return cr.ColumnReference(local_column=column, foreign_column=foreign or column)


def foreign_ref(foreign_table: str,
                key: Union[Dict[str, str], Iterable[ColumnReferenceType]],
                columns: Union[Dict[str, str], Iterable[ColumnReferenceType]]=None,
                *args: ColumnReferenceType,
                no_trigger: bool=False,
                local_is_unique: bool=False,
                foreign_is_unique: bool=False,
                **kwargs: str) -> 'fr.ForeignReference':
    """
    Creates as foreign table reference to the given table name using the given keys and columns. If kwargs are provided, they'll be combined into the columns dictionary.
    :param foreign_table: The table to reference.
    :param key: The local->foreign key mapping of the reference.
    :param columns: The local->foreign column mapping, where local is the field being populated by foreign.
    :param kwargs: A simplified version of columns.
    :return: A ForeignReference with the given arguments.
    """
    key_values: List[cr.ColumnReference]
    column_values: List[cr.ColumnReference]

    if isinstance(key, dict):
        key_values = [column_ref(column=k, foreign=f) for k, f in key.items()]
    else:
        key_values = [column_ref(column=k) for k in key]

    if isinstance(columns, dict):
        column_values = [column_ref(column=c, foreign=f) for c, f in columns.items()]
    elif columns is None:
        column_values = []
    else:
        column_values = [column_ref(column=c) for c in columns]

    for c in args:
        column_values.append(column_ref(column=c))
    for c, f in kwargs.items():
        column_values.append(column_ref(column=c, foreign=f))

    return fr.ForeignReference(foreign_table=foreign_table, key=key_values, columns=column_values, no_trigger=no_trigger, local_is_unique=local_is_unique, foreign_is_unique=foreign_is_unique)

def new_ref(*key: str, no_trigger: bool=False, is_unique: bool=True) -> 'fr.ForeignReference':
    """
    Creates a ForeignReference instance that represents the new row.
    :param key: The fields that compose the key.
    :return: A ForeignReference with the given key.
    """
    return foreign_ref(foreign_table='new', key={k: k for k in key}, no_trigger=no_trigger, local_is_unique=is_unique)

def foreign_map(**kwargs: List['fr.ForeignReference']) -> 'fm.ForeignMapping':
    """
    Creates a foreign mapping instance using the provided foreign references.
    :return: The ForeignMapping instance.
    """
    return fm.ForeignMapping(**kwargs)

