try: from typing import final  # type: ignore
except: from typing_extensions import final


@final
class ColumnReference:
    """Defines a reference between 2 columns of 2 tables."""
    foreign_column: str
    local_column: str

    def __init__(self, foreign_column: str, local_column: str) -> None:
        self.foreign_column = foreign_column
        self.local_column = local_column

    def equality_stmt(self, local_table: str, foreign_table: str) -> str:
        return f"{foreign_table}.{self.foreign_column} = {local_table}.{self.local_column}"

    def coalesce_stmt(self, local_table: str, foreign_table: str, where_statement: str) -> str:
        return f"{self.local_column} = COALESCE((SELECT {foreign_table}.{self.foreign_column} FROM {foreign_table} WHERE {where_statement}), new.{self.local_column})"

