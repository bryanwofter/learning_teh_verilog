from collections import defaultdict
from typing import Any, Callable, Dict, List, Set, Union, NamedTuple, Iterable, Iterator, Optional
from os import path
from trc_packages.core import log
from trc_packages.core.safecasts import safe_int, safe_datetime, safe_str, safe_float, safe_bytes, safe_uuid, safe_bool
from trc_packages.core.context_helpers import contexts
from trc_packages.core.data import _odbc_column as oc
from osgeo import ogr  # type: ignore
from retry import retry  # type: ignore
import pandas  # type: ignore
import sqlalchemy  # type: ignore
import sqlite3
import pyodbc  # type: ignore
_TYPE_MAP: Dict[str, Callable] = {
    'BIT': safe_bool,
    'SMALLINT': safe_int,
    'DATETIME': safe_datetime,
    'VARCHAR': safe_str,
    'REAL': safe_float,
    'DOUBLE': safe_float,
    'LONGBINARY': safe_bytes,
    'BYTE': safe_int,
    'GUID': safe_uuid,
    'INTEGER': safe_int,
    'COUNTER': safe_int,
    'LONGCHAR': safe_str,
    'BIGBINARY': safe_bytes
}
_WFS_TO_SQLITE_TYPE_MAP: Dict[str, str] = {
    'xsd:string': 'VARCHAR',
    'xsd:double': 'FLOAT',
    'xsd:float': 'FLOAT',
    'xsd:int': 'INTEGER',
    'xsd:boolean': 'INTEGER',
    'gml:PointPropertyType': 'BLOB',
}


def pgeo_to_sqlite(src: str, dst: str, new_table_names: Dict[str, str]=dict()) -> bool:
    """
    Converts the given source PGeo database into an equivalent SQLite w/ spatialite database. This will only convert spatial tables.
    :param src: The source PGeo file.
    :param dst: The destination SQLite file.
    :param new_table_names: The original->new table name mapping used to rename the created SQLite tables.
    """
    sqlite_driver: ogr.Driver = ogr.GetDriverByName('SQLite')
    pgeo_driver: ogr.Driver = ogr.GetDriverByName('PGeo')
    pgeo_source: ogr.DataSource = pgeo_driver.Open(src)

    if not isinstance(sqlite_driver.CopyDataSource(pgeo_source, dst, ['OGR_SQLITE_SYNCHRONOUS=OFF']), ogr.DataSource):
        return False

    if new_table_names:
        sqlite: sqlite3.Connection
        with sqlite3.connect(dst) as sqlite:
            old_table_name: str
            new_table_name: str
            for old_table_name, new_table_name in new_table_names.items():
                sqlite.executescript(f"""ALTER TABLE {old_table_name} RENAME TO {new_table_name};
                                     UPDATE geometry_columns SET f_table_name='{new_table_name}' WHERE f_table_name='{old_table_name}';
                                     UPDATE sqlite_sequence SET name='{new_table_name}' WHERE name='{old_table_name}';""")

    return True


def shapefile_to_sqlite(src: str, dst: str) -> bool:
    """
    Converts the given source shapefile into an equivalent SQLite w/ spatialite database.
    :param src: The source shapefile.
    :param dst: The destination SQLite file.
    """
    sqlite_driver: ogr.Driver = ogr.GetDriverByName('SQLite')
    shapefile_driver: ogr.Driver = ogr.GetDriverByName('ESRI Shapefile')
    shapefile_source: ogr.DataSource = shapefile_driver.Open(src)

    return isinstance(sqlite_driver.CopyDataSource(shapefile_source, dst, ['OGR_SQLITE_SYNCHRONOUS=OFF']), ogr.DataSource)


def copy_sqlite_to_mdb(sqlite_file: str, mdb_file: str, table_count_callback: Optional[Callable[[int], None]]=None,
                       table_callback: Optional[Callable[[str], None]]=None) -> bool:
    """
    Exports the provided SQLite file as an MDB file to the provided path.
    :param sqlite_file: The path of the SQLite file.
    :param mdb_file: The output path of the MDB file.
    :param table_count_callback: Invoked with the total number of tables to export.
    :param table_callback: Invoked after a table has been exported successfully.
    :return: True if the export is successful, otherwise false.
    """
    if not path.isfile(sqlite_file):
        return False
    if not path.isfile(mdb_file):
        return False

    # TODO: Add a way to handle non-exception errors
    sqlite: sqlite3.Connection
    mdb: pyodbc.Connection
    with contexts(sqlite3.connect(sqlite_file),
                  pyodbc.connect(f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}}; DBQ={mdb_file}")) as (sqlite, mdb):
        sqlite.row_factory = sqlite3.Row
        sqlite_cursor: sqlite3.Cursor = sqlite.cursor()
        mdb_cursor: pyodbc.Cursor = mdb.cursor()

        if table_count_callback is not None:
            table_count_callback(sqlite_cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type = 'table'").fetchone()[0])

        for table in [r['name'] for r in sqlite_cursor.execute("SELECT name FROM sqlite_master WHERE type = 'table'")]:
            if mdb_cursor.tables(table=table).fetchone():
                mdb_cursor.execute(f"DELETE FROM {table}")

            sqlite_data: sqlite3.Cursor = sqlite_cursor.execute(f"SELECT * FROM {table}")
            mdb_data: pyodbc.Cursor = mdb_cursor.execute(f"SELECT * FROM {table}")
            mdb_fields: List[Any] = list(mdb_data.columns(table=table))
            fields: Union[Set[str], List[str]] = (set([f[0] for f in sqlite_data.description]) & set([f[3] for f in mdb_fields]))
            types: Dict[str, Callable] = {f[3]: _TYPE_MAP[f[5]] for f in mdb_fields if f[3] in fields}
            fields = list(fields)
            args: List[Any] = [[types[f](r[f]) for f in fields] for r in sqlite_data]

            if args:
                field_names: str = ','.join(fields)
                params: str = ','.join(['?' for _ in fields])
                mdb_cursor.executemany(f"INSERT INTO {table} ({field_names}) VALUES ({params})", args)

                if table_callback is not None:
                    table_callback(table)

        mdb.commit()
        return True


def copy_mdb_to_sqlite(mdb_file: str, sqlite_file: str, ole_fields: List[str]=[],
                       included_tables: Optional[List[str]]=None,
                       table_count_callback: Optional[Callable[[int], None]]=None,
                       table_callback: Optional[Callable[[str], None]]=None) -> bool:
    """
    Copies the provided mdb file to the provided sqlite path.
    :param mdb_file: The MDB to copy.
    :param sqlite_file: The SQLite target.
    :param ole_fields: A list of OLE fields for the conversion.
    :param included_tables: A list of tables to include in the conversion. If not provided, all tables will be copied.
    :param table_count_callback: Invoked with the total number of tables that will be imported.
    :param table_callback: Invoked after a table has been imported successfully.
    :return: True if the copy is successful, otherwise false.
    """
    inclusions: Set[str] = None if included_tables is None else set(included_tables)
    # TODO: Add a way to handle non-exception errors
    mdb: pyodbc.Connection
    sqlite: sqlite3.Connection
    with contexts(pyodbc.connect(f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}}; DBQ={mdb_file}"),
                  sqlite3.connect(sqlite_file)) as (mdb, sqlite):
        mdb_cursor: pyodbc.Cursor = mdb.cursor()
        tables: List[str] = [r.table_name for r in mdb_cursor.tables(tableType='TABLE') if inclusions is None or r.table_name in inclusions]

        if table_count_callback is not None:
            table_count_callback(len(tables))

        table: str
        for table in tables:
            columns: List[oc.OdbcColumn] = sorted(_resolve_columns_and_types(mdb, table))

            create_table: str = """
            CREATE TABLE IF NOT EXISTS "{}" (
            {}
            )""".format(table, ",\n\t".join(str(c) for c in columns))

            sqlite.executescript(create_table)

            data_frame: pandas.DataFrame = pandas.read_sql_query(f"SELECT * FROM {table}", mdb)
            ole_columns: Set[str] = set(ole_fields) & set(data_frame)
            data_frame.to_sql(table, sqlite, if_exists='append', index=False, dtype={c: pandas.BLOB for c in ole_columns})

            if table_callback is not None:
                table_callback(table)

        return True


@retry(UnicodeDecodeError)
def _get_columns(mdb: pyodbc.Connection, table: str) -> List[pyodbc.Row]:
    """
    Gets the columns from the pyodbc connection.
    :param mdb: The mdb to read the columns from.
    :param table: The table to read the columns of.
    """
    iterator: Iterator = iter(mdb.cursor().columns(table=table))

    output: List[pyodbc.Row] = []
    try:
        while True:
            output.append(_get_column(iterator))
    except StopIteration:
        pass

    return output


def _get_column(iterator: Iterator) -> pyodbc.Row:
    """
    Gets the next column from the iterator, retrying if a UnicodeDecodeError is encountered.
    :param iterator: The iterator to retrieve the column from.
    """
    return iterator.__next__()


def _resolve_columns_and_types(mdb: pyodbc.Connection, table: str) -> Iterable['oc.OdbcColumn']:
    """
    Attempts to resolve the true type of all columns in the given MDB connection for the given table.
    :param mdb: The connection to the MDB to resolve the columns of.
    :param table: The table to resolve the columns of.
    """
    column: pyodbc.Row
    for column in _get_columns(mdb, table):
        yield oc.OdbcColumn(table_name=table,
                            position=column.ordinal_position,
                            name=column.column_name,
                            data_type=column.data_type,
                            type_name=column.type_name,
                            size=column.column_size,
                            precision=column.decimal_digits,
                            is_nullable=column.is_nullable == 'YES')

