from trc_packages.core.data import _column_reference as cr
from typing import Dict, List, Tuple
try: from typing import final  # type: ignore
except: from typing_extensions import final


@final
class ForeignReference:
    """Defines a foreign reference between 2 tables."""
    foreign_table: str
    key: List['cr.ColumnReference']
    columns: List['cr.ColumnReference']
    no_trigger: bool
    local_is_unique: bool
    foreign_is_unique: bool

    def __init__(self, foreign_table: str, key: List['cr.ColumnReference'], columns: List['cr.ColumnReference'], *, no_trigger: bool=False, local_is_unique: bool=False, foreign_is_unique: bool=False) -> None:
        self.foreign_table = foreign_table
        self.key = key
        self.columns = columns
        self.no_trigger = no_trigger
        self.local_is_unique = local_is_unique
        self.foreign_is_unique = foreign_is_unique

    def index_stmt(self, local_table: str, include_unique: bool=True) -> str:
        local_unique_part: str = ' UNIQUE ' if self.local_is_unique and include_unique else ' '
        index_stmts: List[str] = [f'''CREATE{local_unique_part}INDEX IF NOT EXISTS {local_table}_{self.join_local_columns('_')}
                                      ON {local_table} ({self.join_local_columns(', ')});''']
        if self.foreign_table != 'new':
            foreign_unique_part: str = ' UNIQUE ' if self.foreign_is_unique and include_unique else ' '
            index_stmts.append(f'''CREATE{foreign_unique_part}INDEX IF NOT EXISTS {self.foreign_table}_{self.join_foreign_columns('_')}
                                   ON {self.foreign_table} ({self.join_foreign_columns(', ')});''')
        return "\n".join(index_stmts)

    def update_stmt(self, local_table: str, new_reference: 'ForeignReference') -> str:
        return f'''UPDATE {local_table}
                   SET {self.coalesce_stmts(local_table, self.where_stmt(local_table))}
                   WHERE {new_reference.where_stmt(local_table)};'''

    def coalesce_stmts(self, local_table: str, where_statement: str) -> str:
        return ",\n\t\t".join(c.coalesce_stmt(local_table, self.foreign_table, where_statement) for c in self.columns)

    def where_stmt(self, local_table: str) -> str:
        return " AND ".join(c.equality_stmt(local_table, self.foreign_table) for c in self.key)

    def on_update_stmt_name(self, local_table: str) -> str:
        return f"{local_table}_after_update_of_{self.join_local_columns('_or_')}"

    def join_local_columns(self, sep: str) -> str:
        return sep.join(k.local_column for k in self.key)

    def join_foreign_columns(self, sep: str) -> str:
        return sep.join(k.foreign_column for k in self.key)

    def on_update_stmt(self, local_table: str, new_reference: 'ForeignReference') -> str:
        return f'''
CREATE TRIGGER IF NOT EXISTS {self.on_update_stmt_name(local_table)}
AFTER UPDATE OF {self.join_local_columns(', ')}
ON {local_table}
FOR EACH ROW BEGIN
{self.update_stmt(local_table, new_reference)}
END;'''

