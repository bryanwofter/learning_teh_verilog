from . import last
from datetime import datetime, date, time
from PyQt5.QtCore import QDateTime, QDate, QTime
from enum import Enum
from typing import Any, ClassVar, Dict, Type, Union
from abc import ABC, abstractmethod
import json


class AbstractJSONDecoder(json.JSONDecoder, ABC):

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        kwargs['object_hook'] = self.object_hook
        super().__init__(*args, **kwargs)

    @abstractmethod
    def object_hook(self, value: Dict) -> Any:
        """
        Returns the value based off of this decoder.
        :param value: The value to decode.
        :return: The decoded value.
        """
        return value


KNOWN_ENUMS: Dict[str, Type[Enum]] = dict()


class JSONEnum(Enum):
    """Provides an Enum base that'll automatically register the type if it inherits from an enum.* type."""

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__()
        global KNOWN_ENUMS
        KNOWN_ENUMS[cls.__name__] = cls


class EnumJSONEncoder(json.JSONEncoder):
    """Provides enum encoding support to the JSON encoder."""

    trc_nested: bool = False
    known_enums: ClassVar[Dict[str, Type[Enum]]] = KNOWN_ENUMS

    def default(self, value: Any) -> Any:
        if type(value) in KNOWN_ENUMS.values():
            return {'__enum__': {'__type__': type(value).__name__, '__member__': last(str(value).split('.'))}}
        elif self.trc_nested:
            return NotImplemented
        else:
            return super().default(value)


class EnumJSONDecoder(AbstractJSONDecoder):
    """Provides enum decoding support to the JSON decoder."""

    known_enums: ClassVar[Dict[str, Type[Enum]]] = KNOWN_ENUMS

    def object_hook(self, value: Dict) -> Any:
        if '__enum__' in value:
            enum_: Dict[str, str] = value['__enum__']
            return KNOWN_ENUMS[enum_['__type__']](enum_['__member__'])
        return value


class QDateJSONEncoder(json.JSONEncoder):
    """Provides QDate encoding support to the JSON encoder."""

    trc_nested: bool = False

    def default(self, value: Any) -> Any:
        if isinstance(value, QDate):
            return {'__date__': value.toString('yyyy-MM-dd')}
        elif self.trc_nested:
            return NotImplemented
        else:
            return super().default(value)


class QDateJSONDecoder(AbstractJSONDecoder):
    """Provides QDate decoding support to the JSON decoder."""

    def object_hook(self, value: Dict) -> Any:
        if '__date__' in value:
            date: QDate = QDate.fromString(value['__date__'], 'yyyy-MM-dd')
            if date.isValid():
                return date
        return value


class QDateTimeJSONEncoder(json.JSONEncoder):
    """Provides QDateTime encoding support to the JSON encoder."""

    trc_nested: bool = False

    def default(self, value: Any) -> Any:
        if isinstance(value, QDateTime):
            return {'__datetime__': value.toString('yyyy-MM-ddThh:mm:ss')}
        elif self.trc_nested:
            return NotImplemented
        return super().default(value)


class QDateTimeJSONDecoder(AbstractJSONDecoder):
    """Provides QDateTime decoding support to the JSON decoder."""

    def object_hook(self, value: Dict) -> Any:
        if '__datetime__' in value:
            datetime: QDateTime = QDateTime.fromString(value['__datetime__'], 'yyyy-MM-ddThh:mm:ss')
            if datetime.isValid():
                return datetime
        return value


class TrcJSONEncoder(json.JSONEncoder):
    """Provides a JSONEncoder that combines all prior declared encoders."""

    __enum_encoder = EnumJSONEncoder()
    __qdate_encoder = QDateJSONEncoder()
    __qdatetime_encoder = QDateTimeJSONEncoder()

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.__enum_encoder.trc_nested = True
        self.__qdate_encoder.trc_nested = True
        self.__qdatetime_encoder.trc_nested = True

    def default(self, value: Any) -> Any:
        if isinstance(value, Enum):
            return self.__enum_encoder.default(value)
        elif isinstance(value, QDate):
            return self.__qdate_encoder.default(value)
        elif isinstance(value, QDateTime):
            return self.__qdatetime_encoder.default(value)
        return super().default(value)


class TrcJSONDecoder(AbstractJSONDecoder):
    """Provides a JSONDecoder that combines all prior declared decoders."""

    __enum_decoder = EnumJSONDecoder()
    __qdate_decoder = QDateJSONDecoder()
    __qdatetime_decoder = QDateTimeJSONDecoder()

    def object_hook(self, value: Dict) -> Any:
        output = self.__enum_decoder.object_hook(value)
        if isinstance(output, Enum):
            return output
        output = self.__qdate_decoder.object_hook(value)
        if isinstance(output, QDate):
            return output
        output = self.__qdatetime_decoder.object_hook(value)
        if isinstance(output, QDateTime):
            return output
        return value


class TrcSimpleEncoder(json.JSONEncoder):
    """Provides a JSONEncoder that provides a simple encoding interface."""

    def default(self, value: Any) -> Any:
        try:
            return super().default(value)
        except TypeError as e:
            if isinstance(value, Enum):
                return self.__encode_enum(value)
            elif isinstance(value, QDate) or isinstance(value, date):
                return self.__encode_date(value)
            elif isinstance(value, QDateTime) or isinstance(value, datetime):
                return self.__encode_datetime(value)
            elif isinstance(value, QTime) or isinstance(value, time):
                return self.__encode_time(value)
            raise e

    def __encode_enum(self, value: Enum) -> str:
        return value._name_

    def __encode_date(self, value: Union[QDate, date]) -> str:
        if isinstance(value, QDate):
            value = date(value.year(), value.month(), value.day()) if value.isValid() else None

        if value is not None:
            value = value.isoformat()
        return value

    def __encode_datetime(self, value: Union[QDateTime, datetime]) -> str:
        if isinstance(value, QDateTime):
            date: QDate = value.date()
            time: QTime = value.time()
            value = datetime(date.year(), date.month(), date.day(), time.hour(), time.minute(), time.second(), time.msec()) if value.isValid() else None

        if value is not None:
            value = value.isoformat()
        return value

    def __encode_time(self, value: Union[QTime, time]) -> str:
        if isinstance(value, QTime):
            value = time(value.hour(), value.minute(), value.second(), value.msec()) if value.isValid() else None

        if value is not None:
            value = value.isoformat()
        return value

