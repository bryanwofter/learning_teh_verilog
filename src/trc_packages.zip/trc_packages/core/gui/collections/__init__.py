from trc_packages.gui import (QtDict as QtDict)
