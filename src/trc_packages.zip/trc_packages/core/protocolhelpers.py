from trc_packages.core import _functions as f
from typing import FrozenSet, Type, TypeVar
_T = TypeVar('_T')
_P = TypeVar('_P')


def follows_protocol(C: Type[_T], P: Type[_P], *members: str, check_type_annotations: bool=False) -> bool:
    """
    Determnines if C follows the protocol P.
    :param C: The class to check against the protocol.
    :param P: The protocol to check against.
    :param members: The members to check for. If none are provided, then all members of the protocol are used.
    :param check_type_annotations: True if C should have its type annotations checked against P, otherwise False. If either type has no type annotations, this is treated as False.
    """

    if C is P:
        return True

    known_fields: FrozenSet[str] = frozenset(f.flatten(B.__dict__ for B in C.__mro__))
    proto_fields: FrozenSet[str] = frozenset(members if any(members) else (f_ for f_ in f.flatten(B.__dict__ for B in P.__mro__) if not f_.startswith('__')))

    has_all_members: bool = known_fields >= proto_fields

    if has_all_members and check_type_annotations and hasattr(C, '__annotations__') and hasattr(P, '__annotations__'):
        for field in proto_fields:  # type: str
            if (field in P.__annotations__ and
                not (field in C.__annotations__ and
                     C.__annotations__[field] is P.__annotations__[field])):
                return False

    return has_all_members

