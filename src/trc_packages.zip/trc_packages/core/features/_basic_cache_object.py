from qgis.core import QgsFeature  # type: ignore
from typing import cast, Generic, Optional, TypeVar
from trc_packages.core.features import _basic_feature_object as basic_feature_object, _basic_vector_object as basic_vector_object, protocols
from trc_packages.core.ui import _supports_read_write_synchronized as srws, _contextmanagers as contextmanagers
import weakref
TFeature = TypeVar('TFeature', bound='protocols.Feature')
TVector = TypeVar('TVector', bound='protocols.Vector')


class BasicCacheObject(Generic[TFeature, TVector], srws.SupportsReadWriteSynchronized):
    """A basic caching object that provides weak reference caching for feature objects."""
    caching: bool = True
    _feature_cache: weakref.WeakValueDictionary = None
    _vector_object: weakref.ReferenceType = None

    @property
    def vector_object(self) -> TVector:
        return cast(TVector, self._vector_object())

    def __init__(self, vector_object: TVector) -> None:
        self._vector_object = weakref.ref(vector_object)
        self._feature_cache = weakref.WeakValueDictionary()

    def has(self, qgs_feature: Optional[QgsFeature]) -> bool:
        """
        Returns True if the qgs_feature exists in this cache, otherwise False.
        :param qgs_feature: The feature to check for the existence of.
        """
        if qgs_feature is None:
            return False
        if self.caching:
            with self.read_synchronized(fail_on_timeout=True):
                return qgs_feature.id() in self._feature_cache
        return False

    def get(self, qgs_feature: Optional[QgsFeature]) -> Optional[TFeature]:
        """
        Returns a feature from this cache, adding it to the cache if it isn't already.
        :param qgs_feature: The feature to cache.
        """
        if qgs_feature is None:
            return None
        if self.caching:
            return self._get_or_cache(qgs_feature)
        return self.vector_object.feature_object_type(self.vector_object, qgs_feature)

    def remove(self, qgs_feature: QgsFeature) -> None:
        """
        Deletes the cached item associated to the given qgs_feature.
        :param qgs_feature: The QgsFeature to delete.
        """
        if qgs_feature is not None and self.caching:
            self._remove_from_cache(qgs_feature)

    def _get_or_cache(self, qgs_feature: QgsFeature) -> TFeature:
        """
        Gets or caches the given feature in this cache.
        :param qgs_feature: The feature to cache.
        """
        id_: int = qgs_feature.id()
        with self.upgradeable_synchronized(fail_on_timeout=True) as lock:  # type: contextmanagers.ReadWriteLockManager
            feature_object: Optional[TFeature] = self._feature_cache.get(id_)

            if feature_object is None:
                with lock.upgrade:
                    feature_object = self._feature_cache.get(id_)

                    if feature_object is None:
                        feature_object = self.vector_object.feature_object_type(self.vector_object, qgs_feature)
                        self._feature_cache[id_] = feature_object

            return feature_object

    def _remove_from_cache(self, qgs_feature: QgsFeature) -> None:
        """
        Removes the cached feature.
        :param qgs_feature: The feature to remove.
        """
        id_: int = qgs_feature.id()
        with self.upgradeable_synchronized(fail_on_timeout=True) as lock:  # type: contextmanagers.ReadWriteLockManager
            feature_object: Optional[TFeature] = self._feature_cache.get(id_)

            if feature_object is not None:
                with lock.upgrade:
                    feature_object = self._feature_cache.get(id_)

                    if feature_object is not None:
                        del self._feature_cache[id_]
                        del feature_object

