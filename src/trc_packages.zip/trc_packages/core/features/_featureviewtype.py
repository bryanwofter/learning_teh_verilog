from functools import wraps
from PyQt5.QtCore import QObject, pyqtSignal, QMutex, pyqtSlot
from sip import wrappertype  # type: ignore
from trc_packages.core.features import protocols, _feature_view as fv
from trc_packages.core.ui import _contextmanagers as contextmanagers
from typing import Any, Callable, cast, ClassVar, Dict, Generic, List, NoReturn, Optional, overload, Type, TypeVar, Tuple, Union
TDb = TypeVar('TDb')
TFeature = TypeVar('TFeature', bound='protocols.Feature')
TPy = TypeVar('TPy')


class featureviewtype(wrappertype):
    """
    Provides a metaclass used to create protocols.Feature views that are unbound from their primary vector. These objects are able to be converted
    back to their non-view counterparts. To initialize a new featureviewtype type, you MUST use the generic argument method to produce a valid object.
    """

    def __new__(meta_class: Type, class_name: str, class_parents: Tuple[type, ...], class_attrs: Dict[str, Any], *, feature_type: Type[TFeature], **kwargs: Any) -> Type['featureviewtype']:  # type: ignore
        """
        Initializes this featureviewtype type with the given information.
        :param meta_class: The metaclass type.
        :param class_name: The name of the new class.
        :param class_parents: The parent types of the new class.
        :param class_attrs: The attributes of the new class.
        :param feature_type: The type of feature represented by the new class.
        """
        if fv.FeatureView not in class_parents:
            class_parents = (*class_parents, fv.FeatureView[TFeature])

        fields: Dict[str, Any] = featureviewtype.__make_fields(feature_type, class_attrs.get('__annotations__', {}))
        fields.update(class_attrs)
        working_type: Type[featureviewtype] = cast(Type[featureviewtype], super().__new__(meta_class, class_name, class_parents, fields))
        return working_type

    def __class_getitem__(cls, feature_type: Type[TFeature]):
        """
        Returns a new typed featureviewtype type.
        :param feature_type: The Feature type being represented by this featureviewtype.
        """
        @wraps(cls.__new__)
        def __new(class_name: str, class_parents: Any, class_attrs: Any, *args: Any, **kwargs: Any) -> Type['featureviewtype']:
            return cast(Type[featureviewtype], cls(class_name, class_parents, class_attrs, *args, feature_type=feature_type, **kwargs))
        return __new

    @staticmethod
    def __make_fields(c: Type[TFeature], type_annotations: Dict[str, Type]) -> Dict[str, Any]:
        """
        Builds the fields of the new class.
        :param c: The feature type the new class is being built from.
        :param type_annotations: The type annotations of the new generated class.
        """
        items: Dict[str, 'protocols.Item'] = cast(Type['protocols.ItemProvider'], c).get_feature_items()
        field_to_property_map: Dict[str, str] = dict()
        properties: Dict[str, Any] = {'FIELD_TO_PROPERTY_MAP': field_to_property_map, 'FEATURE_TYPE': c}

        for name, value in items.items():
            # Items must have a field name and must not be read-only to be mappable to and from a property in the featureviewtype.
            if value.field_name is not None and not value.is_read_only:
                properties[name] = featureviewtype.__make_property(name, value.to_input, value.to_output)
                properties[f'set_{name}'] = featureviewtype.__make_slot(name, type_annotations.get(name))
                properties[f"_{name}"] = None
                field_to_property_map[value.field_name] = name

        return properties

    @staticmethod
    def __make_slot(property_name: str, type_: Optional[Type]) -> Callable[['fv.FeatureView', TPy], None]:
        """
        Builds a new slot for setting the given property.
        :param property_name: The name of the property.
        """
        slot_type: Union[str, Type] = 'PyQt_PyObject' if type_ is None or 'builtins' != type_.__module__ else type_
        slot_name: str = f"set_{property_name}"
        slot_name_parts: List[str] = slot_name.split('_')

        for i in range(1, len(slot_name_parts)):  # type: int
            slot_name_parts[i] = slot_name_parts[i].title()

        alternate_slot_name: str = ''.join(slot_name_parts)

        @pyqtSlot(slot_type, name=slot_name)
        @pyqtSlot(slot_type, name=alternate_slot_name)
        def __set_property(self, value: TPy) -> None:
            with self.synchronized(fail_on_timeout=True):
                setattr(self, property_name, value)
        __set_property.__name__ = slot_name

        return __set_property

    @staticmethod
    def __make_property(property_name: str, input_converter: Callable[[TPy], TDb], output_converter: Callable[[TDb], TPy]) -> property:
        """
        Builds a new property with the given name and using the given converters.
        :param property_name: The name of the property being created. This is used to generate the backing field.
        :param input_converter: The converter for writing to the backing field.
        :param output_converter: The converter for reading from the backing field.
        """
        field_name: str = f"_{property_name}"

        def __del(self) -> NoReturn:
            nonlocal field_name
            nonlocal property_name
            old_value: Any = getattr(self, property_name)
            delattr(self, field_name)
            self.property_changed.emit(property_name, None, old_value)

        def __get(self) -> TPy:
            nonlocal field_name
            nonlocal output_converter
            return output_converter(getattr(self, field_name))

        def __set(self, value: TPy) -> NoReturn:
            nonlocal field_name
            nonlocal input_converter
            nonlocal property_name
            old_value: TPy = getattr(self, property_name)
            setattr(self, field_name, input_converter(value))
            self.property_changed.emit(property_name, value, old_value)

        return property(fdel=__del, fget=__get, fset=__set)

