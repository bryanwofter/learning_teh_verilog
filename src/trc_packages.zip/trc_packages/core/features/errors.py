from trc_packages.core.features import protocols
from trc_packages.core.types import WeakReferenceType
from typing import Iterable, Optional, Type
import weakref


class FeatureFailedValidationError(Exception):
    """Raised when a feature has failed validation."""

    @property
    def validation_results(self) -> Iterable['protocols.ValidationResult']:
        return self._validation_results

    def __init__(self, validation_results: Iterable['protocols.ValidationResult']) -> None:
        self._validation_results = list(validation_results)

    def __str__(self) -> str:
        return ".\r\n".join(v.message for v in self.validation_results) + '.'


class HashFieldRequiredError(Exception):
    """Raised when a hash field is required by a feature."""

    @property
    def vector_type(self) -> Optional[Type[protocols.Vector]]:
        return self._vector_type

    def __init__(self, vector_type: Optional[Type[protocols.Vector]]=None) -> None:
        self._vector_type = vector_type


class FieldMissingError(Exception):
    """Raised when a BasicFeatureObject fails to find a field."""

    @property
    def field_name(self) -> str:
        return self._field_name

    @property
    def vector_name(self) -> str:
        return self._vector_name

    def __init__(self, field_name: str, vector_name: str) -> None:
        self._field_name = field_name
        self._vector_name = vector_name


class TransactionException(Exception):
    """A base for all transaction-based exceptions."""


class StartTransactionFailedError(TransactionException):
    """Raised when a BasicVectorObject fails to begin a new Transaction."""

    @property
    def vector_object(self) -> Optional[object]:
        """The BasicVectorObject that had a transaction attempted."""
        return self._vector_object()

    def __init__(self, vector_object: object) -> None:
        self._vector_object: WeakReferenceType[object] = weakref.ref(vector_object)


class UneditableTransactionError(TransactionException):
    """Raised when a BasicVectorObject is committed while the transaction isn't started."""
    pass


class CommitTransactionFailedError(TransactionException):
    """Raised when a BasicVectorObject fails to commit a Transaction."""

    @property
    def vector_object(self) -> Optional[object]:
        """The BasicVectorObject that had a commit attempted."""
        return self._vector_object()

    def __init__(self, vector_object: object, message: Optional[str]=None) -> None:
        super().__init__(message or ("\n".join(vector_object.qgs_layer.commitErrors()) if vector_object is not None and vector_object.qgs_layer is not None else None))
        self._vector_object: WeakReferenceType[object] = weakref.ref(vector_object)


class ReadOnlyFeatureItemError(Exception):
    """Raised when a read-only FeatureItem is modified."""

    @property
    def field_name(self) -> str:
        return self._field_name

    @property
    def feature_item_name(self) -> str:
        return self._feature_item_name

    @property
    def vector_name(self) -> str:
        return self._vector_name

    def __init__(self, field_name: str, feature_item_name: str, vector_name: str) -> None:
        self._field_name = field_name
        self._feature_item_name = feature_item_name
        self._vector_name = vector_name

