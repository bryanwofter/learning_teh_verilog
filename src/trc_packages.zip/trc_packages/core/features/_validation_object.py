from abc import ABC, abstractmethod
from typing import Generic, List, Optional, TypeVar

T = TypeVar('T')

class ValidationObject(ABC, Generic[T]):
    """Provides the methods needed to implement a validator for a feature object."""

    feature_object: T
    validation_messages: List[str]

    def __init__(self, feature_object: T) -> None:
        self.feature_object = feature_object
        self.validation_messages = []

    @abstractmethod
    def validate(self) -> bool:
        """
        Validates the provided feature object against this validator.
        :return: True if the validations are passed, otherwise false.
        """
        pass

    def get_message(self, join_char: str='\n') -> Optional[str]:
        """
        Returns the validation messages joined by the optional join character.
        :param join_char: The character to join the validation messages with. By default, this is the newline character.
        :return: The joined message value or None.
        """
        return join_char.join(self.validation_messages) if any(self.validation_messages) else None
