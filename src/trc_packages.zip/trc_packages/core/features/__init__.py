"""
Defines all classes, functions and modules that are needed to create objects that wrap QGIS vectors and features.

Additional documentation may be found on the wiki for the github repository.
"""

import trc_packages

if trc_packages.QGIS_EXISTS:
    from trc_packages.core.features import errors as errors

    from trc_packages.core.features import protocols as protocols

    from trc_packages.core.features._basic_cache_object import BasicCacheObject as BasicCacheObject

    from trc_packages.core.features._basic_feature_object import (BasicFeatureObject as BasicFeatureObject,
                                                                  FeatureItemProvider as FeatureItemProvider)

    from trc_packages.core.features._basic_vector_object import BasicVectorObject as BasicVectorObject

    from trc_packages.core.features._contextmanagers import transaction as transaction

    from trc_packages.core.features._feature_item import (FeatureItem as FeatureItem,
                                                          BoolFeatureItem as BoolFeatureItem,
                                                          DateFeatureItem as DateFeatureItem,
                                                          TimeFeatureItem as TimeFeatureItem,
                                                          DateTimeFeatureItem as DateTimeFeatureItem,
                                                          EnumFeatureItem as EnumFeatureItem,
                                                          FloatFeatureItem as FloatFeatureItem,
                                                          IntFeatureItem as IntFeatureItem,
                                                          StrFeatureItem as StrFeatureItem,
                                                          BinaryItem as BinaryItem)

    from trc_packages.core.features._feature_property import FeatureProperty as FeatureProperty

    from trc_packages.core.features._featureviewtype import featureviewtype as featureviewtype

    from trc_packages.core.features._feature_view import FeatureView as FeatureView

    from trc_packages.core.features import factories as factories

    from trc_packages.core.features._functions import (escape_filter_args as escape_filter_args,
                                                       feature_sort as feature_sort,
                                                       make_guid as make_guid,
                                                       transfer_fields as transfer_fields,
                                                       FieldNameType as FieldNameType,
                                                       format_feature as format_feature,
                                                       resolve_fields as resolve_fields)

    from trc_packages.core.features._validation_object import ValidationObject as ValidationObject

    from trc_packages.core.features._aliastypes import (TFeature as TFeature,
                                                        GuidUnion as GuidUnion,
                                                        FeatureUnion as FeatureUnion,
                                                        GuidUnionList as GuidUnionList,
                                                        FeatureUnionList as FeatureUnionList,
                                                        Date as Date,
                                                        Time as Time,
                                                        DateTime as DateTime)

    from trc_packages.core.features._vector_provider import (VectorNamePair as VectorNamePair,
                                                             VectorProvider as VectorProvider)

__all__: list = [f for f in globals()]

