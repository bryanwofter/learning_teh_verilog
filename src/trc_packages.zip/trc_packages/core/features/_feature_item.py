from datetime import date, datetime, time
from enum import Enum
from PyQt5.QtCore import QDate, QDateTime, QTime
from trc_packages.core import first
from trc_packages.core.features import _basic_feature_object as basic_feature_object, protocols
from trc_packages.core.safecasts import safe_bool, safe_cast, safe_float, safe_int, safe_str, safe_datetime
from trc_packages.decorators import qsafe
from typing import Any, Callable, cast, Generic, Optional, Type, TypeVar, TYPE_CHECKING
import sqlite3

T = TypeVar('T')
TDb_co = TypeVar('TDb_co', covariant=True)
TEnum_co = TypeVar('TEnum_co', covariant=True, bound=Enum)
TFeature = TypeVar('TFeature', bound='protocols.Feature')
TFeature_contra = TypeVar('TFeature_contra', bound='protocols.Feature')
TPy_co = TypeVar('TPy_co', covariant=True)

class FeatureItem(protocols.Item[TPy_co, TDb_co], Generic[TPy_co, TDb_co]):
    """Provides a decorator that can be used with explicit implementations of BasicFeatureObject."""

    __name: Optional[str] = None
    __is_read_only: bool = False
    _output_converter: Optional[Callable[[Any], TPy_co]] = None
    _input_converter: Optional[Callable[[Any], TDb_co]] = None

    @staticmethod
    @qsafe
    def default_input_converter(value: Any) -> TDb_co:
        return cast(TDb_co, value)

    @staticmethod
    @qsafe
    def default_output_converter(value: Any) -> TPy_co:
        return cast(TPy_co, value)

    @property
    def field_name(self) -> Optional[str]:
        return self.__name

    @property
    def is_read_only(self) -> bool:
        return self.__is_read_only

    @is_read_only.setter
    def is_read_only(self, value: bool) -> None:
        self.__is_read_only = value

    @is_read_only.deleter
    def is_read_only(self) -> None:
        self.is_read_only = False

    @property
    def input_converter(self) -> Optional[Callable[[Any], TDb_co]]:
        return self._input_converter or type(self)._input_converter or self.default_input_converter

    @input_converter.setter
    def input_converter(self, value: Optional[Callable[[Any], TDb_co]]) -> None:
        self._input_converter = value

    @input_converter.deleter
    def input_converter(self) -> None:
        self.input_converter = None

    @property
    def output_converter(self) -> Optional[Callable[[Any], TPy_co]]:
        return self._output_converter or type(self)._output_converter or self.default_output_converter

    @output_converter.setter
    def output_converter(self, value: Optional[Callable[[Any], TPy_co]]) -> None:
        self._output_converter = value

    @output_converter.deleter
    def output_converter(self) -> None:
        self.output_converter = None

    def __init__(self, name: Optional[str], is_read_only: bool=False, input_converter: Optional[Callable[[Any], TDb_co]]=None,
                 output_converter: Optional[Callable[[Any], TPy_co]]=None, *, doc: Optional[str]=None) -> None:
        self.__name = name
        self.__is_read_only = is_read_only
        self.output_converter = output_converter
        self.input_converter = input_converter
        self.__doc__ = doc

    def __get__(self, instance: TFeature, owner: Type[TFeature]) -> TPy_co:
        return cast(TPy_co, None) if self.__name is None else instance[self.__name]

    def __set__(self, instance: TFeature, value: T) -> None:
        if self.__name is not None:
            instance[self.__name] = value

    def __set_name__(self, owner: Type[TFeature], name: str) -> None:
        if self.__name is None:
            self.__name = name

    def __delete__(self, instance: TFeature) -> None:
        if self.__name is not None:
            del instance[self.__name]

    @qsafe
    def to_input(self, value: T) -> TDb_co:
        return cast(TDb_co, value) if self.input_converter is None else self.input_converter(value)

    @qsafe
    def to_output(self, value: T) -> TPy_co:
        return cast(TPy_co, value) if self.output_converter is None else self.output_converter(value)


class BoolFeatureItem(FeatureItem[Optional[bool], Optional[int]]):
    _input_converter = safe_int
    _output_converter = safe_bool


class DateFeatureItem(FeatureItem[Optional[QDate], Optional[str]]):
    @staticmethod
    @qsafe
    def default_input_converter(value: Any) -> Optional[str]:
        if isinstance(value, QDateTime):
            return value.toString('yyyy-MM-dd')
        elif isinstance(value, QDate):
            return value.toString('yyyy-MM-dd')
        else:
            return value

    @staticmethod
    @qsafe
    def default_output_converter(value: Any) -> Optional[QDate]:
        if isinstance(value, QDateTime):
            return value.date()
        elif isinstance(value, str):
            return QDate.fromString(value, 'yyyy-MM-dd')
        else:
            return value


class TimeFeatureItem(FeatureItem[Optional[QTime], Optional[str]]):
    @staticmethod
    @qsafe
    def default_input_converter(value: Any) -> Optional[str]:
        if isinstance(value, QDateTime):
            return value.toString('hh:mm:ss')
        elif isinstance(value, datetime):
            return value.strftime('%H:%M:%S')
        elif isinstance(value, QTime):
            return value.toString('hh:mm:ss')
        elif isinstance(value, time):
            return value.strftime('%H:%M:%S')
        else:
            return value

    @staticmethod
    @qsafe
    def default_output_converter(value: Any) -> Optional[QTime]:
        if isinstance(value, QDateTime):
            return value.time()
        elif isinstance(value, str):
            return QTime.fromString(value, 'hh:mm:ss')
        else:
            return value


class DateTimeFeatureItem(FeatureItem[Optional[QDateTime], Optional[str]]):
    @staticmethod
    def default_input_converter(value: Any) -> Optional[str]:
        if isinstance(value, QDateTime):
            return value.toString('yyyy-MM-ddThh:mm:ss')
        elif isinstance(value, datetime):
            return value.strftime('%Y-%m-%dT%H:%M:%S')
        elif isinstance(value, QDate):
            return value.toString('yyyy-MM-ddT00:00:00')
        elif isinstance(value, date):
            return value.strftime('%Y-%m-%dT00:00:00')
        else:
            return value

    @staticmethod
    def default_output_converter(value: Any) -> Optional[QDateTime]:
        if isinstance(value, QDate):
            return QDateTime(value)
        elif isinstance(value, str):
            value = safe_datetime(value)

            return None if value is None else QDateTime(QDate(value.year, value.month, value.day), QTime(value.hour, value.minute, value.second))
        else:
            return value


class EnumFeatureItem(FeatureItem[Optional[TEnum_co], Optional[TDb_co]]):
    @qsafe
    def __default_input_converter(self, value: Any) -> Optional[TDb_co]:
        return cast(TDb_co, value.value if isinstance(value, self.__enum_type) else value)

    @qsafe
    def __default_output_converter(self, value: Any) -> Optional[TEnum_co]:
        return safe_cast(self.__enum_type, value)

    __enum_type: Type[TEnum_co]
    @property
    def enum_type(self) -> Type[TEnum_co]:
        return self.__enum_type

    def __init__(self, name: str, enum_type: Type[TEnum_co], is_read_only: bool=False, input_converter: Optional[Callable[[Any], TDb_co]]=None,
                 output_converter: Optional[Callable[[Any], TEnum_co]]=None, *, doc: Optional[str]=None) -> None:
        super().__init__(name=name, is_read_only=is_read_only, input_converter=input_converter or self.__default_input_converter,
                         output_converter=output_converter or self.__default_output_converter, doc=doc)

        self.__enum_type = enum_type


class FloatFeatureItem(FeatureItem[Optional[float], Optional[float]]):
    _input_converter = safe_float
    _output_converter = safe_float


class IntFeatureItem(FeatureItem[Optional[int], Optional[int]]):
    _input_converter = safe_int
    _output_converter = safe_int


class StrFeatureItem(FeatureItem[Optional[str], Optional[str]]):
    _input_converter = safe_str
    _output_converter = safe_str


class BinaryItem(Generic[TFeature_contra]):
    """
    Provides a decorator that can be used with explicit implementations of BasicFeatureObject.

    BinaryItem objects should encompass only fields that require special handling. They are
    slower than standard FeatureItem instances and are *not* transaction safe. All BinaryItem
    properties require their target object to be saved prior to being updated.

    setter property must be set to the SQL used to set/update the field if provided.
    getter property must be set to the SQL used to select the field.
    id_supplier property must be set to a callable that returns the ID of the target object.
    connection_supplier property must be set to a callable that returns the sqlite3 connection of the target object.
    """

    table: str
    id_field: str
    value_field: str
    connection_supplier: Callable[..., sqlite3.Connection]
    is_read_only: bool

    _setter: Optional[str] = None
    @property
    def setter(self) -> str:
        if not self.is_read_only and self._setter is None:
            self._setter = f"""INSERT INTO {self.table} ({self.id_field}, {self.value_field})
                               VALUES (:id, :value)
                               ON CONFLICT ({self.id_field}) DO
                               UPDATE SET ({self.value_field} = :value)
                               WHERE ({self.id_field} = :id)"""
        return cast(str, self._setter)

    _getter: Optional[str] = None
    @property
    def getter(self) -> str:
        if self._getter is None:
            self._getter = f"SELECT {self.value_field} FROM {self.table} WHERE {self.id_field} = ?"
        return cast(str, self._getter)

    def __init__(self, table: str, id_field: str, value_field: str, connection_supplier: Callable[..., sqlite3.Connection],
                 is_read_only: bool=False, *, doc: Optional[str]=None) -> None:
        self.table = table
        self.id_field = id_field
        self.value_field = value_field
        self.connection_supplier = connection_supplier  # type: ignore
        self.is_read_only = is_read_only

    @qsafe
    def __get__(self, instance: TFeature_contra, owner: object) -> Optional[bytes]:
        with self.connection_supplier() as sqlite: #type: sqlite3.Connection
            data: Any = sqlite.execute(self.getter, [instance[self.id_field]]).fetchone()
            return None if data is None else first(list(data))

    @qsafe
    def __set__(self, instance: TFeature_contra, value: Optional[bytes]) -> None:
        if self.setter is not None:
            with self.connection_supplier() as sqlite: #type: sqlite3.Connection
                sqlite.execute(self.setter, {'id': instance[self.id_field], 'value': value})

    def __deleter__(self, instance: TFeature_contra) -> None:
        self.__set__(instance, None)

