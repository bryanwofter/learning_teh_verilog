from enum import Enum
from PyQt5 import QtCore
from PyQt5.QtCore import QDate, QDateTime, QTime
from sqlite3 import Connection
from typing import Any, Callable, Dict, Optional, overload, Tuple, Type, TypeVar, Union
from trc_packages.core.features import _feature_item as fitem, _feature_property as fprop, _feature_view as fview, _basic_vector_object as bvo, protocols
from qgis import core  # type: ignore
F = TypeVar('F', bound=Callable[..., Any])
TDb_co = TypeVar('TDb_co', covariant=True)
TDb = TypeVar('TDb')
TEnum_co = TypeVar('TEnum_co', covariant=True, bound=Enum)
TFeature = TypeVar('TFeature', bound='protocols.Feature')
TItem_co = TypeVar('TItem_co', covariant=True, bound='protocols.Item')
TPy_co = TypeVar('TPy_co', covariant=True)
TPy = TypeVar('TPy')
DbTypeCallable = Optional[Callable[[Any], TDb_co]]
PyTypeCallable = Optional[Callable[[Any], TPy_co]]


@overload
def property_item(*, name: Optional[str]=None, tfeature: Optional[Type[TFeature]]=None, tin: Optional[Type[TDb]]=None,
                  tout: Optional[Type[TPy]]=None) -> Callable[[Callable[[TFeature], TPy]], fprop.FeatureProperty[TPy, TDb, TFeature]]:
    ...
@overload
def property_item(*, name: Optional[str]=None, tfeature: Optional[Type[TFeature]]=None, fin: Optional[Callable[[Any], TDb]]=None,
                  fout: Optional[Callable[[Any], TPy]]=None) -> Callable[[Callable[[TFeature], TPy]], fprop.FeatureProperty[TPy, TDb, TFeature]]:
    ...
@overload
def property_item(*, name: Optional[str]=None, fin: Optional[Callable[[Any], TDb]]=None, fout: Optional[Callable[[Any], TPy]]=None,
                  fdel: Optional[Callable[[TFeature], None]]=None, fget: Optional[Callable[[TFeature], None]]=None,
                  fset: Optional[Callable[[TFeature, TPy], None]]=None) -> Callable[[Callable[[TFeature], TPy]], fprop.FeatureProperty[TPy, TDb, TFeature]]:
    ...


def property_item(*, name: Optional[str]=None, tfeature: Optional[Type]=None, tin: Optional[Type]=None, tout: Optional[Type]=None,
                  fin: Optional[Callable[[Any], Any]]=None, fout: Optional[Callable[[Any], Any]]=None, fdel: Optional[Callable[[Any], None]]=None,
                  fget: Optional[Callable[[Any], Any]]=None, fset: Optional[Callable[[Any, Any], None]]=None) -> Callable[[Callable[..., Any]], fprop.FeatureProperty]:
    """
    Returns a decorator factory that creates a FeatureProperty with the given types and optional functions.
    :param name: The field name of the FeatureProperty.
    :param tfeature: The type of feature that the FeatureProperty is accessing.
    :param tin: The type that the FeatureProperty is setting in the database.
    :param tout: The type that the FeatureProperty is getting from the database.
    :param fin: The input converter that the FeatureProperty is using when updating the database.
    :param fout: The output converter that the FeatureProperty is using when reading from the database.
    :param fdel: The deleter function that the FeatureProperty is using when deleting from the instance.
    :param fget: The getter function that the FeatureProperty is using when reading from the instance.
    :param fset: The setter function that the FeatureProperty is using when writing to the instance.
    """
    return lambda fn: fprop.FeatureProperty(name=name, fin=fin, fout=fout, fdel=fdel, fget=fget or fn, fset=fset)


def item(name: Optional[str]=None, input_converter: DbTypeCallable=None, output_converter: PyTypeCallable=None, is_read_only: bool=False,
         factory: Union[Callable[..., TItem_co], Type]=fitem.FeatureItem[TPy_co, TDb_co], **kwargs: Any) -> TItem_co:
    """
    Produces a new FeatureItem with the given name, optional input_converter and output_converter, is_read_only flag,
    and of the type produced by factory.
    :param name: The name of the FeatureItem.
    :param input_converter: The optional to-db value converter.
    :param output_converter: The optional to-python value converter.
    :param is_read_only: True if the FeatureItem cannot change the underlying value of the BasicFeatureObject, otherwise false.
    :param factory: A Callable that accepts the arguments provided and returns an equivalent FeatureItem.
    """
    kwargs.update({'name': name, 'input_converter': input_converter, 'output_converter': output_converter,
                   'is_read_only': is_read_only})
    return factory(**kwargs)


def ignored_item(name: Optional[str]=None) -> protocols.IgnoredItem:
    """
    Produces a new IgnoredItem with the given name. IgnoredItem will always return None whenever accessed and
    is not written or read from the database.
    """
    return protocols.IgnoredItem(name)


def bool_item(name: Optional[str]=None, is_read_only: bool=False, input_converter: Optional[Callable[[Any], Optional[int]]]=None,
              output_converter: Optional[Callable[[Any], Optional[bool]]]=None, **kwargs: Any) -> fitem.BoolFeatureItem:
    """
    Produces a new BoolFeatureItem with the given name, optional overloaded input_converter and output_converter and
    is_read_only flag.
    :param name: The name of the FeatureItem.
    :param is_read_only: True if the FeatureItem cannot change the underlying value of the BasicFeatureObject, otherwise false.
    :param input_converter: The optional to-db value converter.
    :param output_converter: The optional to-python value converter.
    """
    return item(name, input_converter, output_converter, is_read_only, fitem.BoolFeatureItem, **kwargs)


def date_item(name: str, is_read_only: bool=False, input_converter: Optional[Callable[[Any], Optional[str]]]=None,
              output_converter: Optional[Callable[[Any], Optional[QDate]]]=None, **kwargs: Any) -> fitem.DateFeatureItem:
    """
    Produces a new DateFeatureItem with the given name, optional overloaded input_converter and output_converter and
    is_read_only flag.
    :param name: The name of the FeatureItem.
    :param is_read_only: True if the FeatureItem cannot change the underlying value of the BasicFeatureObject, otherwise false.
    :param input_converter: The optional to-db value converter.
    :param output_converter: The optional to-python value converter.
    """
    return item(name, input_converter, output_converter, is_read_only, fitem.DateFeatureItem, **kwargs)


def time_item(name: str, is_read_only: bool=False, input_converter: Optional[Callable[[Any], Optional[str]]]=None,
              output_converter: Optional[Callable[[Any], Optional[QTime]]]=None, **kwargs: Any) -> fitem.TimeFeatureItem:
    return item(name, input_converter, output_converter, is_read_only, fitem.TimeFeatureItem, **kwargs)


def datetime_item(name: Optional[str]=None, is_read_only: bool=False, input_converter: Optional[Callable[[Any], Optional[str]]]=None,
                  output_converter: Optional[Callable[[Any], Optional[QDateTime]]]=None, **kwargs: Any) -> fitem.DateTimeFeatureItem:
    """
    Produces a new DateTimeFeatureItem with the given name, optional overloaded input_converter and output_converter and
    is_read_only flag.
    :param name: The name of the FeatureItem.
    :param is_read_only: True if the FeatureItem cannot change the underlying value of the BasicFeatureObject, otherwise false.
    :param input_converter: The optional to-db value converter.
    :param output_converter: The optional to-python value converter.
    """
    return item(name, input_converter, output_converter, is_read_only, fitem.DateTimeFeatureItem, **kwargs)


def enum_item(name: str, enum_type: Type[TEnum_co], is_read_only: bool=False, input_converter: DbTypeCallable=None,
              output_converter: Optional[Callable[[Any], Optional[TEnum_co]]]=None, **kwargs: Any) -> fitem.EnumFeatureItem[TEnum_co, TDb_co]:
    """
    Produces a new EnumFeatureItem with the given name, optional overloaded input_converter and output_converter and
    is_read_only flag.
    :param name: The name of the FeatureItem.
    :param enum_type: The type of the Enum handled by this FeatureItem.
    :param is_read_only: True if the FeatureItem cannot change the underlying value of the BasicFeatureObject, otherwise false.
    :param input_converter: The optional to-db value converter.
    :param output_converter: The optional to-python value converter.
    """
    return item(name, input_converter, output_converter, is_read_only, fitem.EnumFeatureItem, enum_type=enum_type, **kwargs)


def float_item(name: Optional[str]=None, is_read_only: bool=False, input_converter: Optional[Callable[[Any], Optional[float]]]=None,
               output_converter: Optional[Callable[[Any], Optional[float]]]=None, **kwargs: Any) -> fitem.FloatFeatureItem:
    """
    Produces a new FloatFeatureItem with the given name, optional overloaded input_converter and output_converter and
    is_read_only flag.
    :param name: The name of the FeatureItem.
    :param is_read_only: True if the FeatureItem cannot change the underlying value of the BasicFeatureObject, otherwise false.
    :param input_converter: The optional to-db value converter.
    :param output_converter: The optional to-python value converter.
    """
    return item(name, input_converter, output_converter, is_read_only, fitem.FloatFeatureItem, **kwargs)


def int_item(name: Optional[str]=None, is_read_only: bool=False, input_converter: Optional[Callable[[Any], Optional[int]]]=None,
             output_converter: Optional[Callable[[Any], Optional[int]]]=None, **kwargs: Any) -> fitem.IntFeatureItem:
    """
    Produces a new IntFeatureItem with the given name, optional overloaded input_converter and output_converter and
    is_read_only flag.
    :param name: The name of the FeatureItem.
    :param is_read_only: True if the FeatureItem cannot change the underlying value of the BasicFeatureObject, otherwise false.
    :param input_converter: The optional to-db value converter.
    :param output_converter: The optional to-python value converter.
    """
    return item(name, input_converter, output_converter, is_read_only, fitem.IntFeatureItem, **kwargs)


def str_item(name: Optional[str]=None, is_read_only: bool=False, input_converter: Optional[Callable[[Any], Optional[str]]]=None,
             output_converter: Optional[Callable[[Any], Optional[str]]]=None, **kwargs: Any) -> fitem.StrFeatureItem:
    """
    Produces a new StrFeatureItem with the given name, optional overloaded input_converter and output_converter and
    is_read_only flag.
    :param name: The name of the FeatureItem.
    :param is_read_only: True if the FeatureItem cannot change the underlying value of the BasicFeatureObject, otherwise false.
    :param input_converter: The optional to-db value converter.
    :param output_converter: The optional to-python value converter.
    """
    return item(name, input_converter, output_converter, is_read_only, fitem.StrFeatureItem, **kwargs)


def bin_item(name: str, table_name: str, id_name: str, factory: Callable[[], Connection],
             is_read_only: bool=False, **kwargs: Any) -> fitem.BinaryItem:
    """
    Produces a new BinaryItem with the given table (table_name), id_field (id_name), value_field (name),
    connection_supplier (factory) and is_read_only flag.
    :param name: The value_field parameter.
    :param table_name: The table parameter.
    :param id_name: The id_field parameter.
    :param factory: The connection_supplier parameter.
    :param is_read_only: True if  the BinaryItem cannot change the underlying value of the BasicFeatureObject, otherwise false.
    """
    return fitem.BinaryItem(table=table_name, id_field=id_name, value_field=name, connection_supplier=factory,
                               is_read_only=is_read_only, **kwargs)

