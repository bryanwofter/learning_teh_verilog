from qgis.core import (QgsExpression, QgsFeatureRequest, QgsLayerTreeGroup, QgsLayerTreeLayer,  # type: ignore
                       QgsMapLayer, QgsProject, QgsVectorLayer, QgsVectorLayerJoinInfo, QgsRectangle)
from qgis.gui import QgsMapCanvas  # type: ignore
from qgis.utils import iface  # type: ignore
from trc_packages.asynclib import _functions as async_functions, protocols as async_protocols
from trc_packages.core import attrempty, first, chunk
from typing import (Any, cast, Dict, FrozenSet, Generic, List, Optional, Type, TypeVar,
                    Union, Iterable)
from trc_packages.core.features import (_basic_cache_object as basic_cache_object,
                                        _basic_feature_object as basic_feature_object,
                                        _contextmanagers as contextmanagers,
                                        _functions as functions,
                                        protocols as protocols,
                                        errors as errors)
from trc_packages import debugging
import os
import re
TFeature = TypeVar('TFeature', bound='protocols.Feature[protocols.Vector]')
TFeature_contra = TypeVar('TFeature_contra', bound='protocols.Feature[protocols.Vector]')


_PATH_FORMAT: str = "{}|{}={}"
_IS_NULL_PATTERN: str = r'\s*=\s*NULL'
_IS_NOT_NULL_PATTERN: str = r'\s*(?:\<\>|\!\=)\s*NULL'


class BasicVectorObject(protocols.Vector[TFeature], Generic[TFeature]):
    """A basic vector object that provides the bare minimum needed."""

    __attached_to_ui: bool = False

    @property
    def attahced_to_ui(self) -> bool:
        return self.__attached_to_ui

    _path: Optional[str] = None

    @property
    def path(self) -> Optional[str]:
        return self._path

    @path.setter
    def path(self, path: str) -> None:
        self._path = path

    @path.deleter
    def path(self) -> None:
        del self._path

    _current_circuit: Optional[str] = None

    @property
    def current_circuit(self) -> Optional[str]:
        return self._current_circuit

    @current_circuit.setter
    def current_circuit(self, current_circuit: Optional[str]) -> None:
        self._current_circuit = current_circuit

    @current_circuit.deleter
    def current_circuit(self) -> None:
        del self._current_circuit

    _data_source: Optional[str] = None

    @property
    def data_source(self) -> Optional[str]:
        return self._data_source

    @data_source.setter
    def data_source(self, data_source: Optional[str]) -> None:
        self._data_source = data_source

    @data_source.deleter
    def data_source(self) -> None:
        del self._data_source

    _layer_name: str = None

    @property
    def layer_name(self) -> str:
        return self._layer_name

    @layer_name.setter
    def layer_name(self, layer_name: str) -> None:
        self._layer_name = layer_name

    @layer_name.deleter
    def layer_name(self) -> None:
        self.layer_name = None

    _base_name: Optional[str] = None

    @property
    def base_name(self) -> Optional[str]:
        return self._base_name

    @base_name.setter
    def base_name(self, base_name: Optional[str]) -> None:
        self._base_name = base_name
        if self.qgs_layer is not None:
            self.qgs_layer.setName(base_name)

    @base_name.deleter
    def base_name(self) -> None:
        self.base_name = None

    field_aliases: Dict[str, str] = None
    feature_object_type: Type[TFeature] = None
    cache: 'basic_cache_object.BasicCacheObject[TFeature, BasicVectorObject[TFeature]]'

    _qgs_layer: QgsVectorLayer = None
    @property
    def qgs_layer(self) -> QgsVectorLayer:
        if isinstance(self._qgs_layer, debugging.DebugVectorLayer):
            return self._qgs_layer.layer
        return self._qgs_layer

    @qgs_layer.setter
    def qgs_layer(self, qgs_layer: QgsVectorLayer) -> None:
        if isinstance(qgs_layer, debugging.DebugVectorLayer):
            self._qgs_layer = qgs_layer
        else:
            self._qgs_layer = debugging.DebugVectorLayer(qgs_layer)

    @qgs_layer.deleter
    def qgs_layer(self) -> None:
        del self._qgs_layer

    @property
    def extent(self) -> Optional[QgsRectangle]:
        return None if self.qgs_layer is None else self.qgs_layer.extent()

    @property
    def field_names(self) -> FrozenSet[str]:
        return frozenset(self.qgs_layer.fields().names())

    @property
    def editable(self) -> bool:
        return self.qgs_layer.isEditable()

    _validators: List[protocols.Validator[TFeature]] = None

    @property
    def validators(self) -> List[protocols.Validator[TFeature]]:
        return self._validators

    def __init__(self, show_in_ui: bool=False, path: Optional[str]=None, current_circuit: Optional[str]=None,
                 layer_name: Optional[str]=None, base_name: Optional[str]=None, feature_object_type: Optional[Type[TFeature]]=None,
                 qgs_layer: QgsVectorLayer=None, data_source: Optional[str]=None, field_aliases: Optional[Dict[str, str]]=None,
                 qgs_layer_path: Optional[str]=None, **kwargs: Any) -> None:
        """
        :param show_in_ui: True if this vector is a part of the UI, otherwise False. If True, the layer will be attached to the UI using the UI thread if possible. attached_to_ui will be set to True when complete.
        :param path: The path of the layer.
        :param current_circuit: The circuit of the layer if no qgs_layer_path was given.
        :param layer_name: The name of the layer.
        :param base_name: The name of the layer within the TOC.
        :param feature_object_type: The type of Feature object produced by this vector layer.
        :param qgs_layer: The fully created QgsVectorLayer of this vector layer.
        :param data_source: Unused
        :param field_aliases: Additional aliases for the field names of this vector layer and its features.
        :param qgs_layer_path: The QGIS-compatible layer path of this vector layer. This is similar to providing qgs_layer.
        """
        self.feature_object_type = feature_object_type or self.feature_object_type or cast(Type[TFeature], basic_feature_object.BasicFeatureObject)
        self.field_aliases = field_aliases or self.field_aliases or dict()
        self.cache = basic_cache_object.BasicCacheObject(self)
        self._validators = []

        in_ui: bool = False

        if qgs_layer is None:
            layer_name = layer_name or self.layer_name
            base_name = base_name or self.base_name or layer_name

            if base_name is not None:
                qgs_layer = (first(QgsProject.instance().mapLayersByName(base_name)) or
                             first(QgsProject.instance().mapLayersByName(f"{current_circuit} {base_name}")) or
                             first(QgsProject.instance().mapLayersByName(f"{base_name} {layer_name}")))

            if qgs_layer is None and layer_name is not None:
                qgs_layer = (first(QgsProject.instance().mapLayersByName(layer_name)) or
                             first(QgsProject.instance().mapLayersByName(f"{current_circuit} {layer_name}")))

        if qgs_layer is None:
            if qgs_layer_path is None:
                path = path or self.path
                current_circuit = current_circuit or self.current_circuit
                layer_name = layer_name or self.layer_name
                qgs_layer_path = _PATH_FORMAT.format(os.path.join(cast(str, path), f"{current_circuit}.sqlite"), 'layername', layer_name)
                if 'filter' in kwargs:
                    qgs_layer_path += f"|subset={kwargs['filter']}"

            qgs_layer = QgsVectorLayer(qgs_layer_path, base_name, 'ogr')

            if qgs_layer.isValid():
                qgs_layer.setName(base_name)
            else:
                qgs_layer = None
        else:
            in_ui = True

        if qgs_layer is not None:
            self.qgs_layer_path = qgs_layer_path
            self.base_name = qgs_layer.name()
            self.layer_name = qgs_layer.sourceName()
            self.current_circuit = current_circuit or first(os.path.splitext(os.path.basename(cast(str, first(qgs_layer.dataProvider().uri().uri().split('|'))))))
            self.path = path or os.path.dirname(cast(str, first(qgs_layer.dataProvider().uri().uri().split('|'))))
            self.data_source = qgs_layer.dataProvider().name()
            self.qgs_layer = qgs_layer

            if in_ui:
                self.__attached_to_ui = True
            elif show_in_ui:
                self.__attach_to_ui(qgs_layer)

    def __attach_to_ui(self, qgs_layer: QgsVectorLayer) -> None:
        """
        Attaches the given QGS layer to the UI.
        :param qgs_layer: The layer to attach to the UI.
        """
        service: Optional[async_protocols.Service] = async_functions.current_service()
        use_run_later: bool = service is not None

        def __run_later() -> None:
            try:
                self.qgs_layer = QgsProject.instance().addMapLayer(qgs_layer)
            finally:
                self.__attached_to_ui = True

        if use_run_later:
            service.run_later(__run_later)
        else:
            __run_later()

    def __getitem__(self, feature_id: Optional[int]) -> Optional[TFeature]:
        if self.qgs_layer is None or feature_id is None:
            return None
        return self.cache.get(self.qgs_layer.getFeature(feature_id))

    def __delitem__(self, feature_id: Optional[int]) -> None:
        if self.qgs_layer is not None and feature_id is not None:
            qgs_feature: Optional[TFeature] = self[feature_id]
            if qgs_feature is not None:
                self.cache.remove(qgs_feature.qgs_feature)
                qgs_feature.remove()

    def all(self) -> Iterable[TFeature]:
        return self.find(None)

    def find(self, filter_, *vargs: Any, **kwargs: Any) -> Iterable[TFeature]:
        if attrempty(self, 'qgs_layer'):
            return []
        elif filter_ is None:
            filter_ = QgsFeatureRequest()
        elif isinstance(filter_, QgsExpression):
            filter_ = QgsFeatureRequest(QgsExpression(filter_))
        elif isinstance(filter_, str):
            filter_ = functions.resolve_fields(filter_, self.feature_object_type).format(*functions.escape_filter_args(*vargs))
            # Sanitize invalid null checks
            filter_ = re.sub(_IS_NOT_NULL_PATTERN, ' IS NOT NULL', filter_)
            filter_ = re.sub(_IS_NULL_PATTERN, ' IS NULL', filter_)
            filter_ = QgsFeatureRequest(QgsExpression(filter_))
        elif not isinstance(filter_, QgsFeatureRequest):
            return []
        for key, value in kwargs.items():
            if key == 'limit':
                filter_.setLimit(value)
            elif key == 'flags':
                filter_.setFlags(value)
            elif key == 'order_by':
                filter_.setOrderBy(value)
            elif key == 'fields':
                filter_.setSubsetOfAttributes([self.resolve_field_name(k) for k in value], self.qgs_layer.fields())
        return (cast(TFeature, self.cache.get(qgs_feature)) for qgs_feature in self.qgs_layer.getFeatures(filter_))

    def join(self, self_field: str, other_vector: Union['BasicVectorObject', QgsVectorLayer], other_field: Optional[str]=None,
             prefix: Optional[str]=None, included_fields: Optional[List[str]]=None, excluded_fields: Optional[List[str]]=None,
             using_memory_cache: bool=True, editable: bool=True) -> bool:
        if attrempty(self, 'qgs_layer'):
            return False
        join_info: QgsVectorLayerJoinInfo = QgsVectorLayerJoinInfo()
        join_info.setTargetFieldName(self_field)
        join_info.setJoinLayer(other_vector.qgs_layer if isinstance(other_vector, BasicVectorObject) else other_vector)
        join_info.setJoinFieldName(other_field if other_field is not None else self_field)
        join_info.setUsingMemoryCache(using_memory_cache)
        join_info.setPrefix(prefix)
        if excluded_fields:
            join_info.setJoinFieldNamesBlackList(excluded_fields)
        if included_fields:
            join_info.setJoinFieldNamesSubset(included_fields)
        join_info.setEditable(editable)
        return self.qgs_layer.addJoin(join_info)

    def resolve_field_name(self, key: str) -> Optional[str]:
        if not attrempty(self, 'qgs_layer'):
            return None
        key = self.field_aliases.get(key, key)
        return None if self.qgs_layer.fields().indexFromName(key) < 0 else key

    def start_editing(self) -> bool:
        return not attrempty(self, 'qgs_layer') and self.qgs_layer.startEditing()

    def start_transaction(self) -> 'protocols.transactionmanager[TFeature]':
        return contextmanagers.transaction(vector_object=self)

    def add_or_update(self, feature: TFeature) -> bool:
        if attrempty(self, 'qgs_layer'):
            return False
        validation_results: List[protocols.ValidationResult] = list(self.validate(feature))
        if any(v for v in validation_results if v.error):
            raise errors.FeatureFailedValidationError(validation_results)
        elif not self.has_feature(feature):
            return self.qgs_layer.addFeature(feature.qgs_feature)
        else:
            return feature.qgs_fields == feature.old_qgs_fields or self.qgs_layer.changeAttributeValues(feature.qgs_id, feature.qgs_fields, feature.old_qgs_fields)

    def delete(self, feature: TFeature) -> bool:
        if feature is None or not self.has_feature(feature):
            return True
        if not attrempty(self, 'qgs_layer') and self.qgs_layer.deleteFeature(feature.qgs_id):
            self.cache.remove(feature.qgs_feature)
            return True
        return False

    def delete_all(self, features: Optional[Iterable[TFeature]]=None) -> bool:
        feature_ids: List[int]
        if features is None:
            feature_ids = self.qgs_layer.allFeatureIds()
        else:
            feature_ids = [f.qgs_id for f in features]

        service: Optional[async_protocols.Service] = async_functions.current_service()
        use_run_later: bool = service is not None

        ids: List[int]
        for ids in chunk(feature_ids, 5000):
            if use_run_later:
                service.yield_until_ran_later(lambda: self.qgs_layer.deleteFeatures(ids), attempts=-1)
            else:
                self.qgs_layer.deleteFeatures(ids)
        return True

    def commit_changes(self) -> bool:
        return not attrempty(self, 'qgs_layer') and self.qgs_layer.commitChanges()

    def rollback_changes(self) -> bool:
        return not attrempty(self, 'qgs_layer') and self.qgs_layer.rollBack()

    def reload(self, feature: Optional[TFeature]=None) -> None:
        if feature is None:
            self.qgs_layer.reload()
        elif feature.qgs_id is not None:
            self.cache.remove(feature.qgs_feature)
            feature.qgs_feature = self.qgs_layer.getFeature(feature.qgs_id)  # type: ignore

    def new_feature(self, **kwargs: Any) -> TFeature:
        feature_object: TFeature = self.feature_object_type(self)  # type: ignore
        for field, value in kwargs.items():
            feature_object[field] = value
        return feature_object

    def fields(self) -> List[str]:
        return [] if attrempty(self, 'qgs_layer') else self.qgs_layer.fields().names()

    def has_feature(self, feature: TFeature, **kwargs: Any) -> bool:
        if attrempty(feature, 'qgs_feature'):
            return False
        elif self.cache.has(feature.qgs_feature) or super().has_feature(feature, **kwargs):
            return True
        return False

    def add_to_group(self, group_name: Optional[str]=None, index: Optional[int]=None) -> None:
        if self.qgs_layer is None:
            return
        tree_root: QgsProject = QgsProject.instance().layerTreeRoot()
        group: QgsLayerTreeGroup = None
        layer: QgsLayerTreeLayer = QgsLayerTreeLayer(self.qgs_layer)
        old_layer: QgsLayerTreeLayer = tree_root.findLayer(self.qgs_layer)
        if group_name is None:
            group = tree_root
        else:
            group = tree_root
            for group_name_part in group_name.split('.'):  # type: str
                group = group.findGroup(group_name_part) or group.addGroup(group_name_part)
        if index is None:
            group.addChildNode(layer)
        else:
            group.insertChildNode(index, layer)
        if old_layer is not None:
            old_layer.parent().takeChild(old_layer)

    def select(self, feature: Optional[TFeature]=None) -> bool:
        if feature is None:
            return iface.setActiveLayer(self.qgs_layer)
        elif not attrempty(self, 'qgs_layer'):
            self.qgs_layer.select(feature.qgs_id)
            return True
        return False

    def select_all(self, *args: TFeature, features: Optional[Iterable[TFeature]]=None) -> bool:
        empty_list: List[TFeature] = []
        if not any(args) and features is None:
            return iface.setActiveLayer(self.qgs_layer)
        elif not attrempty(self, 'qgs_layer'):
            feature_ids: Iterable[int] = (*(args or empty_list), *(features or empty_list))
            self.qgs_layer.select(list(feature_ids))
            return True
        return False

    def block_signals(self) -> 'contextmanagers.block_signals':
        return contextmanagers.block_signals(vector_object=self)

    def load_named_style(self, uri: str, load_from_db: bool=False, *,
                         categories: Union[QgsMapLayer.StyleCategories, QgsMapLayer.StyleCategory]=QgsMapLayer.AllStyleCategories) -> bool:
        if self.qgs_layer is None:
            return False
        _, success = self.qgs_layer.loadNamedStyle(uri, load_from_db, categories)  # type: Tuple[Any, bool]
        return success

    def validate(self, feature: TFeature) -> Iterable[protocols.ValidationResult]:
        for validator in self.validators:  # type: protocols.Validator[TFeature]
            yield from validator.validate(feature)

    def take_focus(self, zoom_to_selected_features: bool=False) -> None:
        canvas: QgsMapCanvas = iface.mapCanvas()
        if zoom_to_selected_features:
            canvas.zoomToSelected(self.qgs_layer)
        else:
            canvas.setExtent(self.extent)

