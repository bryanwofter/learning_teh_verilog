from functools import partial
from trc_packages.core.features import protocols
from trc_packages.decorators import qsafe
from typing import Any, Callable, cast, Generic, Optional, overload, Type, TypeVar
T = TypeVar('T')
TDb = TypeVar('TDb')
TFeature = TypeVar('TFeature', bound='protocols.Feature')
TPy = TypeVar('TPy')


class FeatureProperty(protocols.PropertyItem[TPy, TDb, TFeature], Generic[TPy, TDb, TFeature]):
    """
    Provides a basic implementation of the protocols.PropertyItem protocol.
    """

    _fdel: Optional[Callable[[TFeature], None]] = None
    @property
    def fdel(self) -> Optional[Callable[[TFeature], None]]:
        return self._fdel

    def deleter(self, deleter: Optional[Callable[[TFeature], None]]) -> 'FeatureProperty[TPy, TDb, TFeature]':
        self._fdel = deleter
        return self

    _fget: Optional[Callable[[TFeature], TPy]] = None
    @property
    def fget(self) -> Optional[Callable[[TFeature], TPy]]:
        return self._fget

    def getter(self, getter: Optional[Callable[[TFeature], TPy]]) -> 'FeatureProperty[TPy, TDb, TFeature]':
        self._fget = getter
        return self

    _fin: Optional[Callable[[Any], TDb]] = None
    @property
    def fin(self) -> Optional[Callable[[Any], TDb]]:
        return self._fin

    def input_converter(self, input_converter: Optional[Callable[[Any], TDb]]) -> 'FeatureProperty[TPy, TDb, TFeature]':
        self._fin = input_converter
        return self

    @qsafe
    def to_input(self, value: T) -> TDb:
        input_converter: Optional[Callable[[Any], TDb]] = self.fin

        if input_converter is None:
            return cast(TDb, value)
        else:
            return input_converter(value)

    _fout: Optional[Callable[[Any], TPy]] = None
    @property
    def fout(self) -> Optional[Callable[[Any], TPy]]:
        return self._fout

    def output_converter(self, output_converter: Optional[Callable[[Any], TPy]]) -> 'FeatureProperty[TPy, TDb, TFeature]':
        self._fout = output_converter
        return self

    @qsafe
    def to_output(self, value: T) -> TPy:
        output_converter: Optional[Callable[[Any], TPy]] = self.fout

        if output_converter is None:
            return cast(TPy, value)
        else:
            return output_converter(value)

    _fset: Optional[Callable[[TFeature, TPy], None]] = None
    @property
    def fset(self) -> Optional[Callable[[TFeature, TPy], None]]:
        return self._fset

    def setter(self, setter: Optional[Callable[[TFeature, TPy], None]]) -> 'FeatureProperty[TPy, TDb, TFeature]':
        self._fset = setter
        return self

    _field_name: Optional[str] = None
    @property
    def field_name(self) -> Optional[str]:
        return self._field_name

    @property
    def is_read_only(self) -> bool:
        return False

    @is_read_only.setter
    def is_read_only(self, is_read_only: bool) -> None:
        pass

    @is_read_only.deleter
    def is_read_only(self) -> None:
        pass

    def __delete__(self, instance) -> None:
        super().__delete__(instance)
        del instance[self._field_name]

    def __get__(self, instance, owner) -> TPy:
        result: TPy = super().__get__(instance, owner)

        if result is None:
            result = instance[self.field_name]
            self.__set__(instance, result)

        return result

    def __set__(self, instance, value) -> None:
        super().__set__(instance, value)

    def __set_name__(self, owner, name) -> None:
        if self._field_name is None:
            self._field_name = name

    def __init__(self,
                 name: Optional[str],
                 fin: Optional[Callable[[Any], TDb]]=None,
                 fout: Optional[Callable[[Any], TPy]]=None,
                 fdel: Optional[Callable[[TFeature], None]]=None,
                 fget: Optional[Callable[[TFeature], TPy]]=None,
                 fset: Optional[Callable[[TFeature, TPy], None]]=None,
                 *,
                 doc: Optional[str]=None) -> None:
        self._field_name = name
        self.input_converter(fin).output_converter(fout).deleter(fdel).getter(fget).setter(fset)
        self.__doc__ = doc

