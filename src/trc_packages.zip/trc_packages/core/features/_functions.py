from enum import auto, Enum, unique
from PyQt5 import QtCore
from qgis.core import QgsExpression, QgsFeatureRequest  # type: ignore
from trc_packages.core import flatten
from trc_packages.core.features import protocols, _feature_view as feature_view, errors as errors
from typing import Any, cast, Dict, List, NoReturn, Optional, Type, TypeVar, Tuple
from uuid import uuid4
TFeature = TypeVar('TFeature', bound='protocols.Feature')


def transfer_fields(src: 'protocols.Feature', dst: 'protocols.Feature', org: Optional['protocols.Feature']=None) -> NoReturn:
    """
    Copies the data from src to dst, optionally restoring src to the state provided by org.
    :param src: The source feature.
    :param dst: The destination feature.
    :param org: The optional restoration state for src.
    """
    for field, value in src.items():
        if dst.has_field(field):
            dst[field] = value
    if org:
        for field, value in org.items():
            if src.has_field(field):
                src[field] = value


def resolve_fields(filter_: str, feature_object_type: Type[TFeature]) -> str:
    """
    Resolves the fields of the filter usign the provided Feature type.
    :param filter: The filter to resolve the fields of.
    :param feature_object_type: The Feature type that defines the fields.
    """
    for field, item in cast(Type['protocols.ItemProvider'], feature_object_type).get_feature_items().items():  # type: Tuple[str, protocols.Item]
        filter_ = filter_.replace(f"[{field}]", f'"{item.field_name}"').replace(f"[{item.field_name}]", f'"{item.field_name}"')
    return filter_


def escape_filter_args(*vargs: Any) -> List[str]:
    """
    Escapes all provided filter arguments.
    :param vargs: The arguments to escape.
    """
    output: List[str] = []
    for arg in vargs:
        if isinstance(arg, protocols.Feature):
            if arg.hash_field is None:
                raise errors.HashFieldRequiredError()
            # This is future-proofed to support the possibility of list hash_field. This is not currently allowed by
            # hash_field itself
            fields: List[str]
            if isinstance(arg.hash_field, str):
                fields = [arg.hash_field]
            elif isinstance(arg.hash_field, list):
                fields = arg.hash_field
            else:
                raise TypeError()
            output.extend(escape_filter_args(*(arg[f] for f in fields)))
        elif isinstance(arg, str) or isinstance(arg, bytes):
            output.append(QgsExpression.quotedString(arg))
        elif isinstance(arg, int) or isinstance(arg, float):
            output.append(str(arg))
        elif arg is None:
            output.append('NULL')
        elif hasattr(arg, '__iter__'):
            output.append(','.join(flatten([escape_filter_args(v) for v in arg])))
        elif hasattr(arg, '__int__') or hasattr(arg, '__index__'):
            output.append(str(int(arg)))
        elif hasattr(arg, '__float__'):
            output.append(str(float(arg)))
        elif isinstance(arg, QtCore.QVariant):
            output.append(QgsExpression.quotedValue(arg))
        else:
            output.append(QgsExpression.quotedString(str(arg)))
    return output


def feature_sort(sort: Optional[str], *vargs: Any) -> QgsFeatureRequest.OrderBy:
    """
    Produces an order by clause using the provided sort and optional arguments.
    :param sort: The SQL ORDER BY clause.
    :param vargs: The arguments to escape and populate sort with.
    """
    if sort is None: return QgsFeatureRequest.OrderBy()
    else: return QgsFeatureRequest.OrderBy([QgsFeatureRequest.OrderByClause(
        QgsExpression(sort.format(*escape_filter_args(*vargs))))])


def make_guid() -> str:
    """Returns a GUID produced by uuid.uuid4() as a string."""
    return str(uuid4()).upper()


@unique
class FieldNameType(Enum):
    PY_FIELD = auto()
    DB_FIELD = auto()


def format_feature(feature: 'protocols.Feature', field_name_type: FieldNameType=FieldNameType.PY_FIELD) -> str:
    """
    Returns a formatted version of the given protocol that exposes all of its fields, using the field name based off of the field_name_type parameter.
    :param feature: The feature to format.
    :param field_name_type: The optional field name type to use for formatting.
    """
    feature_items: Dict[str, 'protocols.Item'] = feature.get_feature_items() if field_name_type is FieldNameType.PY_FIELD else feature.get_feature_items_by_field()
    field_data: Dict[str, Any] = {f: p.__get__(feature, type(feature)) for f, p in feature_items.items()}
    return str(field_data)

