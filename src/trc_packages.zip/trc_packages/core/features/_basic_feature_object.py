from PyQt5.QtCore import QVariant
from qgis.core import QgsFeature, QgsGeometry, QgsGpsConnectionRegistry, QgsGpsConnection, QgsGpsInformation, QgsApplication, QgsPointXY
from typing import Any, cast, ClassVar, Dict, Generic, Iterable, Iterator, List, Mapping, NoReturn, Optional, Union, Type, TypeVar
from trc_packages.core.features import factories as factories, protocols as protocols, errors as errors
from trc_packages import debugging
from trc_packages.core import attrempty
from trc_packages.decorators import qsafe
from trc_packages.debugging import Debug
TVector = TypeVar('TVector', bound='protocols.Vector')


class FeatureItemProvider(protocols.ItemProvider):
    """Declares that a class offers an iterable interface for feature items."""

    __feature_items_by_insensitive_field: ClassVar[Dict[type, Dict[str, protocols.Item]]] = dict()
    __feature_items_by_field: ClassVar[Dict[type, Dict[str, protocols.Item]]] = dict()
    __feature_items: ClassVar[Dict[type, Dict[str, protocols.Item]]] = dict()

    def get_feature_item(self, field: str) -> Optional[protocols.Item]:
        return (self.get_feature_items().get(field) or
                self.get_feature_items_by_field().get(field) or
                self.get_feature_items_by_insensitive_field().get(field.upper()) or
                protocols.DefaultItem())

    @classmethod
    def get_feature_items(cls) -> Dict[str, protocols.Item]:
        if cls.__feature_items.get(cls) is None:
            cls.__feature_items[cls] = dict({name: value for name, value in cls.__dict__.items() if protocols.isitem(value)})
            for parent in cls.__bases__:
                if (issubclass(parent, protocols.ItemProvider) and parent != protocols.ItemProvider and parent != BasicFeatureObject):
                    feature_items: Dict[str, protocols.Item] = cast(Type[protocols.ItemProvider], parent).get_feature_items()
                    if feature_items is not None:
                        cls.__feature_items[cls].update(feature_items)
        return cls.__feature_items[cls]

    @classmethod
    def get_feature_items_by_field(cls) -> Dict[str, protocols.Item]:
        if cls.__feature_items_by_field.get(cls) is None:
            cls.__feature_items_by_field[cls] = dict({value.field_name: value for value in cls.get_feature_items().values() if value.field_name is not None})
        return cls.__feature_items_by_field[cls]

    @classmethod
    def get_feature_items_by_insensitive_field(cls) -> Dict[str, protocols.Item]:
        if cls.__feature_items_by_insensitive_field.get(cls) is None:
            cls.__feature_items_by_insensitive_field[cls] = dict({k.upper(): v for k, v in cls.get_feature_items_by_field().items()})
        return cls.__feature_items_by_insensitive_field[cls]


class BasicFeatureObject(FeatureItemProvider, Iterable, protocols.Feature[TVector], Generic[TVector]):
    """Represents a feature of a vector object."""

    vector_object: TVector = None
    hash_field: Optional[Union[str, List[str]]] = None
    row_id: protocols.Item[Optional[int], Optional[int]] = factories.int_item('rowid')
    _geometry: Optional[QgsGeometry] = None
    _qgs_feature: Union[debugging.DebugFeature, QgsFeature] = None
    _old_qgs_fields: Dict[int, QVariant] = None

    @property
    def vector_name(self) -> str:
        return '<disconnected feature>' if attrempty(self, 'vector_object') else self.vector_object.layer_name

    @property
    def qgs_id(self) -> int:
        return self.qgs_feature.id()

    @property
    def is_new(self) -> bool:
        return 0 == self.qgs_feature.id()

    @property
    def is_disconnected(self) -> bool:
        return self.vector_object is None

    @property
    def qgs_feature(self) -> QgsFeature:
        if isinstance(self._qgs_feature, debugging.DebugFeature):
            return self._qgs_feature.feature
        return self._qgs_feature

    @qgs_feature.setter
    def qgs_feature(self, value: QgsFeature) -> NoReturn:
        if isinstance(value, debugging.DebugFeature):
            self._qgs_feature = value
        elif isinstance(value, QgsFeature):
            self._qgs_feature = debugging.DebugFeature(value, self.vector_name)

    @qgs_feature.deleter
    def qgs_feature(self) -> NoReturn:
        del self._qgs_feature

    @property
    def has_hashable_values(self) -> bool:
        if isinstance(self.hash_field, str):
            return self[self.hash_field] is not None
        elif isinstance(self.hash_field, list):
            hash_field: str
            for hash_field in self.hash_field:
                if self[hash_field] is None:
                    return False
        return True

    @property
    def geometry(self) -> Optional[QgsGeometry]:
        return self.qgs_feature.geometry()

    @geometry.setter
    def geometry(self, geometry: Optional[QgsGeometry]) -> NoReturn:
        self.qgs_feature.setGeometry(geometry)

    @geometry.deleter
    def geometry(self) -> NoReturn: self.geometry = None

    @property
    def qgs_fields(self) -> Dict[int, Any]:
        qgs_fields: Dict[int, Any] = {}

        for f in self.qgs_feature.fields().names():
            index: int = self.qgs_feature.fieldNameIndex(f)
            feature_item: protocols.Item = self.get_feature_item(f)
            feature_value: Optional[Any] = None

            if isinstance(feature_item, protocols.IgnoredItem):
                continue
            elif isinstance(feature_item, protocols.PropertyItem):
                feature_value = feature_item.to_input(feature_item.__get__(self, type(self)))
            else:
                feature_value = feature_item.to_input(self.qgs_feature[f])

            qgs_fields[index] = feature_value

        return qgs_fields

    @property
    def old_qgs_fields(self) -> Dict[int, Any]:
        return self._old_qgs_fields

    def __init__(self, vector_object: TVector, qgs_feature: Optional[QgsFeature]=None) -> None:
        self.vector_object = vector_object
        self.qgs_feature = qgs_feature or QgsFeature(vector_object.qgs_layer.fields())
        self._old_qgs_fields = self.qgs_fields

    def get_feature_item(self, field: str) -> Optional[protocols.Item]:
        item: Optional[protocols.Items] = super().get_feature_item(field)

        if isinstance(item, protocols.DefaultItem) and not attrempty(self, 'vector_object') and field in self.vector_object.field_aliases:
            item = self.get_feature_item(self.vector_object.field_aliases[field])
        return item

    @qsafe
    def __getitem__(self, key: str) -> Any:
        item: Optional[protocols.Item] = self.get_feature_item(key)
        field: Optional[str] = self.resolve_field_name(key)
        if not field:
            raise errors.FieldMissingError(key, self.vector_name)
        return None if item is None else item.to_output(self.qgs_feature[field])

    @qsafe
    def __setitem__(self, key: str, value: Any) -> NoReturn:
        item: Optional[protocols.Item] = self.get_feature_item(key)
        field: Optional[str] = self.resolve_field_name(key)
        if not field:
            raise errors.FieldMissingError(key, self.vector_name)
        if item is not None:
            if item.is_read_only:
                raise errors.ReadOnlyFeatureItemError(key, field, cast(str, self.vector_name))
            self.qgs_feature[field] = item.to_input(value)

    def __delitem__(self, key: str) -> NoReturn:
        self.__setitem__(key, None)

    def __hash__(self) -> int:
        return super().__hash__()

    def __eq__(self, other: object) -> bool:
        return super().__eq__(other)

    def __iter__(self) -> Iterator[str]:
        return iter(self.get_feature_items())

    def capture_gps(self) -> bool:
        registry: QgsGpsConnectionRegistry = QgsApplication.gpsConnectionRegistry()
        connections: List[QgsGpsConnection] = [c for c in registry.connectionList() if QgsGpsConnection.NotConnected != c.status()]

        if connections:
            connection: QgsGpsConnection = connections[0]
            gps_info: QgsGpsInformation = connection.currentGPSInformation()

            self.geometry = QgsGeometry.fromPointXY(QgsPointXY(gps_info.longitude, gps_info.latitude))
            return True
        return False

    def connect(self, vector_object: TVector) -> bool:
        if attrempty(self, 'vector_object'):
            self.vector_object = vector_object
            return True
        return False

    def disconnect(self) -> NoReturn:
        del self.vector_object

    def items(self) -> Mapping[str, Any]:
        return {f: self[f] for f in self if self[f] is not NotImplemented}

    def values(self) -> Iterable[Any]:
        return (self[f] for f in self)

    def has_field(self, key: Optional[str]) -> bool:
        return self.resolve_field_name(key) is not None

    def resolve_field_name(self, key: Optional[str]) -> Optional[str]:
        if key is None:
            return None
        item: Optional[protocols.Item] = self.get_feature_item(key)
        key = (None if item is None else item.field_name) or key
        if self.qgs_feature.fields().indexFromName(key) < 0:
            key = None if attrempty(self, 'vector_object') else self.vector_object.resolve_field_name(key)
        return key

    def save(self) -> bool:
        return not attrempty(self, 'vector_object') and self.vector_object.add_or_update(self)

    def remove(self) -> bool:
        return not attrempty(self, 'vector_object') and self.vector_object.delete(self)

    def reload(self) -> NoReturn:
        if not attrempty(self, 'vector_object'):
            self.vector_object.reload(self)

    def select(self) -> NoReturn:
        if not attrempty(self, 'vector_object'):
            self.vector_object.select(self)

    def __str__(self) -> str:
        return str(dict(self.items()))

