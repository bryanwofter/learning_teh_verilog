from PyQt5 import QtCore
from trc_packages.core.features import protocols
from trc_packages.core.ui import _supports_synchronized as s
from typing import Any, ClassVar, Dict, Generic, Optional, overload, Type, TypeVar
TFeature = TypeVar('TFeature', bound='protocols.Feature')
TPy = TypeVar('TPy')


class FeatureView(s.SupportsSynchronized, QtCore.QObject, Generic[TFeature]):
    """
    Provides a set of base functions that all featureviewtype classes need to function properly.
    """
    TView = TypeVar('TView', bound='FeatureView[TFeature]')

    FIELD_TO_PROPERTY_MAP: ClassVar[Dict[str, str]]
    FEATURE_TYPE: Type[TFeature]

    property_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([str, 'PyQt_PyObject', 'PyQt_PyObject'], name='propertyChanged')

    qgs_id: Optional[int] = None;

    def __init__(self, parent: Optional[QtCore.QObject]=None, **kwargs: Any) -> None:
        super().__init__(parent=parent)

        for field, value in kwargs.items():
            self[field] = value

    def __delitem__(self, key: str) -> None:
        delattr(self, self.FIELD_TO_PROPERTY_MAP.get(key, key))

    def __getitem__(self, key: str) -> TPy:
        return getattr(self, self.FIELD_TO_PROPERTY_MAP.get(key, key))

    def __setitem__(self, key: str, value: TPy) -> None:
        setattr(self, self.FIELD_TO_PROPERTY_MAP.get(key, key), value)

    @classmethod
    def from_feature(cls: Type[TView], feature: TFeature) -> TView:
        """
        Converts the provided feature into a FeatureView of this type.
        :param feature: The feature to convert.
        """
        inst = cls()

        for field in inst.FIELD_TO_PROPERTY_MAP:
            inst[field] = feature[field]

        inst.qgs_id = feature.qgs_id
        return inst

    @overload
    def to_feature(self, feature: 'protocols.Vector[TFeature]') -> TFeature: pass
    @overload
    def to_feature(self, feature: TFeature) -> TFeature: pass
    
    def to_feature(self, feature) -> TFeature:
        """
        Converts this FeatureView into the Feature it represents.
        :param feature: The feature or its vector to populate.
        """
        feature = self.FEATURE_TYPE(vector_object=feature) if isinstance(feature, protocols.Vector) else feature  # type: ignore

        for field in self.FIELD_TO_PROPERTY_MAP:
            feature[field] = self[field]

        if self.qgs_id is not None:
            feature.qgs_feature.setId(self.qgs_id)
        return feature

    def to_dict(self) -> Dict[str, Any]:
        """Converts this FeatureView into a Dict."""
        return {f: self[f] for f in self.FIELD_TO_PROPERTY_MAP}

