"""Provides a collection of protocols for the features package."""

from abc import abstractmethod
from functools import reduce
from trc_packages.core import first, protocolhelpers, json_handlers
from trc_packages.decorators import singleton
from typing import (Any, Callable, cast, ContextManager, Dict, FrozenSet, Iterable, Iterator, List, NamedTuple, Optional, overload, Tuple,
                    Type, TypeVar, Union, Mapping)
from types import TracebackType
from typing_extensions import final, Protocol, runtime, runtime_checkable, Literal  # type: ignore
from qgis.core import QgsExpression, QgsFeature, QgsFeatureRequest, QgsGeometry, QgsMapLayer, QgsVectorLayer, QgsRectangle  # type: ignore
import json
T = TypeVar('T')
TDb_co = TypeVar('TDb_co', covariant=True)
TDb = TypeVar('TDb')
TFeature = TypeVar('TFeature', bound='Feature')
_TFeature = TypeVar('_TFeature', bound='Feature')
TFeature_contra = TypeVar('TFeature_contra', contravariant=True, bound='Feature')
TPropertyItem = TypeVar('TPropertyItem', bound='PropertyItem')
TPy_co = TypeVar('TPy_co', covariant=True)
TPy = TypeVar('TPy')
TVector = TypeVar('TVector', bound='Vector')


def isitem(obj: object) -> bool:
    """
    Determines if the target object is compatible with the Item protocol.
    :param obj: The object to check.
    """
    return isinstance(obj, Item)


def isitemprovider(obj: object) -> bool:
    """
    Determines if the target object is compatible with the ItemProvider protocol.
    :param obj: The object to check.
    """
    return isinstance(obj, ItemProvider)


def isfeature(obj: object) -> bool:
    """
    Determines if the target object is compatible with the Feature protocol.
    :param object: The object to check.
    """
    return isinstance(obj, Feature)


def isvector(obj: object) -> bool:
    """
    Determines if the target object is compatible with the Vector protocol.
    :param object: The object to check.
    """
    return isinstance(obj, Vector)


@runtime
@runtime_checkable
class Item(Protocol[TPy_co, TDb_co]):
    """A protocol class used to implement custom feature items that don't extend the FeatureItem class."""

    @abstractmethod
    def __delete__(self, instance: TFeature) -> None:
        """
        Deletes the value of this item from the target feature.
        :param instance: The feature to delete the value from.
        """
        ...

    @abstractmethod
    def __get__(self, instance: TFeature, owner: Type[TFeature]) -> TPy_co:
        """
        Gets the value of this item from the target feature.
        :param instance: The feature to get the value from.
        :param owner: The type of the feature.
        """
        ...

    @abstractmethod
    def __set__(self, instance: TFeature, value: T) -> None:
        """
        Sets the value of this item on the target feature.
        :param instance: The feature to set the value of.
        :param value: The new value of this item within the target feature.
        """
        ...

    @abstractmethod
    def __set_name__(self, owner: Type[TFeature], name: str) -> None:
        """
        Sets the name of this item on the target feature if its name hasn't already been set.
        :param owner: The type of the feature.
        :param name: The new name of this item.
        """
        ...

    @property
    @abstractmethod
    def field_name(self) -> Optional[str]:
        """Returns the field name of this item."""
        ...

    @property
    def is_read_only(self) -> bool:
        """Returns True if this item is read-only, otherwise False."""
        return False

    @is_read_only.setter
    def is_read_only(self, value: bool) -> None:
        """
        Sets the read-only flag of this item.
        :param value: True if this item is read-only, otherwise False.
        """
        raise NotImplementedError()

    @is_read_only.deleter
    def is_read_only(self) -> None:
        """Removes the read-only flag of this item."""
        raise NotImplementedError()

    @abstractmethod
    def to_input(self, value: T) -> TDb_co:
        """
        Converts the target value to the database type of this item.
        :param value: The value to convert.
        """
        ...

    @abstractmethod
    def to_output(self, value: T) -> TPy_co:
        """
        Converts the target value to the Python type of this item.
        :param value: The value to convert.
        """
        ...

    @classmethod
    def __subclasshook__(cls, C) -> bool:
        """
        Determines if C is considered a subclass of the ItemProvider type.
        :param C: The other value to check against.
        """
        if cls is Item:
            type_: Type = C if isinstance(C, type) else type(C)
            if cls is type_:
                return True
            return protocolhelpers.follows_protocol(C, cls,
                                                    '__delete__', '__get__', 'field_name',
                                                    'is_read_only', 'to_input', 'to_output',
                                                    '__set_name__', '__set__',
                                                    check_type_annotations=True)
        return NotImplemented


@runtime
@runtime_checkable
class PropertyItem(Item[TPy, TDb], Protocol[TPy, TDb, TFeature]):
    """A protocol class used to implement custom property-item items."""

    @property
    @abstractmethod
    def fdel(self) -> Optional[Callable[[TFeature], None]]:
        """Returns the deleter function of this PropertyItem."""
        ...

    @property
    @abstractmethod
    def fget(self) -> Optional[Callable[[TFeature], TPy]]:
        """Returns the getter function of this PropertyItem."""
        ...

    @property
    @abstractmethod
    def fin(self) -> Optional[Callable[[Any], TDb]]:
        """Returns the input converter function of this PropertyItem."""
        ...

    @property
    @abstractmethod
    def fout(self) -> Optional[Callable[[Any], TPy]]:
        """Returns the output converter function of this PropertyItem."""
        ...

    @property
    @abstractmethod
    def fset(self) -> Optional[Callable[[TFeature, TPy], None]]:
        """Returns the setter function of this PropertyItem."""
        ...

    @abstractmethod
    def deleter(self: TPropertyItem, deleter: Optional[Callable[[TFeature], None]]) -> TPropertyItem:
        """
        Sets the deleter of this PropertyItem to the given function.
        :param deleter: The deleter function to use.
        """
        ...

    @abstractmethod
    def getter(self: TPropertyItem, getter: Optional[Callable[[TFeature], TPy]]) -> TPropertyItem:
        """
        Sets the getter of this PropertyItem to the given function.
        :param getter: The getter function to use.
        """
        ...

    @abstractmethod
    def input_converter(self: TPropertyItem, input_converter: Optional[Callable[[Any], TDb]]) -> TPropertyItem:
        """
        Sets the input converter of this PropertyItem to the given function.
        :param input_converter: The input converter function to use.
        """
        ...

    @abstractmethod
    def output_converter(self: TPropertyItem, output_converter: Optional[Callable[[Any], TPy]]) -> TPropertyItem:
        """
        Sets the output converter of this PropertyItem to the given function.
        :param output_converter: The output converter function to use.
        """
        ...

    @abstractmethod
    def setter(self: TPropertyItem, setter: Optional[Callable[[TFeature, TPy], None]]) -> TPropertyItem:
        """
        Sets the setter of this PropertyItem to the given function.
        :param setter: The setter function to use.
        """
        ...

    @abstractmethod
    def __delete__(self, instance: _TFeature) -> None:
        deleter: Optional[Callable[[TFeature], None]] = self.fdel

        if deleter is not None:
            deleter(instance)

    @abstractmethod
    def __get__(self, instance: _TFeature, owner: Type[_TFeature]) -> TPy:
        getter: Optional[Callable[[TFeature], TPy]] = self.fget
        if getter is None:
            return None
        else:
            return getter(instance)

    @abstractmethod
    def __set__(self, instance: _TFeature, value: Union[TPy, T]) -> None:
        setter: Optional[Callable[[TFeature, TPy], None]] = self.fset

        if setter is not None:
            setter(instance, cast(TPy, value))

    @classmethod
    def __subclasshook__(cls, C) -> bool:
        if cls is PropertyItem:
            type_: Type = C if isinstance(C, type) else type(C)
            if cls is type_:
                return True
            return (protocolhelpers.follows_protocol(C, cls,
                                                     'fdelete', 'fget', 'fin', 'fout',
                                                     'fset', 'deleter', 'getter',
                                                     'input_converter',
                                                     'output_converter',
                                                     'setter',
                                                     check_type_annotations=True) and
                    issubclass(type_, Item))
        return NotImplemented


@runtime
@runtime_checkable
class ItemProvider(Protocol):
    """A protocol class used to implement custom item providers that don't extend the FeatureItemProvider class."""

    @abstractmethod
    def get_feature_item(self, field: str) -> Optional[Item]:
        """
        Returns the Item object with the given field name.
        :param field: The field of the Item object to get.
        """
        ...

    @classmethod
    @abstractmethod
    def get_feature_items(cls) -> Dict[str, Item]:
        """Returns all Item objects within this ItemProvider instance."""
        ...

    @classmethod
    @abstractmethod
    def get_feature_items_by_field(cls) -> Dict[str, Item]:
        """Returns all Item objects within this ItemProvider instance keyed by their database field names."""
        ...

    @classmethod
    @abstractmethod
    def get_feature_items_by_insensitive_field(cls) -> Dict[str, Item]:
        """Returns all Item objects within this ItemProvider instance keyed by their database field names in a case-insensitive manner."""
        ...

    @classmethod
    def __subclasshook__(cls, C) -> bool:
        """
        Determines if C is considered a subclass of the ItemProvider type.
        :param C: The other value to check against.
        """
        if cls is Feature:
            type_: Type = C if isinstance(C, type) else type(C)
            if cls is type_:
                return True
            return protocolhelpers.follows_protocol(C, cls,
                                                    'get_feature_item', 'get_feature_items',
                                                    'get_feature_items_by_field',
                                                    check_type_annotations=True)
        return NotImplemented


@runtime
@runtime_checkable
class Feature(ItemProvider, Protocol[TVector]):
    """A protocol class used to implement custom features that don't extend the BasicFeatureObject class."""

    @property
    @abstractmethod
    def vector_name(self) -> str:
        """Returns the name of the vector object of this Feature instance, or '<disconnected feature>' if no vector object is available."""
        ...

    @property
    @abstractmethod
    def vector_object(self) -> TVector:
        """Returns the Vector object of this Feature instance."""
        ...

    @property
    @abstractmethod
    def qgs_id(self) -> Optional[int]:
        """Returns the QGIS-assigned ID of this Feature instance."""
        ...

    @property
    @abstractmethod
    def is_new(self) -> bool:
        """Returns True if this Feature instance is considered new to its Vector object, otherwise False."""
        ...

    @property  # type: ignore
    @abstractmethod
    def qgs_feature(self) -> Union[QgsFeature, Dict[str, Any]]:
        """Returns the QGIS feature of this Feature instance."""
        ...

    @property
    @abstractmethod
    def has_hashable_values(self) -> bool:
        """Returns whether or not the hashable values exist on this Feature instance."""
        ...

    @qgs_feature.setter  # type: ignore
    @abstractmethod
    def qgs_feature(self, value: Union[QgsFeature, Dict[str, Any]]) -> None:
        """
        Updates the QGIS feature of this Feature instance.
        :param value: The new QGIS feature, or an equivalent dictionary, containing the values of this Feature instance.
        """
        ...

    @qgs_feature.deleter  # type: ignore
    @abstractmethod
    def qgs_feature(self) -> None:
        """Deletes the QGIS feature of this Feature instance."""
        ...

    @property  # type: ignore
    @abstractmethod
    def geometry(self) -> Optional[QgsGeometry]:
        """Returns the QGIS geometry of this Feature instance."""
        ...

    @geometry.setter  # type: ignore
    @abstractmethod
    def geometry(self, geometry: Optional[QgsGeometry]) -> None:
        """
        Updates the QGIS geometry of this Feature instance.
        :param geometry: The new QGIS geometry of this Feature instance.
        """
        ...

    @geometry.deleter  # type: ignore
    @abstractmethod
    def geometry(self) -> None:
        """Deletes the QGIS geometry of this Feature instance."""
        self.geometry = None  # type: ignore

    @property
    @abstractmethod
    def hash_field(self) -> Optional[Union[str, List[str]]]:
        """
        Returns the field used for hashing of this Feature instance.
        Note: If a list is returned and the implementor supports it, then each of the fields are used in order
              for the comparison.
        """
        ...

    @property
    @abstractmethod
    def qgs_fields(self) -> Dict[int, Any]:
        """Represents the QGIS fields (by index) and their values in this Feature instance."""
        ...

    @property
    @abstractmethod
    def old_qgs_fields(self) -> Dict[int, Any]:
        """Represents the original QGIS fields (by index) and their values in this Feature instance."""
        ...

    @abstractmethod
    def __getitem__(self, key: str) -> Any:
        """
        Gets a value from this Feature instance with the given key.
        :param key: The name of the field to get the value of.
        """
        ...

    @abstractmethod
    def __setitem__(self, key: str, value: Any) -> None:
        """
        Sets a value of this Feature instance at the given key.
        :param key: The name of the field to update the value of.
        :param value: The new value of the field.
        """
        ...

    def __delitem__(self, key: str) -> None:
        """
        Deletes a value of this Feature instance at the given key.
        :param key: The name of the field to delete the value of.
        """
        self[key] = None

    @abstractmethod
    def __iter__(self) -> Iterator[str]:
        """Yields the field names of this Feature instance."""
        ...

    @abstractmethod
    def capture_gps(self) -> bool:
        """
        Attempts to capture the current GPS coordinates for the current object.
        """
        ...

    @abstractmethod
    def connect(self, vector_object: TVector) -> bool:
        """
        Attempts to connect this Feature instance to the provided Vector object.
        :param vector_object: The new Vector object of this Feature instance.
        """
        ...

    @abstractmethod
    def disconnect(self) -> None:
        """Disconnects this Feature instance from its Vector object."""
        ...

    @abstractmethod
    def has_field(self, key: Optional[str]) -> bool:
        """
        Determines if this Feature instance contains a field with the given key.
        :param key: The key used to identify the field.
        """
        ...

    @abstractmethod
    def items(self) -> Mapping[str, Any]:
        """Returns all items of this Feature instance."""
        ...

    @abstractmethod
    def values(self) -> Iterable[Any]:
        """Returns all values of this Feature instance."""
        ...

    @abstractmethod
    def save(self) -> bool:
        """Saves the changes of this Feature instance back to its Vector object."""
        ...

    @abstractmethod
    def remove(self) -> bool:
        """Removes this Feature instance from its Vector object."""
        ...

    @abstractmethod
    def reload(self) -> None:
        """Reloads this Feature instance from its Vector object."""
        ...

    @abstractmethod
    def select(self) -> None:
        """Selects this Feature instance in the UI."""
        ...

    def to_dict(self, *, use_db_fields: bool=True, use_db_types: bool=False) -> Dict[str, Any]:
        """
        Returns a dictionary representation of this Feature instance.
        :param use_db_fields: True if DB field names should be used, otherwise False.
        """
        data: Dict[str, Any] = {}
        name: str
        item: Item
        for name, item in self.get_feature_items().items():
            data[item.field_name if use_db_fields else name] = item.to_input(self[name]) if use_db_types else self[name]
        return data

    def to_json(self, *, use_db_fields: bool=True) -> str:
        return json.dumps(self.to_dict(use_db_fields=use_db_fields), cls=json_handlers.TrcSimpleEncoder)

    __hash_cache: int = None

    @abstractmethod
    def __hash__(self) -> int:
        """Returns the hash of this feature based off of the hash_fields property if any exist."""
        if self.__hash_cache is None:
            hash_field: Union[str, List[str]] = self.hash_field
            value: Union[Any, Tuple[Any, ...]] = None

            if isinstance(hash_field, str):
                value = self[hash_field]
            elif isinstance(hash_field, list):
                value = tuple(self[f] for f in hash_field)
            else:
                value = NotImplemented

            self.__hash_cache = value if value is NotImplemented else hash(value)

        return self.__hash_cache

    @abstractmethod
    def __eq__(self, other: Any) -> bool:
        """
        Returns whether or not other is equal to this feature.
        :param other: The other value of the equality check.
        """
        hash_field: Union[str, List[str]] = self.hash_field
        is_str: bool = isinstance(hash_field, str)

        if not (is_str or isinstance(hash_field, list)) or not isinstance(other, type(self)):
            return NotImplemented

        if is_str:
            hash_field = cast(str, hash_field)
            return self[hash_field] == other[hash_field]
        else:
            for field in hash_field:  # type: str
                if self[field] != other[field]:
                    return False
        return True

    @classmethod
    def __subclasshook__(cls, C) -> bool:
        """
        Determines if C is considered a subclass of the Feature type.
        :param C: The other value to check against.
        """
        if cls is Feature:
            # Ensure we're only checking for Feature types.
            type_: Type = C if isinstance(C, type) else type(C)
            if cls is type_:
                return True
            return (protocolhelpers.follows_protocol(C, cls,
                                                     '__delitem__', '__getitem__', '__iter__',
                                                     'connect', 'disconnect', 'geometry',
                                                     'is_new', 'items', 'qgs_feature', 'qgs_id',
                                                     'reload', 'remove', 'save', 'select',
                                                     'values', 'vector_object', 'vector_name',
                                                     'qgs_fields', 'old_qgs_fields', 'has_field',
                                                     'hash_field', '__hash__', '__eq__',
                                                     'to_dict', 'to_json', check_type_annotations=True) and
                    issubclass(type_, ItemProvider))
        return NotImplemented


@runtime
@runtime_checkable
class Vector(Protocol[TFeature]):
    """A protocol class used to implement custom vectors that don't extend the BasicVectorObject class."""

    @property
    def attached_to_ui(self) -> bool:
        """Returns True if this Vector instance is currently attached to the UI, otherwise False."""
        ...

    @property
    def qgs_layer(self) -> Optional[QgsVectorLayer]:
        """Returns the QGIS layer that is represented by this Vector instance."""
        ...

    @qgs_layer.setter
    def qgs_layer(self, qgs_layer: Optional[QgsVectorLayer]) -> None:
        """
        Updates the QGIS layer that is represented by this Vector instance.
        :param qgs_layer: The new layer of this Vector.
        """
        ...

    @qgs_layer.deleter
    def qgs_layer(self) -> None:
        """Removes the QGIS layer that is represented by this Vector instance."""
        self.qgs_layer = None

    @property
    def field_names(self) -> FrozenSet[str]:
        """Returns all field names of this Vector instance."""
        ...

    @property
    def field_aliases(self) -> Dict[str, str]:
        """Returns all field aliases of this Vector instance."""
        ...

    @property
    def editable(self) -> bool:
        """Returns True if this Vector instance and its Feature objects can be modified, otherwise false."""
        ...

    @property
    def extent(self) -> Optional[QgsRectangle]:
        """Returns the extent of this vector instance."""
        ...

    @property
    def layer_name(self) -> str:
        """Returns the layer name of this Vector instance."""
        ...

    @property
    def feature_object_type(self) -> Type[TFeature]:
        """Returns the type of Feature object produced by this Vector instance."""
        ...

    @property
    def validators(self) -> List['Validator[TFeature]']:
        """Returns the validators associated to this Vector instance."""
        ...

    @abstractmethod
    def __getitem__(self, feature_id: Optional[int]) -> Optional[TFeature]:
        """
        Returns a Feature object from this Vector instance with the given row ID.
        :param feature_id: The ID of the feature to return.
        """
        ...

    @abstractmethod
    def __delitem__(self, feature_id: Optional[int]) -> None:
        """
        Deletes a Feature object from this Vector instance with the given row ID.
        :param feature_id: The ID of the feature to delete.
        """
        ...

    def __iter__(self) -> Iterator[TFeature]:
        """Yields all Feature objects from this Vector instance."""
        yield from self.find(None)

    def __len__(self) -> int:
        """Returns the total number of Feature objects in this Vector instance."""
        return self.count(None)

    @overload
    def find(self, filter_: Optional[str], *vargs: Any, **kwargs: Any) -> Iterable[TFeature]:
        pass

    @overload
    def find(self, filter_: Optional[QgsFeatureRequest], **kwargs: Any) -> Iterable[TFeature]:
        pass

    @overload
    def find(self, filter_: Optional[QgsExpression], **kwargs: Any) -> Iterable[TFeature]:
        pass  # type: ignore

    @abstractmethod
    def find(self, filter_, *vargs: Any, **kwargs: Any) -> Iterable[TFeature]:
        """
        Searches this Vector instance for all Feature objects that match the given filter.
        :param filter_: The filter to apply for resolving features.
        :param vargs: If filter_ is str, the arguments to populate into filter_ after encoding.
        :param kwargs: limit, flags, fields, and order_by values used to change the result set.
        """
        ...

    @overload
    def find_any(self, filter_: Optional[str], *vargs: Any, **kwargs: Any) -> Optional[TFeature]:
        pass

    @overload
    def find_any(self, filter_: Optional[QgsFeatureRequest], **kwargs: Any) -> Optional[TFeature]:
        pass

    @overload
    def find_any(self, filter_: Optional[QgsExpression], **kwargs: Any) -> Optional[TFeature]:
        pass  # type: ignore

    def find_any(self, filter_, *vargs: Any, **kwargs: Any) -> Optional[TFeature]:
        """
        Searches this Vector instance for a single Feature object that match the given filter.
        :param filter_: The filter to apply for resolving features.
        :param vargs: If filter_ is str, the arguments to populate into filter_ after encoding.
        :param kwargs: flags, fields, and order_by values used to change the result set.
        """
        kwargs['limit'] = 1
        return first(self.find(filter_, *vargs, **kwargs))

    @overload
    def count(self, filter_: Optional[str], *vargs: Any, **kwargs: Any) -> int:
        pass

    @overload
    def count(self, filter_: Optional[QgsFeatureRequest], **kwargs: Any) -> int:
        pass

    @overload
    def count(self, filter_: Optional[QgsExpression], **kwargs: Any) -> int:
        pass  # type: ignore

    def count(self, filter_, *vargs: Any, **kwargs: Any) -> int:
        """
        Searches this Vector instance for all Feature objects that match the given filter and returns the total number of them
        found.
        :param filter_: The filter to apply for resolving features.
        :param vargs: If filter_ is str, the arguments to populate into filter_ after encoding.
        :param kwargs: limit, flags, and order_by values used to change the result set.
        """
        return len(self.find(filter_, *vargs, **kwargs))  # type: ignore

    @overload
    def exists(self, filter_: Optional[str], *vargs: Any, **kwargs: Any) -> bool:
        pass

    @overload
    def exists(self, filter_: Optional[QgsFeatureRequest], **kwargs: Any) -> bool:
        pass

    @overload
    def exists(self, filter_: Optional[QgsExpression], **kwargs: Any) -> bool:
        pass  # type: ignore

    def exists(self, filter_, *vargs: Any, **kwargs: Any) -> bool:
        """
        Searches this Vector instance for a single Feature object that match the given filter, returning True if one exists,
        otherwise False.
        :param filter_: The filter to apply for resolving features.
        :param vargs: If filter_ is str, the arguments to populate into filter_ after encoding.
        """
        return self.find_any(filter_, *vargs, **kwargs) is not None

    @abstractmethod
    def join(self, self_field: str, other_vector: Union['Vector', QgsVectorLayer], other_field: Optional[str]=None,
             prefix: Optional[str]=None, included_fields: Optional[List[str]]=None, excluded_fields: Optional[List[str]]=None,
             using_memory_cache: bool=True, editable: bool=True) -> bool:
        """
        Joins this vector to another vector using the provided field names, returning true if the join is successful, otherwise false.
        :param self_field: The field of this vector to join on.
        :param other_vector: A BasicVectorObject to join.
        :param other_field: The field of the other vector to join on. If not provided, self_field is used instead.
        :param prefix: The optional prefix to apply to all fields that are produced by the join.
        :param included_fields: The fields that are included in the join.
        :param excluded_fields: The fields that are excluded from the join.
        :param using_memory_cache: True if joins should be cached in ram, otherwise false.
        :param editable: True if the joined fields should be modifiable, otherwise false.
        """
        ...

    def resolve_field_name(self, key: str) -> Optional[str]:
        """
        Attempts to resolve the provided key to a field name, returning the field name if it exists, otherwise None.
        :param key: The key to resolve.
        """
        ...

    @abstractmethod
    def start_editing(self) -> bool:
        """Enters this Vector instance into editing mode."""
        ...

    @abstractmethod
    def add_or_update(self, feature: TFeature) -> bool:
        """
        Adds or updates the Feature object to this Vector instance.
        :param feature: The Feature object to add or update.
        """
        ...

    def add_or_update_all(self, features: Iterable[TFeature]) -> bool:
        """
        Adds or updates all of the Feature objects to this Vector instance.
        :param features: The Feature objects to add or update.
        """
        features = list(features)
        return not any(features) or reduce(lambda l, r: l and r, (self.add_or_update(f) for f in features))

    @abstractmethod
    def delete(self, feature: TFeature) -> bool:
        """
        Deletes the Feature object from this Vector instance.
        :param feature: The Feature object to delete.
        """
        ...

    def delete_all(self, features: Optional[Iterable[TFeature]]=None) -> bool:
        """
        Deletes all of the Feature objects from this Vector instance.
        :param features: The Feature objects to delete.
        """
        if features is not None:
            feature: TFeature
            for feature in features:
                if not self.delete(feature):
                    return False
        return True

    @abstractmethod
    def commit_changes(self) -> bool:
        """Commits all changes to this Vector instance back to its datasource."""
        ...

    @abstractmethod
    def rollback_changes(self) -> bool:
        """Rolls back all changes to this Vector instance."""
        ...

    @abstractmethod
    def reload(self, feature: Optional[TFeature]=None) -> None:
        """
        Reloads this Vector instance or the provided Feature object from its datasource.
        :param feature: The specific Feature object to reload if provided.
        """
        ...

    @abstractmethod
    def new_feature(self, **kwargs: Any) -> TFeature:
        """
        Returns a new Feature object associated to this Vector instance.
        :param kwargs: The initial field values of the new Feature object.
        """
        ...

    @abstractmethod
    def has_feature(self, feature: TFeature, **kwargs: Any) -> bool:
        """
        Determines if the provided feature exists within this vector.
        :param feature: The feature to determine the existence of.
        """
        if feature.hash_field is not None:
            hash_fields: List[str] = [feature.hash_field] if isinstance(feature.hash_field, str) else cast(List[str], feature.hash_field)
            fields: str = " AND ".join(f"[{f}] = " "{}" for f in hash_fields)

            return self.exists(fields, *(feature[f] for f in hash_fields), **kwargs)
        return False

    def has_features(self, features: Iterable[TFeature]) -> bool:
        """
        Detemines if all provided features exist within this vector.
        :param features: The features to determine the existence of.
        """
        features = list(features)

        return any(features) and reduce(lambda l, r: l and r, (self.has_feature(f) for f in features))

    def has_any_feature(self, features: Iterable[TFeature]) -> bool:
        """
        Determines if any provided feature exists within this vector.
        :param features: The features to determine the existence of.
        """
        features = list(features)

        return any(features) and reduce(lambda l, r: l or r, (self.has_feature(f) for f in features))

    @abstractmethod
    def fields(self) -> Iterable[str]:
        """Yields all fields associated to this Vector instance."""
        ...

    @abstractmethod
    def add_to_group(self, group_name: Optional[str]=None, index: Optional[int]=None) -> None:
        """
        Adds this Vector instance to the provided group in the layer tree.
        :param group_name: The optional name of the group to add this Vector instance to.
        :param index: The optional index to insert this Vector instance into.
        """
        ...

    @abstractmethod
    def select(self, feature: Optional[TFeature]=None) -> bool:
        """
        Selects this Vector instance or the provided Feature object.
        :param feature: The optional Feature object to select.
        """
        ...

    @overload
    def select_all(self, *, features: Iterable[TFeature]) -> bool: pass
    @overload
    def select_all(self, *args: TFeature) -> bool: pass

    @abstractmethod
    def select_all(self, *args: TFeature, features: Iterable[TFeature]=None) -> bool:
        """
        Selects all of the given Feature objects within this Vector instance.
        :param args: A variadic list of Feature objects to select.
        :param features: An iterable that yields Feature objects to select.
        """
        ...

    @abstractmethod
    def load_named_style(self, uri: str, load_from_db: bool=False, *,
                         categories: Union[QgsMapLayer.StyleCategories, QgsMapLayer.StyleCategory]=QgsMapLayer.AllStyleCategories) -> bool:
        """
        Loads the provided URI as the style of this layer, optionally selecting it from the style database and from the
        provided category.
        :param uri: The URI to load the style from.
        :param load_from_db: True if the local style database should be used for loading, otherwise False.
        :param categories: The style categories to load.
        """
        ...

    @abstractmethod
    def block_signals(self) -> ContextManager:
        """Blocks all signals that could be raised if this Vector instance is changed."""
        ...

    @abstractmethod
    def start_transaction(self) -> 'transactionmanager[TFeature]':
        """Begins a transaction block that wraps this Vector instance."""
        ...

    @abstractmethod
    def validate(self, feature: TFeature) -> Iterable['ValidationResult']:
        """
        Applies all validators of this Vector object to the given Feature instance.
        :param feature: The Feature instance to validate.
        :return: The aggregated ValidationResult instances of the validators.
        """
        ...

    @abstractmethod
    def take_focus(self, zoom_to_selected_features: bool=False) -> None:
        """
        Zooms the QGIS map to encompass this layer's selected features.
        :param zoom_to_selected_features: True if the zoom should be put on the selected features of the layer, False if the zoom should be to the extent of the layer.
        """
        ...

    @classmethod
    def __subclasshook__(cls, C) -> bool:
        """
        Determines if C is considered a subclass of the Vector type.
        :param C: The other value to check against.
        """
        if cls is Vector:
            type_: Type = C if isinstance(C, type) else type(C)
            if cls is type_:
                return True
            return protocolhelpers.follows_protocol(C, cls,
                                                    '__delitem__', '__getitem__', 'add_or_update',
                                                    'add_to_group', 'block_signals', 'commit_changes',
                                                    'delete', 'editable', 'exists', 'field_aliases',
                                                    'field_names', 'fields', 'find', 'find_any',
                                                    'join', 'load_named_style', 'new_feature',
                                                    'qgs_layer', 'reload', 'resolve_field_name',
                                                    'rollback_changes', 'select', 'start_editing',
                                                    'start_transaction', 'count', '__iter__',
                                                    '__len__', 'layer_name', 'feature_object_type',
                                                    'delete_all', 'add_or_update_all', 'validators',
                                                    'validate', 'take_focus', 'extent', 'has_feature',
                                                    'has_features', 'has_any_feature', 'attached_to_ui',
                                                    check_type_annotations=True)
        return NotImplemented


@runtime
@runtime_checkable
class transactionmanager(Protocol[TFeature]):
    """
    Provides a protocol for transaction context managers that can be used in with statements.
    """

    @property
    def success(self) -> bool:
        ...

    @success.setter
    def success(self, success: bool) -> None:
        ...

    @success.deleter
    def success(self) -> None:
        self.success = False

    @property
    @abstractmethod
    def vector_object(self) -> 'Vector[TFeature]':
        ...

    @abstractmethod
    def __enter__(self) -> 'transactionmanager[TFeature]':
        """
        Enters into this transaction if possible.
        :raise StartTransactionFailedError: Raised if no transaction is open by the end of the enter call.
        :return: This transactionmanager instance.
        """
        ...

    @abstractmethod
    def __exit__(self, exc_type: Optional[Type[BaseException]], exc: Optional[BaseException], tb: Optional[TracebackType]) -> Literal[False]:
        """
        Ends this transaction, committing it to the database if success is True and no exceptions were raised.
        :param exc_type: The type of the exception raised, if any.
        :param exc: The exception raised, if any.
        :param tb: The traceback of the exception raised, if any.
        :return: False. Transaction managers should not restore themselves after an exception.
        """
        ...

    @classmethod
    def __subclasshook__(cls, C) -> bool:
        if cls is transactionmanager:
            type_: Type = C if isinstance(C, type) else type(C)
            if cls is type_:
                return True
            return protocolhelpers.follows_protocol(C, cls,
                                                    'success', 'vector_object',
                                                    '__enter__', '__exit__',
                                                    check_type_annotations=True)
        return NotImplemented


ValidationResult = NamedTuple('ValidationResult', [('error', bool), ('message', str)])


@runtime
@runtime_checkable
class Validator(Protocol[TFeature_contra]):
    """
    Provides a protocol for determining of an object can be used to validate a feature.
    """

    @abstractmethod
    def validate(self, feature: TFeature_contra) -> Iterable[ValidationResult]:
        """
        Determines if the given feature is considered valid against this validator.
        :param feature: The feature to validate.
        :return: An iterable collection of ValidationResult tuples that contain whether or not a result is considered an error and any messages associated to the result.
        """
        ...

    @classmethod
    def __subclasshook__(cls, C) -> bool:
        if cls is Validator:
            type_: Type = C if isinstance(C, type) else type(C)
            if cls is type_:
                return True
            return protocolhelpers.follows_protocol(C, cls, 'validate', check_type_annotations=True)
        return NotImplemented


@final
@singleton
class DefaultItem(Item[TPy_co, TDb_co]):
    """
    Provides a default implementation of the Item type. This is only used when a converter is
    expected but no Item is found representing the field, otherwise, this object is a no-op.
    """

    def __delete__(self, instance: TFeature) -> None:
        # Unsupported operation
        pass

    def __get__(self, instance: TFeature, owner: Type[TFeature]) -> T:
        # Unsupported operation
        if instance is None and owner is DefaultItem:
            return owner.__dict__.get('__INSTANCE')
        return NotImplemented

    def __set__(self, instance: TFeature, value: T) -> None:
        # Unsupported operation
        pass

    def __set_name__(self, owner: Type[TFeature], name: str) -> None:
        # Unsupported operation
        pass

    @property
    def field_name(self) -> Optional[str]:
        return None

    @property
    def is_read_only(self) -> bool:
        return False

    @is_read_only.setter
    def is_read_only(self, value: bool) -> None:
        # Unsupported operation
        pass

    @is_read_only.deleter
    def is_read_only(self) -> None:
        # Unsupported Operation
        pass

    def to_input(self, value: T) -> TDb_co:
        return cast(TDb_co, value)

    def to_output(self, value: T) -> TPy_co:
        return cast(TPy_co, value)


@final
class IgnoredItem(Item[TPy_co, TDb_co]):
    """
    Ignored features are provided to allow for a feature to be mapped but marked as unused. This is to prevent the feature from
    potentially being mapped up when it contains a datatype that can't be accessed through QGIS's feature system.
    """
    _field_name: Optional[str] = None

    def __init__(self, field_name: Optional[str]=None) -> None:
        self._field_name = field_name

    def __delete__(self, instance: TFeature) -> None:
        # Unsupported operation
        pass

    def __get__(self, instance: TFeature, owner: Type[TFeature]) -> T:
        return None

    def __set__(self, instance: TFeature, value: T) -> None:
        # Unsupported operation
        pass

    def __set_name__(self, owner: Type[TFeature], name: str) -> None:
        if self._field_name is None:
            self._field_name = name

    @property
    def field_name(self) -> Optional[str]:
        return self._field_name

    @property
    def is_read_only(self) -> bool:
        return False

    @is_read_only.setter
    def is_read_only(self, value: bool) -> None:
        # Unsupported operation
        pass

    @is_read_only.deleter
    def is_read_only(self) -> None:
        # Unsupported Operation
        pass

    def to_input(self, value: T) -> TDb_co:
        return None

    def to_output(self, value: T) -> TPy_co:
        return None

