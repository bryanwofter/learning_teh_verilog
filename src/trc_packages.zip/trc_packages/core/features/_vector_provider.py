from trc_packages.core.features import _contextmanagers as contextmanagers, protocols
from typing import cast, Dict, Generic, Iterable, Iterator, Optional, overload, Tuple, Type, TypeVar, Union
V = TypeVar('V', bound='protocols.Vector')
Vc = TypeVar('Vc', bound='protocols.Vector')
Vc1 = TypeVar('Vc1', bound='protocols.Vector')
Vc2 = TypeVar('Vc2', bound='protocols.Vector')
Vc3 = TypeVar('Vc3', bound='protocols.Vector')
Vc4 = TypeVar('Vc4', bound='protocols.Vector')
Vc5 = TypeVar('Vc5', bound='protocols.Vector')
Vc6 = TypeVar('Vc6', bound='protocols.Vector')
Vc7 = TypeVar('Vc7', bound='protocols.Vector')


class VectorNamePair:
    """
    Provides a pair for the base name and layer name of a vector type.
    """

    layer_name: str = None
    base_name: str = None

    def __init__(self, *, layer_name: str=None, base_name: str=None) -> None:
        self.layer_name = layer_name or base_name
        self.base_name = base_name or layer_name

    def __iter__(self) -> Iterator[str]:
        yield self.layer_name
        yield self.base_name


class VectorProvider(Generic[V]):
    """
    Provides a dictionary-like method for getting and managing instances of protocols.Vector classes using common configuration options.
    """

    show_in_ui: bool = False
    path: Optional[str] = None
    current_circuit: Optional[str] = None
    layer_names: Dict[Type[V], Union[VectorNamePair, Tuple[str, str]]] = None

    __vectors: Dict[Type[V], V] = None

    def __init__(self, *, show_in_ui: bool=False, path: Optional[str]=None, current_circuit: Optional[str]=None, layer_names: Dict[Type[V], Union[str, VectorNamePair, Tuple[str, str]]]=dict(), initial_vectors: Dict[Type[V], V]=None) -> None:
        """Initializes this VectorProvider with the given default options."""
        self.show_in_ui = show_in_ui
        self.path = path
        self.current_circuit = current_circuit
        self.layer_names = {t: v if isinstance(v, VectorNamePair) or isinstance(v, tuple) else VectorNamePair(layer_name=v) for t, v in layer_names.items()}
        self.__vectors = dict()
        for vector_type, vector in (initial_vectors or dict()).items():  # type: Tuple[Type[V], V]
            self[vector_type] = vector

    # This overload provides up to 8 explicitly typed and infinite unknown typed vectors to be retrieved from the provider at once.
    @overload
    def __getitem__(self, vector_type: Tuple[Type[Vc], Type[Vc1], Type[Vc2], Type[Vc3], Type[Vc4], Type[Vc5], Type[Vc6], Type[Vc7]]) -> Tuple[Vc, Vc1, Vc2, Vc3, Vc4, Vc5, Vc6, Vc7]:
        ...
    @overload
    def __getitem__(self, vector_type: Tuple[Type[Vc], Type[Vc1], Type[Vc2], Type[Vc3], Type[Vc4], Type[Vc5], Type[Vc6]]) -> Tuple[Vc, Vc1, Vc2, Vc3, Vc4, Vc5, Vc6]:
        ...
    @overload
    def __getitem__(self, vector_type: Tuple[Type[Vc], Type[Vc1], Type[Vc2], Type[Vc3], Type[Vc4], Type[Vc5]]) -> Tuple[Vc, Vc1, Vc2, Vc3, Vc4, Vc5]:
        ...
    @overload
    def __getitem__(self, vector_type: Tuple[Type[Vc], Type[Vc1], Type[Vc2], Type[Vc3], Type[Vc4]]) -> Tuple[Vc, Vc1, Vc2, Vc3, Vc4]:
        ...
    @overload
    def __getitem__(self, vector_type: Tuple[Type[Vc], Type[Vc1], Type[Vc2], Type[Vc3]]) -> Tuple[Vc, Vc1, Vc2, Vc3]:
        ...
    @overload
    def __getitem__(self, vector_type: Tuple[Type[Vc], Type[Vc1], Type[Vc2]]) -> Tuple[Vc, Vc1, Vc2]:
        ...
    @overload
    def __getitem__(self, vector_type: Tuple[Type[Vc], Type[Vc1]]) -> Tuple[Vc, Vc1]:
        ...
    @overload
    def __getitem__(self, vector_type: Tuple[Type[Vc], ...]) -> Tuple[Type[Vc], ...]:
        ...
    @overload
    def __getitem__(self, vector_type: Type[Vc]) -> Vc:
        ...

    def __getitem__(self, vector_type):
        """
        Determines if the given vector has already been created and, if not, creates the vector, returning either the existing or newly created vector back to the caller.
        :param vector_type: The type of vector to use.
        """
        if isinstance(vector_type, tuple):
            return tuple(self[t] for t in vector_type)
        else:
            return self.__get_or_add_item(vector_type)

    def __get_or_add_item(self, vector_type: Type[Vc]) -> Vc:
        """Attempts to get the given vector type from this provider. If the vector type isn't already in this provide, then it will be instantiated and added."""
        if vector_type not in self.__vectors:
            layer_name, base_name = self.layer_names.get(cast(Type[V], vector_type), (None, None))  # type: Tuple[str, str]

            self.__vectors[cast(Type[V], vector_type)] = cast(V, vector_type(  # type: ignore
                show_in_ui=self.show_in_ui, path=self.path, current_circuit=self.current_circuit, layer_name=layer_name, base_name=base_name
            ))

        return cast(Vc, self.__vectors[cast(Type[V], vector_type)])

    def __setitem__(self, vector_type: Type[Vc], vector: Vc) -> None:
        """
        Sets the vector type to the given vector.
        :param vector_type: The type of vector to add.
        :param vector: The vector to add.
        """
        if vector_type in self.__vectors:
            raise KeyError(vector_type, 'vector_type must be removed before it can be set to a new instance.')
        self.__vectors[cast(Type[V], vector_type)] = cast(V, vector)

    def __delitem__(self, vector_type: Type[Vc]) -> None:
        """
        Deletes the vector type.
        :param vector_type: The type of vector to remove.
        """
        del self.__vectors[cast(Type[V], vector_type)]

    def start_transaction(self, *args: Type[V]) -> 'protocols.transactionmanager[protocols.Feature]':
        """Returns a transaction against the given types within this VectorProvider."""
        return contextmanagers.provider_transaction(self, args)

