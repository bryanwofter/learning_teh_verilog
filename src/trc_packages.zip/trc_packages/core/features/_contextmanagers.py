from types import TracebackType
from typing import cast, ContextManager, List, Iterable, Generic, Optional, Type, TypeVar
from typing_extensions import Literal
from trc_packages.core.features import protocols as protocols, _vector_provider as vp, errors as errors
import traceback
TFeature = TypeVar('TFeature', bound='protocols.Feature')


class provider_transaction(ContextManager[protocols.transactionmanager['protocols.Feature']], protocols.transactionmanager['protocols.Feature']):
    """Provides a transaction wrapper for a VectorProvider."""
    success: bool = True
    vector_provider: 'vp.VectorProvider' = None
    vector_types: List[Type['protocols.Vector']] = None
    transactions: List['protocols.transactionmanager[protocols.Feature]'] = None
    vector_object: 'protocols.Vector' = None

    def __init__(self, vector_provider: 'vp.VectorProvider', vector_types: Iterable[Type['protocols.Vector']]) -> None:
        self.vector_provider = vector_provider
        self.vector_types = list(vector_types)
        self.transactions = list()

    def __enter__(self) -> 'provider_transaction':
        if not any(self.transactions):
            try:
                for vector_type in self.vector_types:  # type: Type[protocols.Vector]
                    transaction: protocols.transactionmanager[protocols.Feature] = self.vector_provider[vector_type].start_transaction()
                    transaction.catch_validation_errors = True  # type: ignore
                    self.transactions.append(transaction.__enter__())
            except BaseException as e:
                self.__exit__(type(e), e, traceback.extract_stack())  # type: ignore
                raise e

        return self

    def __exit__(self, exc_type: Optional[Type[BaseException]], exc: Optional[BaseException], tb: Optional[TracebackType]) -> Literal[False]:
        for transaction in self.transactions:
            transaction.success = self.success
            transaction.__exit__(exc_type, exc, tb)
        self.transactions.clear()
        return False


class transaction(ContextManager[protocols.transactionmanager[TFeature]], protocols.transactionmanager[TFeature], Generic[TFeature]):
    """Provides a transaction wrapper for Vector instances that can be used to commit or rollback changes within a with statement."""
    catch_validation_errors: bool = False
    fail_on_uneditable: bool = False
    success: bool = True
    validation_error: errors.FeatureFailedValidationError = None
    vector_object: 'protocols.Vector[TFeature]' = None

    def __init__(self, vector_object: 'protocols.Vector[TFeature]', catch_validation_errors: bool=False, fail_on_uneditable: bool=False) -> None:
        self.vector_object = vector_object
        self.catch_validation_errors = catch_validation_errors
        self.fail_on_uneditable = fail_on_uneditable

    def __enter__(self) -> 'transaction[TFeature]':
        if not self.vector_object.start_editing() and not self.vector_object.editable:
            raise errors.StartTransactionFailedError(vector_object=self.vector_object)

        self.validation_error = None
        return self

    def __exit__(self, exc_type: Optional[Type[BaseException]], exc: Optional[BaseException], tb: Optional[TracebackType]) -> bool:
        if self.success and tb is None:
            if self.vector_object.editable:
                if not self.vector_object.commit_changes():
                    raise errors.CommitTransactionFailedError(vector_object=self.vector_object)
            elif self.fail_on_uneditable:
                raise errors.UneditableTransactionError()

        else:
            self.vector_object.rollback_changes()

        if self.catch_validation_errors and exc_type is errors.FeatureFailedValidationError:
            self.validation_error = cast(errors.FeatureFailedValidationError, exc)
            return True

        return False


class block_signals(ContextManager['protocols.Vector[TFeature]'], Generic[TFeature]):
    """Provides a signal block functionality for Vector instances."""
    vector_object: 'protocols.Vector[TFeature]' = None

    def __init__(self, vector_object: 'protocols.Vector[TFeature]') -> None:
        self.vector_object = vector_object

    def __enter__(self) -> 'protocols.Vector[TFeature]':
        self.vector_object.qgs_layer.blockSignals(True)
        return self.vector_object

    def __exit__(self, exc_type: Optional[Type[BaseException]], exc: Optional[BaseException], tb: Optional[TracebackType]) -> Literal[False]:
        self.vector_object.qgs_layer.blockSignals(False)
        return False

