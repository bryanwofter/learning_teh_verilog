"""
Provides a collection of alias types and generic types that can be used alongside the features library to reduce typing.
"""

from datetime import date, time, datetime
from PyQt5 import QtCore
from trc_packages.core.features import protocols
from typing import List, Union, TypeVar
from uuid import UUID


TFeature = TypeVar('TFeature', bound=protocols.Feature)
GuidUnion = Union[bytes, str, UUID]
FeatureUnion = Union[bytes, str, UUID, TFeature]
GuidUnionList = Union[List[bytes], List[str], List[UUID], List[GuidUnion]]
FeatureUnionList = Union[List[bytes], List[str], List[UUID], List[TFeature], List[FeatureUnion[TFeature]]]
Date = Union[date, QtCore.QDate]
Time = Union[time, QtCore.QTime]
DateTime = Union[datetime, QtCore.QDateTime]

