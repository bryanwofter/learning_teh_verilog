"""
Offers a variety of somewhat common type aliases.
"""

from typing import Callable, Generic, Type, TypeVar, TYPE_CHECKING
from types import TracebackType
from weakref import ReferenceType
_T = TypeVar('_T')


ExceptionType = Type[BaseException]
ExceptionHandler = Callable[[ExceptionType, BaseException, TracebackType], bool]
Runnable = Callable[[], None]
Predicate = Callable[[], bool]

if TYPE_CHECKING:
    WeakReferenceType = ReferenceType
else:
    class WeakReferenceType(Generic[_T], ReferenceType):
        """
        A typehint class used to mask the fact that ReferenceType is only generic in typecheckers.
        """
