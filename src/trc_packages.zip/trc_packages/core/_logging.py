import logging
from logging import handlers
from pathlib import Path
import os.path


_DEFAULT_LOGGING_LEVEL = logging.INFO
_LOG_FILE_PATH = f"{str(Path.home())}/AppData/Local/QGIS/QGIS3/logs/trc/log.log"


def _check_log_folder():
    home = str(Path.home())
    log_folder = home + "/AppData/Local/QGIS/QGIS3/logs/trc"
    if not os.path.exists(log_folder):
        os.makedirs(log_folder)


_check_log_folder()

log = logging.getLogger()
_formatter = logging.Formatter('%(asctime)s - %(filename)s at line %(lineno)d - %(levelname)s: %(message)s')
_handler = logging.handlers.RotatingFileHandler(_LOG_FILE_PATH, maxBytes=500000, backupCount=10)
_handler.setFormatter(_formatter)
log.setLevel(_DEFAULT_LOGGING_LEVEL)
log.addHandler(_handler)
