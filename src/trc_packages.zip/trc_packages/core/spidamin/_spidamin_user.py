from trc_packages.core.spidamin import _spidamin_company as sc
from typing import Any, Dict, Set
try: from typing import Final  # type: ignore
except: from typing_extensions import Final


class SPIDAminUser:
    """
    Provides a simple interface for accessing the properties of an authenticated SPIDAmin user.
    """

    ID_NAME: Final[str] = 'id'
    EXTERNAL_IDS_NAME: Final[str] = 'externalIds'
    LAST_NAME_NAME: Final[str] = 'lastName'
    ENABLED_NAME: Final[str] = 'enabled'
    EMAIL_NAME: Final[str] = 'email'
    COMPANY_NAME: Final[str] = 'company'
    FIRST_NAME_NAME: Final[str] = 'firstName'
    FOREIGN_COMPANIES_NAME: Final[str] = 'foreignCompanies'

    id: int = None
    external_ids: Set[int] = None
    last_name: str = None
    enabled: bool = False
    email: str = None
    company: 'sc.SPIDAminCompany' = None
    first_name: str = None
    foreign_companies: Set['sc.SPIDAminCompany'] = None

    def __init__(self, user: Dict[str, Any]) -> None:
        self.id = user.get(self.ID_NAME)
        self.external_ids = set(user.get(self.EXTERNAL_IDS_NAME))
        self.last_name = user.get(self.LAST_NAME_NAME)
        self.enabled = user.get(self.ENABLED_NAME, False)
        self.email = user.get(self.EMAIL_NAME)
        self.company = sc.SPIDAminCompany(user.get(self.COMPANY_NAME, dict()))
        self.first_name = user.get(self.FIRST_NAME_NAME)
        self.foreign_companies = set(sc.SPIDAminCompany(c) for c in user.get(self.FOREIGN_COMPANIES_NAME, []))

    def __hash__(self) -> int:
        return hash(self.id)

    def __eq__(self, other) -> bool:
                 return self.id == other.id if isinstance(other, type(self)) else NotImplemented


