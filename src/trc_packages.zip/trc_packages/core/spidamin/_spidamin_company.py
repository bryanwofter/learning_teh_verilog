from typing import Any, Dict
try: from typing import Final  # type: ignore
except: from typing_extensions import Final

class SPIDAminCompany:
    """
    Provides a simple interface for accessing the properties of a SPIDAmin company.
    """

    ID_NAME: Final[str] = 'id'
    NAME_NAME: Final[str] = 'name'

    id: int = None
    name: str = None

    def __init__(self, company: Dict[str, Any]) -> None:
        self.id = company.get(self.ID_NAME)
        self.name = company.get(self.NAME_NAME)

    def __hash__(self) -> int:
        return hash(self.id)

    def __eq__(self, other) -> bool:
        return self.id == other.id if isinstance(other, type(self)) else NotImplemented

