from trc_packages.core.spidamin import _spidamin_company as sc, _spidamin_user as su
from typing import Any, Dict, ContextManager, Type, Optional
try: from typing import Literal  # type: ignore
except ImportError: from typing_extensions import Literal
from types import TracebackType
import requests


class SPIDAminClient(ContextManager['SPIDAminClient']):
    """
    Provides a simple client interface for working with SPIDAmin services.
    """

    _host: Optional[str] = None
    _access_token: Optional[str] = None
    _company_name: Optional[str] = None
    _session: Optional[requests.Session] = None
    _cookies: Optional[Dict[str, Any]] = None
    _user: Optional[Dict[str, Any]] = None

    def __init__(self, host: str) -> None:
        self._host = host
        self._session = requests.Session()

    def __hasattr(self, attr: str) -> bool:
        return hasattr(self, attr) and getattr(self, attr) is not None

    def __clear_connected_properties(self) -> None:
        if self.__hasattr('_access_token'):
            del self._access_token
        if self.__hasattr('_cookies'):
            del self._cookies
        if self.__hasattr('_user'):
            del self._user
        if self.__hasattr('_session'):
            self._session.cookies.clear()

    def __clear_company_properties(self) -> None:
        if self.__hasattr('_company_name'):
            del self._company_name

    def connect(self, access_token: str, *, bypass_request: bool=False) -> bool:
        """
        Attempts to connect to the SPIDAmin instance using the given access token.
        :param access_token: The access token to connect with.
        :param bypass_request: True if the user request should be getUser request should be skipped, otherwise False.
        """
        # Ensure we have no accidental left over state when the request is started.
        self.__clear_connected_properties()
        self.__clear_company_properties()
        if self._session is not None:
            self._session.cookies.clear()

            if bypass_request:
                self._access_token = access_token
                self._user = {}
                return True

            json: Optional[Dict[str, Any]] = self.request('usersmaster/usersAPI/getLoggedInUser', apiToken=access_token)

            if json is not None:
                # Let's cache a copy of the user so we can inspect it later.
                self._access_token = access_token
                self._user = json
                return True
        return False

    def extract_user(self) -> Optional['su.SPIDAminUser']:
        return None if self._user is None else su.SPIDAminUser(self._user)

    def switch_company(self, company_name: str) -> bool:
        """
        Attempts to switch the currently selected company.
        :param company_name: The name of the company to select.
        """
        self.__clear_company_properties()
        if self._user is None:
            return False

        user: su.SPIDAminUser = self.extract_user()
        company_id: Optional[int] = None
        company_name = company_name.upper()

        if user.company is not None and user.company.name.upper() == company_name:
            company_id = user.company.id
        else:
            for company in user.foreign_companies:  # type: sc.SPIDAminCompany
                if company.name.upper() == company_name:
                    company_id = company.id
                    break

        if company_id is None:
            return False

        response: Optional[Dict[str, Any]] = self.request('projectmanager/switchcompany', expect_json=False, coselect=company_id)

        if response is not None and 'result' in response and response['result'] is not None:
            # Update the storage of the company and its name.
            self._company_name = company_name
            return True
        else:
            return False

    def request(self, resource: str, *, method: str='GET', expect_json: bool=True, **params: Any) -> Optional[Dict[str, Any]]:
        """
        Performs a request against the SPIDAmin instance.
        :param resource: The resource to apply the request to.
        :param expect_json: True if the response is JSON, otherwise False.
        :param params: The parameters to supply to the request. apiToken will automatically be appended.
        """
        if self._access_token is not None and 'apiToken' not in params:
            params['apiToken'] = self._access_token

        if self._session is not None:
            sanitized_params: Dict[str, str] = {k: f"{v}" for k, v in params.items()}

            response: requests.Response = self._session.request(method,
                                                                f"{self._host}/{resource}",
                                                                params=sanitized_params,
                                                                cookies=self._cookies,
                                                                verify=False)

            if response.status_code < 400:
                self._cookies = dict(response.cookies)
                if expect_json:
                    json: Dict[str, Any] = response.json()

                    if json is None or 'result' not in json:
                        return None
                    else:
                        return json['result']
                else:
                    return {'result': response.text}
        return None

    def __enter__(self) -> 'SPIDAminClient':
        """Returns this client instance."""
        return self

    def __exit__(self, exc_type: Optional[Type[BaseException]], exc: Optional[BaseException], tb: Optional[TracebackType]) -> Literal[False]:
        self.__clear_connected_properties()
        self.__clear_company_properties()
        if self._session is not None:
            self._session.close()
        return False

