from typing import Any, Callable, Iterable, List, Optional, overload, Type, TypeVar, Union
import requests
T = TypeVar('T')
Tl = TypeVar('Tl', tuple, list)


def can_connect(host_name: str, *, timeout: float=1.0) -> bool:
    """
    Determines if the given host can be connected to.
    :param host_name: The URL to contact.
    :param timeout: The amount of time to wait.
    """
    try:
        requests.head(host_name, timeout=timeout, verify=False).raise_for_status()
        return True
    except Exception:
        return False


def is_none_or_whitespace(s: str) -> bool:
    """
    Determines if the given string is None or composed only of whitespace.
    :param s: The string to check.
    :return: True if the string is None or composed only of whitespace, otherwise False.
    """
    return s is None or ((isinstance(s, str) or isinstance(s, bytes)) and not s.strip())


def try_or_get(fn: Callable[[], T], default: T, *, exc_types: List[Type[BaseException]]=None) -> T:
    """
    Attempts to execute fn. If fn raises an exception, then default is returned. If the exception is not within exc_types and exc_types is not empty, then the exception will be raised.
    :param fn: The function to call and return the value of.
    :param default: The value to return if fn raises an exception.
    :param exc_types: The type of exceptions to listen for, if any.
    """
    try:
        return fn()
    except Exception as e:
        if not exc_types or type(e) in exc_types:
            return default
        else:
            raise e


def chunk(l: Tl, count: int) -> Iterable[Tl]:
    """
    Chunks the given tuple or list into multiple tuples or lists of the given size.
    :param l: The tuple or list being chunked.
    :param count: The number of elements per chunked tuple or list.
    """
    count = max(1, count)

    return (l[i:i+count] for i in range(0, len(l), count))


def clamp(value: T, start: T, end: T) -> T:
    """
    Clamps the provided value between start and end.
    :param value: The value to clamp between start and end.
    :param start: The starting point of the clamp range.
    :param end: The endign point of the clamp range.
    """
    minimum: T = min(start, end)
    maximum: T = max(start, end)
    return min(maximum, max(minimum, value))


def attrempty(obj: object, attr: str) -> bool:
    """
    Returns true if the attribute is missing or is considered empty, otherwise false.
    :param obj: The object to check for the attribute of.
    :param attr: The attribute to check for.
    """
    try:
        return getattr(obj, attr) is None
    except ValueError:
        return True


def flatten(arg: Iterable) -> List:
    """
    Flattens the provided iterable object into a list.
    :param arg: The iterable to flatten.
    """
    return [item for sublist in arg for item in sublist]


@overload
def first(arg: List) -> Optional[Any]: pass
@overload
def first(arg: Iterable) -> Optional[Any]: pass


def first(arg) -> Optional[Any]:
    """
    Returns the first element of the iterable.
    :param arg: The iterable to read.
    """
    if isinstance(arg, list):
        return arg[0] if arg else None
    else:
        # If we didn't receive a list, begin iteration of the iterable and return the first element.
        for v in arg:
            return v
        return None


@overload
def last(arg: List) -> Optional[Any]: pass
@overload
def last(arg: Iterable) -> Optional[Any]: pass


def last(arg) -> Optional[Any]:
    """
    Returns the last element of the list.
    :param arg: The list to read.
    """
    if isinstance(arg, list):
        return arg[len(arg) - 1] if arg else None
    else:
        # If we didn't receive a list, iterate over the entire iterable to get the last item. It's inefficient, but it works.
        out: Optional[Any] = None
        for v in arg:
            out = v
        return out

