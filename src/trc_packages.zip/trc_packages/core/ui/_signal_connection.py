from PyQt5 import QtCore
from typing import Any, Callable, ContextManager, Optional, Type
try: from typing import Literal  # type: ignore
except: from typing_extensions import Literal
from types import TracebackType


def connect(signal: QtCore.pyqtSignal, slot: Callable[..., None]) -> 'SignalConnection':
    """
    Connects the given slot to the given signal, returning a context manager that will dispose of the connection upon exiting.
    :param signal: The signal to connect the slot to.
    :param slot: The slot to connect.
    """
    return SignalConnection(signal=signal, to=slot)


class SignalConnection(ContextManager[None]):
    """
    Provides a contextmanager for signal connections.
    """

    __signal: QtCore.pyqtSignal = None
    __to: Optional[Callable[..., None]] = None
    __connection: QtCore.pyqtBoundSignal = None

    def __init__(self, signal: QtCore.pyqtSignal, to: Callable[..., None]) -> None:
        """
        Initializes this SignalConnection.
        :param signal: The signal being connected to.
        :param slot: The slot to connect.
        """
        self.__signal = signal
        self.__to = to

    def __enter__(self) -> None:
        """Enters into this connection."""
        if self.__connection is None:
            self.__connection = self.__signal.connect(self.__to)  # type: ignore

    def __exit__(self, exc_type: Optional[Type[BaseException]], exc: Optional[BaseException], tb: Optional[TracebackType]) -> Literal[False]:
        """
        Exits this connection.
        :param exc_type: The optional exception type that caused the connection to exit.
        :param exc: The optional exception that caused the connection to exit.
        :param tb: The optional traceback that caused the connection to exit.
        """
        if self.__connection is not None:
            try: self.__signal.disconnect(self.__connection)
            except: pass

            self.__connection = None

        return False
        
