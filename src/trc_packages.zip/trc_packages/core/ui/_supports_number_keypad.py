from PyQt5 import QtWidgets
from trc_packages.core.ui import _number_keypad as nk


class SupportsNumberKeypad:
    """
    Provides a class with convenience methods for interacting with a number keypad attached to an object.
    """
    number_keypad: 'nk.NumberKeypad' = None

    def move_number_keypad_onto(self, other: QtWidgets.QWidget) -> None:
        """
        Moves the number keypad instance onto the given widget.
        :param other: The widget to have the keypad moved onto.
        """
        if self.number_keypad is not None:
            self.number_keypad.move_onto(other)

    def move_number_keypad_below(self, other: QtWidgets.QWidget) -> None:
        """
        Moves the number keypad instance below the given widget.
        :param other: The widget to have the keypad moved below.
        """
        if self.number_keypad is not None:
            self.number_keypad.move_below(other)

    def move_number_keypad_above(self, other: QtWidgets.QWidget) -> None:
        """
        Moves the number keypad instance above the given widget.
        :param other: The widget to have the keypad moved above.
        """
        if self.number_keypad is not None:
            self.number_keypad.move_above(other)

    def move_number_keypad_near(self, other: QtWidgets.QWidget, move_onto: bool=False) -> None:
        """
        Moves the number keypad instance near the given widget.
        If the provided object has enough room below it on the screen, this is equivalent to calling move_onto() or move_below().
        Otherwise, this is equivalent to calling move_above().
        :param other: The object to place this keypad near.
        :param move_onto: True if the keypad should use move_onto when movement will fall inside of the window, otherwise false to use move_below.
        """
        if self.number_keypad is not None:
            self.number_keypad.move_near(other, move_onto)

    def show_number_keypad(self) -> None:
        """Displays the number keypad at its current location."""
        self.number_keypad.show()

    def hide_number_keypad(self) -> None:
        """Hides the number keypad."""
        self.number_keypad.hide()

