from functools import wraps
from PyQt5.QtCore import QMutex
from trc_packages.core.ui import _synchro as synchronizer, _synchronize_on as synchronize_on, _supports_synchronized as supports_synchronized
from types import MethodType
from typing import Any, Callable, cast, Optional, TypeVar, Union
F = TypeVar('F')


def synchronized_as(*, independent_method: bool=False, timeout: int=1000, fail_on_timeout: bool=False) -> Callable[[F], F]:
    """
    A decorator that wraps the synchronized decorator to ensure safe typing.
    :param independent_method: True if the method or function is independent of a SupportsSynchronized object, otherwise False.
    :param timeout: The amount of time to wait to obtain the lock.
    :param fail_on_timeout: True if the timeout should raise an exception when the lock can't be obtained, otherwise False.
    """
    return lambda f: synchronized(f, independent_method=independent_method, timeout=timeout, fail_on_timeout=fail_on_timeout)


def synchronized(fn=None, *, independent_method: bool=False, timeout: int=1000, fail_on_timeout: bool=False):
    """
    A decorator for marking a method or function as synchronized.
    :param fn: The function or method to synchronize. Even though this is type-hinted as optional, this overload is deprecated. Instead, @synchronized_as should be used in cases
               where the function being decorated needs additional options.
    :param independent_method: True if the method or function is independent of a SupportsSynchronized object, otherwise False.
    :param timeout: The amount of time to wait to obtain the lock.
    :param fail_on_timeout: True if the timeout should raise an exception when the lock can't be obtained, otherwise False.
    """
    if fn is None:
        # If no function was provided, a dynamic decorator is being used.
        l_independent_method: bool = independent_method
        l_timeout: int = timeout
        l_fail_on_timeout: bool = fail_on_timeout
        return cast(Callable[[F], F], lambda fn, *, independent_method, timeout, fail_on_timeout: synchronized(fn, independent_method=independent_method or l_independent_method, timeout=timeout or l_timeout, fail_on_timeout=fail_on_timeout or l_fail_on_timeout))

    if isinstance(fn, classmethod) or isinstance(fn, staticmethod) or not isinstance(fn, MethodType) or independent_method:
        # If we're working with a classmethod, staticmethod, or function, we need to create our own synchro for the wrapper.
        # Take this path instead to simplify code and improve performance.
        synchro: supports_synchronized.SupportsSynchronized = synchronizer.Synchro()
        is_classmethod: bool = isinstance(fn, classmethod)
        is_staticmethod: bool = isinstance(fn, staticmethod)
        # If the original target is a classmethod or staticmethod, we need to depackage them.
        if is_classmethod or is_staticmethod:
            fn = fn.__func__ 
        @wraps(cast(Callable[..., Any], fn))
        def __wrapper(*args, **kwargs):
            nonlocal synchro
            return synchronize_on.synchronize_on(synchro, timeout, fail_on_timeout, fn, *args, **kwargs)
        # If the original target was a classmethod or staticmethod, we need to re-package them in their appropriate type.
        if is_classmethod:
            __wrapper = classmethod(__wrapper)  # type: ignore
        elif is_staticmethod:
            __wrapper = staticmethod(__wrapper)  # type: ignore
    else:
        @wraps(fn)
        def __wrapper(self, *args, **kwargs):
            return synchronize_on.synchronize_on(self, timeout, fail_on_timeout, fn, self, *args, **kwargs)
    return __wrapper

