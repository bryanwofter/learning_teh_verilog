from trc_packages.core.ui import _supports_synchronized as supports_synchronized, errors
from typing import Callable, TypeVar
R = TypeVar('R')


def synchronize_on(synchro: supports_synchronized.SupportsSynchronized, timeout: int, fail_on_timeout: bool, fn: Callable[..., R], *args, **kwargs) -> R:
    """
    Attempts to take a lock on the provided synchro object, waiting the given timeout period.

    If the lock is successfully taken, then fn will be invoked with the given arguments and its result will be returned. If the lock can't be taken,
    a LockTimeoutError will be raised.
    :param synchro: The SupportsSynchronized instance to use for locking.
    :param timeout: The amount of time to wait before giving up on taking the lock.
    :param fail_on_timeout: True if an exception should be raised if the timeout period passes, otherwise False.
    :param fn: The function to invoke if the lock is successfully taken.
    """
    with synchro.synchronized(timeout=timeout, fail_on_timeout=fail_on_timeout) as lock_taken:
        if 'fail_on_timeout' in kwargs:
            del kwargs['fail_on_timeout']
        if lock_taken:
            return fn(*args, **kwargs)
        else:
            raise errors.LockTimeoutError()

