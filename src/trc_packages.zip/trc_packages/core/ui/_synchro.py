from trc_packages.core.ui import _supports_synchronized as supports_synchronized


class Synchro(supports_synchronized.SupportsSynchronized):
    """
    Provides a SupportsSynchronized implementation that can be used when a class itself doesn't inherit from SupportsSynchronized.
    """

