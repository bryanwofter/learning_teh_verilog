from PyQt5 import uic, QtWidgets  # type: ignore
from PyQt5.QtCore import QObject, Qt, pyqtSignal, pyqtBoundSignal
from PyQt5.QtGui import QWindow
from PyQt5.QtWidgets import QWidget, QLayout, QTreeWidget, QTreeWidgetItem
from os import path
from trc_packages.asynclib import protocols
from trc_packages.core import types as t
from trc_packages import core
from typing import Any, Callable, List, Tuple, cast, Optional, overload, Union, Type, TypeVar
TWidget = TypeVar('TWidget', bound='QWidget')
FormTypes = Tuple[Any, Any]
_PERCENT_FORMAT: str = '%p%'


@overload
def set_progress_text(progress: QtWidgets.QProgressBar, text: str, *, prepend_percent: bool=False, append_percent: bool=False) -> None:
    ...


@overload
def set_progress_text(progress: 'core.ui._loading_progress_dialog.LoadingProgressDialog', text: str, *, prepend_percent: bool=False,
                      append_percent: bool=False) -> None:
    ...


def set_progress_text(progress, text: str, *, prepend_percent: bool=False, append_percent: bool=False) -> None:
    """
    Sets the progress text of the provided progress bar along with the optional format for the percentage.
    :param progress: The progress bar to update the text of.
    :param text: The text to set the progress bar's text to.
    :param format: The formatting of the text.
    """
    formatted_text: List[str] = [text]

    if prepend_percent:
        formatted_text.insert(0, _PERCENT_FORMAT)
    elif append_percent:
        formatted_text.append(_PERCENT_FORMAT)

    if isinstance(progress, core.ui._loading_progress_dialog.LoadingProgressDialog):
        progress = progress.progress

    progress.setFormat(" ".join(formatted_text))
    progress.update()


def connect_slots_by_name(q_object: QObject) -> None:
    """
    Provides a python implementation for QMetaObject.connectSlotsByName that works on QObject instances that are *not* the parent of their
    controls.
    :param q_object: The QObject that is having its slots connected to its children.
    """
    properties: List[str] = [k for k in q_object.__dict__.keys()]
    properties.extend(type(q_object).__dict__.keys())
    for name in properties:
        name_parts: List[str] = name.split('_')
        if name_parts.pop(0) == 'on':
            value: Optional[Callable] = getattr(q_object, name)
            if callable(value):
                signal_name: str = name_parts.pop()
                field_name: str = "_".join(name_parts)
                if hasattr(q_object, field_name):
                    field: Optional[QObject] = getattr(q_object, field_name)
                    if isinstance(field, QObject) and hasattr(field, signal_name):
                        signal: Optional[pyqtSignal] = getattr(field, signal_name)
                        if isinstance(signal, pyqtSignal) or isinstance(signal, pyqtBoundSignal):
                            signal.connect(value)


def safe_disconnect(signal: Any, slot: Optional[Any]=None) -> None:
    """
    Attempts to safely disconnect the provided signal.
    :param signal: The signal to disconnect.
    :param slot: The optional slot to disconnect.
    """
    try:
        if slot is None:
            signal.disconnect()
        else:
            signal.disconnect(slot)
    except:
        pass


def get_window(q_object: Optional[QObject]) -> Optional[QWindow]:
    """
    Attempts to find the window of the provided QObject. If no window is found, None is returned.
    :param q_object: The QObject to find the QWindow of.
    """
    while q_object is not None and not q_object.isWindowType():
        q_object = q_object.parent()
    return cast(Optional[QWindow], q_object)


def get_parent(q_object: Optional[QObject], q_widget_type: Type[TWidget]) -> Optional[TWidget]:
    """
    Attempts to find a parent of the provided QObject that is of the provided type. If no parent is found, None is returned.
    :param q_object: The QObject to find the parent of.
    :param q_widget_type: The QWidget type to find.
    """
    while q_object is not None and not isinstance(q_object, q_widget_type):
        q_object = q_object.parent()
    return cast(Optional[TWidget], q_object)


def load_dirname_ui_type(dirname_source: str, file: str) -> FormTypes:
    """
    Simplifies the uic.loadUiType(os.path.join(path.dirname())) call.
    :param dirname_source: The value of __file__ in the module the UI type is being loaded in.
    :param file: The name of the .ui file.
    """
    return uic.loadUiType(path.join(path.dirname(dirname_source), file))


def set_layout_alignment(widget: QWidget, alignment: Qt.Alignment) -> bool:
    """
    Attempts to set the layout alignment of the given widget, returning True if the alignment is updated, otherwise false.
    :param widget: The widget to update the alignment of.
    :param alignment: The alignment to apply.
    """
    parent: QObject = widget.parent()
    if parent is not None and hasattr(parent, 'layout'):
        layout: QLayout = parent.layout()  # type: ignore
        if layout is not None:
            return layout.setAlignment(widget, alignment)
    return False


def shift_widget(parent: QWidget, child: QWidget, amount: int) -> int:
    """
    Shifts the provided widget to the new position based off of the amount provided.
    :param parent: The parent widget that the item is being moved within.
    :param child: The child widget that is being moved.
    :param amount: The amount to move the child widget.
    """
    layout: QLayout = parent.layout()
    index: int = layout.indexOf(child)
    new_index: int = __adjust_index(index, amount, layout.count())
    layout.removeWidget(child)
    layout.insertWidget(new_index, child)  # type: ignore
    return new_index


def shift_tree_item(parent: QTreeWidget, child: QTreeWidgetItem, amount: int) -> int:
    """
    Shifts the provided tree item to the new position based off of the amount provided.
    :param parent: The parent widget that the item is being moved within.
    :param child: The child widget that is being moved.
    :param amount: The amount to move the child widget.
    """
    parent_item: Union[QTreeWidget, QTreeWidgetItem] = __tree_item_parent(child)
    index: int = __index_of_tree_item(parent_item, child)
    count: int = __tree_item_count(parent_item)
    new_index: int = __adjust_index(index, amount, count)
    __insert_tree_item(parent, new_index, __take_tree_item(parent_item, index))
    return new_index


def __adjust_index(index: int, amount: int, count: int) -> int:
    return min(max(0, index + amount), count - 1)


def __tree_item_parent(item: QTreeWidgetItem) -> Union[QTreeWidget, QTreeWidgetItem]:
    return item.treeWidget() if item.parent() is None else item.parent()


def __index_of_tree_item(parent: Union[QTreeWidget, QTreeWidgetItem], item: QTreeWidgetItem) -> int:
    return parent.indexOfTopLevelItem(item) if isinstance(parent, QTreeWidget) else parent.indexOfChild(item)


def __tree_item_count(parent: Union[QTreeWidget, QTreeWidgetItem]) -> int:
    return parent.topLevelItemCount() if isinstance(parent, QTreeWidget) else parent.childCount()


def __take_tree_item(parent: Union[QTreeWidget, QTreeWidgetItem], index: int) -> QTreeWidgetItem:
    return parent.takeTopLevelItem(index) if isinstance(parent, QTreeWidget) else parent.takeChild(index)


def __insert_tree_item(parent: Union[QTreeWidget, QTreeWidgetItem], index: int, child: QTreeWidgetItem) -> None:
    if isinstance(parent, QTreeWidget):
        parent.insertTopLevelItem(index, child)
    else:
        parent.insertChild(index, child)

