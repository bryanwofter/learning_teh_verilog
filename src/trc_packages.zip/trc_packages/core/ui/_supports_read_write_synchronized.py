from PyQt5 import QtCore
from trc_packages.asynclib import _trc_thread_storage as ts
from trc_packages.core.ui import _contextmanagers as contextmanagers
from typing import Any, Optional


class SupportsReadWriteSynchronized:
    """
    Declares a class provides a locking mechanism through the read_synchronized and write_synchronized methods.
    """

    lock_taken: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='lockTaken')
    lock_released: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='lockReleased')
    read_lock_taken: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='readLockTaken')
    read_lock_released: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='readLockReleasd')
    write_lock_taken: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='writeLockTaken')
    write_lock_released: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='writeLockReleased')

    _lock: QtCore.QReadWriteLock = None

    _lock_manager: ts.TrcThreadStorage['contextmanagers.ReadWriteLockManager'] = ts.TrcThreadStorage('_SupportsReadWriteSynchronized__lock_manager')

    def __new__(cls, *args: Any, **kwargs: Any) -> Any:
        """Initializes the inheritor of this type's lock."""
        inst = super().__new__(cls)
        if inst._lock is None:
            inst._lock = QtCore.QReadWriteLock()
        return inst

    def read_synchronized(self, *, timeout: int=1000, fail_on_timeout: bool=False) -> 'contextmanagers.ReadWriteLockManager':
        """
        Takes a read lock on this lock provider.
        :param timeout: The optional timeout period for taking the lock.
        :param fail_on_timeout: True if timeouts should raise an exception, otherwise False.
        """
        if self._lock_manager is None or not self._lock_manager.has_lock:
            self._lock_manager = self.__setup_lock_manager(contextmanagers.take_read_lock(self._lock, timeout, fail_on_timeout))
        return self._lock_manager

    def upgradeable_synchronized(self, *, timeout: int=1000, fail_on_timeout: bool=False) -> 'contextmanagers.ReadWriteLockManager':
        """
        Takes an upgradeable read lock on this lock provider.
        :param timeout: The optional timeout period for taking the lock.
        :param fail_on_timeout: True if timeouts should raise an exception, otherwise False.
        """
        if self._lock_manager is None or not self._lock_manager.has_lock:
            self._lock_manager = self.__setup_lock_manager(contextmanagers.take_upgradeable_lock(self._lock, timeout, fail_on_timeout))
        elif self._lock_manager.is_read:
            raise Exception()  # TODO: Implement real exception
        return self._lock_manager

    def write_synchronized(self, *, timeout: int=1000, fail_on_timeout: bool=False) -> 'contextmanagers.ReadWriteLockManager':
        """
        Takes a write lock on this lock provider. If a read lock is already taken, the read lock will be released and the write lock will be attempted.
        :param timeout: The optional timeout period for taking the lock.
        :param fail_on_timeout: True if timeouts should raise an exception, otherwise False.
        """
        if self._lock_manager is None or not self._lock_manager.has_lock:
            self._lock_manager = self.__setup_lock_manager(contextmanagers.take_write_lock(self._lock, timeout, fail_on_timeout))
        elif not self._lock_manager.has_write_lock:
            raise Exception()  # TODO: Implement real exception
        return self._lock_manager

    def __setup_lock_manager(self, lock_manager: 'contextmanagers.ReadWriteLockManager') -> 'contextmanagers.ReadWriteLockManager':
        """
        Prepares the supplied lock manager.
        :param lock_manager: The lock manager to prepare.
        """
        q_object: Optional[QtCore.QObject] = self if isinstance(self, QtCore.QObject) else None
        lock_manager.setParent(q_object)
        lock_manager.lock_taken.connect(self.__emit_lock_taken)
        lock_manager.lock_released.connect(self.__emit_lock_released)
        lock_manager.read_lock_taken.connect(self.__emit_read_lock_taken)
        lock_manager.read_lock_released.connect(self.__emit_read_lock_released)
        lock_manager.write_lock_taken.connect(self.__emit_write_lock_taken)
        lock_manager.write_lock_released.connect(self.__emit_write_lock_released)
        return lock_manager
        
    def __emit_lock_taken(self) -> None:
        if isinstance(self, QtCore.QObject):
            self.lock_taken.emit()

    def __emit_lock_released(self) -> None:
        if isinstance(self, QtCore.QObject):
            self.lock_released.emit()

    def __emit_read_lock_taken(self) -> None:
        if isinstance(self, QtCore.QObject):
            self.read_lock_taken.emit()

    def __emit_read_lock_released(self) -> None:
        if isinstance(self, QtCore.QObject):
            self.read_lock_released.emit()

    def __emit_write_lock_taken(self) -> None:
        if isinstance(self, QtCore.QObject):
            self.write_lock_taken.emit()

    def __emit_write_lock_released(self) -> None:
        if isinstance(self, QtCore.QObject):
            self.write_lock_released.emit()

