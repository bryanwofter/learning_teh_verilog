from abc import abstractmethod


class CommitableUi:
    """Provides the base methods needed to implement a UI that can commit or discard its changes."""

    @property
    @abstractmethod
    def is_valid(self) -> bool:
        """
        Determines if the changes made to the UI are considered valid. The result of this
        method should be produced by the validate_changes() method.
        """
        return True

    def try_commit_changes(self) -> bool:
        """
        Attempts to commit all changes in this UI and its sub UIs. This only ensures that
        is_valid returns True. This method should not be overridden.
        """
        self.validate_changes()
        if self.is_valid:
            self.commit_changes()
            return True
        else:
            return False

    @abstractmethod
    def commit_changes(self) -> None:
        """Commits all changes in this UI and its sub UIs."""
        ...

    @abstractmethod
    def rollback_changes(self) -> None:
        """Rolls back all changes in this UI and its sub UIs."""
        ...

    @abstractmethod
    def validate_changes(self) -> None:
        """Populates any validation messages of the UI."""
        ...

