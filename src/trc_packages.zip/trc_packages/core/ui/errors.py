class TrcUiException(Exception):
    """
    A base exception for all UI errors.
    """

class LockUpgradeNotAllowedError(TrcUiException):
    """
    Raised if a lock couldn't be taken due to upgrade being called on a non-upgradeable lock.
    """


class LockDowngradeNotAllowedError(TrcUiException):
    """
    Raised if a lock couldn't be downgraded due to the lock being a non-upgradeable lock.
    """


class LockRestorationFailedError(TrcUiException):
    """
    Raised if non-throwing upgradeable lock couldn't take a write lock and couldn't restore its read lock.
    """


class LockTimeoutError(TrcUiException):
    """
    Raised if a lock couldn't be taken within the given timeout period.
    """


class SignalBlockFailedError(TrcUiException):
    """
    Raised if a signal couldn't be blocked on a control.
    """

