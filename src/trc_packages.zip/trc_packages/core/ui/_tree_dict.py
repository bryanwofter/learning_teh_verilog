"""
Provides a relatively easy way to work with QtWidgets.QTreeWidget and QtWidgets.QTreeWidgetItem instances so that they behave
like standard dictionaries.

Example code:
`
from PyQt5 import QtWidgets
from trc_packages.core import errors
from trc_packages.core.ui import treedataitem, TreeDict, treedict, treedictitem, treelistitem

widget: QtWidgets.QTreeWidget = QtWidgets.QTreeWidget()
widget.show()
tree: TreeDict = treedict(widget)

# Add an item to the root of the tree - String should be a unique identifier
tree['item'] = treedataitem()
tree['item'].text = 'My Item'
tree['item'].data = 100

# treedataitem instances can't have children added to them - They are useful for items that only represent data values
try:
    tree['item']['test'] = treedataitem()
except errors.ItemAccessOnDataOnlyTreeNodeError:
    print('A data item cannot have child nodes')

# Use a treedictitem to have string-keyed inner nodes - It acts nearly the same as TreeDict.
tree['item2'] = treedictitem()
tree['item2'].text = 'My Second Item'
tree['item2']['inner_item'] = treedataitem()
tree['item2']['inner_item'].text = 'My Child Item'

# Use a treelistitem to have int-keyed inner nodes - This is most useful if there are no unique keys for the items.
tree['item2']['inner_item2'] = treelistitem()
tree['item2']['inner_item2'].text = 'My Nested List Child Item'
tree['item2']['inner_item2'].append(treedataitem())
tree['item2']['inner_item2'][0].text = 'My Child Item at Index 1'

# All nodes can have a data value, not just the treedataitem
tree['item2'].data = 'Some data'
print(tree['item2'].data)

# Deleting items is as simple as a dictionary delete
del tree['item']

# Deleting the parent from an item removes it from that parent
del tree['item2']['inner_item2'][0].parent

# Attempting to reuse an existing node before its removed is an error
try:
    tree['item'] = tree['item2']['inner_item']
except errors.ReuseOfAttachedTreeNodeError:
    print('Node is already attached to a parent')
`
"""

from typing import Any, cast, Dict, List, Generic, Iterable, Iterator, Tuple, Type, TypeVar, Optional, overload, Union
from PyQt5 import QtWidgets
from PyQt5.QtCore import Qt
from trc_packages import core
from trc_packages.core.ui import _supports_synchronized as s
import abc
import weakref
TKey = TypeVar('TKey')
NodeWidget = Union[QtWidgets.QTreeWidget, QtWidgets.QTreeWidgetItem]


class TreeNode(s.SupportsSynchronized, Generic[TKey], abc.ABC):
    """Represents a general purpose node within a TreeDict."""

    _key: TKey
    _container: Optional[Union[List['TreeNode'], Dict[TKey, 'TreeNode']]] = None
    _parent: Optional[weakref.ReferenceType] = None
    _widget: NodeWidget = None
    _data: Optional[Any] = None

    @property
    def tree_widget(self) -> Optional[QtWidgets.QTreeWidget]:
        parent: Optional[TreeNode] = self.parent
        return cast(Optional[QtWidgets.QTreeWidget], self._widget) if parent is None else parent.tree_widget

    @property
    def parent(self) -> Optional['TreeNode']:
        return None if self._parent is None else self._parent()

    @parent.setter
    def parent(self, parent: Optional['TreeNode']) -> None:
        if self.parent is None:
            self._parent = None if parent is None else weakref.ref(parent)
        else:
            raise core.errors.ReuseOfAttachedTreeNodeError()

    @parent.deleter
    def parent(self) -> None:
        if self.parent is not None:
            if isinstance(self.parent._container, list):
                for i in range(0, len(self.parent._container)):  # type: int
                    if self == self.parent._container[i]:
                        del self.parent[i]
                        return
            else:
                del self.parent[self._key]

    @property
    def data(self) -> Any:
        if isinstance(self._widget, QtWidgets.QTreeWidget):
            return None
        else:
            return self._data or self._widget.data(0, Qt.UserRole)

    @data.setter
    def data(self, value: Any) -> None:
        if isinstance(self._widget, QtWidgets.QTreeWidgetItem):
            self._data = value
            self._widget.setData(0, Qt.UserRole, value)

    @data.deleter
    def data(self) -> None:
        if isinstance(self._widget, QtWidgets.QTreeWidgetItem):
            self.data = None

    @property
    def text(self) -> Optional[str]:
        if isinstance(self._widget, QtWidgets.QTreeWidget):
            return None
        else:
            return self._widget.text(0)

    @text.setter
    def text(self, value: Optional[str]) -> None:
        if isinstance(self._widget, QtWidgets.QTreeWidgetItem):
            self._widget.setText(0, cast(str, value))

    @text.deleter
    def text(self) -> None:
        if isinstance(self._widget, QtWidgets.QTreeWidgetItem):
            self.text = None

    def set_text(self, column: int, text: str) -> None:
        """
        """
        self._widget.setText(column, text)  # type: ignore

    def get_text(self, column: int) -> str:
        return self._widget.text(column)  # type: ignore

    @abc.abstractmethod
    def __delitem__(self, key: TKey) -> None:
        """
        Deletes an item from this TreeNode.
        :param key: The key to delete.
        """
        ...

    @abc.abstractmethod
    def __getitem__(self, key: TKey) -> 'TreeNode':
        """
        Gets an item from this TreeNode.
        :param key: The key to get.
        """
        ...

    @abc.abstractmethod
    def __setitem__(self, key: TKey, value: 'TreeNode') -> None:
        self._insert_item(key, value, True)

    def _insert_item(self, key: TKey, value: 'TreeNode', overwrite: bool) -> None:
        """
        Sets an item in this TreeNode.
        :param key: The key to set.
        :param value: The value to set.
        :param overwrite: True if this is a set instead of an insert, otherwise False.
        """
        # Overwrite is only an option on list based items.
        overwrite = overwrite or not isinstance(self._container, list)
        if value._parent is not None:
            # Attempted to reuse an already in use node. ERROR. ERROR.
            raise core.errors.ReuseOfAttachedTreeNodeError()
        elif self._container is None:
            raise core.errors.ItemAccessOnDataOnlyTreeNodeError()

        index: int = -1
        data: Any = None
        text: Optional[str] = None

        if key in self._container and overwrite:
            # If the element already exists, we need to remove it. Inline replacements aren't doable.
            child_widget: QtWidgets.QTreeWidgetItem = cast(QtWidgets.QTreeWidgetItem, self[key]._widget)
            if isinstance(self._widget, QtWidgets.QTreeWidget):
                index = self._widget.indexOfTopLevelItem(child_widget)
            else:
                index = self._widget.indexOfChild(child_widget)
            data = self[key].data
            text = self[key].text
            del self[key]

        # Create a new tree node that wraps a widget item.
        child_widget = QtWidgets.QTreeWidgetItem()
        if isinstance(self._container, list) and isinstance(key, int):
            if len(self._container) > key:
                index = key
        if -1 == index:
            self._add_child(child_widget)
        else:
            self._insert_child(index, child_widget)

        # Populate the container.
        value._key = key
        value._widget = child_widget
        value.parent = self
        value.data = data
        value.text = text

        if isinstance(self._container, list) and len(self._container) == key:
            self._container.append(value)
        elif overwrite:
            self._container[key] = value  # type: ignore
        else:
            self._container.insert(key, value)  # type: ignore

    def __iter__(self) -> Iterator:
        if self._container is None:
            raise core.errors.ItemAccessOnDataOnlyTreeNodeError()
        return iter(self._container)

    def __len__(self) -> int:
        if self._container is None:
            raise core.errors.ItemAccessOnDataOnlyTreeNodeError()
        return len(self._container)

    @abc.abstractmethod
    def clear(self) -> None:
        if self._container is None:
            raise core.errors.ItemAccessOnDataOnlyTreeNodeError()
        self._container.clear()

    def expand(self) -> None:
        if isinstance(self._widget, QtWidgets.QTreeWidgetItem):
            self._widget.setExpanded(True)

    def collapse(self) -> None:
        if isinstance(self._widget, QtWidgets.QTreeWidgetItem):
            self._widget.setExpanded(False)

    def toggle_expanded(self) -> None:
        if isinstance(self._widget, QtWidgets.QTreeWidgetItem):
            self._widget.setExpanded(not self._widget.isExpanded())

    def _index_of(self, child_widget: QtWidgets.QTreeWidgetItem) -> int:
        if isinstance(self._widget, QtWidgets.QTreeWidget):
            return self._widget.indexOfTopLevelItem(child_widget)
        else:
            return self._widget.indexOfChild(child_widget)

    def _add_child(self, child_widget: QtWidgets.QTreeWidgetItem) -> None:
        if isinstance(self._widget, QtWidgets.QTreeWidget):
            self._widget.addTopLevelItem(child_widget)
        else:
            self._widget.addChild(child_widget)

    def _insert_child(self, index: int, child_widget: QtWidgets.QTreeWidgetItem) -> None:
        if isinstance(self._widget, QtWidgets.QTreeWidget):
            self._widget.insertTopLevelItem(index, child_widget)
        else:
            self._widget.insertChild(index, child_widget)

    def _remove_child(self, child_widget: QtWidgets.QTreeWidgetItem) -> None:
        if isinstance(self._widget, QtWidgets.QTreeWidget):
            self._widget.takeTopLevelItem(self._widget.indexOfTopLevelItem(child_widget))
        else:
            self._widget.removeChild(child_widget)

    @abc.abstractmethod
    def find_item_by_widget(self, child_widget: QtWidgets.QTreeWidgetItem) -> Optional['TreeNode']:
        """
        Attempts to find an item using the provided widget.
        :param child_widget: The widget to search for the item of.
        """
        return self if self._widget == child_widget else None

    @abc.abstractmethod
    def find_item_by_widget(self, child_widget: QtWidgets.QTreeWidgetItem) -> Optional['TreeNode']:
        """
        Attempts to find an item using the provided widget.
        :param child_widget: The widget to search for the item of.
        """
        return self if self._widget == child_widget else None


class TreeDataItem(TreeNode[None]):

    _container: None

    def __delitem__(self, key: None) -> None:
        raise core.errors.ItemAccessOnDataOnlyTreeNodeError()

    def __getitem__(self, key: None) -> TreeNode:
        raise core.errors.ItemAccessOnDataOnlyTreeNodeError()

    def __setitem__(self, key: None, value: TreeNode) -> None:
        raise core.errors.ItemAccessOnDataOnlyTreeNodeError()

    def clear(self) -> None:
        raise core.errors.ItemAccessOnDataOnlyTreeNodeError()

    def find_item_by_widget(self, child_widget: QtWidgets.QTreeWidgetItem) -> Optional[TreeNode]:
        return super().find_item_by_widget(child_widget)

    def find_item_by_widget(self, child_widget: QtWidgets.QTreeWidgetItem) -> Optional[TreeNode]:
        return super().find_item_by_widget(child_widget)


class TreeDictItem(TreeNode[str]):

    _container: Dict[str, TreeNode]

    def __init__(self) -> None:
        self._container = dict()

    def __delitem__(self, key: str) -> None:
        node: Optional[TreeNode] = self._container.get(key)
        if node is not None:
            self._remove_child(cast(QtWidgets.QTreeWidgetItem, node._widget))
            del self._container[key]
            del node._key

    def __getitem__(self, key: str) -> TreeNode:
        return self._container[key]

    def __setitem__(self, key: str, value: TreeNode) -> None:
        super().__setitem__(key, value)

    def clear(self) -> None:
        values: List[TreeNode] = list(self._container.values())
        for value in values:
            if not isinstance(value, TreeDataItem):
                value.clear()
            del value.parent
        if isinstance(self._widget, QtWidgets.QTreeWidget):
            self._widget.clear()
        super().clear()

    def get(self, key: str, default: Optional[TreeNode]=None):
        return self._container.get(key, default)

    def items(self) -> Any:
        return self._container.items()

    def keys(self) -> Any:
        return self._container.keys()

    def update(self, other: Optional[Dict[str, TreeNode]]=None, **kwargs: TreeNode):
        if other is None:
            other = kwargs
        for key, value in other.items():
            self[key] = value

    def values(self):
        return self._container.values()

    def find_item_by_widget(self, child_widget: QtWidgets.QTreeWidgetItem) -> Optional['TreeNode']:
        result: Optional['TreeNode'] = super().find_item_by_widget(child_widget)
        if result is None:
            for value in self.values():
                result = value.find_item_by_widget(child_widget)
                if result is not None:
                    break
        return result


class TreeListItem(TreeNode[int]):

    _container: List[TreeNode]

    def __init__(self) -> None:
        self._container = list()

    def __delitem__(self, key: int) -> None:
        if len(self) > key:
            node: TreeNode = self._container[key]
            self._remove_child(cast(QtWidgets.QTreeWidgetItem, node._widget))
            del self._container[key]
            del node._key

    def __getitem__(self, key: int) -> TreeNode:
        return self._container[key]

    def __setitem__(self, key: int, value: TreeNode) -> None:
        super().__setitem__(key, value)

    def append(self, value: TreeNode) -> None:
        self[len(self)] = value

    def clear(self) -> None:
        values: List[TreeNode] = list(self._container)
        for value in values:
            if not isinstance(value, TreeDataItem):
                value.clear()
            del value.parent
        if isinstance(self._widget, QtWidgets.QTreeWidget):
            self._widget.clear()
        super().clear()

    def extend(self, other: Iterable[TreeNode]) -> None:
        for value in other:
            self.append(value)

    def remove(self, value: TreeNode) -> None:
        if value.parent == self:
            del value.parent
        else:
            raise core.errors.DeletionOfNonChildNodeError()

    def insert(self, key: int, value: TreeNode) -> None:
        """
        Inserts the value into the given list index.
        :param key: The list index to insert the value into.
        :param value: The value to insert.
        """
        self._insert_item(key, value, False)

    def find_item_by_widget(self, child_widget: QtWidgets.QTreeWidgetItem) -> Optional['TreeNode']:
        result: Optional['TreeNode'] = super().find_item_by_widget(child_widget)
        if result is None:
            for value in self:
                result = value.find_item_by_widget(child_widget)
                if result is not None:
                    break
        return result

    def find_item_by_widget(self, child_widget: QtWidgets.QTreeWidgetItem) -> Optional['TreeNode']:
        result: Optional['TreeNode'] = super().find_item_by_widget(child_widget)
        if result is None:
            for value in self:
                result = value.find_item_by_widget(child_widget)
                if result is not None:
                    break
        return result


class TreeDict(TreeDictItem):

    # Raw trees do not support parent access.
    @property
    def parent(self) -> None: return None

    @parent.setter
    def parent(self, value: None) -> None: pass

    @parent.deleter
    def parent(self) -> None: pass

    @property
    def columns(self) -> int:
        return self._widget.columnCount()

    @columns.setter
    def columns(self, columns: int) -> None:
        self._widget.setColumnCount(columns)  # type: ignore

    @columns.deleter
    def columns(self) -> None:
        self.columns = 1

    _current_item: Optional[TreeNode] = None
    @property
    def current_item(self) -> Optional[TreeNode]:
        return self._current_item

    @current_item.setter
    def current_item(self, current_item: TreeNode) -> None:
        cast(QtWidgets.QTreeWidget, self._widget).setCurrentItem(cast(QtWidgets.QTreeWidgetItem, current_item._widget))

    @current_item.deleter
    def current_item(self) -> None:
        cast(QtWidgets.QTreeWidget, self._widget).setCurrentItem(cast(QtWidgets.QTreeWidgetItem, None))

    _current_item: Optional[TreeNode] = None
    @property
    def current_item(self) -> Optional[TreeNode]:
        return self._current_item

    @current_item.setter
    def current_item(self, current_item: TreeNode) -> None:
        cast(QtWidgets.QTreeWidget, self._widget).setCurrentItem(cast(QtWidgets.QTreeWidgetItem, current_item._widget))

    @current_item.deleter
    def current_item(self) -> None:
        cast(QtWidgets.QTreeWidget, self._widget).setCurrentItem(None)

    @property
    def current_items(self) -> Iterable[TreeNode]:
        item: QtWidgets.QTreeWidgetItem
        for item in self._widget.selectedItems():
            tree_node: Optional[TreeNode] = self.find_item_by_widget(item)

            if tree_node is not None:
                yield tree_node

    def __init__(self, widget: QtWidgets.QTreeWidget) -> None:
        # Raw trees require there to be a widget in order to function.
        super().__init__()
        self._widget = widget
        widget.currentItemChanged.connect(self.on_current_item_changed)  # type: ignore

    def on_current_item_changed(self, current: QtWidgets.QTreeWidgetItem, previous: QtWidgets.QTreeWidgetItem) -> None:
        """
        Updates the current item based off of the current item selection.
        :param current: The newly selected item.
        :param previous: The previously selected item.
        """
        if current != previous:
            self._current_item = self.find_item_by_widget(current)


def treedict(widget: QtWidgets.QTreeWidget) -> TreeDict:
    return TreeDict(widget)


def treedataitem() -> TreeDataItem:
    return TreeDataItem()


def treedictitem() -> TreeDictItem:
    return TreeDictItem()


def treelistitem() -> TreeListItem:
    return TreeListItem()

