from PyQt5 import QtCore, QtGui, QtWidgets
from trc_packages.core.ui import _functions as f
from typing import Any, cast, Set, Optional
import pkg_resources
NumberKeypadForm: Any
NumberKeypadBase: Any
NumberKeypadForm, NumberKeypadBase = f.load_dirname_ui_type(pkg_resources.resource_filename('trc_packages.resources.core.ui', 'number_keypad.ui'), 'number_keypad.ui')


class NumberKeypad(NumberKeypadBase, NumberKeypadForm):
    """Provides a keypad for entering numeric values more easily."""

    cancel_button_clicked: QtCore.pyqtSignal = QtCore.pyqtSignal([bool], name='cancelButtonClicked')
    save_button_clicked: QtCore.pyqtSignal = QtCore.pyqtSignal([bool], name='saveButtonClicked')
    moved: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='moved')

    _ZERO_POINT: QtCore.QPoint = QtCore.QPoint(0, 0)

    button_0: QtWidgets.QPushButton = None
    button_1: QtWidgets.QPushButton = None
    button_2: QtWidgets.QPushButton = None
    button_3: QtWidgets.QPushButton = None
    button_4: QtWidgets.QPushButton = None
    button_5: QtWidgets.QPushButton = None
    button_6: QtWidgets.QPushButton = None
    button_7: QtWidgets.QPushButton = None
    button_8: QtWidgets.QPushButton = None
    button_9: QtWidgets.QPushButton = None
    cancel_button: QtWidgets.QPushButton = None
    decimal_button: QtWidgets.QPushButton = None
    display: QtWidgets.QLineEdit = None
    remove_button: QtWidgets.QPushButton = None
    save_button: QtWidgets.QPushButton = None

    @property
    def text(self) -> Optional[str]:
        return self.display.text()

    @text.setter
    def text(self, value: Optional[str]) -> None:
        self.display.setText(cast(str, value))

    @text.deleter
    def text(self) -> None:
        self.text = None

    def __init__(self, text: Optional[str] = None, parent: Optional[QtCore.QObject] = None) -> None:
        super().__init__(parent)
        self.setupUi(self)
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint)

        self.text = text
        self.cancel_button.installEventFilter(self)
        self.decimal_button.installEventFilter(self)
        self.display.installEventFilter(self)
        self.remove_button.installEventFilter(self)
        self.save_button.installEventFilter(self)

        for v in range(0, 10):
            self.connect_on_button_clicked(getattr(self, f"button_{v}"), str(v))

    @QtCore.pyqtSlot(bool)
    def on_remove_button_clicked(self) -> None:
        if self.text is not None:
            self.text = self.text[:-1]

    @QtCore.pyqtSlot(bool)
    def on_decimal_button_clicked(self) -> None:
        if self.text is not None:
            self.text += '.'

    def connect_on_button_clicked(self, button: QtWidgets.QPushButton, value: str) -> None:
        @QtCore.pyqtSlot(bool)
        def __on_button_clicked() -> None:
            if self.text is not None:
                self.text += value

        button.clicked.connect(__on_button_clicked)
        button.installEventFilter(self)

    @QtCore.pyqtSlot(bool)
    def on_cancel_button_clicked(self, checked: bool) -> None:
        self.cancel_button_clicked.emit(checked)

    @QtCore.pyqtSlot(bool)
    def on_save_button_clicked(self, checked: bool) -> None:
        self.save_button_clicked.emit(checked)

    def move_to(self, other: QtWidgets.QWidget, new_pos: QtCore.QPoint) -> None:
        """
        Moves this keypad to the given x and y coordinate.
        :param other: The object to place this keypad at.
        :param new_pos: The new position to place this keypad at.
        """
        if not self.within_x_bound(other):
            new_pos.setX(new_pos.x() + other.width() - self.width())

        self.hide()
        self.move(new_pos)
        self.moved.emit()

    def move_onto(self, other: QtWidgets.QWidget) -> None:
        """
        Moves this keypad over top of the provided object.
        :param other: The object to place this keypad over top of.
        """
        self.move_to(other, other.mapToGlobal(self._ZERO_POINT))

    def move_below(self, other: QtWidgets.QWidget) -> None:
        """
        Moves this keypad below the provided object.
        :param other: The object to place this keypad below.
        """
        new_pos: QtCore.QPoint = other.mapToGlobal(self._ZERO_POINT)
        new_pos.setY(new_pos.y() + other.height())
        self.move_to(other, new_pos)

    def move_above(self, other: QtWidgets.QWidget) -> None:
        """
        Moves this keypad above the provided object.
        :param other: The object to place this keypad above.
        """
        new_pos: QtCore.QPoint = other.mapToGlobal(self._ZERO_POINT)
        new_pos.setY(new_pos.y() - self.height())
        self.move_to(other, new_pos)

    def move_near(self, other: QtWidgets.QWidget, move_onto: bool=False) -> None:
        """
        Moves this keypad near the provided object.
        If the provided object has enough room below it on the screen, this is equivalent to calling move_onto() or move_below().
        Otherwise, this is equivalent to calling move_above().
        :param other: The object to place this keypad near.
        :param move_onto: True if the keypad should use move_onto when movement will fall inside of the window, otherwise false to use move_below.
        """
        if self.within_y_bound(other, move_onto):
            if move_onto:
                self.move_onto(other)
            else:
                self.move_below(other)
        else:
            self.move_above(other)

    def within_y_bound(self, other: QtWidgets.QWidget, move_onto: bool=False) -> bool:
        """
        Determines if this keypad is within other's y-bound based off of its window.
        :param other: The QWidget to check the y-bound of.
        :param move_onto: True if the check shouldn't include the height of other, otherwise false.
        """
        window: Optional[QtWidgets.QWidget] = f.get_window(other) or f.get_parent(other, QtWidgets.QDialog)

        if window is None:
            return True
        else:
            window_pos: QtCore.QPoint = window.mapToGlobal(self._ZERO_POINT)
            other_pos: QtCore.QPoint = other.mapToGlobal(self._ZERO_POINT)
            window_y_bound: int = window_pos.y() + window.height()
            self_y_bound: int = self.height() + other_pos.y()

            if not move_onto:
                self_y_bound += other.height()
            return self_y_bound < window_y_bound

    def within_x_bound(self, other: QtWidgets.QWidget) -> bool:
        """
        Determines if this keypad is within the other's x-bound based off of its window.
        :param other: The QWidget to check the x-bound of.
        """
        window: Optional[QtWidgets.QWidget] = f.get_window(other) or f.get_parent(other, QtWidgets.QDialog)

        if window is None:
            return True
        else:
            window_pos: QtCore.QPoint = window.mapToGlobal(self._ZERO_POINT)
            other_pos: QtCore.QPoint = other.mapToGlobal(self._ZERO_POINT)
            window_x_bound: int = window_pos.x() + window.width()
            self_x_bound: int = self.width() + other_pos.x()
            return self_x_bound < window_x_bound

    def showEvent(self, event: QtGui.QShowEvent) -> None:
        """
        Handles the number keypad being shown, setting focus onto the display.
        :param event: The event causing the GUI to be shown.
        """
        self.display.setFocus(QtCore.Qt.OtherFocusReason)
        super().showEvent(event)

    def eventFilter(self, producer: QtCore.QObject, event: QtCore.QEvent) -> bool:
        """
        Filters out the given event if it need not be handled.
        :param producer: The object responsible for the event.
        :param event: The event to filter.
        """
        result: bool = super().eventFilter(producer, event)

        if isinstance(event, QtGui.QFocusEvent) and event.lostFocus():
            children: Set[QtCore.QObject] = {self.button_0, self.button_1, self.button_2,
                                             self.button_3, self.button_4, self.button_5,
                                             self.button_6, self.button_7, self.button_8,
                                             self.button_9, self.cancel_button, self.decimal_button,
                                             self.display, self.remove_button, self.save_button}

            if producer in children and not any(c.hasFocus() for c in children if isinstance(c, QtWidgets.QWidget)):
                self.cancel_button_clicked.emit(False)

        return result

