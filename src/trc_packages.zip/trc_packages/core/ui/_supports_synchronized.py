from PyQt5 import QtCore
from trc_packages.core.ui import _contextmanagers as contextmanagers
from typing import Any


class SupportsSynchronized:
    """
    Declares a class provides a locking mechanism through the take_lock method.
    """

    _lock: QtCore.QMutex = None

    def __new__(cls, *args: Any, **kwargs: Any) -> Any:
        """Initializes the inheritor of this type's mutex."""
        inst = super().__new__(cls)
        if inst._lock is None:
            inst._lock = QtCore.QMutex()
        return inst

    def synchronized(self, *, timeout: int=1000, fail_on_timeout: bool=False) -> 'contextmanagers.take_lock':
        """
        Takes a lock on the syncroot of this provider.
        :param timeout: The optional timeout period for taking the lock.
        :param fail_on_timeout: True if timeouts should raise an exception, otherwise False.
        """
        return contextmanagers.take_lock(self._lock, timeout, fail_on_timeout)
