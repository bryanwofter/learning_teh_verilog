from trc_packages.core.ui import _supports_synchronized as support, _synchronized as s
from typing import Any, Dict, Iterable, Mapping, Optional, overload, Tuple, TypeVar, Union
K = TypeVar('K')
V = TypeVar('V')
T = TypeVar('T')


class SyncDict(support.SupportsSynchronized, Dict[K, V]):
    """
    Provides a dictionary that uses a Synchro to allow for safe multi-threaded modification.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)

    @s.synchronized_as(fail_on_timeout=True)
    def __delitem__(self, key: K) -> None:
        super().__delitem__(key)

    @s.synchronized_as(fail_on_timeout=True)
    def __setitem__(self, key: K, value: V) -> None:
        super().__setitem__(key, value)

    @s.synchronized_as(fail_on_timeout=True)
    def clear(self) -> None:
        super().clear()

    @s.synchronized_as(fail_on_timeout=True)
    def pop(self, k: Optional[K]=None, default: Union[V, T]=None) -> Union[V, T]:
        return super().pop(k, default)

    @s.synchronized_as(fail_on_timeout=True)
    def popitem(self) -> Tuple[K, V]:
        return super().popitem()

    @s.synchronized_as(fail_on_timeout=True)
    def setdefault(self, k: K, default: V=None) -> V:
        return super().setdefault(k, default)

    @s.synchronized_as(fail_on_timeout=True)
    def update(self, m: Union[Iterable[Tuple[K, V]], Mapping[K, V]]=None, **kwargs: V) -> None:  # type: ignore
        if m is None:
            super().update(**kwargs)
        else:
            super().update(m, **kwargs)

