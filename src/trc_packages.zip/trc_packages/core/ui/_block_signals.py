from PyQt5 import QtCore
from trc_packages.core.ui import errors
from typing import ContextManager, Optional, Type, Tuple
from typing_extensions import Literal
from types import TracebackType


class block_signals(ContextManager[Tuple[QtCore.QObject, ...]]):
    """
    Provides a signal blocker for 1 or more QObject instances that is controlled using a with statement.
    When using block_signals, manual calls to blockSignals should be avoided within the with statement.
    """

    q_objects: Tuple[QtCore.QObject, ...] = None
    signals_blocked: bool = False

    def __init__(self, *q_objects: QtCore.QObject) -> None:
        self.q_objects = q_objects

    def __enter__(self) -> Tuple[QtCore.QObject, ...]:
        """Enters into this context manager, setting all QObject instances to blocked."""
        if not self.signals_blocked:
            q_object: QtCore.QObject
            for q_object in self.q_objects:
                if not (q_object.blockSignals(True) or q_object.signalsBlocked()):
                    raise errors.SignalBlockFailedError()
            self.signals_blocked = True

        # Make a safety copy of the tuple to prevent improper modifications.
        return tuple(self.q_objects)

    def __exit__(self, exc_type: Optional[Type[BaseException]], exc: Optional[BaseException], tb: Optional[TracebackType]) -> Literal[False]:
        """
        Exits from this context manager, setting all QObjects to unblocked.
        :param exc_type: The type of exception raised, if any.
        :param exc: The exception raised, if any.
        :param tb: The traceback of the exception raised, if any.
        """
        if self.signals_blocked:
            q_object: QtCore.QObject
            for q_object in self.q_objects:
                q_object.blockSignals(False)
            self.signals_blocked = False
        return False

