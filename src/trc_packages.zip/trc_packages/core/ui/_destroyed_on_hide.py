from PyQt5 import QtCore, QtGui
from trc_packages.core.ui import _functions as f
from trc_packages.decorators._deprecated import deprecated


class DestroyedOnHide:
    """Provides a method for destroying a QWidget as soon as its accepted for hiding."""

    hidden: QtCore.pyqtSignal = QtCore.pyqtSignal([])

    def hideEvent(self, event: QtGui.QHideEvent) -> None:
        """
        Destroys the UI if the hide event is consumed by the super call.
        :param event: The event triggering the hide.
        """
        super().hideEvent(event)  # type: ignore
        if event.isAccepted():
            self.hidden.emit()
            f.safe_disconnect(self.hidden)
            self.destroy()  # type: ignore

