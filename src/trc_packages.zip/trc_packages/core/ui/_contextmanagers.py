from enum import auto, Enum, unique
from PyQt5 import QtCore
from trc_packages.core.ui import errors as errors
from types import TracebackType
from typing import Any, ContextManager, Generic, Optional, Type, TypeVar
try: from typing import Literal  # type: ignore
except: from typing_extensions import Literal


class take_lock(ContextManager[bool]):
    """
    Provides a locking mechanism for QMutex objects with a timeout.
    True will be returned by __enter__ if the lock is successfully entered, otherwise False.
    """
    mutex: QtCore.QMutex
    timeout: int
    fail_on_timeout: bool = False
    has_lock: bool = False

    def __init__(self, mutex: QtCore.QMutex, timeout: int=1000, fail_on_timeout: bool=False) -> None:
        self.mutex = mutex
        self.timeout = timeout
        self.fail_on_timeout = fail_on_timeout

    def __enter__(self) -> bool:
        if not self.has_lock:
            self.has_lock = self.mutex.tryLock(self.timeout)
        if not self.has_lock and self.fail_on_timeout:
            errors.LockTimeoutError()
        return self.has_lock

    def __exit__(self, exc_type: Optional[Type[BaseException]], exc: Optional[BaseException], tb: Optional[TracebackType]) -> Literal[False]:
        if self.has_lock:
            self.has_lock = False
            self.mutex.unlock()
        return False


def take_read_lock(lock: QtCore.QReadWriteLock, timeout: int=1000, fail_on_timeout: bool=False) -> 'ReadWriteLockManager': 
    """
    Provides a read locking mechanism for QReadWriteLock objects with a timeout.
    :param lock: The lock that will be taken by the with statement.
    :param timeout: The amount of time to wait before erroring.
    :fail_on_timeout: True if an error should be raised if the lock times out, otherwise False.
    """
    return ReadWriteLockManager(ReadWriteLockManager.LockType.READ, lock, timeout, fail_on_timeout)


def take_upgradeable_lock(lock: QtCore.QReadWriteLock, timeout: int=1000, fail_on_timeout: bool=False) -> 'ReadWriteLockManager':
    """
    Provides an upgradeable read locking mechanism for QReadWriteLock objects with a timeout.
    :param lock: The lock that will be taken by the with statement.
    :param timeout: The amount of time to wait before erroring.
    :fail_on_timeout: True if an error should be raised if the lock times out, otherwise False.
    """
    return ReadWriteLockManager(ReadWriteLockManager.LockType.UPGRADEABLE, lock, timeout, fail_on_timeout)


def take_write_lock(lock: QtCore.QReadWriteLock, timeout: int=1000, fail_on_timeout: bool=False) -> 'ReadWriteLockManager':
    """
    Provides a read locking mechanism for QReadWriteLock objects with a timeout.
    :param lock: The lock that will be taken by the with statement.
    :param timeout: The amount of time to wait before erroring.
    :fail_on_timeout: True if an error should be raised if the lock times out, otherwise False.
    """
    return ReadWriteLockManager(ReadWriteLockManager.LockType.WRITE, lock, timeout, fail_on_timeout)


class ReadWriteLockManager(QtCore.QObject):
    """Provides a read/write lock mechanism for QReadWriteLock objects with a timeout."""

    lock_taken: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='lockTaken')
    lock_released: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='lockReleased')
    read_lock_taken: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='readLockTaken')
    read_lock_released: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='readLockReleasd')
    write_lock_taken: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='writeLockTaken')
    write_lock_released: QtCore.pyqtSignal = QtCore.pyqtSignal([], name='writeLockReleased')

    @unique
    class LockType(Enum):
        """Represents the types of locks that can be taken."""
        READ = auto()
        UPGRADEABLE = auto()
        WRITE = auto()

    read_write_lock: QtCore.QReadWriteLock
    timeout: int = 1000
    fail_on_timeout: bool = False
    lock_type: LockType = LockType.READ
    has_read_lock: bool = False
    has_write_lock: bool = False
    lock_shares: int = 0
    upgrade: Optional['UpgradeManager'] = None

    @property
    def is_read(self) -> bool:
        return self.lock_type is self.LockType.READ

    @property
    def is_upgradeable(self) -> bool:
        return self.lock_type is self.LockType.UPGRADEABLE

    @property
    def is_write(self) -> bool:
        return self.lock_type is self.LockType.WRITE

    @property
    def has_lock(self) -> bool:
        return self.has_read_lock or self.has_write_lock

    def __init__(self, lock_type: LockType, read_write_lock: QtCore.QReadWriteLock, timeout: int=1000, fail_on_timeout: bool=False, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)
        self.read_write_lock = read_write_lock
        self.timeout = timeout
        self.fail_on_timeout = fail_on_timeout
        self.lock_type = lock_type
        self.lock_shares = 0
        self.upgrade = UpgradeManager(self)

    def _downgrade(self, timeout: Optional[int]=None) -> None:
        """
        Downgrades this lock, erroring after the given timeout if a read lock cannot be taken.
        This method should not be invoked directly. Instead, the upgrade field should be used to ensure proper functionality of lock upgrading.

        :param timeout: If provided, the amount of time to wait for resuming the read lock. If not provided, the timeout property will be used.
        :raises errors.LockTimeoutError: Raised when taking the read lock times out.
        :raises errors.LockDowngradeNotAllowedError: Raised when attempting to downgrade a LockType.READ lock.
        """
        timeout = self.timeout if timeout is None else timeout

        if self.lock_type is self.LockType.UPGRADEABLE and self.has_lock:
            if self.has_write_lock:
                self.has_write_lock = False
                self.read_write_lock.unlock()
                if self.has_read_lock or self.read_write_lock.tryLockForRead(timeout):
                    self.has_read_lock = True
                    self.read_lock_taken.emit()
                else:
                    raise errors.LockTimeoutError()
        elif self.lock_type is not self.LockType.WRITE:
            raise errors.LockDowngradeNotAllowedError()

    def _upgrade(self, timeout: Optional[int]=None, fail_on_timeout: Optional[bool]=None) -> bool:
        """
        Upgrades this lock, erroring after the given timeout if a write lock cannot be taken.
        This method should not be invoked directly. Instead, the upgrade field should be used to ensure proper functionality of lock upgrading.

        :param timeout: If provided, the amount of time for taking the write lock. If not provided, the timeout property will be used.
        :param fail_on_timeout: If True, an error will be raised if taking the write lock takes longer than the timeout. If False, timeout will be cut in half and a read lock will be attempted.
        :raises errors.LockTimeoutError: Raised when taking the write lock times out.
        :raises errors.LockUpgradeNotAllowedError: Raised when attempting to upgrade a LockType.READ lock.
        :raises errors.LockRestorationFailedError: Raised when restoring the previous read lock fails.
        """
        timeout = self.timeout if timeout is None else timeout
        fail_on_timeout = self.fail_on_timeout if fail_on_timeout is None else fail_on_timeout

        if not fail_on_timeout:
            # If fail_on_timeout is False, we need to cut the timeout in half so that things are stalled for the same amount of time at most.
            timeout //= 2

        if self.lock_type is self.LockType.UPGRADEABLE and self.has_lock:
            if self.has_read_lock:
                self.has_read_lock = False
                self.read_write_lock.unlock()
                if self.has_write_lock or self.read_write_lock.tryLockForWrite(timeout):
                    self.has_write_lock = True
                    self.write_lock_taken.emit()
                elif fail_on_timeout:
                    raise errors.LockTimeoutError()
                elif self.has_read_lock or self.read_write_lock.tryLockForRead(timeout):
                    self.has_read_lock = True
                else:
                    raise errors.LockRestorationFailedError()
        elif self.lock_type is not self.LockType.WRITE:
            raise errors.LockUpgradeNotAllowedError()

        return self.has_write_lock

    def __bool__(self) -> bool:
        """Gets True if this lock has been taken, otherwise False."""
        return self.has_lock

    def __enter__(self) -> 'ReadWriteLockManager':
        """Attempts to enter into this lock through its current lock type."""
        if not self.has_lock:
            if self.lock_type is self.LockType.WRITE:
                self.has_write_lock = self.read_write_lock.tryLockForWrite(self.timeout)
            else:
                self.has_read_lock = self.read_write_lock.tryLockForRead(self.timeout)
            if self.has_lock:
                self.lock_taken.emit()
                if self.has_write_lock:
                    self.write_lock_taken.emit()
                else:
                    self.read_lock_taken.emit()
            elif self.fail_on_timeout:
                raise errors.LockTimeoutError()
        self.lock_shares += 1
        return self

    def __exit__(self, exc_type: Optional[Type[BaseException]], exc: Optional[BaseException], tb: Optional[TracebackType]) -> Literal[False]:
        """
        Attempts to exit this lock.
        :param exc_type: The type of exception that caused the exit, if any.
        :param exc: The exception that caused the exit, if any.
        :param tb: The traceback of the exception that caused the exit, if any.
        """
        if self.has_lock:
            self.lock_shares -= 1
            if 1 > self.lock_shares:
                self.lock_shares = 0
                self.lock_released.emit()
                if self.has_write_lock:
                    self.write_lock_released.emit()
                else:
                    self.read_lock_released.emit()
                self.has_read_lock = self.has_write_lock = False
                self.read_write_lock.unlock()
        return False

class UpgradeManager(QtCore.QObject):
    """Provides an upgrade/downgrade lock mechanism for ReadWriteLockManager when its upgrade method is invoked."""

    has_upgraded_lock: bool = False
    lock_manager: ReadWriteLockManager = None
    upgraded_shares: int = 0
    timeout: Optional[int]=None
    fail_on_timeout: Optional[bool]=None

    def __init__(self, lock_manager: ReadWriteLockManager) -> None:
        self.lock_manager = lock_manager
        self.upgraded_shares = 0

    def __call__(self, *, timeout: Optional[int]=None, fail_on_timeout: Optional[bool]=None) -> 'UpgradeManager':
        """
        Sets the timeout and fail_on_timeout fields of this manager for the duration of this invocation.
        :param timeout: The optional timeout to wait for.
        :param fail_on_timeout: True if an error should be raised on timeout, otherwise False.
        """
        self.timeout = timeout
        self.fail_on_timeout = fail_on_timeout
        return self

    def __enter__(self) -> 'UpgradeManager':
        """Attempts to enter into an upgraded lock through the selected lock_manager."""
        if not self.has_upgraded_lock:
            self.has_upgraded_lock = self.lock_manager._upgrade(self.timeout, self.fail_on_timeout)
        self.upgraded_shares += 1
        return self

    def __exit__(self, exc_type: Optional[Type[BaseException]], exc: Optional[BaseException], tb: Optional[TracebackType]) -> Literal[False]:
        """
        Attempts to exit this lock.
        :param exc_type: The type of exception that caused the exit, if any.
        :param exc: The exception that caused the exit, if any.
        :param tb: The traceback of the exception that caused the exit, if any.
        """
        if self.has_upgraded_lock:
            self.upgraded_shares -= 1
            if 1 > self.upgraded_shares:
                self.upgraded_shares = 0
                self.has_upgraded_lock = False
                self.lock_manager._downgrade()
        return False

    def __bool__(self) -> bool:
        """Returns true if an upgrade is currently held, otherwise False."""
        return self.has_upgraded_lock

