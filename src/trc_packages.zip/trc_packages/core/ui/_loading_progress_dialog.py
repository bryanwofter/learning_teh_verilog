from PyQt5 import QtCore, QtGui, QtWidgets
from trc_packages.core.ui import _functions as f
from typing import Any, cast, Optional
import pkg_resources
LoadingProgressDialogForm: Any
LoadingProgressDialogBase: Any
LoadingProgressDialogForm, LoadingProgressDialogBase = f.load_dirname_ui_type(pkg_resources.resource_filename('trc_packages.resources.core.ui', 'loading_progress_dialog.ui'), 'loading_progress_dialog.ui')


class LoadingProgressDialog(LoadingProgressDialogForm, LoadingProgressDialogBase):
    """Provides a convenience UI for displaying a progress bar."""

    progress: QtWidgets.QProgressBar
    progress_label: QtWidgets.QLabel

    @property
    def text(self) -> Optional[str]:
        return self.progress_label.text()

    @text.setter
    def text(self, value: Optional[str]) -> None:
        self.progress_label.setText(cast(str, value))

    @text.deleter
    def text(self) -> None:
        self.text = None

    @property
    def minimum(self) -> int:
        return self.progress.minimum()

    @minimum.setter
    def minimum(self, value: int) -> None:
        self.progress.setMinimum(value)

    @minimum.deleter
    def minimum(self) -> None:
        self.minimum = 0

    @property
    def maximum(self) -> int:
        return self.progress.maximum()

    @maximum.setter
    def maximum(self, value: int) -> None:
        self.progress.setMaximum(value)

    @maximum.deleter
    def maximum(self) -> None:
        self.maximum = 0

    @property
    def value(self) -> int:
        return self.progress.value()

    @value.setter
    def value(self, value: int) -> None:
        self.progress.setValue(value)

    @value.deleter
    def value(self) -> None:
        self.value = 0

    @property
    def text_visible(self) -> bool:
        return self.progress.isTextVisible()

    @text_visible.setter
    def text_visible(self, value: bool) -> None:
        self.progress.setTextVisible(value)

    @text_visible.deleter
    def text_visible(self) -> None:
        self.text_visible = False

    _prevent_closing: bool = False

    @property
    def prevent_closing(self) -> bool:
        return self._prevent_closing

    @prevent_closing.setter
    def prevent_closing(self, value: bool) -> None:
        self._prevent_closing = value

    @prevent_closing.deleter
    def prevent_closing(self) -> None:
        self._prevent_closing = False

    @property
    def percentage(self) -> float:
        if self.maximum == 0:
            return 0
        else:
            self.value / self.maximum

    @percentage.setter
    def percentage(self, value: float) -> None:
        self.value = round(self.maximum * value)

    @percentage.deleter
    def percentage(self) -> None:
        self.percentage = 0.0

    def __init__(self, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)
        self.setupUi(self)

    def closeEvent(self, event: QtGui.QCloseEvent) -> None:
        """
        Handles the close request of the window.
        :param event: The event to consume.
        """
        if self.prevent_closing:
            event.ignore()
        else:
            super().closeEvent(event)

    def keyPressEvent(self, event: QtGui.QKeyEvent) -> None:
        """
        Handles the escape key of the window.
        :param event: The event to consume.
        """
        if event.key() == QtCore.Qt.Key_Escape and self.prevent_closing:
            event.ignore()
        else:
            super().keyPressEvent(event)

