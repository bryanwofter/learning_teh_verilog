class DeletionOfNonChildNodeError(Exception):
    """Raised when a TreeNode attempts to delete a child that does not belong to them."""


class ReuseOfAttachedTreeNodeError(Exception):
    """Raised when a TreeNode is attached to a new tree while still being attached to another tree."""


class ItemAccessOnDataOnlyTreeNodeError(Exception):
    """Raised when item access is used on a TreeNode that doesn't support items."""

