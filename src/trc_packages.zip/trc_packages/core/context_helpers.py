from types import TracebackType
from typing import Any, cast, ContextManager, List, Optional, Type, TypeVar, Tuple
T = TypeVar('T')


class contexts(ContextManager[Tuple[T, ...]]):
    """
    Provides a handler for multiple contexts. This is a one-time use context and will error if it is used after initialization.

    For some reason, Python3 lacks the nested function that Python2 has. This is meant to be an alternative function.
    """

    _instances: List[ContextManager[T]]

    def __init__(self, *args: ContextManager[Any]) -> None:
        self._instances = [cast(ContextManager, a) for a in args]

    def __enter__(self) -> Tuple[T, ...]:
        return tuple(i.__enter__() for i in self._instances)

    def __exit__(self, exc_type: Optional[Type[BaseException]], exc: Optional[BaseException], tb: Optional[TracebackType]) -> bool:
        ignore_exception: Optional[bool] = None

        for instance in self._instances:
            try:
                ignore_exception = instance.__exit__(exc_type, exc, tb) and (ignore_exception is None or ignore_exception)
            except: pass

        return ignore_exception or False

