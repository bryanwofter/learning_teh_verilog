class ControllerException(Exception):
    """A base exception for all controller errors."""


class ControllerSetupError(ControllerException):
    """Raised whenever a controller has an exception during setup."""


class ControllerBindError(ControllerException):
    """Raised whenever a controller has an exception during bind."""


class ControllerUnbindError(ControllerException):
    """Raised whenever a controller has an exception during unbind."""


class ControllerCommitError(ControllerException):
    """Raised whenever a controller has an exception during commit."""


class ControllerDiscardError(ControllerException):
    """Raised whenever a controller has an exception during discard."""


class ControllerRefreshError(ControllerException):
    """Raised whenever a controller has an exception during refresh."""


class ControllerUninitializedError(ControllerException):
    """Raised whenever a controller is setup but methods requiring setup are invoked."""


class ControllerUnboundError(ControllerException):
    """Raised whenever a controller isn't bound but methods requiring binding are invoked."""


class UnresolvedControllerTypeError(ControllerException):
    """Raised whenever a controller isn't found under a given name and set of directories."""

