from collections.abc import Sequence
from PyQt5 import QtCore, QtWidgets
from typing import FrozenSet, List, Optional
from trc_packages.core import _logging as l, features
from trc_packages.gui import _qt_controller_factory as qcf, errors
from typing_extensions import final


class QtController:
    """
    Provides a common implementation for GUI controllers, including any potential default methods or calls.
    """

    container: QtWidgets.QWidget = None

    # region Controller Factory
    _controller_factory: 'qcf.QtControllerFactory' = None

    @property
    def controller_factory(self) -> 'qcf.QtControllerFactory':
        return self._controller_factory

    @controller_factory.setter
    def controller_factory(self, value: 'qcf.QtControllerFactory') -> None:
        if not self._setup:
            self._controller_factory = value
            child_controller: QtController
            for child_controller in self.child_controllers:
                child_controller.controller_factory = value
    # endregion

    is_bound_changed: QtCore.pyqtSignal = QtCore.pyqtSignal([bool, bool], [], name='isBoundChanged')

    # region Is Bound
    _is_bound: bool = False

    @property
    def is_bound(self) -> bool:
        return self._is_bound

    @is_bound.setter
    def is_bound(self, value: bool) -> None:
        if self._is_bound != value:
            self.is_bound_changed.emit(self._is_bound, value)
            self._is_bound = value
    # endregion

    # region Child Controller Names
    _child_controller_names: FrozenSet[str] = None

    @property
    def child_controller_names(self) -> FrozenSet[str]:
        if self._child_controller_names is None:
            child_controller_names: List[str] = []
            # In order to create child controllers, a type hint is absolutely required.
            for property, type in self.__annotations__.items():
                if property.endswith('_controllers'):
                    if property != 'child_controllers':
                        child_controller_names.append(property)
                elif property.endswith('_controller'):
                    child_controller_names.append(property)
            self._child_controller_names = frozenset(child_controller_names)
        return self._child_controller_names

    @property
    def child_controllers(self) -> List['QtController']:
        children: List['QtController'] = []
        for name in self.child_controller_names:
            child: Optional['QtController'] = getattr(self, name)
            if name.endswith('_controllers'):
                if isinstance(child, dict):
                    children.extend(child.values())
                elif isinstance(child, Sequence):
                    children.extend(child)
            else:
                children.append(child)
        return children
    # endregion

    # region Setup
    _setup: bool = False

    @final
    def setup(self) -> None:
        """
        Invoked to setup the GUI after the QtControllerFactory has completed construction of the controller.
        This is automatically called by QtControllerFactory to ensure all controllers are in a state of useability. Common functionality that doesn't rely on
        data should be handled in this method.
        """
        if not self._setup:
            try:
                self._settingUp()
                self._setup = True
            except Exception as e:
                l.log.exception(f"An error occurred during setup of controller {type(self)}.")
                raise errors.ControllerSetupError() from e

            for child in self.child_controllers:
                if isinstance(child, QtController):
                    child.setup()

    def _settingUp(self) -> None:
        """Invoked by setup after the QtControllerFactory has completed construction of the controller and its children."""
        pass
    # endregion

    # region Bind
    data_binding: QtCore.pyqtSignal = QtCore.pyqtSignal(name='dataBinding')
    data_bound: QtCore.pyqtSignal = QtCore.pyqtSignal(name='dataBound')

    @final
    def bind(self) -> None:
        """
        Invoked by user code to prepare the UI for use, including binding any fields or data and setting up any additional listeners.
        If there are child controllers associated to this controller, they will be bound after this controller is bound.
        """
        if not self._setup:
            raise errors.ControllerUninitializedError()
        if not self.is_bound:
            self.data_binding.emit()

            try:
                self._binding()
                self.is_bound = True
            except Exception as e:
                l.log.exception(f"An error occurred during binding of controller {type(self)}.")
                raise errors.ControllerBindError() from e

            for child in self.child_controllers:
                # Only perform the binding if the child is an actual controller.
                if isinstance(child, QtController):
                    child.bind()

            self.data_bound.emit()

    def _binding(self) -> None:
        """Invoked by the bind method when binding has begun."""
        pass

    data_unbinding: QtCore.pyqtSignal = QtCore.pyqtSignal(name='dataUnbinding')
    data_unbound: QtCore.pyqtSignal = QtCore.pyqtSignal(name='dataUnbound')

    @final
    def unbind(self) -> None:
        """
        Invoked by user code to close the UI after use, including disposing of any fields or data and listeners.
        If there are child controllers associated to this controller, they will be unbound before this controller is unbound.
        """
        self._ensure_initialized_and_bound()
        self.data_unbinding.emit()

        for child in self.child_controllers:
            if isinstance(child, QtController):
                child.unbind()

        try:
            self._unbinding()
            self.is_bound = False
        except Exception as e:
            l.log.exception(f"An error occurred during unbinding of controller {type(self)}.")
            raise errors.ControllerUnbindError() from e

        self.data_unbound.emit()

    def _unbinding(self) -> None:
        """Invoked by the unbind method when closing has begun."""
        pass
    # endregion

    # region Commit
    data_committing: QtCore.pyqtSignal = QtCore.pyqtSignal(name='dataCommitting')
    data_committed: QtCore.pyqtSignal = QtCore.pyqtSignal(name='dataCommitted')

    def commit(self) -> None:
        """
        Commits this controller to its data source.
        If there are child controllers associated to this controller, they will be committed before this controller is committed.
        """
        self._ensure_initialized_and_bound()
        self.data_committing.emit()

        for child in self.child_controllers:
            if isinstance(child, QtController):
                child.commit()

        try:
            self._committing()
        except features.errors.FeatureFailedValidationError as f:
            # We need to re-raise validation errors. Maintaining the stack trace isn't important in this case.
            raise f
        except Exception as e:
            l.log.exception(f"An error occurred during committing of controller {type(self)}.")
            raise errors.ControllerCommitError() from e

        self.data_committed.emit()

    def _committing(self) -> None:
        """Invoked by the commit method when committing has begun."""
        pass

    data_discarding: QtCore.pyqtSignal = QtCore.pyqtSignal(name='dataDiscarding')
    data_discarded: QtCore.pyqtSignal = QtCore.pyqtSignal(name='dataDiscarded')

    def discard(self) -> None:
        """
        Discards all changes applied to this controller.
        If there are any child controllers associated to this controller, they will be discarded after this controller is discarded.
        """
        self._ensure_initialized_and_bound()
        self.data_discarding.emit()

        try:
            self._discarding()
        except Exception as e:
            l.log.exception(f"An error occurred during discarding of controller {type(self)}.")
            raise errors.ControllerDiscardError() from e

        for child in self.child_controllers:
            if isinstance(child, QtController):
                child.discard()

        self.data_discarded.emit()

    def _discarding(self) -> None:
        """Invoked by the discard method when discarding has begun."""
        pass

    data_refreshing: QtCore.pyqtSignal = QtCore.pyqtSignal(name='dataRefreshing')
    data_refreshed: QtCore.pyqtSignal = QtCore.pyqtSignal(name='dataRefreshed')

    def refresh(self) -> None:
        """
        Refreshes the data of this controller.
        If there are any child controllers associated to this controller, they will be refreshed after this controller is refreshed.
        """
        self._ensure_initialized_and_bound()
        self.data_refreshing.emit()

        try:
            self._refreshing()
        except Exception as e:
            l.log.exception(f"An error occurred during refreshing of controller {type(self)}.")
            raise errors.ControllerRefreshError() from e

        for child in self.child_controllers:
            if isinstance(child, QtController):
                child.refresh()

        self.data_refreshed.emit()

    def _refreshing(self) -> None:
        """Invoked by the refresh method when refreshing has begun."""
        pass
    # endregion

    def _ensure_initialized_and_bound(self) -> None:
        """Raises a ControllerUninitializedError or ControllerUnboundError whenever initialization/binding is expected but not encountered."""
        if not self._setup:
            raise errors.ControllerUninitializedError()
        elif not self.is_bound:
            raise errors.ControllerUnboundError()

