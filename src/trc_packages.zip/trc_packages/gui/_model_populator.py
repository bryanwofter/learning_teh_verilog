from PyQt5 import QtCore, QtWidgets
from trc_packages.core import safecasts
from trc_packages.gui import _model_property as mp
from trc_packages.core.ui import _supports_read_write_synchronized as srws
from typing import Any, Callable, Dict, List, Generic, Iterable, Optional, Set, Type, TypeVar, Tuple
_T = TypeVar('_T', bound=QtCore.QObject)
_M = TypeVar('_M')
_O = TypeVar('_O', bound=QtCore.QObject)
_V = TypeVar('_V')


class ModelPopulator(srws.SupportsReadWriteSynchronized, Generic[_T, _M]):
    """
    Provides an interface for populating the ModelProperty instances of a QObject.
    """

    class Accessor(Generic[_O, _V]):
        getter: Optional[Callable[[_O], _V]] = None
        setter: Optional[Callable[[_O, _V], None]] = None

        def __init__(self, *, getter: Optional[Callable[[_O], _V]], setter: Optional[Callable[[_O, _V], None]]) -> None:
            self.getter = getter
            self.setter = setter

    _form_type: Type[_T] = None

    @property
    def form_type(self) -> Type[_T]:
        return self._form_type

    _model_type: Type[_M] = None

    @property
    def model_type(self) -> Type[_M]:
        return self._model_type

    _accessors: Dict[Type[QtCore.QObject], 'ModelPopulator.Accessor'] = None
    __populators: Dict[Tuple[Type[Any], Type[Any]], 'ModelPopulator'] = {}

    __model_properties: List['mp.ModelProperty'] = None
    @property
    def _model_properties(self) -> Iterable['mp.ModelProperty']:
        populate: bool = False
        with self.read_synchronized(fail_on_timeout=True):
            populate = self.__model_properties is None

        if populate:
            with self.write_synchronized(fail_on_timeout=True):
                if self.__model_properties is None:
                    self.__model_properties = self._discover_model_properties()

        return self.__model_properties

    @staticmethod
    def instance(form_type: Type[_T], model_type: Type[_M]) -> 'ModelPopulator[_T, _M]':
        """
        Returns a singleton instance for the given type.
        :param form_type: The type of the form to populate.
        :param model_type: The type of the model to populate.
        """
        key: Tuple[Type[_T], Type[_M]] = (form_type, model_type)

        if key not in ModelPopulator.__populators:
            ModelPopulator.__populators[key] = ModelPopulator(form_type, model_type)

        return ModelPopulator.__populators[key]

    def __init__(self, form_type: Type[_T], model_type: Type[_M]) -> None:
        self._form_type = form_type
        self._model_type = model_type
        self._accessors = {}

    def _discover_model_properties(self) -> List['mp.ModelProperty']:
        """
        Discovers all model properties associated to the form type.
        """
        return [v for v in self._form_type.__dict__.values() if isinstance(v, mp.ModelProperty)]

    def register_accessor(self, type_: Type[_O], *, getter: Callable[[_O], _V]=None, setter: Callable[[_O, _V], None]=None) -> bool:
        """
        Attempts to register a new accessor with this ModelPopulator.
        :param type_: The type that the accessor is applied to.
        :param getter: The optional getter of this ModelPopulator accessor.
        :param setter: The optional setter of this ModelPopulator accessor.
        """
        can_register: bool
        with self.read_synchronized() as lock:
            can_register = lock and type_ not in self._accessors

        if can_register:
            with self.write_synchronized() as lock:
                if type_ not in self._accessors:
                    self._accessors[type_] = self.Accessor(getter=getter, setter=setter)
                    return True

        return False

    def deregister_accessor(self, type_: Type[_O]) -> bool:
        """
        Attempts to remove an accessor from this ModelPopulator.
        :param type_: The type that the accessor is applied to.
        """
        can_deregister: bool
        with self.read_synchronized() as lock:
            can_deregister = lock and type_ in self._accessors

        if can_deregister:
            with self.write_synchronized() as lock:
                if type_ in self._accessors:
                    del self._accessors[type_]
                    return True

        return False

    def _resolve_accessor(self, type_: Type[_O], types: Optional[Set[Type]]=None) -> Optional['ModelPopulator.Accessor[_O, Any]']:
        """
        Attempts to resolve an accessor for the given type.
        :param type_: The type to resolve the accessor of.
        """
        with self.read_synchronized() as lock:
            if lock and type_ in self._accessors:
                return self._accessors[type_]
        mro: Type[_O]
        types = types or set()
        for mro in (m for m in type_.__mro__ if m is not object and m not in types):
            types.add(mro)
            accessor: Optional[self.Accessor[_O, Any]] = self._resolve_accessor(mro, types)
            if accessor is not None:
                return accessor
        return None

    def populate_form(self, *, form: _T, model: Optional[_M]) -> None:
        """
        Populates the provided form with the optional model's data. If no model is given,
        the form will be reset to an empty state.
        :param form: The form to populate.
        :param model: The model to populate the form with.
        """
        model_property: mp.ModelProperty
        for model_property in self._model_properties:
            self._set_value(getattr(form, model_property.property_name, None),
                            getattr(model, model_property.name, None))

    def populate_model(self, *, form: _T, model: Optional[_M]) -> None:
        """
        Populates the provided model wit the form's data.
        :param form: The form to populate the model with.
        :param model: The model to populate.
        """
        if model is not None:
            model_property: mp.ModelProperty
            for model_property in self._model_properties:
                control: QtCore.QObject = getattr(form, model_property.property_name, None)
                setattr(model, model_property.name, self._get_value(control))

    def _set_value(self, control: QtCore.QObject, value: Any) -> None:
        """
        Sets the value of the control if possible.
        :param control: The control to update the value of.
        :param value: The value to set the control to.
        """
        idx: int = -1
        accessor: Optional[self.Accessor[QtCore.QObject, Any]] = self._resolve_accessor(type(control))

        if accessor is not None:
            accessor.setter(control, value)
        elif isinstance(control, QtWidgets.QAbstractButton) and control.isCheckable():
            control.setChecked(safecasts.safe_bool(value, default=False))

        elif isinstance(control, QtWidgets.QComboBox):
            idx = control.findText(safecasts.safe_str(value))

            if -1 == idx:
                idx = control.findData(value)

            if -1 == idx and control.isEditable():
                control.setCurrentText(safecasts.safe_str(value))
            else:
                control.setCurrentIndex(idx)

        elif isinstance(control, QtWidgets.QDateEdit):
            if isinstance(value, QtCore.QDateTime):
                value = value.date()
            control.setDate(value if isinstance(value, QtCore.QDate) else safecasts.safe_date(value) or QtCore.QDate())

        elif isinstance(control, QtWidgets.QTimeEdit):
            if isinstance(value, QtCore.QDateTime):
                value = value.time()
            control.setTime(value if isinstance(value, QtCore.QTime) else safecasts.safe_time(value) or QtCore.QTime())

        elif isinstance(control, QtWidgets.QDateTimeEdit):
            control.setDateTime(value if isinstance(value, QtCore.QDateTime) else safecasts.safe_date(value) or QtCore.QDateTime())

        elif isinstance(control, QtWidgets.QDoubleSpinBox):
            control.setValue(safecasts.safe_double(value, default=0.0))

        elif isinstance(control, QtWidgets.QLabel):
            control.setText(safecasts.safe_str(value))

        elif isinstance(control, QtWidgets.QLineEdit):
            control.setText(safecasts.safe_str(value))

        elif isinstance(control, QtWidgets.QSpinBox):
            control.setValue(safecasts.safe_int(value, default=0))

        elif isinstance(control, QtWidgets.QTextEdit):
            control.setPlainText(safecasts.safe_str(value))

    def _get_value(self, control: QtCore.QObject) -> Any:
        """
        Gets the value of the control if possible.
        :param control: The control to get the value of.
        """
        accessor: Optional[self.Accessor[QtCore.QObject, Any]] = self._resolve_accessor(type(control))
        value: Any = None

        if accessor is not None:
            value = accessor.getter(control)

        elif isinstance(control, QtWidgets.QAbstractButton) and control.isCheckable():
            value = control.isChecked()

        elif isinstance(control, QtWidgets.QComboBox):
            value = control.currentData() or control.currentText()

        elif isinstance(control, QtWidgets.QDateEdit):
            value = control.date()

        elif isinstance(control, QtWidgets.QTimeEdit):
            value = control.time()

        elif isinstance(control, QtWidgets.QDateTimeEdit):
            value = control.dateTime()

        elif isinstance(control, QtWidgets.QDoubleSpinBox):
            value = control.value()

        elif isinstance(control, QtWidgets.QLabel):
            value = control.text()

        elif isinstance(control, QtWidgets.QLineEdit):
            value = control.text()

        elif isinstance(control, QtWidgets.QSpinBox):
            value = control.value()

        elif isinstance(control, QtWidgets.QTextEdit):
            value = control.toPlainText()

        return value

