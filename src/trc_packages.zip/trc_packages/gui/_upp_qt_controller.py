from trc_packages.core.features import protocols
from trc_packages.gui import _qt_controller
from trc_packages.reports import UPPProductionReport
from PyQt5.QtCore import pyqtSlot, QObject
from typing import Optional


class UPPQtController(_qt_controller.QtController):
    
    model_property_name: str = None
    
    @pyqtSlot(name='on_dataCommitted')
    def on_data_committed(self) -> None:
        model: protocols.Feature = None
        if self.model_property_name is not None:
            model = getattr(self, self.model_property_name, None)

        if isinstance(model, protocols.Feature) and model.hash_field is not None:
            feature_guid: str = None
                
            if isinstance(model.hash_field, str):
                feature_guid = model[model.hash_field]
            else:
                # We need to make sure the keys are always in the same order to prevent false negatives
                feature_guid = ",".join(sorted([model[f] for f in model.hash_field]))
                
            report: UPPProductionReport = UPPProductionReport(parent=self)
            report.on_feature_identified(feature_guid)

    def __init__(self, parent: Optional[QObject]=None) -> None:
        self.data_committed.connect(self.on_data_committed)
