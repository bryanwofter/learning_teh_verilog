from PyQt5 import QtCore
from typing import Any, Dict, Generic, ItemsView, Iterable, KeysView, List, Mapping, NamedTuple, Optional, overload, TypeVar, Tuple, Union, ValuesView
import collections
K = TypeVar('K')
V = TypeVar('V')
T = TypeVar('T')
MapLike = Union[Iterable[Tuple[K, V]], Mapping[K, V]]


class QtDict(Generic[K, V], QtCore.QObject):
    """
    Provides a dictionary implementation that offers signals.
    """

    items_about_to_be_inserted: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='itemsAboutToBeInserted', arguments=['keys', 'new_values'])  # type: ignore
    items_inserted: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject'], name='itemsInserted', arguments=['keys'])  # type: ignore
    items_about_to_be_replaced: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject', 'PyQt_PyObject'], name='itemsAboutToBeReplaced', arguments=['keys', 'new_values', 'old_values'])  # type: ignore
    items_replaced: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject'], name='itemsReplaced', arguments=['keys'])  # type: ignore
    items_about_to_be_removed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject'], name='itemsAboutToBeRemoved', arguments=['keys'])  # type: ignore
    items_removed: QtCore.pyqtSignal = QtCore.pyqtSignal(['PyQt_PyObject', 'PyQt_PyObject'], name='itemsRemoved', arguments=['keys', 'values'])  # type: ignore

    __dict: Dict[K, V] = None

    def __contains__(self, key: K) -> bool:
        """
        Determines if the given key exists within this QtDict.
        :param key: The key to look for.
        """
        return key in self.__dict

    def __delitem__(self, key: K) -> None:
        """
        Removes an item from this QtDict with the given key. If the key exists, then it will be removed. Otherwise, an error will be raised.
        :param key: The key to remove.
        """
        self.__remove_items([key])

    def __eq__(self, other) -> bool:
        """
        Determines if this QtDict is equivalent to the given argument.
        :param other: A QtDict or Mapping-like object.
        """
        if isinstance(other, QtDict):
            return self.__dict == other.__dict and self.parent() == other.parent()
        elif isinstance(other, collections.Mapping):
            return self.__dict == other
        return NotImplemented

    def __ge__(self, other) -> bool:
        """
        Determines if this QtDict is greater than or equal to the given argument.
        :param other: A QtDict or Mapping-like object.
        """
        return self.__dict >= other

    def __getitem__(self, key: K) -> V:
        """
        Gets an item in this QtDict using the given key.
        :param key: The key to get.
        """
        return self.__dict[key]

    def __gt__(self, other) -> bool:
        """
        Determines if this QtDict is greater than the given argument.
        :param other: A QtDict or Mapping-like object.
        """
        return self.__dict > other

    def __hash__(self) -> int:
        """Gets the hashcode of this QtDict."""
        return hash((self.__dict, self.parent()))

    def __init__(self, other: Optional[MapLike[K, V]]=None, parent: Optional[QtCore.QObject]=None, **kwargs: Any) -> None:
        """
        Initializes this QtDict with the optional parent object, passing any additional arguments to the dict constructor.
        :param parent: The parent of this QtDict.
        """
        super().__init__(parent=parent)
        self.__dict = dict(**kwargs) if other is None else dict(other, **kwargs)

    def __iter__(self) -> Iterable[K]:
        """Iterates over this QtDict's keys."""
        return self.__dict.__iter__()

    def __le__(self, other) -> bool:
        """
        Determines if this QtDict is less than or equal to the given argument.
        :param other: A QtDict or Mapping-like object.
        """
        return self.__dict <= other

    def __len__(self) -> int:
        """Gets the length of this QtDict."""
        return len(self.__dict)

    def __lt__(self, other) -> bool:
        """
        Determines if this QtDict is less than the given argument.
        :param other: A QtDict or Mapping-like object.
        """
        return self.__dict < other

    def __ne__(self, other) -> bool:
        """
        Determines if this QtDict is not equal to the given argument.
        :param other: A QtDict or Mapping-like object.
        """
        return not self.__eq__(other)

    def __reduce__(self) -> Union[str, Tuple[Any, ...]]:
        """Returns reduction information about this QtDict."""
        return self.__dict.__reduce__()

    def __reduce_ex__(self, protocol: int) -> Union[str, Tuple[Any, ...]]:
        """Returns reduction information about this QtDict."""
        return self.__dict.__reduce_ex__(protocol)

    def __repr__(self) -> str:
        """Returns the string representation of this QtDict."""
        return self.__dict.__repr__()

    def __setitem__(self, key: K, value: V) -> None:
        """
        Sets an item in this QtDict with the given key. If the key exists, a replace signal will be emitted. Otherwise, an insert signal will be emitted.
        :param key: The key to add or update.
        :param value: The new value.
        """
        self.__update_items([key], [value])

    def __str__(self) -> str:
        """Returns the string representation of this QtDict."""
        return self.__dict.__str__()

    def clear(self) -> None:
        """Removes all items from this QtDict."""
        self.__remove_items(list(self.keys()))

    def copy(self) -> 'QtDict[K, V]':
        """Makes a copy of this QtDict."""
        return QtDict(self.__dict, parent=self.parent())

    def get(self, k: K, default: Union[V, T]=None) -> Union[V, T]:
        """
        Gets the provided key's value from this QtDict.
        :param k: The key to get.
        :param default: The optional default value to use if the key isn't found.
        """
        return self.__dict.get(k, default)

    def items(self) -> ItemsView[K, V]:
        """Gets a view of the items in this QtDict."""
        return self.__dict.items()

    def keys(self) -> KeysView[K]:
        """Gets a view of the keys in this QtDict."""
        return self.__dict.keys()

    def pop(self, k: K, *args: Union[V, T]) -> Union[V, T]:
        """
        Pops the value of the given key from this QtDict, returning the optional default value if one is provided.
        :param k: The key to pop.
        :param default: The optional default value to return if the value doesn't exist.
        """
        value: Union[V, T]
        if 1 == len(args):
            value = self.get(k, args[0])
        else:
            value = self[k]
        if k in self:
            self.__remove_items([k])
        return value

    def popitem(self) -> Tuple[K, V]:
        """Pops the last item from this QtDict. This pop will only trigger the itemsRemoved signal due to the way it has to be implemented."""
        item: Tuple[K, V] = self.__dict.popitem()
        # Because we have to do a call to the super popitem, we're going to do a bit of a cheat here. We're readding it so we can call the appropriate __remove_items method. I know, I know. Genius.
        self.__dict[item[0]] = item[1]
        self.__remove_items([item[0]])
        return item

    def setdefault(self, k: K, default: V=None) -> V:
        """
        Gets the value of the given key if one is present, or adds the default value to this QtDict if one isn't already present.
        :param k: The key to get or add.
        :param default: The default value to use if the key doesn't already exist.
        """
        if k not in self:
            self.__update_items([k], [default])
            return default
        else:
            return self[k]

    def update(self, other: Union[Mapping[K, V], Iterable[Tuple[K, V]]]=None, **kwargs: V) -> None:
        """
        Updates this QtDict with the given mapping or iterable and kwargs.
        :param other: The optional mapping or iterable to add into this QtDict.
        """
        update_keys: List[K] = []
        update_values: List[V] = []
        if other is not None:
            other = dict(other)
            other.update(kwargs)  # type: ignore
        else:
            other = kwargs  # type: ignore

        for k, v in other.items():
            update_keys.append(k)
            update_values.append(v)

        self.__update_items(update_keys, update_values)

    def __update_items(self, keys: List[K], new_values: List[V]) -> None:
        """
        Determines if the specific keys are a replace or insert and calls the appropriate methods.
        :param keys: The keys to resolve the action of.
        :param new_values: The values to replace or insert into this QtDict.
        """
        insert_keys: List[K] = []
        replace_keys: List[K] = []

        insert_new_values: List[V] = []
        replace_new_values: List[V] = []
        replace_old_values: List[V] = []

        for i in range(0, len(keys)):  # type: int
            key: K = keys[i]
            value: V = new_values[i]
            if key in self:
                replace_keys.append(key)
                replace_new_values.append(value)
                replace_old_values.append(self[key])
            else:
                insert_keys.append(key)
                insert_new_values.append(value)

        has_inserts: bool = len(insert_keys) > 0
        has_replaces: bool = len(replace_keys) > 0

        if has_inserts:
            self.items_about_to_be_inserted['PyQt_PyObject', 'PyQt_PyObject'].emit(insert_keys, insert_new_values)  # type: ignore
            self.__dict.update((insert_keys[i], insert_new_values[i]) for i in range(0, len(insert_keys)))
            self.items_inserted['PyQt_PyObject'].emit(insert_keys)  # type: ignore
        if has_replaces:
            self.items_about_to_be_replaced['PyQt_PyObject', 'PyQt_PyObject', 'PyQt_PyObject'].emit(replace_keys, replace_new_values, replace_old_values)  # type: ignore
            self.__dict.update((replace_keys[i], replace_new_values[i]) for i in range(0, len(replace_keys)))
            self.items_replaced['PyQt_PyObject'].emit(replace_keys)  # type: ignore

    def __remove_items(self, keys: List[K]) -> None:
        """
        Performs the deletion of the given key list.
        :param keys: The keys to delete from this QtDict.
        """
        values: List[V] = []

        for k in keys:
            values.append(self[k])
        self.items_about_to_be_removed['PyQt_PyObject'].emit(keys)  # type: ignore
        for k in keys:
            del self.__dict[k]
        self.items_removed['PyQt_PyObject', 'PyQt_PyObject'].emit(keys, values)  # type: ignore

