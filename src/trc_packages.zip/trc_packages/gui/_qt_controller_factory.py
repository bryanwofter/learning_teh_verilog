from PyQt5 import uic, QtCore  # type: ignore
from trc_packages.gui import _qt_controller as qc, errors
from typing import Any, Dict, List, Optional, overload, Tuple, Type, TypeVar
import os
C = TypeVar('C', bound='qc.QtController')


class QtControllerFactory(QtCore.QObject):
    """
    Provides factory methods for generating QtController-based instances and classes.
    Additional search paths may be supplied through the path field.
    """

    __controller_types: Dict[str, Type['qc.QtController']] = None
    path: List[str] = None

    def __init__(self, parent: Optional[QtCore.QObject]=None, *, path: List[str]=None) -> None:
        super().__init__(parent=parent)

        self.__controller_types = dict()
        self.path = path or []

    @overload
    def make(self, controller_type: str, *, controller_dirname_source: Optional[str]=None, cache_type: bool=False, parent: Optional[QtCore.QObject]=None) -> C:
        ...
    @overload
    def make(self, controller_type: Type[C], *, parent: Optional[QtCore.QObject]=None) -> C:
        ...

    def make(self, controller_type, *, controller_dirname_source: Optional[str]=None, cache_type: bool=False, parent: Optional[QtCore.QObject]=None) -> C:
        """
        Creates a new instance of the given controller.
        :param controller_type: The type of controller to create an instance of and to setup. If a string is used, the type is generated through uic.
        :param controller_dirname_source: The path of the controller's UI file when controller_type is a string. If not provided, its assumed that the full path was provided to controller_type.
        :param cache_type: True if the controller_type should be cached when invoking uic loading, otherwise False.
        :param parent: The optional parent of the controller. If parent is set to None, then this QtControllerFactory is used.
        """
        controller: C
        if isinstance(controller_type, str):
            if cache_type:
                cached_name: str = f"{controller_dirname_source}::{controller_type}"
                if cached_name not in self.__controller_types:
                    self.__controller_types[cached_name] = self._load_ui_type(controller_dirname_source, controller_type)
                controller_type = self.__controller_types[cached_name]
            else:
                controller_type = self._load_ui_type(controller_dirname_source, controller_type)
        controller = controller_type(parent=parent)
        controller.controller_factory = self
        controller.setup()
        return controller

    def _load_ui_type(self, dirname_source: Optional[str], file: str) -> Type[C]:
        """
        Attempts to load the UI type for the given dirname_source and file. If no dirname_source is provided, then the factory path list is searched instead.
        :param dirname_source: The path to extract the dirname from.
        :param file: The name of the UI file, with or without the extension.
        """
        file_name: str = os.path.splitext(file)[0]
        file_path: Optional[str] = None

        if dirname_source is None:
            for path in self.path:  # type: str
                file_path = os.path.join(path, f"{file_name}.ui")

                if os.path.isfile(file_path):
                    break
        else:
            file_path = os.path.join(os.path.dirname(dirname_source), f"{file_name}.ui")

        if file_path is None or not os.path.isfile(file_path):
            raise errors.UnresolvedControllerTypeError()
        else:
            form_type, base_type = uic.loadUiType(file_path)  # type: Tuple[Any, Any]

            class controller(form_type, base_type, qc.QtController):
                """A wrapper class used to represent the newly created controller."""
            controller.__name__ = f"{file_name}_controller"
            return controller

