from trc_packages.gui import _qt_controller as qc, _model_populator as mp
from trc_packages.decorators import singleton
from typing import ContextManager, Generic, Optional, Type, TypeVar
from typing_extensions import final, Literal
from types import TracebackType
_M = TypeVar('_M')


class QtModelController(Generic[_M], qc.QtController):
    """
    Provides a QtController implementation that offers a strongly-typed model.

    When implementing custom binding behavior, the first statement should be a call to super()._binding().
    """

    @singleton
    class noopmanager(ContextManager[None]):

        def __enter__(self) -> None:
            pass

        def __exit__(self, exc_type: Optional[Type[BaseException]], exc: Optional[BaseException], tb: Optional[TracebackType]) -> Literal[False]:
            return False

    _model: Optional[_M] = None

    @property
    def model(self) -> Optional[_M]:
        return self._model

    @model.setter
    def model(self, value: Optional[_M]) -> None:
        if not self.is_bound:
            self._model = value
            self.bind()

    @model.deleter
    def model(self) -> None:
        if self.is_bound:
            self.unbind()
            self._model = None

    @property
    def model_populator(self) -> 'mp.ModelPopulator[QtModelController, _M]':
        return mp.ModelPopulator.instance(type(self), type(self.model))

    def _binding(self) -> None:
        self.model_populator.populate_form(form=self, model=self.model)

    def _unbinding(self) -> None:
        self.model_populator.populate_form(form=self, model=None)

    def _start_transaction(self) -> ContextManager[None]:
        return self.noopmanager()

    @final
    def commit(self) -> None:
        if self.is_bound:
            with self._start_transaction():
                for child in self.child_controllers:
                    if isinstance(child, qc.QtController):
                        child.commit()
                self.model_populator.populate_model(form=self, model=self.model)
                self._committing()

    def _committing(self) -> None:
        """Invoked by the commit method when committing has begun."""
        pass

    @final
    def discard(self) -> None:
        if self.is_bound:
            model: _M = self.model

            for child in self.child_controllers:
                if isinstance(child, qc.QtController):
                    child.discard()

            del self.model
            self.model = model

    def _discarding(self) -> None:
        """Invoked by the discard method when discarding has begun."""
        pass

