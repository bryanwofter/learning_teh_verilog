from PyQt5 import QtCore
from typing import Generic, Optional, Type, TypeVar
_T = TypeVar('_T', bound=QtCore.QObject)
_U = TypeVar('_U', bound=QtCore.QObject)


class ModelProperty(Generic[_T]):
    """
    A descriptor used to mark a Qt widget as being associated to a property of a model.
    """
    _name: str = None
    _field_name: str = None
    _property_name: str = None
    _default: Optional[_T] = None
    _type: Type[_T] = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def type_(self) -> Type[_T]:
        return self._type

    @property
    def field_name(self) -> str:
        return self._field_name

    @property
    def property_name(self) -> str:
        return self._property_name

    def __init__(self, type_: Type[_T], *, name: Optional[str]=None, default: Optional[_T]=None) -> None:
        self._name = name
        self._default = default
        self._type = type_

    def __delete__(self, instance: _U) -> None:
        """
        Deletes this ModelProperty from the instance.
        :param instance: The instance to delete this ModelProperty from.
        """
        delattr(instance, self._field_name)

    def __get__(self, instance: Optional[_U], owner: Type[_U]) -> _T:
        """
        Gets this ModelProperty from the owner or instance.
        :param instance: The instance to get the ModelProperty from.
        :param owner: The owner to get the ModelProperty from if no instance is provided.
        """
        return getattr(instance or owner, self._field_name, self._default)

    def __set__(self, instance: _U, value: _T) -> None:
        """
        Sets this ModelProperty on the instance.
        :param instance: The instance to put the ModelProperty into.
        :param value: The new value of the ModelProperty.
        """
        setattr(instance, self._field_name, value)
        value.setObjectName(self._property_name)

    def __set_name__(self, owner: Type[_U], name: str) -> None:
        """
        Sets the name of this ModelProperty if one wasn't provided by the constructor.
        :param owner: The owner type of this ModelProperty.
        :param name: The property name of this ModelProperty.
        """
        if self._name is None:
            self._name = name

        self._field_name = f"_{owner.__name__}__{name}"
        self._property_name = name

