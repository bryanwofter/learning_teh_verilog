def classFactory(iface):
    """
    Used for loading the trc_packages plugin stub.
    """
    from ._trc_packages import TRCPackages
    return TRCPackages(iface)

import importlib as __importlib
DEBUGGING: bool = False
MOCK_THREADS: bool = False
UNIT_TEST: bool = False
QGIS_EXISTS: bool = __importlib.util.find_spec('qgis') is not None  # type: ignore
del __importlib

