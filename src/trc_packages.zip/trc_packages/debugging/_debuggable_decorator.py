from functools import wraps
from typing import Any, Callable, cast, Generic, Optional, Type, TypeVar, Tuple
import trc_packages
import sys
F = TypeVar('F')


class DebuggableDecorator(Generic[F]):
    """
    Provides a wrapper for functions that can set a function to call one method in debugging or another method if not debugging.
    """

    debugging: Optional[bool] = None
    __debug: Optional[F] = None
    __predebug: Optional[F] = None
    __postdebug: Optional[F] = None
    __production: Optional[F] = None
    __catch: Optional[F] = None

    def __init__(self, production: F, *, debugging: Optional[bool]=None, debug: Optional[F]=None,
                 catch: Optional[F]=None, predebug: Optional[F]=None,
                 postdebug: Optional[F]=None) -> None:
        self.debugging = debugging
        self.__debug = debug
        self.__predebug = predebug
        self.__postdebug = postdebug
        self.__production = production
        self.__catch = catch

    def catch(self, catch: F) -> 'DebuggableDecorator[F]':
        """
        Sets the catch function of this debuggable annotation.
        Arguments passed to a catch callable will be the exception, its type, and its corresponding traceback.
        """
        self.__catch = catch
        return self

    def debug(self, debug: F) -> 'DebuggableDecorator[F]':
        """Sets the debug function of this debuggable annotation."""
        self.__debug = debug
        return self

    def predebug(self, predebug: F) -> 'DebuggableDecorator[F]':
        """Sets the function to call before the debug or production function if debugging is set."""
        self.__predebug = predebug
        return self

    def postdebug(self, postdebug: F) -> 'DebuggableDecorator[F]':
        """Sets the function to call after the debug or production function if debugging is set."""
        self.__postdebug = postdebug
        return self

    def production(self, production: F) -> 'DebuggableDecorator[F]':
        """Sets the production function."""
        self.__production = production
        return self

    @staticmethod
    def __no_pre_post(*args: Any, **kwargs: Any) -> Any: pass

    @staticmethod
    def __no_catch(*args: Any, **kwargs: Any) -> Any: pass

    def __get__(self, instance: Any, owner: type) -> F:
        if instance is None:
            return cast(F, self)
        else:
            @wraps(cast(Callable[..., Any], self.__production))
            def __call(*args: Any, **kwargs: Any) -> Any:
                return self(instance, *args, **kwargs)
            return cast(F, __call)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        debugging: bool = self.debugging or trc_packages.DEBUGGING
        production: F = self.__production
        catch: F = self.__catch or cast(F, self.__no_catch)
        predebug: F = self.__predebug or cast(F, self.__no_pre_post)
        debug: F = self.__debug or production
        postdebug: F = self.__postdebug or cast(F, self.__no_pre_post)
        if self.debugging or trc_packages.DEBUGGING:
            caught: bool = True
            try:
                predebug(*args, **kwargs)  # type: ignore
                return debug(*args, **kwargs)  # type: ignore
            except:
                exc_type, exc, tb = sys.exc_info()  # type: Tuple[Any, Any, Any]
                caught = catch(*args, **kwargs, exc=exc, exc_type=exc_type, tb=tb)  # type: ignore
                if not caught: raise exc
            finally:
                if caught: postdebug(*args, **kwargs)  # type: ignore
        else:
            return production(*args, **kwargs)  # type: ignore
