from qgis.core import QgsVectorLayer  # type: ignore
from typing import Any
from . import _bases as bases, errors, _functions as functions

class DebugVectorLayer(bases._AllocCounter):
    """Provides a vector layer-like object that provides debugging information about the wrapped vector layer."""

    __layer: QgsVectorLayer = None

    @property
    def layer(self) -> QgsVectorLayer: return self.__layer

    # @functions.debuggable
    def __new__(cls, *args: Any, **kwargs: Any) -> object:  # type: ignore
        """Returns the original layer provided."""
        return (args[0] if args else None) or kwargs.get('layer')

    '''
    # @__new__.debug  # type: ignore
    def __new__debug(cls, *args: Any, **kwargs: Any) -> object:  # type: ignore
        """Returns the layer wrapped in a DebugVectorLayer and increments the allocation count."""
        layer: QgsVectorLayer = (args[0] if args else None) or kwargs.get('layer')
        if layer is not None: cls._inc_alloc(layer.name())
        return super().__new__(cls)
    '''

    @functions.debuggable
    def __del__(self) -> None:
        raise errors.DebugOnlyError()

    @__del__.debug  # type: ignore
    def __del__(self) -> None:
        """Deletes the layer reference and decrements the allocation count."""
        if self.__layer is not None: self._dec_alloc(self.__layer.name())
        del self.__layer

    @functions.debuggable
    def __init__(self, layer: QgsVectorLayer) -> None: raise errors.DebugOnlyError()

    @__init__.debug  # type: ignore
    def __init__(self, layer: QgsVectorLayer) -> None:
        self.__layer = layer
        for name in dir(self.__layer):
            if not name.startswith('__') and not name.endswith('__') and callable(getattr(self.__layer, name)):
                setattr(self, name, getattr(self.__layer, name))

