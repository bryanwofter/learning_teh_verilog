class DebuggingError(Exception):
    """A base for all exceptions raised during a debugging functionality."""


class DebugOnlyError(DebuggingError):
    """Raised if a feature is only supported during debug."""

