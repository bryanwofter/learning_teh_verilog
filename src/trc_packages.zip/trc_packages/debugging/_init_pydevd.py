from trc_packages import debugging
import sys as __sys
import pathlib as __pathlib


for __i in range(0, len(__sys.path)):  # type: int
    # Rebuild all of the paths using pathlib.
    __sys.path[__i] = str(__pathlib.Path(__sys.path[__i]).resolve())

# Load the pydevd library.
import pydevd

