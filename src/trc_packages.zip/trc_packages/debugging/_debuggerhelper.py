from functools import wraps
from trc_packages.debugging import _debug
from typing import Any, TypeVar
T = TypeVar('T')

ENABLED: bool = False


def printtodebugger(fn: T) -> T:
    if ENABLED:
        @wraps(fn)
        def __wrapper(*args: Any, **kwargs: Any) -> Any:
            _debug.Debug.print_if_debugging(lambda: f"{fn.__name__} (func: {fn}) invoked with (args: {args}) {{kwargs: {kwargs}}}")
            _debug.Debug.print(f'--------------------------------------------------------------')
            result: Any = fn(*args, **kwargs)
            _debug.Debug.print_if_debugging(lambda: f"{fn.__name__} (func: {fn}) returned (result: {result})")
            _debug.Debug.print(f'--------------------------------------------------------------')
            return result
    else:
        __wrapper = fn

    return __wrapper


def pausedebugger(fn: T) -> T:
    if ENABLED:
        @wraps(fn)
        def __wrapper(*args: Any, **kwargs: Any) -> Any:
            _debug.Debug.pause()
            return fn(*args, **kwargs)
    else:
        __wrapper = fn

    return __wrapper

