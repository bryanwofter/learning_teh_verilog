from collections import defaultdict
from typing import Any, cast, ClassVar, Dict, NoReturn, Optional


class _AllocCounter:
    """Provides a base that can be used to count allocations."""
    _ALLOC_COUNTS: ClassVar[Optional[Dict[Any, int]]] = None

    @classmethod
    def _get_alloc_counts(cls) -> Dict[Any, int]:
        # Because _AllocCounter is effectively an abstract class, we don't want to instantiate its _ALLOC_COUNTS dictionary ever, otherwise it'll cause us some issues.
        if cls is not _AllocCounter and cls._ALLOC_COUNTS is None:
            cls._ALLOC_COUNTS = defaultdict(lambda: 0)
        return cast(Dict[Any, int], cls._ALLOC_COUNTS)

    @classmethod
    def _inc_alloc(cls, key: Any) -> NoReturn:
        cls._get_alloc_counts()[key] += 1
        print(f"{cls._get_alloc_counts()[key]} {key} allocated")

    @classmethod
    def _dec_alloc(cls, key: Any) -> NoReturn:
        cls._get_alloc_counts()[key] -= 1
        print(f"{cls._get_alloc_counts()[key]} {key} remaining")
        if cls._get_alloc_counts()[key] == 0:
            del cls._get_alloc_counts()[key]

    @classmethod
    def dump_alloc_counts(cls) -> Dict[Any, int]:
        """Returns all allocation counts for this class."""
        return cls._get_alloc_counts()

