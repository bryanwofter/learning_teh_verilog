from trc_packages.core import _logging as l
from trc_packages.debugging import _init_pydevd
from trc_packages.decorators import _singleton as s
from typing import Any, Callable, FrozenSet, Iterable, Optional, overload, Type, TypeVar, no_type_check
from typing_extensions import Literal
from types import TracebackType
import logging
import pydevd  # type: ignore
import trc_packages

T = TypeVar('T')


class _debugtype(type):
    """
    Provides a metaclass for the Debug class.
    All methods of this metaclass are passed to their equivalent methods on the Debug class.
    """

    @property
    def _instance(cls: Type[T]) -> T:
        return cls()

    @property
    def host(cls: Type[T]) -> Optional[str]:
        return cls._instance._host  # type: ignore

    @property
    def debugging(cls: Type[T]) -> bool:
        return cls._instance._debugging  # type: ignore

    @no_type_check
    def start(cls: Type[T], *, host: Optional[str]=None) -> bool:
        """
        Starts the debug session to the given host if one hasn't already been started.
        :param host: The host that is currently running the debugging server. If None is provided, then localhost will be used.
        """
        return cls._instance._start(host=host)

    @no_type_check
    def stop(cls: Type[T]) -> bool:
        """Stops the current debug session."""
        return cls._instance._stop()

    @no_type_check
    def pause(cls: Type[T]) -> None:
        """If currently in a debug session, Python will enter into a break state at the location of the function call."""
        cls._instance._pause()

    @no_type_check
    def pause_if(cls: Type[T], predicate: Optional[Callable[[], bool]]=None, *, check: bool=None) -> None:
        """
        If currently in a debug session, Python will enter into a break state at the location of the function call *if* predicate returns True. If predicate is not provided,
        check must be supplied and will be used in its place.
        :param predicate: The predicate to execute in order to determine if the pause condition is met.
        :param check: True if the inline check condition is passed, otherwise False.
        """
        cls._instance._pause_if(predicate, check=check)

    @no_type_check
    def pause_if_raised(cls: Type[T], * exception_types: Type[BaseException]) -> 'PauseIfRaisedContextManager':
        """
        If currently in a debug session, Python will enter into a break state at the end of the call wrapped in the PauseIfRaisedContextManager *if* an exception of one of the provided types is raised. If no exception
        types are provided, then all exceptions will lead to a break state.
        """
        return cls._instance._pause_if_raised(exception_types=exception_types)

    @property
    def print_func(cls: Type[T]) -> Optional[Callable[..., None]]:
        return cls._instance._print_func

    @print_func.setter
    def print_func(cls: Type[T], value: Optional[Callable[..., None]]) -> None:
        cls._instance._print_func = value

    @print_func.deleter
    def print_func(cls: Type[T]) -> None:
        cls.print_func = None

    @no_type_check
    def print(cls: Type[T], *args: Any) -> None:
        """
        Prints all given arguments to the debugging output and the debugging log file.
        :param args: The arguments to print.
        """
        cls._instance._print(*args)

    @no_type_check
    def print_if_debugging(cls: Type[T], callable: Callable[[], None]) -> None:
        """
        Prints the result of the given callable to the debugging output and the debugging log file. This should be used if the result of an expensive
        process needs to have its result printed but only if debugging is currently enabled.
        :param callable: The callable to print the result of.
        """
        cls._instance._print_if_debugging(callable)


class PauseIfRaisedContextManager:
    """
    Provides a helper for pausing if a specific exception is raised.
    """

    debugger: 'Debug' = None
    exception_types: Optional[FrozenSet[Type[BaseException]]] = None

    def __init__(self, debugger: 'Debug', exception_types: Optional[Iterable[Type[BaseException]]]) -> None:
        """
        Initializes this PauseIfRaisedContextManager with the given debugger and exception_types. If no exception_types are provided, all exceptions will be caught.
        """
        self.debugger = debugger
        if exception_types:
            self.exception_types = frozenset(exception_types)

    def __enter__(self) -> None:
        return None

    def __exit__(self, exc_type: Optional[Type[BaseException]], exc: Optional[BaseException], tb: Optional[TracebackType]) -> Literal[False]:
        """
        Pauses Python if the exc_type is within the exception_types of this context manager.
        :param exc_type: The type of exception raised, if any.
        :param exc: The exception raised, if any.
        :param tb: The traceback of the exception raised, if any.
        """
        self.debugger._pause_if(lambda: exc_type is not None and (not self.exception_types or not any(self.exception_types) or exc_type in self.exception_types))
        return False


@s.singleton
class NoOpPauseIfRaisedContextManager(PauseIfRaisedContextManager):
    """
    Used when not currently in debugging mode.
    """

    def __init__(self) -> None:
        super().__init__(None, None)

    def __exit__(self, exc_type: Type[BaseException], exc: Optional[BaseException], tb: Optional[TracebackType]) -> Literal[False]:
        """Always returns False - this singleton is provided only to help with making sure there are minimal performance hits when using not debugging."""
        return False


@s.singleton
class Debug(metaclass=_debugtype):
    """
    Provides a helper for debugging code.
    The class-based methods should be preferred over getting an instance of the Debug. Debug is currently a singleton but this may change if multiple remote debuggers is deemed
    desirable functionality.
    """

    _faulted: bool = False
    _host: str = None
    _previous_log_level: int = None
    _print_func: Optional[Callable[..., None]] = None

    @property
    def _debugging(self) -> bool:
        return trc_packages.DEBUGGING

    @_debugging.setter
    def _debugging(self, value: bool) -> None:
        trc_packages.DEBUGGING = value

    @_debugging.deleter
    def _debugging(self) -> None:
        self.debugging = False

    def _start(self, *, host: Optional[str]=None) -> bool:
        if not self._debugging:
            self._debugging = True
            self._host = host
            self._previous_log_level = l.log.level
            l.log.level = logging.DEBUG
            try:
                pydevd.settrace(host)
            except Exception as e:
                self._faulted = True
                raise e
        return self._debugging

    def _stop(self) -> bool:
        if self._debugging:
            self._debugging = False
            if not self._faulted:
                pydevd.stoptrace()
            self._faulted = False
            l.log.level = self._previous_log_level
        return not self._debugging

    def _pause(self) -> None:
        if self._debugging and not self._faulted:
            # Use step into on your debugging to return back to the original caller
            # TODO: Investigate ways to tell pydevd to automatically adjust the stack frame
            pydevd.settrace(self._host)

    def _pause_if(self, predicate: Optional[Callable[[], bool]]=None, *, check: Optional[bool]=None) -> None:
        if self._debugging and not self._faulted:
            if predicate is not None and check is not None:
                raise ValueError("check and predicate supplied, only expecting one or the other.")
            if isinstance(check, bool):
                def predicate() -> bool:
                    nonlocal check
                    return check
            elif check is not None:
                raise TypeError("check must be a bool.")
            if not callable(predicate):
                raise TypeError("predicate must be a callable.")

            if predicate():
                self._pause()

    def _pause_if_raised(self, *, exception_types: Optional[Iterable[Type[BaseException]]]=None) -> PauseIfRaisedContextManager:
        return PauseIfRaisedContextManager(self, exception_types) if self._debugging and not self._faulted else NoOpPauseIfRaisedContextManager()

    def _print(self, *args: Any) -> None:
        if self._print_func is not None and self._debugging:
            self._print_func(*args)

    def _print_if_debugging(self, callable: Callable[[], None]) -> None:
        if self._print_func is not None and self._debugging:
            self._print_func(callable())

