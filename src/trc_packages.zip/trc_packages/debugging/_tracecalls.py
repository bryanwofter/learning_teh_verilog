"""
Provides a decorator for tracing calls to methods.
"""

from functools import wraps
from typing import Any, Callable, List
import traceback
import trc_packages

def tracecalls(fn: Callable[..., Any]) -> Callable[..., Any]:
    traces: List = []
    @wraps(fn)
    def __wrapper(*args: Any, **kwargs: Any) -> Any:
        if trc_packages.DEBUGGING:
            nonlocal traces
            traces.append(traceback.extract_stack())
        return fn(*args, **kwargs)
    __wrapper.traces = traces  # type: ignore
    return __wrapper
