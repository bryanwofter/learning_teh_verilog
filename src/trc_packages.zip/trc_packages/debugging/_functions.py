from typing import Any, Callable, Optional, TypeVar, Union
from . import _debuggable_decorator as dd
F = TypeVar('F')


DebugCallable = Optional[F]


def debuggablewith(*, debugging: bool, catch: Optional[F]=None, debug: Optional[F]=None, predebug: Optional[F]=None, postdebug: Optional[F]=None) -> Callable[[F], 'dd.DebuggableDecorator[F]']:
    """
    Returns a factory for creating a debuggable decorator.
    :param debugging: True if debugging is enabled, otherwise False.
    :param catch: The optional function to use for catching exceptions.
    :param debug: The optional function to use for debugging.
    :param predebug: The optional function to use for pre-debug calls.
    :param postdebug: The optional function to use for post-debug calls.
    :return: A decorator factory.
    """
    return lambda fn: debuggable_decorator(fn, debugging=debugging, catch=catch, debug=debug, predebug=predebug, postdebug=postdebug)


def debuggable(production: F, catch: Optional[F]=None, debug: Optional[F]=None, predebug: Optional[F]=None, postdebug: Optional[F]=None, debugging: Optional[bool]=None) -> 'dd.DebuggableDecorator[F]':
    """
    Returns a debuggable decorator.
    :param production: The target method of this decorator.
    :param debugging: True if debugging is enabled, otherwise False.
    :param catch: The optional function to use for catching exceptions.
    :param debug: The optional function to use for debugging.
    :param predebug: The optional function to use for pre-debug calls.
    :param postdebug: The optional function to use for post-debug calls.
    """
    return debuggable_decorator(production=production, debug=debug, predebug=predebug, postdebug=postdebug, debugging=debugging, catch=catch)


def debuggable_decorator(production: F, catch: Optional[F]=None, debug: Optional[F]=None, predebug: Optional[F]=None, postdebug: Optional[F]=None, debugging: Optional[bool]=None) -> 'dd.DebuggableDecorator[F]':
    """
    Returns a debuggable decorator.
    :param production: The target method of this decorator.
    :param debugging: True if debugging is enabled, otherwise False.
    :param catch: The optional function to use for catching exceptions.
    :param debug: The optional function to use for debugging.
    :param predebug: The optional function to use for pre-debug calls.
    :param postdebug: The optional function to use for post-debug calls.
    """
    return dd.DebuggableDecorator(production=production, debugging=debugging, debug=debug, catch=catch, predebug=predebug, postdebug=postdebug)

