from . import _bases as bases, _functions as functions

class AllocCount(bases._AllocCounter):
    """Provides a method for debugging allocations."""

    @functions.debuggable
    def __new__(cls, *args, **kwargs) -> object:
        return super().__new__(cls)

    @__new__.debug  # type: ignore
    def __new__(cls, *args, **kwargs) -> object:
        cls._inc_alloc(cls)
        return super().__new__(cls)

    @functions.debuggable
    def __del__(self) -> None: pass

    @__del__.debug  # type: ignore
    def __del__(self) -> None: self._dec_alloc(self.__class__)

