from qgis.core import QgsFeature  # type: ignore
from typing import Any, NoReturn, Optional
from . import _bases as bases, errors, _functions as functions


class DebugFeature(bases._AllocCounter):
    """Provides a vector feature-like object that provides debugging information about the wrapped vector feature."""

    __feature: QgsFeature = None
    __layer_name: Optional[str] = None

    @property
    def feature(self) -> QgsFeature: return self.__feature

    # @functions.debuggable
    def __new__(cls, *args: Any, **kwargs: Any) -> object:  # type: ignore
        """Returns the original feature as this object."""
        return (args[0] if args else None) or kwargs.get('feature')

    '''
    @__new__.debug  # type: ignore
    def __new__(cls, *args: Any, **kwargs: Any) -> object:
        """Returns the feature wrapped in a DebugFeature and increments the allocation count."""
        feature: QgsFeature = (args[0] if args else None) or kwargs.get('feature')
        layer_name: str = (args[1] if len(args) > 1 else None) or kwargs.get('layer_name')
        if layer_name is not None: cls._inc_alloc(layer_name)
        return super().__new__(cls)
    '''

    @functions.debuggable
    def __del__(self) -> None: raise errors.DebugOnlyError()

    @__del__.debug  # type: ignore
    def __del__(self) -> None:
        """Deletes the feature reference and decrements the allocation count."""
        if self.__layer_name is not None: self._dec_alloc(self.__layer_name)
        del self.__feature
        del self.__layer_name

    def __getitem__(self, key: str) -> Any: return self.__feature[key]

    def __setitem__(self, key: str, value: Any) -> NoReturn: self.__feature[key] = value

    def __delitem__(self, key: str) -> NoReturn: del self.__feature[key]

    @functions.debuggable
    def __init__(self, feature: QgsFeature, layer_name: str) -> None: raise errors.DebugOnlyError()

    @__init__.debug  # type: ignore
    def __init__(self, feature: QgsFeature, layer_name: str) -> None:
        self.__feature = feature
        self.__layer_name = layer_name
        for name in dir(self.__feature):
            if not name.startswith('__') and not name.endswith('__') and callable(getattr(self.__feature, name)):
                setattr(self, name, getattr(self.__feature, name))

