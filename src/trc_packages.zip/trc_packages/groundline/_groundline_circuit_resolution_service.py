from PyQt5 import QtCore
from trc_packages.asynclib import TrcService
from trc_packages.groundline import _groundline_circuit_details as gcd
from typing import List, Optional
import os


class GroundlineCircuitResolutionService(TrcService[List['gcd.GroundlineCircuitDetails']]):
    """
    Resolves all circuits available in the database directory of the groundline application.
    """

    db_path: str = None
    validation_messages: List[str] = None

    def __init__(self, db_path: str, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(parent=parent)
        self.db_path = db_path
        self.validation_messages = []

    def _run(self) -> List['gcd.GroundlineCircuitDetails']:
        """Returns all circuits available in the database directory."""
        self.validation_messages.clear()
        results: List[gcd.GroundlineCircuitDetails] = []

        if self.db_path is None:
            self.validation_messages.append('Database path is required.')
        elif not os.path.isdir(self.db_path):
            self.validation_messages.append('Database path must be a directory.')

        if any(self.validation_messages):
            return results

        circuit_name: str
        circuit_ext: str
        for circuit_name in os.listdir(self.db_path):
            circuit_path: str = os.path.join(self.db_path, circuit_name)

            if os.path.isfile(circuit_path):
                circuit_name, circuit_ext = os.path.splitext(circuit_name)
                if circuit_ext == '.mdb':
                    results.append(gcd.GroundlineCircuitDetails(circuit_name=circuit_name,
                                                                circuit_path=self.db_path,
                                                                mdb_file=circuit_path))

        return results
