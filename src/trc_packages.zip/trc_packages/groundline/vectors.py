from trc_packages.core.features import BasicVectorObject, protocols
from typing import Any, Dict, List, Optional, Type, TypeVar, Union, Iterable
from trc_packages.groundline.resistograph import ResistographFileNo
from trc_packages.groundline import datamodels
from trc_packages.groundline import _configuration as conf
from qgis.core import QgsVectorLayer
T = TypeVar('T', bound=protocols.Feature)


class GroundlineVectorObject(BasicVectorObject[T]):
    """A base for all groundline vector objects."""

    _path: str = 'C:\\A_Mapping\\Groundline\\Field\\Audit\\DB'
    @property
    def path(self) -> str:
        return self._path or conf.Configuration().db_path

    @path.setter
    def path(self, value: str) -> None:
        self._path = value

    @path.deleter
    def path(self) -> None:
        del self._path

    _current_circuit: str = 'CECCGndLineField'
    @property
    def current_circuit(self) -> str:
        return self._current_circuit or conf.Configuration().project_name

    @current_circuit.setter
    def current_circuit(self, value: str) -> None:
        self._current_circuit = value

    @current_circuit.deleter
    def current_circuit(self) -> None:
        del self._current_circuit

    layer_group: str = None


class ConductorDisplayStatusVector(GroundlineVectorObject[datamodels.ConductorDisplayStatusFeature]):
    """Represents the lutblConductorDisplayStatus table."""

    feature_object_type: Type[datamodels.ConductorDisplayStatusFeature] = datamodels.ConductorDisplayStatusFeature
    layer_name: str = 'lutblConductorDisplayStatus'
    layer_group: str = 'Support'


class ConductorSizeVector(GroundlineVectorObject[datamodels.ConductorSizeFeature]):
    """Represents the lutblConductorSizes table."""

    feature_object_type: Type[datamodels.ConductorSizeFeature] = datamodels.ConductorSizeFeature
    layer_name: str = 'lutblConductorSizes'
    layer_group: str = 'Support'


class FeederVector(GroundlineVectorObject[datamodels.FeederFeature]):
    """Represents the lutblFeeders table."""

    feature_object_type: Type[datamodels.FeederFeature] = datamodels.FeederFeature
    layer_name: str = 'lutblFeeders'
    layer_group: str = 'Support'


class InspectionLevelVector(GroundlineVectorObject[datamodels.InspectionLevelFeature]):
    """Represents the lutblInspectionLevels table."""

    feature_object_type: Type[datamodels.InspectionLevelFeature] = datamodels.InspectionLevelFeature
    layer_name: str = 'lutblInspectionLevels'
    layer_group: str = 'Support'


class LicenseeAreaVector(GroundlineVectorObject[datamodels.LicenseeAreaFeature]):
    """Represents the lutblLicenseeAreas table."""

    feature_object_type: Type[datamodels.LicenseeAreaFeature] = datamodels.LicenseeAreaFeature
    layer_name: str = 'lutblLicenseeAreas'
    layer_group: str = 'Support'


class NeutralSizeVector(GroundlineVectorObject[datamodels.NeutralSizeFeature]):
    """Represents the lutblNeutralSizes table."""

    feature_object_type: Type[datamodels.NeutralSizeFeature] = datamodels.NeutralSizeFeature
    layer_name: str = 'lutblNeutralSizes'
    layer_group: str = 'Support'


class PadTransformerKvaVector(GroundlineVectorObject[datamodels.PadTransformerKvaFeature]):
    """Represents the lutblPadTransformerKvas table."""

    feature_object_type: Type[datamodels.PadTransformerKvaFeature] = datamodels.PadTransformerKvaFeature
    layer_name: str = 'lutblPadTransformerKvas'
    layer_group: str = 'Support'


class ApplicationVector(GroundlineVectorObject[datamodels.ApplicationFeature]):
    """Represents the lutblPoleApplications table."""

    feature_object_type: Type[datamodels.ApplicationFeature] = datamodels.ApplicationFeature
    layer_name: str = 'lutblPoleApplications'
    layer_group: str = 'Support'


class CapacitorKvarVector(GroundlineVectorObject[datamodels.CapacitorKvarFeature]):
    """Represents the lutblPoleCapacitorKvars table."""

    feature_object_type: Type[datamodels.CapacitorKvarFeature] = datamodels.CapacitorKvarFeature
    layer_name: str = 'lutblPoleCapacitorKvars'
    layer_group: str = 'Support'


class ItemCategoryVector(GroundlineVectorObject[datamodels.ItemCategoryFeature]):
    """Represents the lutblPoleItemCategories table."""

    feature_object_type: Type[datamodels.ItemCategoryFeature] = datamodels.ItemCategoryFeature
    layer_name: str = 'lutblPoleItemCategories'
    layer_group: str = 'Support'


class ItemTypeVector(GroundlineVectorObject[datamodels.ItemTypeFeature]):
    """Represents the lutblPoleItemTypes table."""

    feature_object_type: Type[datamodels.ItemTypeFeature] = datamodels.ItemTypeFeature
    layer_name: str = 'lutblPoleItemTypes'
    layer_group: str = 'Support'


class MaintenanceCodeVector(GroundlineVectorObject[datamodels.MaintenanceCodeFeature]):
    """Represents the lutblMaintCodes table."""

    feature_object_type: Type[datamodels.MaintenanceCodeFeature] = datamodels.MaintenanceCodeFeature
    layer_name: str = 'lutblPoleMaintCodes'
    layer_group: str = 'Support'

    def find(self, filter_, *args, **kwargs) -> Iterable[datamodels.MaintenanceCodeFeature]:
        return sorted(super().find(filter_, *args, **kwargs), key=lambda v: v.sort_order)


class MaterialVector(GroundlineVectorObject[datamodels.MaterialFeature]):
    """Represents the lutblPoleMaterials table."""

    feature_object_type: Type[datamodels.MaterialFeature] = datamodels.MaterialFeature
    layer_name: str = 'lutblPoleMaterials'
    layer_group: str = 'Support'


class OwnerVector(GroundlineVectorObject[datamodels.OwnerFeature]):
    """Represents the lutblPoleOwners table."""

    feature_object_type: Type[datamodels.OwnerFeature] = datamodels.OwnerFeature
    layer_name: str = 'lutblPoleOwners'
    layer_group: str = 'Support'

    def find(self, filter_, *args, **kwargs) -> Iterable[datamodels.OwnerFeature]:
        return sorted(super().find(filter_, *args, **kwargs), key=lambda v: v.sort_order)


class RecloserAmpVector(GroundlineVectorObject[datamodels.RecloserAmpFeature]):
    """Represents the lutblPoleRecloserAmps table."""

    feature_object_type: Type[datamodels.RecloserAmpFeature] = datamodels.RecloserAmpFeature
    layer_name: str = 'lutblPoleRecloserAmps'
    layer_group: str = 'Support'


class RegulatorAmpVector(GroundlineVectorObject[datamodels.RegulatorAmpFeature]):
    """Represents the lutblPoleRegulatorAmps table."""

    feature_object_type: Type[datamodels.RegulatorAmpFeature] = datamodels.RegulatorAmpFeature
    layer_name: str = 'lutblPoleRegulatorAmps'
    layer_group: str = 'Support'


class SwitchAmpVector(GroundlineVectorObject[datamodels.SwitchAmpFeature]):
    """Represents the lutblPoleSwitchAmps table."""

    feature_object_type: Type[datamodels.SwitchAmpFeature] = datamodels.SwitchAmpFeature
    layer_name: str = 'lutblPoleSwitchAmps'
    layer_group: str = 'Support'


class SwitchTypeVector(GroundlineVectorObject[datamodels.SwitchTypeFeature]):
    """Represents the lutblPoleSwitchTypes table."""

    feature_object_type: Type[datamodels.SwitchTypeFeature] = datamodels.SwitchTypeFeature
    layer_name: str = 'lutblPoleSwitchTypes'
    layer_group: str = 'Support'


class TransformerKvaVector(GroundlineVectorObject[datamodels.TransformerKvaFeature]):
    """Represents the lutblPoleTransformerKvas table."""

    feature_object_type: Type[datamodels.TransformerKvaFeature] = datamodels.TransformerKvaFeature
    layer_name: str = 'lutblPoleTransformerKvas'
    layer_group: str = 'Support'


class SubstationVector(GroundlineVectorObject[datamodels.SubstationFeature]):
    """Represents the lutblSubstations table."""

    feature_object_type: Type[datamodels.SubstationFeature] = datamodels.SubstationFeature
    layer_name: str = 'lutblSubstations'
    layer_group: str = 'Support'


class AttachmentVector(GroundlineVectorObject[datamodels.AttachmentFeature]):
    """Represents the tblPoleAttachments table."""

    feature_object_type: Type[datamodels.AttachmentFeature] = datamodels.AttachmentFeature
    layer_name: str = 'tblPoleAttachments'
    layer_group: str = 'Data'


class CapacitorVector(GroundlineVectorObject[datamodels.CapacitorFeature]):
    """Represents the tblPoleCapacitors table."""

    feature_object_type: Type[datamodels.CapacitorFeature] = datamodels.CapacitorFeature
    layer_name: str = 'tblPoleCapacitors'
    layer_group: str = 'Data'


class GuyVector(GroundlineVectorObject[datamodels.GuyFeature]):
    """Represents the tblPoleGuys table."""

    feature_object_type: Type[datamodels.GuyFeature] = datamodels.GuyFeature
    layer_name: str = 'tblPoleGuys'
    layer_group: str = 'Data'


class LightVector(GroundlineVectorObject[datamodels.LightFeature]):
    """Represents the tblPoleLights table."""

    feature_object_type: Type[datamodels.LightFeature] = datamodels.LightFeature
    layer_name: str = 'tblPoleLights'
    layer_group: str = 'Data'


class MaintenanceVector(GroundlineVectorObject[datamodels.MaintenanceFeature]):
    """Represents the tblPoleMaint table."""

    feature_object_type: Type[datamodels.MaintenanceFeature] = datamodels.MaintenanceFeature
    layer_name: str = 'tblPoleMaint'
    layer_group: str = 'Data'

    __next_record_id: Optional[int] = None
    @property
    def _next_record_id(self) -> int:
        if self.__next_record_id is None:
            self.__next_record_id = self.qgs_layer.maximumValue(self.qgs_layer.fields().indexOf('RecordId'))
        self.__next_record_id += 1
        return self.__next_record_id

    @property
    def next_record_id(self) -> int:
        return self._next_record_id

    def new_feature(self, **kwargs: Any) -> datamodels.MaintenanceFeature:
        feature: datamodels.MaintenanceFeature = super().new_feature(**kwargs)
        if feature.record_id is None:
            feature.record_id = self.next_record_id
        return feature


class PictureVector(GroundlineVectorObject[datamodels.PictureFeature]):
    """Represents the tblPolePictures table."""

    feature_object_type: Type[datamodels.PictureFeature] = datamodels.PictureFeature
    layer_name: str = 'tblPolePictures'
    layer_group: str = 'Data'


class RecloserVector(GroundlineVectorObject[datamodels.RecloserFeature]):
    """Represents the tblPoleReclosers table."""

    feature_object_type: Type[datamodels.RecloserFeature] = datamodels.RecloserFeature
    layer_name: str = 'tblPoleReclosers'
    layer_group: str = 'Data'


class RegulatorVector(GroundlineVectorObject[datamodels.RegulatorFeature]):
    """Represents the tblPoleRegulators table."""

    feature_object_type: Type[datamodels.RegulatorFeature] = datamodels.RegulatorFeature
    layer_name: str = 'tblPoleRegulators'
    layer_group: str = 'Data'


class PoleVector(GroundlineVectorObject[datamodels.PoleFeature]):
    """Represents the tblPoles table."""

    feature_object_type: Type[datamodels.PoleFeature] = datamodels.PoleFeature
    layer_name: str = 'tblPoles'
    layer_group: str = 'Data'

    def __init__(self, show_in_ui: bool=False, path: Optional[str]=None, current_circuit: Optional[str]=None,
                 layer_name: Optional[str]=None, base_name: Optional[str]=None, feature_object_type: Optional[Type[datamodels.PoleFeature]]=None,
                 qgs_layer: QgsVectorLayer=None, data_source: Optional[str]=None, field_aliases: Optional[Dict[str, str]]=None,
                 qgs_layer_path: Optional[str]=None, **kwargs: Any) -> None:
        super().__init__(show_in_ui=show_in_ui, path=path, current_circuit=current_circuit, layer_name=layer_name,
                         base_name=base_name, feature_object_type=feature_object_type, qgs_layer=qgs_layer,
                         data_source=data_source, field_aliases=field_aliases, qgs_layer_path=qgs_layer_path,
                         **kwargs)

        if self.qgs_layer:
            field_index: int = self.qgs_layer.fields().indexFromName('shape')
            if field_index > -1:
                # We need to remove the mapping of this field - it only causes issues
                self.qgs_layer.deleteAttribute(field_index)


class ResistographFileVector(GroundlineVectorObject[datamodels.ResistographFileFeature]):
    """Represents the tblResistographFiles table."""

    feature_object_type: Type[datamodels.ResistographFileFeature] = datamodels.ResistographFileFeature
    layer_name: str = 'tblResistographFiles'
    layer_group: str = 'Data'

    def by_file_nos(self, *file_nos: Union[ResistographFileNo, int, str]) -> List[datamodels.ResistographFileFeature]:
        return self.find("ResistographFileNumber IN ({})",
                         [int(ResistographFileNo(f) if isinstance(f, str) else f) for f in file_nos])

    def not_in_file_nos_and_without_file(self, *file_nos: Union[ResistographFileNo, int, str]) -> List[datamodels.ResistographFileFeature]:
        return self.find("ResistographFileNumber NOT IN ({}) AND FileImage IS NULL",
                         [int(ResistographFileNo(f) if isinstance(f, str) else f) for f in file_nos])

    def by_file_no(self, file_no: Union[int, str, ResistographFileNo]) -> Optional[datamodels.ResistographFileFeature]:
        if isinstance(file_no, str):
            file_no = ResistographFileNo(file_no)
        return self.find_any("ResistographFileNumber = {}", int(file_no))

    def by_file_nos_without_file(self, *file_nos: Union[ResistographFileNo, int, str]) -> List[datamodels.ResistographFileFeature]:
        return self.find("ResistographFileNumber IN ({}) AND FileName IS NULL",
                         [int(ResistographFileNo(f) if isinstance(f, str) else f) for f in file_nos])

    def by_file_no_without_file(self, file_no: Union[ResistographFileNo, int, str]) -> Optional[datamodels.ResistographFileFeature]:
        if isinstance(file_no, str):
            file_no = ResistographFileNo(file_no)
        return self.find_any("ResistographFileNumber = {} AND FileName IS NULL", file_no)

    def by_file_name(self, file_name: Union[ResistographFileNo, str]) -> Optional[datamodels.ResistographFileFeature]:
        return self.find_any("NameOfUploadedFile = {}", file_name.file_path if isinstance(file_name, ResistographFileNo) else file_name)

