from trc_packages.core.settings import setting, ProjectSettings
from trc_packages import mrisa

class Configuration(mrisa.Configuration):
    """
    Provides settings for the Groundline application and its associated plugins.
    """

    plugin_name: str = 'mrisa_field.groundline'
    project_year: int = setting[int]('project_year')
    range_start: int = setting[int]('range_start')
    range_end: int = setting[int]('range_end')
    groundline_only: bool = setting[bool]('groundline_only')
