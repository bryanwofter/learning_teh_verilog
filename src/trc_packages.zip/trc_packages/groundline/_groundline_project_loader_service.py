from PyQt5 import QtCore
from qgis import core, utils  # type: ignore
from trc_packages.asynclib import TrcServiceExecutor, step, protocols
from trc_packages.core import first, try_or_get
from trc_packages.core.data.conversions import pgeo_to_sqlite
from trc_packages.groundline import _configuration as conf, vectors
from trc_packages.projects import MdbProjectLoaderServiceABC
from trc_packages.debugging import Debug
from typing import Any, Callable, Dict, List, Optional
import os


class GroundlineProjectLoaderService(MdbProjectLoaderServiceABC[vectors.GroundlineVectorObject, 'conf.Configuration']):
    """
    Provides an MDB project loader for the Groundline project.
    """

    circuit: Optional['gcd.GroundlineCircuitDetails'] = None

    project_year: Optional[int] = None
    range_start: Optional[int] = None
    range_end: Optional[int] = None
    groundline_only: Optional[bool] = None
    post_sqlite_initializer: Optional[Callable[[], None]] = None

    @property
    def project_name(self) -> Optional[str]:
        return None if self.circuit is None else self.circuit.circuit_name

    @property
    def project_path(self) -> Optional[str]:
        return None if self.circuit is None else os.path.join(self.project_root, self.project_name)

    @property
    def db_path(self) -> Optional[str]:
        return None if self.circuit is None else self.circuit.circuit_path

    @property
    def mdb_file(self) -> Optional[str]:
        return None if self.circuit is None else self.circuit.mdb_file

    @property
    def circuit_name(self) -> Optional[str]:
        return None if self.circuit is None else self.circuit.circuit_name

    @property
    def aerial_path(self) -> Optional[str]:
        return self.project_path

    @property
    def aerial_file(self) -> Optional[str]:
        return None if self.circuit is None or self.remote_aerial_root is None else os.path.join(self.aerial_path, f"{self.project_name}_aerial.sid")

    @property
    def remote_aerial_file(self) -> Optional[str]:
        return None if self.circuit is None or self.remote_aerial_root is None else os.path.join(self.remote_aerial_root, f"{self.project_name}_aerial.sid")

    @property
    def config(self) -> 'conf.Configuration':
        return conf.Configuration()

    def __init__(self, project_root: str, master_root: str, layer_data: Dict[str, List[List[Any]]], group_data: Dict[str, List[str]],
                 remote_template_project_root: str, remote_aerial_root: str, parent: Optional[QtCore.QObject]=None) -> None:
        super().__init__(project_root=project_root,
                         master_root=master_root,
                         vector_type=vectors.GroundlineVectorObject,
                         layer_data=layer_data,
                         group_data=group_data,
                         remote_template_project_root=remote_template_project_root,
                         remote_aerial_root=remote_aerial_root,
                         index_definitions=[],
                         spatialite_definitions={'Poles': []},
                         template_project_pole_layer='poles',
                         parent=parent)

    @step
    def _validate_arguments(self) -> bool:
        if self.project_name is None:
            self.validation_messages.append('No project selected.')
        if self.user_name is None:
            self.validation_messages.append('No username entered.')
        if self.project_year is None or self.project_year < 2017:
            self.validation_messages.append('Invalid project year selected.')
        if self.range_start is None or self.range_start not in range(10000, 50000, 10000):
            self.validation_messages.append('Invalid starting polenum.')
        if self.range_end is None or self.range_start is not None and self.range_end != (self.range_start + 9999):
            self.validation_messages.append('Invalid ending polenum.')

        return super()._validate_arguments()

    @step
    def _validate_project(self) -> bool:
        self.valid_project = os.path.isfile(self.project_file)

        if self.valid_project:
            self.yield_until_ran_later(lambda: utils.iface.addProject(self.project_file), attempts=-1)
            self.valid_project = all(l.error().isEmpty() for l in self.project.mapLayers().values() if l.name in self.layer_data)

        return super()._validate_project()

    @step
    def _download_template_project(self) -> bool:
        return super()._download_template_project()

    @step
    def _build_project(self) -> bool:
        template_project_file: Optional[str] = self.template_project_file
        if not self.valid_project:
            if template_project_file is not None and os.path.isfile(template_project_file):
                self.yield_until_ran_later(lambda: utils.iface.addProject(template_project_file), attempts=-1)

            self.config.project_name = self.project_name
            self.config.user_name = self.user_name.upper()
            self.config.project_dir = self.project_path
            self.config.source_db_file = self.mdb_file
            self.config.output_db_file = self.sqlite_file
            self.config.db_path = self.db_path
            self.config.project_year = self.project_year
            self.config.groundline_only = self.groundline_only
            self.config.range_end = self.range_end
            self.config.range_start = self.range_start
            self.yield_until_ran_later(lambda: self.project.setFileName(self.project_file), attempts=-1)
            self.yield_until_ran_later(lambda: core.QgsLayerDefinition.loadLayerDefinition(os.path.join(self.master_root, 'basemap.qlr'), self.project, self.project.layerTreeRoot()),
                                       attempts=-1)
            self.created_project_file = True

            if self.template_project_pole_layer is not None and any(self.project.mapLayersByName(self.template_project_pole_layer)):
                self.yield_until_ran_later(lambda: self.project.removeMapLayer(first(self.project.mapLayersByName(self.template_project_pole_layer))),
                                           attempts=-1)

            self.yield_until_ran_later(self.project.write, attempts=-1)
            self.yield_until_ran_later(lambda: utils.iface.addProject(self.project_file), attempts=-1)

        return super()._build_project()

    @step
    def _build_sqlite(self) -> bool:
        return super()._build_sqlite()

    @step
    def _validate_project_path(self) -> bool:
        return super()._validate_project_path()

    @step
    def _prepare_vector_layers(self) -> bool:
        if self.post_sqlite_initializer is not None:
            self.post_sqlite_initializer()
        return super()._prepare_vector_layers()

    @step
    def _prepare_vector_layer_joins(self) -> bool:
        return super()._prepare_vector_layer_joins()

    @step
    async def _handle_special_layers(self) -> bool:
        step_size: float = self.step_size * 3
        prev_progress: float = self._progress  # type: ignore

        @QtCore.pyqtSlot(float, name='on_executor_progressChanged')
        def __on_progress_changed(progress: float) -> None:
            self._progress = prev_progress + step_size * progress

        executor: TrcServiceExecutor = TrcServiceExecutor(self,
                                                          services=[self._create_spatialite_database,
                                                                    self._download_aerial,
                                                                    self._process_background_gdb],
                                                          total_worker_services=3)

        executor.progress_changed.connect(__on_progress_changed)

        await executor
        self._progress += self.step_size
        return not any(self.validation_messages)

    @step
    def _create_spatialite_database(self, service: protocols.Service[None]) -> None:
        if self.spatialite_file is None:
            return

        self.spatialite_building.emit()

        if os.path.isfile(self.spatialite_file):
            self.spatialite_build_skipped.emit()
        else:
            pgeo_to_sqlite(src=self.mdb_file, dst=self.spatialite_file, new_table_names={'tblpoles': 'Poles'})
            self.spatialite_built[str].emit('Poles')  # type: ignore

        self.spatialite_built.emit()

    @step
    def _download_aerial(self, service: protocols.Service[None]) -> None:
        super()._download_aerial(service)

    @step
    def _process_background_gdb(self, service: protocols.Service[None]) -> None:
        try:
            if self.background_gdb_file is not None and os.path.isdir(self.background_gdb_file):
                self.background_gdb_preparation.emit()

                def _process_background() -> None:
                    self.feeders = [
                        try_or_get(lambda: vectors.GroundlineVectorObject(self.created_project_file, qgs_layer_path=f"{self.background_gdb_file}|layername=CECCPrimaryLines", base_name='Primaries'), None),
                        try_or_get(lambda: vectors.GroundlineVectorObject(self.created_project_file, qgs_layer_path=f"{self.background_gdb_file}|layername=CECCSecondaryLines", base_name='Secondaries'), None),
                        None,
                        None,
                        try_or_get(lambda: vectors.GroundlineVectorObject(self.created_project_file, qgs_layer_path=f"{self.background_gdb_file}|layername=Streets", base_name='Streets'), None)
                    ]
                self.yield_until_ran_later(_process_background)
                self.background_gdb_prepared.emit()
            else:
                self.feeders = [None, None, None, None, None]
        finally:
            service._progress = 1.0

    @step
    def _prepare_feeder_layers(self) -> bool:
        def _prepare_feeders() -> None:
            self.feeders[2] = vectors.GroundlineVectorObject(self.created_project_file or self.created_spatialite_file,
                                                             path=self.project_path,
                                                             circuit_name=self.circuit_name,
                                                             layer_name='Poles',
                                                             base_name='Primaries')
            self.feeders[3] = vectors.GroundlineVectorObject(self.created_project_file or self.created_spatialite_file,
                                                             path=self.project_path,
                                                             circuit_name=self.circuit_name,
                                                             layer_name='Poles',
                                                             base_name='Secondaries')
        self.yield_until_ran_later(_prepare_feeders, attempts=-1)
        super()._prepare_feeder_layers()
        return True

    @step
    def _prepare_pole_layers(self) -> bool:
        return super()._prepare_pole_layers()

    @step
    def _normalize_layer_positions(self) -> bool:
        if self.created_spatialite_file or self.created_project_file:
            # TODO: Why is this failing to bind the columns properly?
            self.yield_until_ran_later(lambda: self.poles.join('poleguid', self.vectors['tblPoles'], 'PoleGUID', included_fields=['PoleNum', 'DisplayStatus'], prefix='pole.'),
                                       attempts=-1)

        return super()._normalize_layer_positions()

    @step
    def _load_layer_styles(self) -> bool:
        self.yield_until_ran_later(lambda: self.poles.load_named_style(os.path.join(self.master_root, 'poles_style.qml')), attempts=-1)

        if self.working_primaries is not None:
            self.yield_until_ran_later(lambda: self.working_primaries.load_named_style(os.path.join(self.master_root, 'working_primaries_style.qml')),
                                       attempts=-1)

        if self.working_secondaries is not None:
            self.yield_until_ran_later(lambda: self.working_secondaries.load_named_style(os.path.join(self.master_root, 'working_secondaries_style.qml')),
                                       attempts=-1)

        if self.primaries is not None:
            self.yield_until_ran_later(lambda: self.primaries.load_named_style(os.path.join(self.master_root, 'client_id_style.qml')), attempts=-1)

        if self.secondaries is not None:
            self.yield_until_ran_later(lambda: self.secondaries.load_named_style(os.path.join(self.master_root, 'pole_num_style.qml')), attempts=-1)

        if self.substations is not None:
            self.yield_until_ran_later(lambda: self.substations.load_named_style(os.path.join(self.master_root, 'streets_style.qml')), attempts=-1)

        return super()._load_layer_styles()

    @step
    def _load_pole_editor_script(self) -> bool:
        pole_editor: core.QgsEditFormConfig = core.QgsEditFormConfig()
        pole_editor.setUiForm(os.path.join(self.master_root, 'pole_edit_dialog.ui'))
        pole_editor.setInitFilePath(os.path.join(self.master_root, 'pole_edit_dialog.py'))
        pole_editor.setInitFunction('main')
        pole_editor.setInitCodeSource(core.QgsEditFormConfig.PythonInitCodeSource.CodeSourceFile)
        self.yield_until_ran_later(lambda: self.poles.qgs_layer.setEditFormConfig(pole_editor), attempts=-1)

        return super()._load_pole_editor_script()

    @step
    def _update_extent(self) -> bool:
        return super()._update_extent()

    @step
    def _finalize_project(self) -> bool:
        def _finalize_project() -> None:
            self.primaries.base_name = 'Client IDs'
            self.secondaries.base_name = 'Pole Num'
        self.yield_until_ran_later(_finalize_project, attempts=-1)
        return super()._finalize_project()

