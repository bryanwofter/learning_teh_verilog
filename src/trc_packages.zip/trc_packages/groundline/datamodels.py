import sqlite3
from trc_packages.core.features.factories import (bool_item, date_item, datetime_item,
                                                 float_item, int_item, str_item, bin_item, ignored_item)
from trc_packages.core.features import (BasicFeatureObject, FeatureItemProvider, FeatureItem, BoolFeatureItem, DateFeatureItem,
                                        DateTimeFeatureItem, FloatFeatureItem, IntFeatureItem, StrFeatureItem, BinaryItem)
from trc_packages.core.features.protocols import IgnoredItem
from trc_packages.groundline import _configuration as conf


class LuFeature(FeatureItemProvider):
    """A base for all tables that represent a type and share the same 3 common features."""
    hash_field: str = 'ID'

    record_id: IntFeatureItem = int_item('ID')
    description: StrFeatureItem = str_item('Description')
    sort_order: IntFeatureItem = int_item('DisplayOrder')


class ConductorDisplayStatusFeature(BasicFeatureObject):
    """Represents a feature in the lutblConductorDisplayStatus table."""

    status: IntFeatureItem = int_item('DisplayStatus')
    conductor_type: StrFeatureItem = str_item('ConductorType')


class ConductorSizeFeature(LuFeature, BasicFeatureObject):
    """Represents a feature in the lutblConductorSizes table."""


class FeederFeature(LuFeature, BasicFeatureObject):
    """Represents a feature in the lutblFeeders table."""

    substation_id: IntFeatureItem = int_item('SubstationID')


class InspectionLevelFeature(BasicFeatureObject):
    """Represents a feature in the lutblInspectionLevels table."""

    level: IntFeatureItem = int_item('InspectionLevel')
    description: StrFeatureItem = str_item('Description')


class LicenseeAreaFeature(LuFeature, BasicFeatureObject):
    """Represents a feature in the lutblLicenseeAreas table."""


class NeutralSizeFeature(LuFeature, BasicFeatureObject):
    """Represents a feature in the lutblNeutralSizes table."""


class PadTransformerKvaFeature(LuFeature, BasicFeatureObject):
    """Represents a feature in the lutblPadTransformerKvas table."""


class ApplicationFeature(LuFeature, BasicFeatureObject):
    """Represents a feature in the lutblPoleApplications table."""


class CapacitorKvarFeature(LuFeature, BasicFeatureObject):
    """Represents a feature in the lutblPoleCapacitorKvars table."""


class ItemCategoryFeature(LuFeature, BasicFeatureObject):
    """Represents a feature in the lutblPoleItemCategories table."""


class ItemTypeFeature(LuFeature, BasicFeatureObject):
    """Represents a feature in the lutblPoleItemTypes table."""

    category_id: IntFeatureItem = int_item('PoleItemCategoryID')


class MaintenanceCodeFeature(BasicFeatureObject):
    """Represents a feature in the luPoleMaintCodes table."""
    hash_field: str = 'PoleMaintCodeId'

    record_id: IntFeatureItem = int_item('PoleMaintCodeId')
    description: StrFeatureItem = str_item('Description')
    sort_order: int = int_item('DisplayOrder')
    code_type: StrFeatureItem = str_item('CodeType')


class MaterialFeature(LuFeature, BasicFeatureObject):
    """Represents a feature in the lutblPoleMaterials table."""


class OwnerFeature(BasicFeatureObject):
    """Represents a feature in the lutblPoleOwners table."""

    record_id: IntFeatureItem = int_item('ID')
    name: StrFeatureItem = str_item('PoleOwner')
    sort_order: IntFeatureItem = int_item('DisplayOrder')


class RecloserAmpFeature(LuFeature, BasicFeatureObject):
    """Represents a feature in the lutblPoleRecloserAmps table."""


class RegulatorAmpFeature(LuFeature, BasicFeatureObject):
    """Represents a feature in the lutblPoleRegulatorAmps table."""


class SwitchAmpFeature(LuFeature, BasicFeatureObject):
    """Represents a feature in the lutblPoleSwitchAmps table."""


class SwitchTypeFeature(LuFeature, BasicFeatureObject):
    """Represents a feature in the lutblPoleSwitchTypes table."""


class TransformerKvaFeature(LuFeature, BasicFeatureObject):
    """Represents a feature in the lutblPoleTransformerKvas table."""


class SubstationFeature(BasicFeatureObject):
    """Represents a feature in the lutblSubstations table."""
    hash_field: str = 'ID'

    record_id: IntFeatureItem = int_item('ID')
    name: StrFeatureItem = str_item('SubstationName')
    sort_order: IntFeatureItem = int_item('DisplayOrder')


class AttachmentFeature(BasicFeatureObject):
    """Represents a feature in the tblPoleAttachments table."""
    hash_field: str = 'ID'

    record_id: IntFeatureItem = int_item('ID')
    pole_guid: StrFeatureItem = str_item('PoleGUID')
    owner_id: IntFeatureItem = int_item('OwnerID')
    licensee_area_id: IntFeatureItem = int_item('LicenseeAreaID')
    is_cable: BoolFeatureItem = bool_item('Cable')
    is_drop: BoolFeatureItem = bool_item('Drop')
    is_pedestal: BoolFeatureItem = bool_item('Pedestal')
    is_pedestal_bond: BoolFeatureItem = bool_item('PedestalBond')
    is_riser: BoolFeatureItem = bool_item('Riser')
    is_guy: BoolFeatureItem = bool_item('Guy')
    is_idle: BoolFeatureItem = bool_item('Idle')


class CapacitorFeature(BasicFeatureObject):
    """Represents a feature in the tblPoleCapacitors table."""
    hash_field: str = 'ID'

    record_id: IntFeatureItem = int_item('ID')
    pole_guid: StrFeatureItem = str_item('PoleGUID')
    capacitor_id: IntFeatureItem = int_item('CapacitorID')
    k_var_id: IntFeatureItem = int_item('KvarID')
    conductor_guid: StrFeatureItem = str_item('ConductorGUID')


class GuyFeature(BasicFeatureObject):
    """Represents a feature in the tblPoleGuys table."""
    hash_field: str = 'ID'

    record_id: IntFeatureItem = int_item('ID')
    pole_guid: StrFeatureItem = str_item('PoleGUID')
    guy_id: IntFeatureItem = int_item('GuyID')


class LightFeature(BasicFeatureObject):
    """Represents a feature in the tblPoleLights table."""
    hash_field: str = 'ID'

    record_id: IntFeatureItem = int_item('ID')
    pole_guid: StrFeatureItem = str_item('PoleGUID')
    light_id: IntFeatureItem = int_item('LightID')


class MaintenanceFeature(BasicFeatureObject):
    """Represents a feature in the tblPoleMaint table."""
    hash_field: str = 'RecordId'

    record_id: IntFeatureItem = int_item('RecordId')
    pole_guid: StrFeatureItem = str_item('PoleGUID')
    code_id: IntFeatureItem = int_item('PoleMaintCodeID')
    was_repaired_in_field: BoolFeatureItem = bool_item('RepairedInField')


class PictureFeature(BasicFeatureObject):
    """Represents a feature in the tblPolePictures table."""
    hash_field: str = 'RecordID'

    record_id: IntFeatureItem = int_item('RecordID')
    pole_guid: StrFeatureItem = str_item('PoleGUID')
    picture_name: StrFeatureItem = str_item('Picture')
    mapping_picture_name: StrFeatureItem = str_item('MappingPicture')
    camera_name: StrFeatureItem = str_item('CameraName')
    camera_owner_name: StrFeatureItem = str_item('CameraOwner')


class RecloserFeature(BasicFeatureObject):
    """Represents a feature in the tblPoleReclosers table."""
    hash_field: str = 'ID'

    record_id: IntFeatureItem = int_item('ID')
    pole_guid: StrFeatureItem = str_item('PoleGUID')
    recloser_id: IntFeatureItem = int_item('RecloserID')
    amp_id: IntFeatureItem = int_item('AmpID')
    is_automatic_reset: BoolFeatureItem = bool_item('AutomaticReset')
    conductor_guid: StrFeatureItem = str_item('ConductorGUID')


class RegulatorFeature(BasicFeatureObject):
    """Represents a feature in the tblPoleRegulators table."""
    hash_field: str = 'ID'

    record_id: IntFeatureItem = int_item('ID')
    pole_guid: StrFeatureItem = str_item('PoleGUID')
    regulator_id: IntFeatureItem = int_item('RegulatorID')
    amp_id: IntFeatureItem = int_item('AmpID')
    conductor_guid: StrFeatureItem = str_item('ConductorGUID')


class PoleFeature(BasicFeatureObject):
    """Rerpresents a feature in the tblPoles table."""
    hash_field: str = 'PoleGUID'

    object_id: IntFeatureItem = int_item('OBJECTID')
    # shape: IgnoredItem = ignored_item('Shape')
    guid: StrFeatureItem = str_item('PoleGUID')
    display_status: StrFeatureItem = str_item('DisplayStatus')
    owner_name: StrFeatureItem = str_item('Owner')
    gps_n: FloatFeatureItem = float_item('GpsN')
    gps_w: FloatFeatureItem = float_item('GpsW')
    sub_meter: FloatFeatureItem = float_item('SubMeter')
    inspection_level: IntFeatureItem = int_item('InspectionLevel')
    inspector: StrFeatureItem = str_item('InspectedBy')
    inspected_on: DateTimeFeatureItem = datetime_item('InspectedDate')
    modification_inspector: StrFeatureItem = str_item('InspectedModifiedBy')
    inspection_modified_on: DateTimeFeatureItem = datetime_item('InspectedModifiedDate')
    birthmark: IntFeatureItem = int_item('Birthmark')
    pole_class: IntFeatureItem = int_item('Class')
    pole_height: FloatFeatureItem = float_item('Height')
    pole_material: StrFeatureItem = str_item('Material')
    application: StrFeatureItem = str_item('Application')
    osmose_year: IntFeatureItem = int_item('OsmoseYear')
    pole_no: IntFeatureItem = int_item('PoleNum')
    map_no: StrFeatureItem = str_item('MapNumber')
    address: StrFeatureItem = str_item('Address')
    directions: StrFeatureItem = str_item('Directions')
    note: StrFeatureItem = str_item('Note')
    first_edit_user: StrFeatureItem = str_item('FirstEditUser')
    first_edited_on: DateTimeFeatureItem = datetime_item('FirstEditDate')
    modification_user: StrFeatureItem = str_item('ModifiedUser')
    modified_on: DateTimeFeatureItem = datetime_item('ModifiedDate')
    pole_tag: IntFeatureItem = int_item('PoleTag')
    tagging_user: StrFeatureItem = str_item('TaggedBy')
    tagged_on: DateTimeFeatureItem = datetime_item('TaggedDate')
    ground_wire_fixed: BoolFeatureItem = bool_item('GndWireFixed')
    ground_wire_fixing_user: StrFeatureItem = str_item('GndWireFixedBy')
    ground_wire_fixed_on: DateTimeFeatureItem = datetime_item('GndWireFixedDate')
    ground_wire_above_reach: BoolFeatureItem = bool_item('GndWireBrokeAboveReach')
    beaver_damage_fixed: BoolFeatureItem = bool_item('BeaverDmgFixed')
    beaver_damage_fixing_user: StrFeatureItem = str_item('BeaverDmgFixedBy')
    beaver_damage_fixed_on: DateTimeFeatureItem = datetime_item('BeaverDmgFixedDate')
    no_of_guy_markers_added: IntFeatureItem = int_item('NumGuyMarkersAdded')
    guy_markers_adding_user: StrFeatureItem = str_item('GuyMarkersAddedBy')
    guy_markers_added_on: DateTimeFeatureItem = datetime_item('GuyMarkersAddedDate')
    pole_top_user: StrFeatureItem = str_item('PoleTopUser')
    pole_top_date: DateTimeFeatureItem = datetime_item('PoleTopDate')
    pad_type: StrFeatureItem = str_item('PadType')
    pad_kva_id: IntFeatureItem = int_item('PadKvaID')
    pad_tag: IntFeatureItem = int_item('PadTag')
    pad_tagging_user: StrFeatureItem = str_item('PadTaggedBy')
    pad_tagged_on: DateTimeFeatureItem = datetime_item('PadTaggedDate')
    meter_location: StrFeatureItem = str_item('MeterLocation')
    meter_line: StrFeatureItem = str_item('MeterLine')
    host_guid: StrFeatureItem = str_item('HostGUID')
    equipment_no: StrFeatureItem = str_item('EquipNumber')
    insp_v: BoolFeatureItem = bool_item('InspV')
    insp_sp: BoolFeatureItem = bool_item('InspSP')
    insp_dt3: BoolFeatureItem = bool_item('InspDT3')
    insp_ew: BoolFeatureItem = bool_item('InspEW')
    insp_edr: BoolFeatureItem = bool_item('InspEDR')
    insp_per: BoolFeatureItem = bool_item('InspPER')
    client_id: StrFeatureItem = str_item('ClientID')


class ResistographFileFeature(BasicFeatureObject):
    """Represents a feature in the tblResistographFiles table."""
    hash_field: str = 'ResistographGUID'

    guid: StrFeatureItem = str_item('ResistographGUID')
    pole_guid: StrFeatureItem = str_item('PoleGUID')
    file_no: IntFeatureItem = int_item('ResistographFileNumber')
    height: FloatFeatureItem = float_item('Height')
    direction: StrFeatureItem = str_item('CompassDirection')
    file_name: StrFeatureItem = str_item('NameOfUploadedFile')
    reading_date: DateFeatureItem = date_item('DateOfReading')
    image: BinaryItem = bin_item('FileImage', table_name='tblResistographFiles', id_name='ResistographGUID',
                                 factory=lambda: sqlite3.connect(conf.Configuration().output_db_file))

