from qgis.utils import iface
from qgis.core import QgsProject
from typing import Any, ClassVar, Dict, List, Generator, Optional, no_type_check
from trc_packages import mrisa, asynclib
from trc_packages.core.data.conversions import copy_mdb_to_sqlite
from trc_packages.groundline import _configuration as conf
import os
from os import path
import shutil

class ProjectLoader(mrisa.ProjectLoader):
    """
    Provides a MRISA-based project loader for the Groundline Application.
    """

    REMOTE_AERIAL_PATH: ClassVar[str] = '\\\\columbus-vfp\\shared\\CLS\\MRISA_Setup\\Apps\\Groundline\\Aerials'
    MASTER_PATH: ClassVar[str] = 'C:\\A_Mapping\\Groundline\\Field\\Audit\\Master'
    BASE_PATH: ClassVar[str] = path.dirname(MASTER_PATH)
    PROJECT_PATH: ClassVar[str] = path.join(BASE_PATH, 'Projects')
    DB_PATH: ClassVar[str] = path.join(BASE_PATH, 'DB')

    project_year: Optional[int] = None
    range_start: Optional[int] = None
    range_end: Optional[int] = None
    groundline_only: Optional[bool] = None

    @property
    def config(self) -> conf.Configuration:
        return conf.Configuration()

    @asynclib.progressive(steps=5, synchronous=True)
    def _progression_valid_arguments(self) -> None:
        if self.project_name is None:
            self.validation_messages.append('No project selected.')
        if self.user_name is None:
            self.validation_messages.append('No username entered.')
        if self.project_year is None or self.project_year < 2017:
            self.validation_messages.append('Invalid project year selected.')
        if self.range_start is None or self.range_start not in range(10000, 50000):
            self.validation_messages.append('Invalid starting polenum.')
        if self.range_end is None or self.range_end != (self.range_start + 9999):  # type: ignore
            self.validation_messages.append('Invalid ending polenum.')

    @asynclib.progressive(steps=1, synchronous=True)
    @no_type_check
    def _progression_project(self) -> None:
        super()._progression_project()
        if self.created_project_file:
            self.config.project_year = self.project_year
            self.config.groundline_only = self.groundline_only
            self.config.range_end = self.range_end
            self.config.range_start = self.range_start

    @no_type_check
    def load_or_create_map(self, layer_data: Dict[str, List[List]], group_data: Dict[str, List[str]]) -> bool:
        self.layer_data = layer_data
        self.group_data = group_data
        self.loading.value = 0
        self.loading.maximum = 100
        self.loading.open()
        for _ in self._load_or_create_map_progression(self.loading.progress):
            pass
        self.loading.close()
        return not any(self.validation_messages)
