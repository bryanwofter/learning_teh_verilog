from typing import Any, List, SupportsInt, Optional
from trc_packages.core import first
from trc_packages.core.safecasts import safe_int, safe_datetime
import os
import datetime


class ResistographFileNo(SupportsInt):
    """Provides a class that wraps a resistograph file name and produces a numeric value from it."""

    file_path: str = None
    file_name: str = None
    initials: Optional[str] = None
    company: str = None
    downloaded_on: datetime.datetime = None
    file_no: int = None

    @property
    def display_name(self) -> str:
        return f"{self.file_no} ({self.file_name})"

    def __init__(self, file_path: str) -> None:
        # Get the file path components for constructing the data of the resistograph file.
        self.file_path = file_path
        self.file_name = os.path.basename(self.file_path)
        file_path_parts: List[str] = first(os.path.splitext(self.file_name)).split('-')

        if 4 == len(file_path_parts):
            self.initials = file_path_parts[0]
            del file_path_parts[0]

        self.company = file_path_parts[0]
        self.downloaded_on = safe_datetime(file_path_parts[1], '%m%d%y')
        self.file_no = safe_int(file_path_parts[2])

    def __int__(self) -> int:
        return self.file_no

    def __str__(self) -> str:
        return self.file_name

    def __hash__(self) -> int:
        return hash(int(self))

    def __eq__(self, other) -> bool:
        left: Any
        right: Any
        if isinstance(other, type(self)) or isinstance(other, int):
            left = int(self)
            right = int(other)
        elif isinstance(other, str):
            left = str(self)
            right = other
        else:
            return NotImplemented
        return left == right

    def __gt__(self, other) -> bool:
        left: Any
        right: Any
        if isinstance(other, type(self)) or isinstance(other, int):
            left = int(self)
            right = int(other)
        elif isinstance(other, type(str)):
            left = str(self)
            right = other
        else:
            return NotImplemented
        return left > right

