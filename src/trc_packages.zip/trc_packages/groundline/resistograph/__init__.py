import trc_packages

if trc_packages.QGIS_EXISTS:
    from trc_packages.groundline.resistograph._resistograph_file_no import ResistographFileNo as ResistographFileNo

