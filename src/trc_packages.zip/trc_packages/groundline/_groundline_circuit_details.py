from typing import Any


class GroundlineCircuitDetails:
    """
    Provides a POD class that represents a circuit and its details within the groundline application.
    """
    circuit_name: str = None
    circuit_path: str = None
    mdb_file: str = None

    def __init__(self, *, circuit_name: str, circuit_path: str, mdb_file: str) -> None:
        self.circuit_name = circuit_name
        self.circuit_path = circuit_path
        self.mdb_file = mdb_file

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, type(self)):
            return self.circuit_name == other.circuit_name
        else:
            return NotImplemented

    def __gt5__(self, other: Any) -> bool:
        if isinstance(other, type(self)):
            return self.circuit_name > other.circuit_name
        else:
            return NotImplemented

    def __hash__(self) -> int:
        return hash(self.circuit_name)

